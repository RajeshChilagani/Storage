// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANDelegates.h"
#include "ANEnums.h"

#include "ANWorldNavRoom.generated.h"

class UBillboardComponent;
class UBoxComponent;
class USceneComponent;

class AANSecondaryAINavRoom;
class ARoom;

UCLASS(BlueprintType, Blueprintable)
class UNDERWATER_API AANWorldNavRoom : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANWorldNavRoom();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void Destroyed() override;


#if WITH_EDITOR
//Editor Functions
public:
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent);
#endif 

protected:
	//The root component for this object
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* RoomSceneRoot;

	//Billboard component for object visibility
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBillboardComponent* BillboardComponent;

	//Box collider of the room bounds
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBoxComponent* RoomBounds;

//WorldNavRoom
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	EANLevels ResidingLevel;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	int32 RoomFloor;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	FName RoomName;

	/**Indicates if the player is currently in this room */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Room")
	bool bIsPlayerInRoom;

public:
	UFUNCTION(BlueprintCallable)
	FVector GetRoomExtents();

	UFUNCTION(BlueprintCallable)
	void SetRoomExtents(FVector Extent);
	
	FVector GetRoomLocation();
	
	UFUNCTION()
	void OnRoomBeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnRoomEndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

public:
	UPROPERTY(BlueprintAssignable)
	FOnWorldNavRoomStateChanged OnNavRoomStateChanged;
public:
	void CleanupBeforeDestroyed();

	//Secondary AI
	UPROPERTY(VisibleAnywhere, Category = "Secondary AI")
	AANSecondaryAINavRoom* SecondaryAINavRoom;

	UFUNCTION(BlueprintCallable, Category = "Secondary AI")
	AANSecondaryAINavRoom* GetSecondaryAINavRoom() { return SecondaryAINavRoom; }

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Secondary AI")
	bool bAddSecondaryAINavRoom;

	//Persistent AI
	UPROPERTY(VisibleAnywhere, Category = "Secondary AI")
	ARoom* PersistentAINavRoom;

	UFUNCTION(BlueprintCallable, Category = "Secondary AI")
	ARoom* GetPersistentAINavRoom() { return PersistentAINavRoom; }

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Secondary AI")
	bool bAddPersistentAINavRoom;
private:
};
