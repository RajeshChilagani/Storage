// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Interface/ANPowerable.h"

#include "ANPowerableDestructible.generated.h"

class USceneComponent;
class UStaticMeshComponent;

UCLASS()
class UNDERWATER_API AANPowerableDestructible : public AActor, public IANPowerable
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	// Sets default values for this actor's properties
	AANPowerableDestructible();

	virtual void BeginPlay() override;


//Components
public:
	//The scene root
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	USceneComponent* SceneRoot;

	//The object mesh
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UStaticMeshComponent* ObjectMesh;


//Powerable Variables
protected:
	//Is this object powered on?
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	bool bPoweredOn;

	//The name of this powerable object
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	FText PowerableName;

//Powerable Functions
public:
	virtual void BP_PowerOn_Implementation() override;
	virtual void BP_PowerOff_Implementation() override;
	virtual bool BP_IsPoweredOn_Implementation() override;
	virtual FText BP_GetPowerableName_Implementation() override;
};
