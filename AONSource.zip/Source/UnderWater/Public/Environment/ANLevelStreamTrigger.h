// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANEnums.h"

#include "ANLevelStreamTrigger.generated.h"

class AExponentialHeightFog;
class APostProcessVolume;
class ASkyLight;
class UBoxComponent;

UCLASS()
class UNDERWATER_API AANLevelStreamTrigger : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANLevelStreamTrigger();


//Components
public:
	//The trigger box itself
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UBoxComponent* TriggerBox;


//Customizable Variables
public:
	//If we load a level when hitting this trigger
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bLoadLevel;

	//The level we want to load when entering this trigger
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults", meta = (EditCondition = "bLoadLevel"))
	EANLevels LevelToLoad;

	//If we unload a level when hitting this trigger
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bUnloadLevel;

	//The level we want to unload when entering this trigger
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults", meta = (EditCondition = "bUnloadLevel"))
	EANLevels LevelToUnload;

	//The post process volume used for the transition levels
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	APostProcessVolume* TransitionPostProcessVolume;

	//The fog we use for the transition levels
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	AExponentialHeightFog* TransitionFog;

	//The skylight we use for the transition levels
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	ASkyLight* SkyLight;


//Gameplay Variables
protected:
	bool bLoadingLevels;


//Gameplay Functions
protected:
	//Overlap Begin
	UFUNCTION()
	virtual void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION(BlueprintCallable)
	void SetupLoadLevel();

	UFUNCTION(BlueprintCallable)
	void LoadLevel();

	//Code called when we load any level
	UFUNCTION(BlueprintImplementableEvent)
	void BP_LoadLevel();

	UFUNCTION(BlueprintCallable)
	void UnloadLevel();

	//Code called when we unload any level
	UFUNCTION(BlueprintImplementableEvent)
	void BP_UnloadLevel();
};
