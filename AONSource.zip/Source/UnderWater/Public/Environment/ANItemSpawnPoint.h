// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Interface/ANSaveable.h"

#include "ANItemSpawnPoint.generated.h"

class UChildActorComponent;
class USceneComponent;

class AANPickableItem;

UCLASS()
class UNDERWATER_API AANItemSpawnPoint : public AActor, public IANSaveable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	// Sets default values for this actor's properties
	AANItemSpawnPoint();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;


//Components
public:
	//The root of the spawn point
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* ItemSpawnPointRoot;

	//The pickable item to put here
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Components")
	UChildActorComponent* CA_PickableItem;


//Gameplay Variables
protected:
	//If there is an item in this spawn point right now
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Gameplay")
	bool bFilled;

//Gameplay Functions
public:
	//Picks up the associated pickable item
	UFUNCTION(BlueprintCallable)
	void PickUpItem(AANPickableItem* PickableItem);


//Getters and Setters
public:
	//If there is an item in this spawn point right now
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsFilled() const { return bFilled; };


//Saveable Variables
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Saveable")
	FGuid SaveableGuid;
	
//Saveable Functions
public:
	virtual FGuid BP_GetSaveableGuid_Implementation() override;
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_SaveObject_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
