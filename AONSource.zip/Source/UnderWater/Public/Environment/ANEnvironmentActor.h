// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANEnvironmentActor.generated.h"

UCLASS()
class UNDERWATER_API AANEnvironmentActor : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANEnvironmentActor();

	virtual void BeginPlay() override;


//Components
public:
	//The root of the actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* EnvironmentRoot;


//Gameplay Functions
public:
	//Plays an environment event
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void PlayEnvironmentEvent();
	virtual void PlayEnvironmentEvent_Implementation();

};
