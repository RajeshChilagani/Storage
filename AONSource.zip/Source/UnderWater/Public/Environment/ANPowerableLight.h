// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Interface/ANPowerable.h"

#include "ANPowerableLight.generated.h"

UCLASS()
class UNDERWATER_API AANPowerableLight : public AActor, public IANPowerable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	// Sets default values for this actor's properties
	AANPowerableLight();

	virtual void BeginPlay() override;


//Custom Variables
public:
	//The intensity level of the light when it's on
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Default")
	float LightOnIntensity;

	//The intensity level of the light when it's on
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Default")
	float LightOffIntensity;

	//The color of the light when it's on
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Default")
	FLinearColor LightOnColor;

	//The color of the light when it's off
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Default")
	FLinearColor LightOffColor;


//Powerable Variables
protected:
	//Is this object powered on?
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	bool bPoweredOn;

	//The name of this powerable object
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	FText PowerableName;

//Powerable Functions
public:
	virtual void BP_PowerOn_Implementation() override;
	virtual void BP_PowerOff_Implementation() override;
	virtual bool BP_IsPoweredOn_Implementation() override;
	virtual FText BP_GetPowerableName_Implementation() override;
};
