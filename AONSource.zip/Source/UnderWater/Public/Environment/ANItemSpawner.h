// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"

#include "Interface/ANPowerable.h"

#include "ANItemSpawner.generated.h"

class UANDialogueConversation;

UENUM(BlueprintType)
enum class EItemToSpawn :uint8 
{
	 Explosive,
	 Projectile,
};

UCLASS()
class UNDERWATER_API AANItemSpawner : public AANPuzzleInteractable, public IANPowerable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANItemSpawner();

	virtual void BeginPlay() override;
	virtual void Tick(float deltaTime) override;


//Components
public:
	//The spawn point scene component
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* ItemSpawnPointSceneComponent;

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> ItemSpawnedDialogueConversation;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> ItemSpawnBeganDialogueConversation;
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> InCoolDownDialogueConversation;

//Customizable Functions
protected:
	//The item to spawn with this spawner
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSubclassOf<AANPickableItem> PickableItemToSpawn;

	//The time it takes to spawn this item in seconds
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (ClampMin = "0.1"))
	float ItemSpawnTimeSeconds;

	//The time it takes to be able to generate items again from this spawner after it generates
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (ClampMin = "0.1"))
	float CoolDownTimeSeconds = 10.f;

	//The maximum number of possible times this spawner can generate items
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	uint8 MaxPossibleSpawns = 10; 

	//If this is powered on at the start
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	bool bPoweredOnAtStart;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	EItemToSpawn ItemType;

//Gameplay Variables
protected:
	//If the item has been spawned and is ready to be picked up
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	bool bItemReady;

	//The number of spawns we have left
	UPROPERTY(Transient, BlueprintReadOnly, Category = "Defaults")
	uint8 NumRemainingSpawns = 10;

	//Timer handles for spawning items
	static FTimerHandle SpawnExplosiveItemTimerHandle;
	static FTimerHandle SpawnProjectileItemTimerHandle;
	FTimerHandle CoolDownTimerHandle;

//Gameplay Functions
protected:
	//Spawns the item
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SpawnItem();

	//Called when an item is spawned. Blueprint functionality.
	UFUNCTION(BlueprintImplementableEvent, Category = "Gameplay")
	void BP_SpawnedItem();

	//Called when the item that was spawned is picked up
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void OnItemPickedUp(AANPickableItem* PickedUpPickableItem);

	//Called when an item is spawned. Blueprint functionality.
	UFUNCTION(BlueprintImplementableEvent, Category = "Gameplay")
	void BP_OnItemPicked();

	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void OnCoolDownCompleted();

	UFUNCTION(BlueprintImplementableEvent, Category = "Gameplay")
	void BP_OnCoolDownCompleted();


//Interactable Functions
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;


//Powerable Variables
protected:
	//Is this object powered on?
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Powerable")
	bool bPoweredOn;

	//The name of this powerable object
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	FText PowerableName;

//Powerable Functions
public:
	virtual void BP_PowerOn_Implementation() override;
	virtual void BP_PowerOff_Implementation() override;
	virtual bool BP_IsPoweredOn_Implementation() override;
	virtual FText BP_GetPowerableName_Implementation() override;
};
