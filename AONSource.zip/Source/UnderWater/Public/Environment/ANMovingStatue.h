// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANMovingStatue.generated.h"

UCLASS()
class UNDERWATER_API AANMovingStatue : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANMovingStatue();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Gameplay Functions
public:
	//Updates the state of the statue to a specified level
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Statue")
	void BP_UpdateState(int32 StateLevel, bool bInstantUpdate);

};
