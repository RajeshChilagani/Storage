// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Interface/ANInteractable.h"
#include "Interface/ANPowerable.h"

#include "ANOpeningDoor.generated.h"

class UBoxComponent;
class USceneComponent;
class UStaticMeshComponent;
class UTextRenderComponent;

UCLASS()
class UNDERWATER_API AANOpeningDoor : public AActor, public IANInteractable, public IANPowerable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANOpeningDoor();
	
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Components
public:
	//The scene root
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	USceneComponent* SceneRoot;

	//The door mesh
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UStaticMeshComponent* DoorMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UBoxComponent* DoorRangeBoxComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UBoxComponent* CustomDepthBounds;

//Customizable Variables
public:
	//The location of the door where it goes to when it closes. (Relative position)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	FVector ClosePosition;

	//The location of the door where it goes to when it opens. (Relative position)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	FVector OpenPosition;

	//The time it takes for the door to open/close.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	float MoveTime;

	//If this door is locked by default at the start
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	bool bLockedAtStart;

	//Is this object powered on?
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	bool bPoweredOnAtStart;

	//If the door is stuck. If this is true, this door cannot open.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	bool bStuck;


//Gameplay Variables
public:

protected:
	//If the door has been initialized.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bInitialized;

	//If the door is open. Usually false by default.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bOpen;

	//If the door is moving (aka, when the door is opening or closing).
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bMoving;

	//The current time for opening/closing the door
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float CurrentMoveTime;

	//If the door is locked. May or may not be locked by default.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bLocked;


//Gameplay Functions
public:
	//Opens the door
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void OpenDoor();

	//Called when we fail to open the door
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void FailOpenDoor();

	//Closes the door
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void CloseDoor();

	//Locks the door
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void LockDoor();

	//Unlocks the door
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void UnlockDoor();


//Getters and Setters
public:
	//Returns whether or not this door is initialized
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsInitialized() const { return bInitialized; }

	//Sets the initialized state
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetInitialized(bool bNewInitialized) { bInitialized = bNewInitialized; };

	//Returns whether or not this door is open
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsOpen() const { return bOpen; }

	//Returns whether or not this door is locked
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsLocked() const { return bLocked; }

	//Returns whether or not we can open this door right now
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	bool CanOpen() const;


//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	//Special interact function for the baddy to open doors (if they can be opened)
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual void BaddyInteract();
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;


//Powerable Variables
protected:
	//Is this object powered on?
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	bool bPoweredOn;

	//The name of the powerable object
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	FText PowerableName;

//Powerable Functions
public:
	virtual void BP_PowerOn_Implementation() override;
	virtual void BP_PowerOff_Implementation() override;
	virtual bool BP_IsPoweredOn_Implementation() override;
	virtual FText BP_GetPowerableName_Implementation() override;

//CustomDepthBounds - CDB
public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthEnabled();

	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthDisabled();

private:
	UFUNCTION()
	void OnCDBBeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnCDBEndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
};
