// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANEnums.h"

#include "ANMapRoom.generated.h"

class UBillboardComponent;
class UBoxComponent;
class USceneComponent;

UCLASS()
class UNDERWATER_API AANMapRoom : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANMapRoom();

	virtual void BeginPlay() override;


//Components
protected:
	//The root component for this object
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	USceneComponent* RoomSceneRoot;

	//Billboard component for object visibility
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBillboardComponent* BillboardComponent;

	//Box collider of the room bounds
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UBoxComponent* RoomBoxCollider;


//Customizable Variables
public:
	//The map/level this map room is in
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	EANLevels ResidingLevel;

	//The floor of this map room
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	int32 RoomFloor;

	//This map room's name; should match a name found in the TMap in the function library
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Room")
	FName RoomName;


//Gameplay Functions
protected:
	UFUNCTION()
	void OnRoomBeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnRoomEndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

};
