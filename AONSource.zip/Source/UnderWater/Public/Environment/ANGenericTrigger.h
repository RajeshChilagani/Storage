// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANDelegates.h"

#include "Interface/ANSaveable.h"

#include "ANGenericTrigger.generated.h"

class UAkAudioEvent;
class UAkComponent;
class UBoxComponent;

class UANCondition;
class UANDialogueConversation;

UCLASS()
class UNDERWATER_API AANGenericTrigger : public AActor, public IANSaveable
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANGenericTrigger();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;


//Components
public:
	//The trigger box itself
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UBoxComponent* TriggerBox;

	//The Ak Component for playing SFX (not dialogue)
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UAkComponent* SFXAkComponent;


//Delegates
public:
	//Delegate for when this generic trigger is triggered
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnGenericTriggerTriggered OnGenericTriggerTriggered;


//Customizable Variables
public:
	//Whether or not entering this trigger box again after having been played will try to call the trigger event again
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bRepeatable;

	//Classes that can trigger this event. Child classes will also trigger.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TArray<UClass*> TriggerableClasses;

	//A condition that must be met if it is set for this trigger to play
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TSubclassOf<UANCondition> ConditionToVerifySubclass;

	//Audio event to play on enter
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	UAkAudioEvent* AudioEventToPlay;

	//The dialogue conversation that will play when we hit this box collider. Will not play anything if not set.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> DialogueConversation;


//Gameplay Variables
protected:
	//Whether or not we have played the dialogue from this trigger box
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bPlayed;

//Gameplay Functions
protected:
	//Overlap Begin
	UFUNCTION()
	virtual void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	//Plays the SFX associated with this trigger
	UFUNCTION()
	void PlaySFX(AActor* OverlappedActor);

	//Plays the dialogue associated with this trigger
	UFUNCTION()
	void PlayDialogue(AActor* OverlappedActor);

	//Plays the trigger event. Called when OnOverlapBegin and other conditions are valid.
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void PlayTriggerEvent(AActor* OverlappedActor);
	virtual void PlayTriggerEvent_Implementation(AActor* OverlappedActor);

	//If this trigger should play when we enter the trigger and all other conditions are valid
	UFUNCTION(BlueprintNativeEvent, Category = "Gameplay")
	bool ShouldPlayTrigger(AActor* OverlappedActor) const;
	virtual bool ShouldPlayTrigger_Implementation(AActor* OverlappedActor) const;

	//Destroys this trigger if it is unplayable on load
	UFUNCTION()
	virtual void DestroyUnplayableTriggerOnLoad();


//Saveable Variables
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Saveable")
	FGuid SaveableGuid;

//Saveable Interface
public:
	virtual FGuid BP_GetSaveableGuid_Implementation() override;
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_SaveObject_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
