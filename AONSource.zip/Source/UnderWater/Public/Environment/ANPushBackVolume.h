// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"

#include "GameFramework/Actor.h"

#include "ANPushBackVolume.generated.h"

class UArrowComponent;
class UBoxComponent;
class UParticleSystemComponent;
class UPrimitiveComponent;
class UStaticMeshComponent;

class AANMainCharacter;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPushBackVolume : public AActor
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANPushBackVolume();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Components
public:
	//The root scene component
	UPROPERTY(EditAnywhere, Category = "Components")
	USceneComponent* RootSceneComponent;

	//The box collider for handling overlaps
	UPROPERTY(EditAnywhere, Category = "Components")
	UBoxComponent* BoxCollider;

	//The bubble VFX
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Components")
	UParticleSystemComponent* BubbleVFX;

	//Arrow component to show which direction the object is pointing
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Components")
	UArrowComponent* ArrowComponent;
	

//Gameplay Variables.
public:
	//Amount of distance per second that the player is pushed back
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	float PushSpeed;

protected:
	//A list of overlapped actors to push back
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Pushback")
	TArray<AActor*> OverlappedActors;

//Gameplay Functions
public:
	UFUNCTION()
	virtual void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	UFUNCTION()
	virtual void OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	//Checks if we can pushback an actor
	UFUNCTION(BlueprintPure, Category = "Pushback")
	bool CanPushBackActor(AActor* OtherActor);

	//Pushes back an actor
	UFUNCTION(BlueprintCallable, Category = "Pushback")
	void PushBackActor(AActor* OtherActor, float DeltaTime);
};
