// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Environment/ANLevelStreamTrigger.h"
#include "ANTeleportLevelStreamTrigger.generated.h"

class APlayerStart;

class AANMainCharacter;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANTeleportLevelStreamTrigger : public AANLevelStreamTrigger
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANTeleportLevelStreamTrigger();


//Customizable Variables
protected:
	//The time it takes before the level streaming begins
	UPROPERTY(EditDefaultsOnly, Category = "Level Streaming")
	float QueueLevelStreamingTime;

	//The destination we will teleport to
	UPROPERTY(EditInstanceOnly, Category = "Level Streaming")
	APlayerStart* TeleportDestination;

	//The level stream trigger that we will disable when activating this
	UPROPERTY(EditInstanceOnly, Category = "Level Streaming")
	AANTeleportLevelStreamTrigger* DisableTeleportLevelStreamTrigger;


//Gameplay Variables
protected:
	FTimerHandle QueueLevelStreamingHandle;

	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	bool bEnabled;

//Gameplay Functions
public:
	virtual void OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) override;

	//Does the level streaming logic
	UFUNCTION()
	void DoLevelStreaming(AANMainCharacter* MainCharacter);

	//Sets the enabled status
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetEnabled(bool bNewEnabled) { bEnabled = bNewEnabled; };
};
