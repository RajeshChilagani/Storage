// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Info.h"
#include "ANEnums.h"
#include "ANWorldNavRoomManager.generated.h"

class AANWorldNavRoom;

UCLASS(BlueprintType, Blueprintable)
class UNDERWATER_API AANWorldNavRoomManager : public AInfo
{
	GENERATED_BODY()
	

//Unreal Functions
public:	
	AANWorldNavRoomManager();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void Destroyed();


//Editor Variables
public:
	UPROPERTY(EditAnywhere, Category = "SpawnRoom")
	FVector DefaultRoomExtents;

	UPROPERTY(EditAnywhere, Category = "SpawnRoom")
	FName SpawningRoomName;

	UPROPERTY(EditAnywhere, Category = "SpawnRoom")
	TSubclassOf<AANWorldNavRoom> EditorRoomToSpawn;

#if WITH_EDITOR
//Editor Functions
public:
	UFUNCTION(CallInEditor, Category = "SpawnRoom")
	void CreateNewRoomFromEditor();
#endif


//Customizable Variables
public:
	UPROPERTY(EditAnywhere)
	bool bShowDebugDraw = false;


//Gameplay Variables
public:
	UPROPERTY(BlueprintReadOnly)
	AANWorldNavRoom* CurrentRoomWithPlayer;

	UPROPERTY(BlueprintReadOnly)
	AANWorldNavRoom* LastRoomWithPlayer;

	UPROPERTY(BlueprintReadOnly)
	EANLevels CurrentLevelPlayerIn;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	TMap<FName, AANWorldNavRoom*> WorldNavRoomMap;

//Gameplay Functions
public:
	UFUNCTION()
	bool IsValidRoomName(const FName& RoomName);

	UFUNCTION(BlueprintCallable)
	void CreateNewRoom(const FName& RoomName, const FVector& RoomExtents, TSubclassOf<AANWorldNavRoom> RoomToSpawn);

	UFUNCTION()
	void UpdateCurrentRoomStatus(AANWorldNavRoom* NavRoom, bool ActiveState);

	UFUNCTION(BlueprintCallable)
	AANWorldNavRoom* GetCurrentRoom() { return CurrentRoomWithPlayer; }

	UFUNCTION(BlueprintCallable)
	EANLevels GetCurrentLevel() { return CurrentLevelPlayerIn; }

	UFUNCTION(BlueprintCallable)
	AANWorldNavRoom* GetLastRoom() { return LastRoomWithPlayer; }

	UFUNCTION(BlueprintCallable)
	AANWorldNavRoom* GetNavRoomFromName(const FString Name);

	UFUNCTION(BlueprintCallable)
	void RemoveWorldNavRoom(FName RoomName);

private:
	void DrawDebugRoomsInGame();

	void CleanUpBeforeDestroyed();

};
