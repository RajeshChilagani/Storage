// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interface/ANInteractable.h"
#include "ANInspectable.generated.h"

class UANHUDWidgetBase;

/** 
An Interactable Item that can be Inspected.
The Item contains a static mesh which can be inspected using the provided InspectActions
*/
UCLASS()
class UNDERWATER_API AANInspectable : public AActor, public IANInteractable
{
	GENERATED_BODY()
	
public:	
	AANInspectable();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Interaction", meta = (ClampMin = "1.0", ClampMax = "25.0"))
	float MeshRotationSpeed;

	/**The Speed at which the camera zooms when zooming on mesh */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Interaction", meta = (ClampMin = "1.0", ClampMax = "10.0"))
	float ZoomSpeed;
	
	/**Min possible FOV for zooming. Zooming stops after this value */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Interaction", meta = (ClampMin = "15.0", ClampMax = "30"))
	float MinFOVClamp;
	
	/**Max possible FOV for zooming. Zooming stops after this value */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Interaction", meta = (ClampMin = "90.0", ClampMax = "135"))
	float MaxFOVClamp;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	bool bInventoryItem;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FVector SpawnLocation;

	//The inspectable HUD widget to spawn and show
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSubclassOf<UANHUDWidgetBase> InspectableHUDWidgetClass;

protected:
	//Adds the inspectable HUD as the next HUD
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Puzzle")
	void BP_AddInspectableHUD(AANPlayerControllerBase* PlayerController);

	//Removes the inspectable HUD from the HUD list
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Puzzle")
	void BP_RemoveInspectableHUD(AANPlayerControllerBase* PlayerController);

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class USceneComponent* SceneComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class UCameraComponent* CameraComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class USpotLightComponent* SpotLightComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class UStaticMeshComponent* MainMeshComponent;

	//The spawned instance of the inspectable HUD widget
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	UANHUDWidgetBase* InspectableHUDWidget;

	//If the inventory was open when we started inspecting this object
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	bool bWasInventoryOpen;

public:
	void Inspect(float AxisValue, EInspectAction AxisDirection);

/** Interactable Interface */
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	bool bInteracting;

	/** The character interacting with this object right now */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	class AANCharacterBase* LongInteractingCharacter;

};
