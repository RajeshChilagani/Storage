// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANDelegates.h"
#include "Interface/ANInteractable.h"

#include "ANPickableItem.generated.h"

class UAkAudioEvent;

class UANDialogueConversation;

UCLASS()
class UNDERWATER_API AANPickableItem : public AActor, public IANInteractable
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANPickableItem();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Components
public:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PickableItem")
	class USceneComponent* SceneComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PickableItem")
	class UStaticMeshComponent* MainMeshComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	class UBoxComponent* CustomDepthBounds;


//Delegates
public:
	//Delegate for when the item is picked up. This is mainly for notifying the item spawn point that the item has been picked up.
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnItemPickedUp OnItemPickedUp;


//Customizable Variables
public:	
	//The item name for this pickable item. This should match an item name in the data table.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	FString ItemName;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	int32 Count = 1;

	//The dialogue conversation to play when the item is picked up. Will not play if empty.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	UANDialogueConversation* PickedUpItemDialogueConversation;


//Gameplay Functions
public:
	//If we should play dialogue when picking up this item. Will not be called if the dialogue conversation is null.
	UFUNCTION(BlueprintNativeEvent, BlueprintPure, Category = "Gameplay")
	bool ShouldPlayDialogue() const;

protected:
	virtual void AddItemToInventory(class UANInventorySystem* IS);


//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;

//CustomDepthBounds - CDB
public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthEnabled();

	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthDisabled();

private:
	//CustomDepth
	UFUNCTION()
	void OnCDBBeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnCDBEndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
};
