// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "ANCondition.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANCondition : public UObject
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANCondition();

//Gameplay Functions
public:
	//Checks if this condition meets the conditions
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	bool MeetsConditions(AActor* CheckActor);
};
