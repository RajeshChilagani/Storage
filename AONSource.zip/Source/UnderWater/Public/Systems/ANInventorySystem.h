// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "ANDelegates.h"
#include "ANEnums.h"
#include "ANStructs.h"

#include "ANInventorySystem.generated.h"

class UDataTable;

/**
 * An Inventory system to store all items in game.
 */
UCLASS(BlueprintType)
class UNDERWATER_API UANInventorySystem : public UObject
{
	GENERATED_BODY()

//Unreal Engine Functions
public:
	UANInventorySystem();

	~UANInventorySystem();


//Variables
protected:
	UPROPERTY(BlueprintReadOnly, Category = "Inventory")
	TMap<FString, int32> m_Items;

	UPROPERTY(BlueprintReadOnly)
	UDataTable* m_ItemDataTable;


//Delegates
public:
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnItemAdded OnItemAdded;

	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnItemRemoved OnItemRemoved;


//Functions
public:
	//Adds an item to the inventory
	UFUNCTION(BlueprintCallable)
	void AddItem(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod);

	//Removes an item from the inventory
	UFUNCTION(BlueprintCallable)
	void RemoveItem(const FString& ItemName, int32 Count);

	//Uses an item from the inventory
	UFUNCTION(BlueprintCallable)
	void UseItem(const FString& ItemName, int32 Count);

	//Checks to see if there is an item in the inventory
	UFUNCTION(BlueprintPure)
	bool HasItem(const FString& ItemName);

	//Gets the number that the player has of this item
	UFUNCTION(BlueprintPure)
	int32 GetNumOfItem(const FString& ItemName);

	//Searches the inventory with the search string and returns all items names that contain provided search string.
	UFUNCTION(BlueprintCallable)
	void SearchInventory(const FString& SearchString, TArray<FString>& Out_Items);

	//Gets the item data from the data table
	FANItem* GetItemDataFromTable(const FString& ItemName);

	//Gets a copy of the item data from the data table. Used for accessing item data in blueprints.
	UFUNCTION(BlueprintCallable)
	FANItem BP_GetItemDataFromTable(const FString& ItemName);

protected:
	//Tries to auto craft an item from a material item
	void TryAutoCraft(const FANItem* MaterialItem);

	//Loads the item data table
	UFUNCTION()
	void LoadItemDataTable();


public:
	//Checks if this is a valid item in the data table
	bool IsAValidItem(const FString& ItemName);

	//Gets a constant reference of the items map
	const TMap<FString, int32>& GetItemsMap() const { return m_Items; };
	
};
