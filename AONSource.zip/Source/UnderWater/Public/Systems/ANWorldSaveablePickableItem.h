// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Systems/ANPickableItem.h"
#include "Interface/ANWorldSaveable.h"

#include "ANStructs.h"

#include "ANWorldSaveablePickableItem.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANWorldSaveablePickableItem : public AANPickableItem, public IANWorldSaveable
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	// Sets default values for this actor's properties
	AANWorldSaveablePickableItem();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Gameplay Functions
protected:
	virtual void AddItemToInventory(class UANInventorySystem* IS) override;


//WorldSaveable Variables
protected:
	//The Guid for saving this world saveable
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "World Saveable")
	FGuid WorldSaveableGuid;

//WorldSaveable Functions
public:
	virtual void BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign) override;
	virtual bool BP_CanSaveToWorldSaveablesMap_Implementation() override;
	virtual void BP_UpdateWorldSaveableState_Implementation() override;
	virtual FGuid BP_GetWorldSaveableGuid_Implementation() override;
	virtual FWorldSaveableData BP_GetWorldSaveableData_Implementation() override;
	virtual FString BP_ConstructSaveableParamsString_Implementation() override;

};
