// Fill out your copyright notice in the Description page of Project Settings.
#pragma once

#include "CoreMinimal.h"

#include "ANEnums.h"

#include "ANCraftingSystem.generated.h"

class UANInventorySystem;
struct FANItem;

/**
* Represents a craftable inventory item.
*/
USTRUCT(BlueprintType)
struct FCraftableItem
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnyWhere, BlueprintReadOnly)
	bool bIsReadyToCraft;

	FANItem* CraftableItemData;

	FCraftableItem() = default;
	
	FCraftableItem(FANItem* ItemData);
};

/**
 * The Crafting system manages & crafts all craftables.
 */
UCLASS(BlueprintType)
class UNDERWATER_API UANCraftingSystem : public UObject
{
	GENERATED_BODY()
public:
	UANCraftingSystem();

	~UANCraftingSystem();
	
	bool Init(UANInventorySystem* InventorySystem);
	
	/*Updates the crafting status for each craftable item*/
	UFUNCTION(BlueprintCallable)
	void UpdateCraftingStatus();

	UFUNCTION(BlueprintCallable)
	void CraftFromIndex(int32 IndexOfCraftableItem);

	UFUNCTION(BlueprintCallable)
	void Craft(const FCraftableItem& ItemToBeCrafted);

	UPROPERTY(BlueprintReadOnly)
	TArray<FCraftableItem> m_CraftableItems;

private:
	void SetInventorySystem(UANInventorySystem* InventorySystem);

	void LoadCraftableItems();

	UANInventorySystem* m_InventorySystem;
};
