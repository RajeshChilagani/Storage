#pragma once

#include "UObject/NameTypes.h"

/*This class is responsible for all constants*/

namespace CollisionProfiles
{
	//Unreal Profiles
	const FName NoCollision(TEXT("NoCollision"));
	const FName BlockAllDynamic(TEXT("BlockAllDynamic"));

	//Custom Profiles
	const FName Projectile(TEXT("Projectile"));
	const FName InteractableObject(TEXT("InteractableObject"));
	const FName WorldSelectable(TEXT("WorldSelectable"));
	const FName InvisibleTrigger(TEXT("InvisibleTrigger"));
}

namespace ConsoleCommands
{
	const FString DisableAllScreenMessages = "DisableAllScreenMessages";
	const FString EnableAllScreenMessages = "EnableAllScreenMessages";
	const FString ToggleAllScreenMessages = "ToggleAllScreenMessages";
}

namespace Sockets
{
	const FName RightHand(TEXT("hand_rSocket"));
}

namespace ActionMappings
{
	const FName Fire(TEXT("Fire"));
	const FName Aim(TEXT("Aim"));
	const FName Interact(TEXT("Interact"));
	const FName Flashlight(TEXT("Flashlight"));
	const FName Reload(TEXT("Reload"));
	const FName Jet(TEXT("Jet"));
	const FName Ascend(TEXT("Ascend"));
	const FName Descend(TEXT("Descend"));
	const FName Inventory(TEXT("Inventory"));
	const FName Map(TEXT("Map"));
	const FName AttachmentOne(TEXT("AttachmentOne"));
	const FName AttachmentTwo(TEXT("AttachmentTwo"));
	const FName AttachmentThree(TEXT("AttachmentThree"));
	const FName AttachmentFour(TEXT("AttachmentFour"));
	const FName UIConfirm(TEXT("UIConfirm"));
	const FName UIBack(TEXT("UIBack"));
	const FName UISpecialOne(TEXT("UISpecialOne"));
	const FName UISpecialTwo(TEXT("UISpecialTwo"));
	const FName UITabRightOne(TEXT("UITabRightOne"));
	const FName UITabLeftOne(TEXT("UITabLeftOne"));
	const FName UITabRightTwo(TEXT("UITabRightTwo"));
	const FName UITabLeftTwo(TEXT("UITabLeftTwo"));
	const FName UIUp(TEXT("UIUp"));
	const FName UIDown(TEXT("UIDown"));
	const FName UIRight(TEXT("UIRight"));
	const FName UILeft(TEXT("UILeft"));
	const FName UICursorClick(TEXT("UICursorClick"));
	const FName Pause(TEXT("Pause"));
	const FName DebugMenu(TEXT("DebugMenu"));
}

namespace AxisMappings
{
	const FName LSVertical(TEXT("LSVertical"));
	const FName LSHorizontal(TEXT("LSHorizontal"));
	const FName RSVertical(TEXT("RSVertical"));
	const FName RSHorizontal(TEXT("RSHorizontal"));
	const FName MouseVertical(TEXT("MouseVertical"));
	const FName MouseHorizontal(TEXT("MouseHorizontal"));
	const FName MouseWheel(TEXT("MouseWheel"));
}

namespace FunctionNames
{
	const FName SendInput_Pressed(TEXT("SendInput_Pressed"));
	const FName SendInput_Released(TEXT("SendInput_Released"));
}

namespace DefaultSaveValues
{
	const FVector DefaultStartLocation(FVector(-17000.0f, 11340.0f, 410.0f));
	const FRotator DefaultStartRotation(FRotator(0.0f, 0.0f, 0.0f));
}

namespace SaveableParams
{
	const FString CompleteTrue = "complete=true;";
	const FString CompleteFalse = "complete=false;";
	const FString ItemFilledTrue = "itemfilled=true;";
	const FString ItemFilledFalse = "itemfilled=false;";
	const FString PlayedTrue = "played=true;";
	const FString PlayedFalse = "played=false;";
	const FString PowerStateOnTrue = "powerstateon=true;";
	const FString PowerStateOnFalse = "powerstateon=false;";

	const FString Battery0 = "battery0=";
	const FString Battery1 = "battery1=";
	const FString Battery2 = "battery2=";
	const FString UnlockCode = "unlockcode=";
	const FString InsertedItem = "inserteditem=";
	const FString Health = "health=";
	const FString NumInteractions = "numinteractions=";

	const FString Guid = "guid=";
}

namespace SaveableBoolNames
{
	const FName bHasUsedOxygenStation(TEXT("bUsedOxygenStation"));
	const FName bTutorialFinished(TEXT("bTutorialFinished"));
	const FName bHasHarpoonGun(TEXT("bHasHarpoonGun"));
	const FName bFinishedHarpoonTutorial(TEXT("bFinishedHarpoonTutorial"));
	const FName bFoundHiddenRoom(TEXT("bFoundHiddenRoom"));
	const FName bLearnedFacilityName(TEXT("bLearnedFacilityName"));
	const FName bUsedMedkit(TEXT("bUsedMedkit"));
	const FName bRemindedPlayerOfDormitoryKeyCardValidator(TEXT("bRemindedPlayerOfDormitoryKeyCardValidator"));
	const FName bRemindedPlayerOfDormitoryKeyCardValidatorFinished(TEXT("bRemindedPlayerOfDormitoryKeyCardValidatorFinished"));
	const FName bBaddySpawningEnabled(TEXT("bBaddySpawningEnabled"));
}

namespace SaveableStringNames
{
	const FName Code1(TEXT("Code1"));
	const FName Code2(TEXT("Code2"));
	const FName Code3(TEXT("Code3"));
	const FName Code4(TEXT("Code4"));
	const FName Code5(TEXT("Code5"));
	const FName CrossSwitchesCode(TEXT("CrossSwitchesCode"));
}


namespace RumbleNames
{
	const FName OpenInventory(TEXT("OpenInventory"));
}

namespace SaveSlots
{
	const FString GameplaySaveGame = "Abyss of Neptune Gameplay Save Game";
	const FString SettingsSaveGame = "Abyss of Neptune Settings Save Game";
}

namespace LevelNames
{
	const FName GameWorld_P(TEXT("GameWorld_P"));
	const FName GameWorld_Shared(TEXT("GameWorld_Shared"));
	const FName GameWorld_Transitions(TEXT("GameWorld_Transitions"));

	const FName Academics_P(TEXT("Academics_P"));
	const FName Academics_SL_AI(TEXT("Academics_SL_AI"));
	const FName Academics_SL_Audio(TEXT("Academics_SL_Audio"));
	const FName Academics_SL_Foliage(TEXT("Academics_SL_Foliage"));
	const FName Academics_SL_FX(TEXT("Academics_SL_FX"));
	const FName Academics_SL_Geometry(TEXT("Academics_SL_Geometry"));
	const FName Academics_SL_Lighting(TEXT("Academics_SL_Lighting"));
	const FName Academics_SL_Props(TEXT("Academics_SL_Props"));
	const FName Academics_SL_Puzzles(TEXT("Academics_SL_Puzzles"));
	const FName Academics_SL_ScriptedEvents(TEXT("Academics_SL_ScriptedEvents"));

	const FName Dormitory_P(TEXT("Dormitory_P"));
	const FName Dormitory_SL_Audio(TEXT("Dormitory_SL_Audio"));
	const FName Dormitory_SL_Foliage(TEXT("Dormitory_SL_Foliage"));
	const FName Dormitory_SL_FX(TEXT("Dormitory_SL_FX"));
	const FName Dormitory_SL_Geometry(TEXT("Dormitory_SL_Geometry"));
	const FName Dormitory_SL_Lighting(TEXT("Dormitory_SL_Lighting"));
	const FName Dormitory_SL_Props(TEXT("Dormitory_SL_Props"));
	const FName Dormitory_SL_Puzzles(TEXT("Dormitory_SL_Puzzles"));

	const FName Exterior_P(TEXT("Exterior_P"));
	const FName Exterior_SL_Audio(TEXT("Exterior_SL_Audio"));
	const FName Exterior_SL_Foliage(TEXT("Exterior_SL_Foliage"));
	const FName Exterior_SL_Geometry(TEXT("Exterior_SL_Geometry"));
	const FName Exterior_SL_Lighting(TEXT("Exterior_SL_Lighting"));

	const FName Lab_P(TEXT("Lab_P"));
	const FName Lab_SL_AI(TEXT("Lab_SL_AI"));
	const FName Lab_SL_Audio(TEXT("Lab_SL_Audio"));
	const FName Lab_SL_Foliage(TEXT("Lab_SL_Foliage"));
	const FName Lab_SL_FX(TEXT("Lab_SL_FX"));
	const FName Lab_SL_Geometry(TEXT("Lab_SL_Geometry"));
	const FName Lab_SL_Lighting(TEXT("Lab_SL_Lighting"));
	const FName Lab_SL_Props(TEXT("Lab_SL_Props"));
	const FName Lab_SL_Puzzles(TEXT("Lab_SL_Puzzles"));
	const FName Lab_SL_ScriptedEvents(TEXT("Lab_SL_ScriptedEvents"));

	const FName Lobby_P(TEXT("Lobby_P"));
	const FName Lobby_SL_Audio(TEXT("Lobby_SL_Audio"));
	const FName Lobby_SL_Enemies(TEXT("Lobby_SL_Enemies"));
	const FName Lobby_SL_Foliage(TEXT("Lobby_SL_Foliage"));
	const FName Lobby_SL_FX(TEXT("Lobby_SL_FX"));
	const FName Lobby_SL_Geometry(TEXT("Lobby_SL_Geometry"));
	const FName Lobby_SL_Lighting(TEXT("Lobby_SL_Lighting"));
	const FName Lobby_SL_Props(TEXT("Lobby_SL_Props"));
	const FName Lobby_SL_Puzzles(TEXT("Lobby_SL_Puzzles"));

	const FName Tutorial_P(TEXT("Tutorial_P"));
	const FName Tutorial_SL_Audio(TEXT("Tutorial_SL_Audio"));
	const FName Tutorial_SL_Foliage(TEXT("Tutorial_SL_Foliage"));
	const FName Tutorial_SL_Geometry(TEXT("Tutorial_SL_Geometry"));
	const FName Tutorial_SL_Lighting(TEXT("Tutorial_SL_Lighting"));
	const FName Tutorial_SL_Props(TEXT("Tutorial_SL_Props"));
	const FName Tutorial_SL_Puzzles(TEXT("Tutorial_SL_Puzzles"));
}

namespace FilePaths
{
	const FString KeyPad_BP_Path = "Blueprint'/Game/Blueprints/Puzzle/KeyPad_BP.KeyPad_BP'";
	const FString KeyButton_BP_Path = "Blueprint'/Game/Blueprints/Puzzle/KeyButton_BP.KeyButton_BP'";
}

namespace AchievementNames
{
	const FName AbyssOfLearning(TEXT("AbyssOfLearning"));
	const FName AbyssOfShooting(TEXT("AbyssOfShooting"));
	const FName AbyssOfAcademia(TEXT("AbyssOfAcademia"));
	const FName AbyssOfSearching(TEXT("AbyssOfSearching"));
	const FName AbyssOfExploration(TEXT("AbyssOfExploration"));
	const FName AbyssOfCompletion(TEXT("AbyssOfCompletion"));
	const FName AbyssOfSpeedrunning(TEXT("AbyssOfSpeedrunning"));
	const FName AbyssOfGrit(TEXT("AbyssOfGrit"));
	const FName AbyssOfMercy(TEXT("AbyssOfMercy"));
	const FName AbyssOfPersistence(TEXT("AbyssOfPersistence"));
	const FName AbyssOfMasochism(TEXT("AbyssOfMasochism"));
	const FName AbyssOfDevelopers(TEXT("AbyssOfDevelopers"));
}

