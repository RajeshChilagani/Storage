// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Projectiles/ANBaseProjectile.h"
#include "Projectiles/ANHookProjectile.h"
#include "ANWeaponBase.generated.h"

UCLASS()
class UNDERWATER_API AANWeaponBase : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANWeaponBase();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

public:
	//How often the weapon can fire
	UPROPERTY(EditAnywhere, Category = "Weapon")
	float FireRate = 1.0;
	
	//The gun mesh itself
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Weapon")
	USkeletalMeshComponent* GunMesh;
	
	//This is the mesh will be visible on the gun before the player can fire it.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Weapon")
		UStaticMeshComponent* ProjectileToShowOnTheGun;

	//Different types of projectiles supported by this weapon
	UPROPERTY(EditAnywhere, Category = "Weapon")
	TArray<TSubclassOf<AANBaseProjectile>> TypesOfProjectiles;

protected:
	//The owning character
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Weapon")
	AANCharacterBase* CharacterOwner;

	USceneComponent* Root = nullptr;
	USkeletalMeshSocket* BulletSpawnSocket= nullptr;
	FName BulletSpawnSocketName = "BulletSpawn";
	FName ProjectileLocationOnGun = "HarpoonProjectileLocation";

	TSubclassOf<AANBaseProjectile> BulletToSpawn;
	
	FTimerHandle TimerHandle;

	float nextFire = 0.0f;


	//For Hook Type
	bool IsHookFired = false;
	bool IsAttackPressed = false;
	
public:
	//Fires the weapon
	UFUNCTION(BlueprintCallable)
	virtual void Fire();

	//Checks if the projectile is present in the inventory system.
	virtual bool CanFire(FString Name);

public:
	//Gets the owning character
	UFUNCTION(BlueprintPure, Category = "Getters")
	AANCharacterBase* GetCharacterOwner() const { return CharacterOwner; };

protected:
	//hides the projectile on the gun
	void HideProjectileOnGun() const;
	void ShowProjectileOnGun() const;
	
};
