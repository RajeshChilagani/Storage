// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Weapon/ANWeaponBase.h"

#include "ANDelegates.h"

#include "ANWeaponHarpoon.generated.h"

class AANHookProjectile;
class UANInventorySystem;
/**
 * 
 */
UCLASS()
class UNDERWATER_API AANWeaponHarpoon : public AANWeaponBase
{
	GENERATED_BODY()
	void BeginPlay() override;

public:
	void Tick(float DeltaSeconds) override;

	//Call the fire methods which fires the corresponding projectile.
	void Fire() override;

	//Checks if the projectile is present in the inventory system.
	bool CanFire(FString Name) override;
	void SetIsHookFire() { IsHookFired = true; }


private:

	//used to change the projectile which is shown on the gun.
	void ChangeProjectileOnGun(int ID);
	
	//Firing methods.
	void RegularFire();
	void HookFire();
	
	
	//Called after firing projectiles, removes them from the inventory
	void UpdateInventory(FString Name);
	
	//Play CameraShake after firing
	UPROPERTY(EditAnywhere, Category = "Config")
	TSubclassOf<UCameraShake> FireCameraShake;
	

	//Reset the visibility on the projectile which is shown on the gun.
	FTimerHandle VisibilityReset;
	
	//Hook reel Controls.
	void ReelHook() const;
	void ReelPlayerToTarget();


protected:
	//The hook
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Weapon")
	AANHookProjectile* HookRef = nullptr;

public:
	//Gets the hook
	UFUNCTION(BlueprintPure, Category = "Weapon")
	FORCEINLINE AANHookProjectile* GetHook() const { return HookRef; };

	UFUNCTION()
		void OnItemAddedToInventory(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod);
private:
	UANInventorySystem* InventorySystemRef;


};
