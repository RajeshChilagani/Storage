// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"

#include "ANStructs.h"

#include "ANDialogueConversation.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANDialogueConversation : public UPrimaryDataAsset
{
	GENERATED_BODY()
	
//Customizable Variables
protected:
	//If this conversation can overlap another conversation to have them occurring simultaneously
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Dialogue")
	bool bOverlap;

	//Represents the dialogue lines in this conversation, in order
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Dialogue")
	TArray<FDialogueLine> DialogueLines;

//Getters
public:
	//If this conversation can overlap another one
	UFUNCTION(BlueprintPure, Category = "Dialgoue")
	FORCEINLINE bool CanOverlap() const { return bOverlap; }

	//Gets all the dialogue lines on this asset
	UFUNCTION(BlueprintPure, Category = "Dialogue")
	TArray<FDialogueLine> GetDialogueLines() const { return DialogueLines; };
};
