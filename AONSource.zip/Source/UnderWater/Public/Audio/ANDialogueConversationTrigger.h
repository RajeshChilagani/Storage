// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Environment/ANGenericTrigger.h"

#include "ANDialogueConversationTrigger.generated.h"

class UANDialogueConversation;

UCLASS()
class UNDERWATER_API AANDialogueConversationTrigger : public AANGenericTrigger
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANDialogueConversationTrigger();


//Gameplay Functions
protected:
	virtual void PlayTriggerEvent_Implementation(AActor* OverlappedActor) override;

};
