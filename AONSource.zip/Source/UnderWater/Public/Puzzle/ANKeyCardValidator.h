// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "POD/ANKeycardAccessData.h"
#include "ANKeyCardValidator.generated.h"

class UAkAudioEvent;

class AANOpeningDoor;

/**
 * Validates a keycard and unlocks a target door.
 */
UCLASS()
class UNDERWATER_API AANKeyCardValidator : public AANPuzzleInteractable
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANKeyCardValidator();


public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnActivation();

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	KeyType AccessKeyType;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	bool bIsActivated;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	AANOpeningDoor* TargetDoor;

	UPROPERTY(BlueprintReadOnly)
	UANKeycardAccessData* KeyCardData;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FText AccessGrantedText;

	//SFX that plays when access is granted
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	UAkAudioEvent* AccessGrantedSFX;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	FText AccessDeniedText;

	//SFX that plays when access is denied
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	UAkAudioEvent* AccessDeniedSFX;

	//The time that the access text is displayed for
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite)
	float AccessTextTimeSeconds;

	virtual void CompletePuzzle_Implementation(bool bInstantComplete);

//Itemable Functions
public:
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem) override;
};
