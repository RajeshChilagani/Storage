// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANStructs.h"

#include "Interface/ANSaveable.h"
#include "Puzzle/ANPuzzleObjectBase.h"

#include "ANVoltageSystem.generated.h"

class UChildActorComponent;
class USceneComponent;
class UStaticMeshComponent;

class AANOpeningDoor;
class AANBatteryContainer;
class AANVoltagePanel;


UCLASS()
class UNDERWATER_API AANVoltageSystem : public AANPuzzleObjectBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	// Sets default values for this actor's properties
	AANVoltageSystem();

	virtual void BeginPlay() override;


//Components
public:
	//The root component of the voltage system
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	USceneComponent* VoltageSystemRoot;

	//Mesh for the control panel
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UStaticMeshComponent* ControlPanelMesh;

	//Battery container on the left
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UChildActorComponent* BatteryContainer0_CA;

	//Battery container in the middle
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UChildActorComponent* BatteryContainer1_CA;

	//Battery container on the right
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UChildActorComponent* BatteryContainer2_CA;

	//The voltage panel
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UChildActorComponent* VoltagePanel_CA;


//Customizable Variables
protected:
	//Voltage parameters for turning on different powerable objects
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Voltage System")
	TArray<FVoltageParams> Targets;

	//The default battery for position 0. If empty, will not spawn a battery.
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Voltage System")
	FString DefaultBattery0;

	//The default battery for position 1. If empty, will not spawn a battery.
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Voltage System")
	FString DefaultBattery1;

	//The default battery for position 2. If empty, will not spawn a battery.
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Voltage System")
	FString DefaultBattery2;


//Gameplay Variables
protected:
	//If we have loaded info on this voltage system from a save
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Voltage System")
	bool bLoaded;

	//Current voltage in the system
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Voltage System")
	int32 CurrentVoltage;

	//The number of powered on objects there are right now
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Voltage System")
	int32 NumPoweredOnObjects;

//Gameplay Functions
public:
	//Checks the voltage and sets things if valid
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Voltage System")
	void CheckVoltage(bool bPlaySFX);

	//Updates the voltage
	UFUNCTION(BlueprintCallable, Category = "Voltage System")
	void UpdateVoltage();

	//Inserts a battery into the chosen slot
	UFUNCTION(BlueprintCallable, Category = "Voltage System")
	void InsertBattery(const FString& ItemName, bool bConsumeItem, int32 BatteryIndex);


//Getters
public:
	//Gets the battery container at index (0, 1, or 2) from the child actor
	UFUNCTION(BlueprintPure, Category = "Getters")
	AANBatteryContainer* GetBatteryContainer(int32 BatteryIndex) const;

	//Gets the voltage panel from the child actor
	UFUNCTION(BlueprintPure, Category = "Getters")
	AANVoltagePanel* GetVoltagePanel() const;

	//Gets the current voltage
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE int32 GetCurrentVoltage() const { return CurrentVoltage; };

	//Gets the number of powered on objects
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE int32 GetNumPoweredOnObjects() const { return NumPoweredOnObjects; };


//Saveable Functions
public:
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
