// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"

#include "Interface/ANItemable.h"

#include "ANOxygenStation.generated.h"

class UAkAudioEvent;
class USceneComponent;
class UStaticMeshComponent;

class AANPressureStabilizer;
class AANScreenButton;
class IANSelectable;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANOxygenStation : public AANPuzzleInteractable
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANOxygenStation();


//Components
public:
	//The scene component that we save at
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	USceneComponent* SaveTransformSceneComponent;


//Customizable Variables
protected:
	//The level that we are in when we save
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	EANLevels SaveLevel;

	//The SFX that plays when we refill at the oxygen station
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	UAkAudioEvent* OxygenStationRefillSFX;


//Gameplay Variables
protected:
	//An array of all the screen buttons
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<AANScreenButton*> ScreenButtons;

//Gameplay Functions
protected:
	//Enables the screen buttons
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void EnableScreenButtons();

	//Disables the screen buttons
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void DisableScreenButtons();

	//Unhighlights all screen buttons
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Getters")
	void BP_UnhighlightAllScreenButtons();


//Getters
public:
	//Gets the screen buttons
	UFUNCTION(BlueprintPure, Category = "Getters")
	TArray<AANScreenButton*> GetScreenButtons() const { return ScreenButtons; };

	//Gets the screen buttons as selectable buttons
	TArray<TArray<IANSelectable*>> GetScreenButtonsAsSelectableArray() const;


//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;


//Itemable Interface
public:
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem) override;

};
