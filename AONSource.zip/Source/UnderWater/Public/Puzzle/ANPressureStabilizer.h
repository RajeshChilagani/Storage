// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANPressureStabilizer.generated.h"

class AANOxygenStation;
/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPressureStabilizer : public AANPuzzleInteractable
{
	GENERATED_BODY()
public:
	UFUNCTION(BlueprintImplementableEvent)
	void ExecuteStabilizerPuzzle();

public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;

protected:
	UPROPERTY(BlueprintReadWrite)
	AANOxygenStation* OxygenStationRef;

};
