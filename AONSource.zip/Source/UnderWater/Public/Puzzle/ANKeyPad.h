// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Puzzle/ANPuzzleObjectBase.h"

#include "ANKeyPad.generated.h"

class UChildActorComponent;
class UDecalComponent;
class USceneComponent;
class UStaticMeshComponent;

class AANKeyButton;
class IANSelectable;


UCLASS()
class UNDERWATER_API AANKeyPad : public AANPuzzleObjectBase
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANKeyPad();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

//Components
public:
	//The root of the key pad
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	USceneComponent* KeyPadRoot;

	//The mesh for the key pad itself
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UStaticMeshComponent* KeyPadMesh;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_OneKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_TwoKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_ThreeKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_FourKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_FiveKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_SixKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_SevenKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_EightKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_NineKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_XKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_ZeroKeyButton;

	//The key button child actor
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UChildActorComponent* CA_EnterKeyButton;


	//The decal for the current code on slot one
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UDecalComponent* CurrentCodeSlotOneDecal;

	//The decal for the current code on slot two
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UDecalComponent* CurrentCodeSlotTwoDecal;
	
	//The decal for the current code on slot three
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UDecalComponent* CurrentCodeSlotThreeDecal;

	//The decal for the current code on slot four
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UDecalComponent* CurrentCodeSlotFourDecal;


//Customizable Variables
public:
	//The code to unlock the door. This must be 4 characters in length.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FString UnlockCode;


//Gameplay Variables
protected:
	//The current code we have entered.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Code")
	FString CurrentUnlockCode;

	//A list of all key buttons
	TArray<AANKeyButton*> KeyButtons;

//Gameplay Functions
public:
	//Adds the next number
	UFUNCTION(BlueprintCallable, Category = "Code")
	void AddNumber(FString NewNumber);

	//Deletes the most recently entered number
	UFUNCTION(BlueprintCallable, Category = "Code")
	void DeleteNumber();

	//Confirms the entered string and checks if it's correct
	UFUNCTION(BlueprintCallable, Category = "Code")
	void ConfirmNumber();

	//Checks to see if the number is correct
	UFUNCTION(BlueprintPure, Category = "Code")
	bool CheckNumber() const;

	//Updates the number on the panel
	UFUNCTION(BlueprintImplementableEvent, Category = "Code")
	void BP_UpdateNumberOnPanel();


//Getters and Setters
public:
	//Assigns a new unlock code to this key pad
	UFUNCTION(BlueprintCallable, Category = "Code")
	void AssignUnlockCode(const FString& NewUnlockCode);

	//Returns an array of all the selectable buttons
	TArray<IANSelectable*> GetAllKeyButtonsAsSelectables() const;

	//Returns an array of an array of all the selectable buttons
	TArray<TArray<IANSelectable*>> GetAllKeyButtonsAsSelectableArray() const;
};
