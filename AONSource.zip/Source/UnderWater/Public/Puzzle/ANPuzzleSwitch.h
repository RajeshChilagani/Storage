// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interface/ANSelectable.h"
#include "ANPuzzleSwitch.generated.h"

class UAkAudioEvent;

class AANToggleSwitchesPuzzle;

UCLASS()
class UNDERWATER_API AANPuzzleSwitch : public AActor, public IANSelectable
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANPuzzleSwitch();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, BLueprintReadWrite)
	AANToggleSwitchesPuzzle* OwnerTogglesPuzzle;

public:	
	UFUNCTION(BlueprintImplementableEvent)
	void OnToggleSwitch();

	UFUNCTION(BlueprintCallable)
	void SwitchToggle();

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bToggleState;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	uint8 id;


	
/** Selectable Functions*/
public:
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Highlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual bool BP_CanSelect_Implementation() const override { return true; };

/** Selectable Variables*/
protected:
	//The player numbers that are currently selecting/highlighting this widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<EPlayerNumbers> HighlightedPlayers;

	//The SFX that plays when you confirm this widget with the A button/enter key.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* ConfirmSFX;

	//The SFX that plays when you move onto this widget.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* HighlightSFX;

	//The SFX that plays when you move away from this widget. Most UI will not implement this.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* UnhighlightSFX;

	//Is at least one player selecting/highlighting this widget right now?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bHighlighted;
};
