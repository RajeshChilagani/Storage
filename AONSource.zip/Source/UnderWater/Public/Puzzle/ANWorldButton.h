// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANDelegates.h"
#include "ANEnums.h"

#include "Interface/ANSelectable.h"

#include "ANWorldButton.generated.h"

class UAkAudioEvent;

UCLASS()
class UNDERWATER_API AANWorldButton : public AActor, public IANSelectable
{
	GENERATED_BODY()

//Unreal Functions
public:
	// Sets default values for this actor's properties
	AANWorldButton();

	virtual void BeginPlay() override;


//Components
public:
	//The root of the world button
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* WorldButtonRoot;

	//The mesh for the world button itself
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UStaticMeshComponent* WorldButtonMesh;



//Delegates
public:
	//Delegate called when we confirm the button press
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnWorldButtonConfirmed OnWorldButtonConfirmed;


//Gameplay Functions
public:
	//Presses the button
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void PressButton();


	//Selectable Variables
protected:
	//Is this selectable enabled right now (can be selected)?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bEnabled;

	//The player numbers that are currently selecting/highlighting this widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<EPlayerNumbers> HighlightedPlayers;

	//The SFX that plays when you confirm this widget with the A button/enter key.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* ConfirmSFX;

	//The SFX that plays when you move onto this widget.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* HighlightSFX;

	//The SFX that plays when you move away from this widget. Most UI will not implement this.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* UnhighlightSFX;

	//Is at least one player selecting/highlighting this widget right now?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bHighlighted;


//Selectable Functions
public:
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Highlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual bool BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const override;
	virtual void BP_EnableSelectable_Implementation() override;
	virtual void BP_DisableSelectable_Implementation() override;
	virtual bool BP_CanSelect_Implementation() const override;
};
