// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"

#include "ANEnums.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "AANInformationPanelPool.generated.h"

class UChildActorComponent;

USTRUCT(BlueprintType)
struct FANInfoPanel : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnyWhere, BlueprintReadOnly)
	FText Description;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EInfoPanelCategory Category;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	class UTexture* InfoTexture;
};

/**
 * Holds InfoPanel actors that are synced with the referenced NumLock puzzle
 */
UCLASS()
class UNDERWATER_API AANInformationPanelPool : public AActor
{
	GENERATED_BODY()
public:
	AANInformationPanelPool();
	
	virtual void BeginPlay() override;

	/** Loads textures to the Infopanel actor components */
	UFUNCTION(BlueprintCallable)
	void LoadPanelItems(const FString& NumericValue, int32 NumericValuePostion, UPARAM(ref) TArray<UTexture*>& Out_Textures, UPARAM(ref) TArray<FText>& Out_Descriptions);

	UFUNCTION(BlueprintCallable)
	bool GetPanelInfoData(FName RowName, FANInfoPanel& Out_InfoObject);

	/** Total number of panel actors held by this pool */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta=(ClampMin="3", ClampMax="5"))
	int32 PanelActorsCount;

	/** The UClass used for creating panel actor components */
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	TSubclassOf<AANPuzzleInteractable> PanelActorClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class AANNumLockPuzzle* TargetNumLock;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	class USceneComponent* InfoPanelPoolRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	TArray<UChildActorComponent*> PanelActors;

private:
	UTexture* GetTextureFromInfoTable(FName RowName);

	/** Load the datatable which contains all the Info textures */
	void LoadTexturesTable();
	
	void RefreshCategoryInfoMap();

	void LoadCategoryInfoMap();

	/** Stores the count of textures corresponding to each category from Info texture data table */
	UPROPERTY()
	TMap<EInfoPanelCategory, int32> InfoPanelCategoryMap;

};
