// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Puzzle/ANWorldButton.h"

#include "ANPuzzleButton.generated.h"

class UAkAudioEvent;
class UDecalComponent;

UCLASS()
class UNDERWATER_API AANPuzzleButton : public AANWorldButton
{
	GENERATED_BODY()

//Unreal Functions
public:
	// Sets default values for this actor's properties
	AANPuzzleButton();


//Components
public:
	//The decal for the puzzle button
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UDecalComponent* PuzzleButtonDecal;
};
