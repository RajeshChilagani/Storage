// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Puzzle/ANWorldButton.h"

#include "ANScreenButton.generated.h"

class UTextRenderComponent;

UCLASS()
class UNDERWATER_API AANScreenButton : public AANWorldButton
{
	GENERATED_BODY()

//Unreal Functions
public:
	// Sets default values for this actor's properties
	AANScreenButton();


//Components
public:
	//The decal for the screen button
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UTextRenderComponent* ScreenButtonText;


//Customizable Variables
public:
	//The text to be displayed on the text render component
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Defaults")
	FText DisplayText;

};
