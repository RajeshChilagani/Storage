// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Puzzle/ANPuzzleObjectBase.h"
#include "ANPuzzleTarget.generated.h"

UCLASS()
class UNDERWATER_API AANPuzzleTarget : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANPuzzleTarget();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "PuzzleTarget")
	TArray<AANPuzzleObjectBase*> Dependencies;

	UFUNCTION(BlueprintImplementableEvent, Category = "PuzzleTarget")
	void OnAllDependenciesSolved();

	UFUNCTION(BlueprintImplementableEvent, Category = "PuzzleTarget")
	void ResetTargetToUnsolved();

private:
	UPROPERTY()
	int32 NumOfDependencies;

	UPROPERTY()
	bool bIsOnAllDependenciesSolvedInvoked;

	UPROPERTY()
	bool bShouldResetTarget;
};
