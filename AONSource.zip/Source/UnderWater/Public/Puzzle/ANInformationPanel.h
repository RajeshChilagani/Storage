// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANInformationPanel.generated.h"

class UTexture;
/**
 * 
 */
UCLASS()
class UNDERWATER_API AANInformationPanel : public AANPuzzleInteractable
{
	GENERATED_BODY()
public:
	AANInformationPanel();
	virtual void BeginPlay() override;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<UTexture*> Textures;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FText> Descriptions;

	void UpdatePanelItems(const TArray<UTexture*>& NewTextures, const TArray<FText>& NewDescriptions);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void UpdateWidgetTextures();
protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UStaticMeshComponent* PanelMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	class UWidgetComponent* WidgetBP;

};
