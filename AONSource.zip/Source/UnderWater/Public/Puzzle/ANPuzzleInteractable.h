 // Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleObjectBase.h"
#include "Interface/ANInteractable.h"
#include "Interface/ANItemable.h"

#include "ANDelegates.h"

#include "ANPuzzleInteractable.generated.h"

class USpotLightComponent;

class AANCharacterBase;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPuzzleInteractable : public AANPuzzleObjectBase, public IANInteractable, public IANItemable
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANPuzzleInteractable();


//Components
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class USceneComponent* PuzzleRootComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class UCameraComponent* PuzzleCameraComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class USpotLightComponent* SpotLightComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	class UStaticMeshComponent* MainMeshComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	class UBoxComponent* CustomDepthBounds;

//Delegates
public:
	//Delegate for beginning interaction
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnPuzzleBeginInteract OnPuzzleBeginInteract;

	//Delegate for ending interaction
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnPuzzleEndInteract OnPuzzleEndInteract;


//Customizable Variables
protected:
	//Is the camera needed?
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Interaction")
	bool bIsCameraNeeded;

	//Does this puzzle interactable open the inventory?
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Interaction")
	bool bOpensInventory;

	//Does this puzzle display the close prompt?
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Interaction")
	bool bDisplayClosePrompt;


//Interactable Variables
protected:
	//If this item is being interacted with right now
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	bool bInteracting;

	//The character interacting with this object right now
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	AANCharacterBase* LongInteractingCharacter;

	//Is the puzzle camera active?
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	bool bPuzzleCameraActive;


//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;


//Itemable Variables
protected:
	//A list of item names that can be inserted into this puzzle
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Itemable")
	TArray<FString> InsertableItemNames;

//Itemable Interface
public:
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem) override;
	virtual bool BP_CanInsertItem_Implementation(const FString& InsertedItem) override;
	virtual void BP_TakeItem_Implementation(const FString& TakenItem) override;


//DepthStencilBox - DSB
//CustomDepthBounds - CDB
public:
	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthEnabled();

	UFUNCTION(BlueprintImplementableEvent)
	void OnRenderCustomDepthDisabled();
protected:
	UFUNCTION(BlueprintCallable)
	void SetDepthStencilState(bool bEnable);
private:
	UFUNCTION()
	void OnCDBBeginOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnCDBEndOverlap(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
};
