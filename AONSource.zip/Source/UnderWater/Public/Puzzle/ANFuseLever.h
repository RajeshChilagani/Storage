// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANFuseLever.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANFuseLever : public AANPuzzleInteractable
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintImplementableEvent)
	void ToggleFuse();

//Interactable Interface
public:
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
};
