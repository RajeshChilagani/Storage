// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANToggleSwitchesPuzzle.generated.h"

class AANPuzzleSwitch;
class IANSelectable;
/**
 * 
 */
UCLASS()
class UNDERWATER_API AANToggleSwitchesPuzzle : public AANPuzzleInteractable
{
	GENERATED_BODY()

public:
	AANToggleSwitchesPuzzle();

public:
	void ToggleStateChanged(AANPuzzleSwitch* Switch);

	UFUNCTION(BlueprintImplementableEvent)
	void UpdateToggles(AANPuzzleSwitch* UpdatedSwitch);

	UFUNCTION(BlueprintCallable)
	TArray<AANPuzzleSwitch*> GetAllSwitches() { return PuzzleSwitches; };
	//Interactable Interface
public:
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;

protected:
	UPROPERTY(BlueprintReadWrite, Category = "Controller Support")
	TArray<AANPuzzleSwitch*> PuzzleSwitches;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Controller Support", meta = (ClampMin = "1"))
	int32 RowLength;
};
