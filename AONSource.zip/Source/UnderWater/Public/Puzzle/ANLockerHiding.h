// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/TimelineComponent.h"
#include "Components/ActorComponent.h"
#include "ANLockerHiding.generated.h"

class UCurveFloat;
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UNDERWATER_API UANLockerHiding : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UANLockerHiding();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	FTimeline Timeline;

	UPROPERTY(EditAnywhere, Category = "Timeline")
	UCurveFloat* CurveFloat;
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	UFUNCTION(BlueprintNativeEvent, Category = "Locker Hiding System")
	void OpenLocker();
	virtual void OpenLocker_Implementation();



		
};
