// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANStructs.h"

#include "ANVoltagePanel.generated.h"

UCLASS()
class UNDERWATER_API AANVoltagePanel : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANVoltagePanel();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Gameplay Functions
public:
	//Initializes the voltage panel
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_InitializeVoltagePanel();

	//Creates the items in the UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_CreateItemsUI(const TArray<FVoltageParams>& VoltageParams);

	//Updates the panels in the UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_UpdatePanelsUI(int32 NewVoltage);

};
