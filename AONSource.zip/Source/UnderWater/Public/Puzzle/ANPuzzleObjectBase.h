// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Misc/Guid.h"

#include "ANDelegates.h"

#include "Interface/ANSaveable.h"
#include "ANPuzzleObjectBase.generated.h"

class UAkAudioEvent;

UCLASS()
class UNDERWATER_API AANPuzzleObjectBase : public AActor, public IANSaveable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANPuzzleObjectBase();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Delegates
public:
	//Delegate for completing the puzzle
	UPROPERTY(BlueprintAssignable, Category = "InventoryEvents")
	FOnPuzzleComplete OnPuzzleComplete;

	//Delegate for uncompleting the puzzle
	UPROPERTY(BlueprintAssignable, Category = "InventoryEvents")
	FOnPuzzleUncomplete OnPuzzleUncomplete;


//Customizable Variables
protected:
	//Audio event for when the puzzle is complete. If not set, will not play when complete.
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Defaults")
	UAkAudioEvent* PuzzleCompleteSFX;


//Gameplay Variables
public:

private:
	//Is this puzzle complete?
	UPROPERTY(VisibleAnywhere, Category = "Puzzle")
	bool bPuzzleComplete;

//Gameplay Functions
protected:
	//Completes the puzzle. If InstantComplete is true, should skip a lot of the audio/visual logic and set it instantly to the completed state (mainly for loading).
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Puzzle")
	void CompletePuzzle(bool bInstantComplete);
	virtual void CompletePuzzle_Implementation(bool bInstantComplete);

	//Uncompletes the puzzle
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Puzzle")
	void UncompletePuzzle();
	virtual void UncompletePuzzle_Implementation();


//Getters and Setters
public:
	//Is this puzzle complete?
	UFUNCTION(BlueprintCallable, Category = "Puzzle")
	bool IsPuzzleComplete() const { return bPuzzleComplete; };


//Saveable Variables
protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Saveable")
	FGuid SaveableGuid;

//Saveable Interface
public:
	virtual FGuid BP_GetSaveableGuid_Implementation() override;
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_SaveObject_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
