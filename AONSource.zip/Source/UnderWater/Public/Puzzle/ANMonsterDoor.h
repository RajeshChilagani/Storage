// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleObjectBase.h"
#include "ANMonsterDoor.generated.h"

class USceneComponent;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANMonsterDoor : public AANPuzzleObjectBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANMonsterDoor();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

//Components
public:
	//The root component for the monster door
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "PuzzleCamera")
	USceneComponent* MonsterDoorRootComponent;


//Customizable Variables
protected:
	//The scale for starting the pulse effect
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FVector StartPulseScale;
	
	//The scale for at the limits of the pulse effect
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FVector EndPulseScale;

	//How long it takes to get from the start to end pulse one time. (Reverse will use this time too.)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (ClampMin = "0.1"))
	float PulseTimeSeconds;

	//The scale for at the limits of the pulse effect
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FVector DiminishScale;

	//How long it takes to get from the current to diminish pulse one time
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults", meta = (ClampMin = "0.1"))
	float DiminishTimeSeconds;


//Gameplay Variables
protected:
	//If the pulse is reversing right now
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bPulseReversing;

	//The time of the pulse we are at
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float CurrentTimeSeconds;

	//The current scale
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	FVector CurrentScale;

	//If the monster door is diminishing right now
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bDiminishing;

	//The scale when the diminish started
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	FVector ScaleAtDiminshStart;

//Gameplay Functions
public:
	virtual void CompletePuzzle_Implementation(bool bInstantComplete);

	//Updates the scale for objects
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_UpdateScale(FVector NewScale);

	//Called when the object is diminished
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_EndDiminish();

	//Receives damage
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void ReceiveDamage(int32 DamageAmount);

};
