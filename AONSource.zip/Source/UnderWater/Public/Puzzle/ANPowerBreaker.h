// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANPowerBreaker.generated.h"

class IANPowerable;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPowerBreaker : public AANPuzzleInteractable
{
	GENERATED_BODY()


//Unreal Functions
public:
	AANPowerBreaker();

//Custom Variables
public:
	//The list of powerable objects that are affected by this item gaining power
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	TArray<TScriptInterface<IANPowerable>> PowerableObjects;

	//The list of powerable objects that are affected by this item gaining power - should change to IANPowerable later but this is last minute
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	TArray<AActor*> PowerableObjectsAsActors;

//Gameplay Variables
protected:
	//If this power breaker is turned on
	UPROPERTY(VisibleAnywhere, Category = "Gameplay")
	bool bPowerStateOn;

//Gameplay Functions
public:
	//Alters the power state. If on, turns off. If off, turns on.
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AlterPowerState();


//Interactable Functions
public:
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;


//Saveable Functions
public:
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
