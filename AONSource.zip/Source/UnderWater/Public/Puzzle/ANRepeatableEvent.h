// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANStructs.h"

#include "Interface/ANWorldSaveable.h"

#include "ANRepeatableEvent.generated.h"

UCLASS()
class UNDERWATER_API AANRepeatableEvent : public AActor, public IANWorldSaveable
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANRepeatableEvent();
	
	virtual void BeginPlay() override;


//Customizable Variables
protected:
	//The time it takes for this event to repeat
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Repeatable Event", meta = (ClampMin = "0.1"))
	float EventRepeatTimeSeconds;

	//If this event should play instantly at the start
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Repeatable Event")
	bool bPlayEventAtStart;


//Gameplay Variables
protected:
	//Timer handle for repeating the event
	UPROPERTY(BlueprintReadWrite, Category = "Repeatable Event")
	FTimerHandle RepeatTimerHandle;

//Gameplay Functions
public:
	//Plays the event
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Repeatable Event")
	void PlayEvent();

	//Removes the event and stops it from playing
	UFUNCTION(BlueprintCallable, Category = "Repeatable Event")
	void RemoveEvent();


//WorldSaveable Variables
protected:
	//The Guid for saving this world saveable
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "World Saveable")
	FGuid WorldSaveableGuid;

//WorldSaveable Functions
public:
	virtual void BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign) override;
	virtual bool BP_CanSaveToWorldSaveablesMap_Implementation() override;
	virtual void BP_UpdateWorldSaveableState_Implementation() override;
	virtual FGuid BP_GetWorldSaveableGuid_Implementation() override;
	virtual FWorldSaveableData BP_GetWorldSaveableData_Implementation() override;
	virtual FString BP_ConstructSaveableParamsString_Implementation() override;

};
