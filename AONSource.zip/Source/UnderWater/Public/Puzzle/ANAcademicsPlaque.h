// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Interface/ANInteractable.h"
#include "Interface/ANItemable.h"
#include "Interface/ANPowerable.h"
#include "Puzzle/ANPuzzleObjectBase.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANAcademicsPlaque.generated.h"

class AANCharacterBase;
class AANMovingStatue;
class UStaticMeshComponent;


/**
 * 
 */
UCLASS()
class UNDERWATER_API AANAcademicsPlaque : public AANPuzzleInteractable , public IANPowerable
{
	GENERATED_BODY()
public:
	AANAcademicsPlaque();
	virtual void BeginPlay() override;

public:
	//Is this object powered on?
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Default")
	bool bPoweredOnAtStart = false;

public:
	//Updates the drive count in blueprints
	UFUNCTION(BlueprintImplementableEvent, Category = "Academics Plaque")
	void BP_InsertDrive(bool bInstantInsert);




//Customizable Variables
protected:
	//The text that the plaque starts with
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Statue Plaque")
	FText StartText;

	//The moving statue reference
	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Statue Plaque")
	AANMovingStatue* MovingStatue;


//Gameplay Variables
protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Statue Plaque")
	TArray<FString> HardrivePositions;

	//The number of times we have interacted with the 
	UPROPERTY(BlueprintReadWrite, Category = "Statue Plaque")
	int32 NumInteractions;


//Gameplay Functions
public:
	//Gets the moving statue
	UFUNCTION(BlueprintPure, Category = "Statue Plaque")
	FORCEINLINE AANMovingStatue* GetMovingStatue() const { return MovingStatue; }


//Interactable Functions
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsInteracting() const override;
	virtual bool IsLongInteract() const override;


//Itemable Functions
public:
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem) override;


//Powerable Variables
protected:
	//Is this object powered on?
	UPROPERTY(BlueprintReadWrite, Category = "Powerable")
	bool bPoweredOn;
	//The name of the powerable object
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Powerable")
	FText PowerableName;

//Powerable Functions
public:
	virtual void BP_PowerOn_Implementation();
	virtual void BP_PowerOff_Implementation();
	virtual bool BP_IsPoweredOn_Implementation();
	virtual FText BP_GetPowerableName_Implementation() override;


//Saveable Functions
public:
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;

};
