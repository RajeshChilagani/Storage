// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Interface/ANInteractable.h"
#include "Interface/ANItemable.h"
#include "Puzzle/ANPuzzleObjectBase.h"
#include "Puzzle/ANPuzzleInteractable.h"

#include "ANBatteryContainer.generated.h"

class USceneComponent;

class AANCharacterBase;
class AANOpeningDoor;
class AANVoltageSystem;
class UANInventoryItem;

UCLASS()
class UNDERWATER_API AANBatteryContainer : public AANPuzzleInteractable
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANBatteryContainer();
	
	virtual void BeginPlay() override;


//Gameplay Variables
protected:
	//The current item name that is inserted
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Voltage System")
	FString CurrentItemName;

	//Whether we have a battery in this container or not
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Voltage System")
	bool bFilled;

	//The current voltage we are at with the passed in battery
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Voltage System")
	int32 CurrentVoltage;

	//The current item that is inserted
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Voltage System")
	AActor* CurrentItemActor;

	//The voltage system reference
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Voltage System")
	AANVoltageSystem* VoltageSystem;

//Gameplay Functions
public:
	//Inserts a battery and updates the container
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Voltage System")
	void BP_InsertBattery(const FString& ItemName);

	//Removes the active battery and updates the container
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Voltage System")
	void BP_RemoveBattery();


	UFUNCTION(BlueprintCallable, Category = "Voltage System")
	void SetVoltageSystemRef(AANVoltageSystem* NewVoltageSystem);


//Getters
public:
	//Gets the current voltage
	UFUNCTION(BlueprintPure, Category = "Voltage System")
	FORCEINLINE int32 GetCurrentVoltage() const { return CurrentVoltage; };

	//Gets if this container is filled
	UFUNCTION(BlueprintPure, Category = "Voltage System")
	FORCEINLINE bool IsFilled() const { return bFilled; };


//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;


//Itemable Functions
public:
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem) override;
	virtual void BP_TakeItem_Implementation(const FString& TakenItem) override;

	//Gets the current item name
	UFUNCTION(BlueprintPure, Category = "Battery")
	FORCEINLINE FString GetCurrentItemName() const { return CurrentItemName; };


//Saveable Functions
public:
	virtual FString BP_ConstructSaveString_Implementation() override;
	virtual void BP_SaveObject_Implementation() override;
	virtual void BP_LoadObject_Implementation(const FString& LoadString) override;
};
