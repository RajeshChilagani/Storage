// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANEnums.h"

#include "Interface/ANSelectable.h"

#include "ANKeyButton.generated.h"

class UAkAudioEvent;

class AANKeyPad;

UCLASS()
class UNDERWATER_API AANKeyButton : public AActor, public IANSelectable
{
	GENERATED_BODY()

//Unreal Functions
public:	
	// Sets default values for this actor's properties
	AANKeyButton();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

//Components
public:
	//The root of the key button
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	USceneComponent* KeyButtonRoot;

	//The mesh for the key button itself
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Key")
	UStaticMeshComponent* KeyButtonMesh;


//Customizable Variables
public:
	//The string to add when pressing this button. Ideally, this should only be one letter/number in length.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FString KeyString;

	//The key button type. AKA, what it does.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	EANKeyButtonTypes KeyButtonType;


//Gameplay Variables
protected:
	//The key pad that this key button is attached to
	UPROPERTY(VisibleAnywhere, Category = "Key")
	AANKeyPad* AssociatedKeyPad;

//Gameplay Functions
public:
	//Presses the key
	UFUNCTION(BlueprintCallable, Category = "Key")
	void PressKey();


//Getters and Setters
public:
	//Assigns the key pad to this key button
	UFUNCTION(BlueprintCallable, Category = "Key")
	void AssignKeyPad(AANKeyPad* NewKeyPad);



//Selectable Variables
protected:
	//Is this selectable enabled right now (can be selected)?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bEnabled;

	//The player numbers that are currently selecting/highlighting this widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<EPlayerNumbers> HighlightedPlayers;

	//The SFX that plays when you confirm this widget with the A button/enter key.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* ConfirmSFX;

	//The SFX that plays when you move onto this widget.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* HighlightSFX;

	//The SFX that plays when you move away from this widget. Most UI will not implement this.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* UnhighlightSFX;

	//Is at least one player selecting/highlighting this widget right now?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bHighlighted;


//Selectable Functions
public:
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Highlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual bool BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const override;
	virtual void BP_EnableSelectable_Implementation() override;
	virtual void BP_DisableSelectable_Implementation() override;
	virtual bool BP_CanSelect_Implementation() const override;
};
