// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "ANStructs.h"
#include "CoreMinimal.h"
#include "Core/Public/HAL/Runnable.h"

//Forward Declaration.
//class FRunnableThread;
class AANSecondaryAINavRoom;


class UNDERWATER_API AANCustomNavPathFinder : public FRunnable
{
	
public:
	//Add an algorithm later
	AANCustomNavPathFinder(FVector StartPoint, FVector EndPoint, TMap<FVector, FNavMeshData> NavData, FIntVector gridSize, FVector origin);


	//Run the path finding here
	virtual uint32 Run() override;

	//Manually stop the path finding process.
	virtual  void Stop() override;

	/// <summary>
	/// All clean up code here;
	/// </summary>
	virtual void Exit() override;

	TArray<FVector> GetPath() const;

	bool IsPathFindingComplete() const;

	void StopThread();
	
protected:
	bool bStopThread = false;

	bool bIsPathFindingComplete = false;

	FVector StartPoint;
	FVector EndPoint;
	
	TMap<FVector, FNavMeshData> NavPoints;


	FVector GetNavPointIndexFromLocation(FVector Location);

	bool IsPointValid(FVector Point) const;

	//The path that ws generated
	TArray<FVector> FoundPath;


	//The begin location of the box component;
	//Can be reomved if we find the bug with get location
	FVector NavRegionBeginLocation;

	FIntVector GridSize;
};
