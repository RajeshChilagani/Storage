// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"

#include "ANDelegates.h"
#include "ANEnums.h"

#include "ANCharacterBase.generated.h"

class UAkAudioEvent;
class UAkComponent;
class UForceFeedbackEffect;
class UParticleSystem;
class UWorld;

struct FForceFeedbackParameters;

UCLASS()
class UNDERWATER_API AANCharacterBase : public ACharacter
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANCharacterBase();
	
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;


//Components
public:
	//The AK component for posting sound events on this character
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UAkComponent* CharacterAkComponent;


//Input Functions
public:
	//Processes the input and attempts to call an action
	virtual void ProcessInput(EANInputActions ANInputAction, EInputEvent InputEvent);

	//Processes the axis and attempts to call an action
	virtual void ProcessAxis(EANInputAxes ANInputAxis, float AxisValue);

protected:
	virtual void InputAction_Fire_Pressed();
	virtual void InputAction_Fire_Released();

	virtual void InputAction_Aim_Pressed();
	virtual void InputAction_Aim_Released();

	virtual void InputAction_Interact_Pressed();
	virtual void InputAction_Interact_Released();

	virtual void InputAction_Flashlight_Pressed();
	virtual void InputAction_Flashlight_Released();

	virtual void InputAction_Reload_Pressed();
	virtual void InputAction_Reload_Released();

	virtual void InputAction_Jet_Pressed();
	virtual void InputAction_Jet_Released();

	virtual void InputAction_Ascend_Pressed();
	virtual void InputAction_Ascend_Released();

	virtual void InputAction_Descend_Pressed();
	virtual void InputAction_Descend_Released();

	virtual void InputAction_Inventory_Pressed();
	virtual void InputAction_Inventory_Released();

	virtual void InputAction_Map_Pressed();
	virtual void InputAction_Map_Released();

	virtual void InputAction_AttachmentOne_Pressed();
	virtual void InputAction_AttachmentOne_Released();

	virtual void InputAction_AttachmentTwo_Pressed();
	virtual void InputAction_AttachmentTwo_Released();
	
	virtual void InputAction_AttachmentThree_Pressed();
	virtual void InputAction_AttachmentThree_Released();
	
	virtual void InputAction_AttachmentFour_Pressed();
	virtual void InputAction_AttachmentFour_Released();

	virtual void InputAxis_LSVertical(float AxisValue);
	virtual void InputAxis_LSHorizontal(float AxisValue);

	virtual void InputAxis_RSVertical(float AxisValue);
	virtual void InputAxis_RSHorizontal(float AxisValue);

	virtual void InputAxis_MouseVertical(float AxisValue);
	virtual void InputAxis_MouseHorizontal(float AxisValue);

	virtual void InputAxis_MouseWheel(float AxisValue);

//Delegates
public:
	//Delegate for when the character dies
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnCharacterDeath OnCharacterDeath;

	//Delegate for when the character's health upates
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnCharacterUpdateHealthUI OnCharacterUpdateHealthUI;


//Customizable Variables
protected:
	//The max health for this character; also how much they start with
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	int32 MaxHealth;

	//The SFX for receiving damage
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* ReceiveDamageSFX;

	//The SFX that plays on death
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* DieSFX;

	//VFX to play when taking damage
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX")
	UParticleSystem* BloodVFX;


//Camera Functions
public:
	//Sets the player controller's camera blend target to the specified actor
	UFUNCTION(BlueprintCallable, Category = "Camera")
	void SetViewTargetWithBlend(AActor* NewBlendTarget);


//Movement Functions
public:
	//Moves the character
	UFUNCTION(BlueprintCallable, Category = "Movement")
	void MoveCharacter(float XValue, float YValue);

	//Can this character move right now?
	UFUNCTION(BlueprintPure, Category = "Movement")
	virtual bool CanMove() const;


//Gameplay Variables
public:

protected:
	//Whether or not this character is alive
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bAlive;

	//How much health the character has right now
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	int32 CurrentHealth;
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float TimeToResetDamage = 3.0f;

	UPROPERTY(BlueprintAssignable, Category = "Damage Event")
	FOnTakeDamageReset OnTakeDamageReset;

private:
	FTimerHandle HealthResetTimerHandle;
	
	
//Gameplay Functions
public:
	//Function to prevent potential issues when we pause the game
	UFUNCTION()
	virtual void PreventPauseIssues();

	//Receives damage
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void ReceiveDamage(int32 DamageReceived);

	//Directly sets health to a value
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void SetHealth(int32 NewHealthValue);

	//Recovers health damage
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void RecoverHealth(int32 HealthRecovered);

	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void ResetHealthTimer();
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void StartHealthResetCoolDown();

	//Kills the character
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void Die();


//Helper Variables
protected:
	//A world reference
	UPROPERTY()
	UWorld* WorldRef;

//Helper Functions
public:
	//Plays a rumble/force feedback effect
	UFUNCTION(BlueprintCallable, Category = "Rumble")
	void PlayRumble(UForceFeedbackEffect* RumbleEffect, const FName& RumbleTag, bool bLooping);

	//Stops a rumble/force feedback effect
	UFUNCTION(BlueprintCallable, Category = "Rumble")
	void StopRumble(UForceFeedbackEffect* RumbleEffect, const FName& RumbleTag);

	//Tries to post an Ak Audio Event on this character
	UFUNCTION(BlueprintCallable, Category = "SFX")
	void PostAkAudioEventOnCharacter(UAkAudioEvent* AudioEvent);


//Getters and Setters
public:
	//Checks whether or not this character is alive
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsAlive() const { return bAlive; };

	//Gets the max health for this character
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE int32 GetMaxHealth() const { return MaxHealth; };

	//Gets the current health for this character
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE int32 GetCurrentHealth() const { return CurrentHealth; };

	//Gets the character Ak Component
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE UAkComponent* GetCharacterAkComponent() const { return CharacterAkComponent; };

};
