// Created by Vishal Naidu (GitHub: Vieper1) | naiduvishal13@gmail.com | Vishal.Naidu@utah.edu

#pragma once

#include "CoreMinimal.h"
#include "Character/ANCharacterBase.h"

#include "ANDelegates.h"
#include "ANEnums.h"
#include "ANStructs.h"

#include "ANMainCharacter.generated.h"

class UAkAudioEvent;
class UAkComponent;
class UCameraComponent;
class UForceFeedbackEffect;
class UParticleSystemComponent;
class UPhysicsConstraintComponent;
class USpringArmComponent;
class USpotLightComponent;
class UTimelineComponent;

class AANLocker;
class AANPlayerControllerBase;
class AANWeaponHarpoon;
class IANInteractable;
class IANSelectable;
class UANInventorySystem;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNoParamDelegate);

UCLASS()
class UNDERWATER_API AANMainCharacter : public AANCharacterBase
{
	GENERATED_BODY()
	

//Unreal Functions
public:
	AANMainCharacter();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;


////////////////////////////////////////////////////////////////////// INPUT
protected:
	//The aim sensitivity for the horizontal direction
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Input")
	float ControllerAimVerticalSensitivity;

	//The aim sensitivity for the horizontal direction
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Input")
	float ControllerAimHorizontalSensitivity;

public:
	//Sets the player's input to the specified mode
	UFUNCTION(BlueprintCallable, Category = "Input")
	void SetGameInput(EGameInputTypes NewGameInputType);

	//Checks if this character is in the game input type
	UFUNCTION(BlueprintPure, Category = "Input")
	bool IsInGameInput() const;

	//Checks if this character is in the UI input type
	UFUNCTION(BlueprintPure, Category = "Input")
	bool IsInUIInput() const;



//Inputs from CharacterBase
protected:
	virtual void InputAction_Fire_Pressed() override;
	virtual void InputAction_Fire_Released() override;

	virtual void InputAction_Aim_Pressed() override;
	virtual void InputAction_Aim_Released() override;

	virtual void InputAction_Interact_Pressed() override;
	virtual void InputAction_Interact_Released() override;

	virtual void InputAction_Flashlight_Pressed() override;
	virtual void InputAction_Flashlight_Released() override;

	//Turns on the flashlight, no SFX
	UFUNCTION(BlueprintCallable)
	void TurnOnFlashlight();

	//Turns off the flashlight, no SFX
	UFUNCTION(BlueprintCallable)
	void TurnOffFlashlight();

	virtual void InputAction_Reload_Pressed() override;
	virtual void InputAction_Reload_Released() override;

	virtual void InputAction_Jet_Pressed() override;
	virtual void InputAction_Jet_Released() override;

	virtual void InputAction_Ascend_Pressed() override;
	virtual void InputAction_Ascend_Released() override;

	virtual void InputAction_Descend_Pressed() override;
	virtual void InputAction_Descend_Released() override;

	virtual void InputAction_Inventory_Pressed() override;
	virtual void InputAction_Inventory_Released() override;

	virtual void InputAction_Map_Pressed() override;
	virtual void InputAction_Map_Released() override;

	virtual void InputAction_AttachmentOne_Pressed() override;
	virtual void InputAction_AttachmentOne_Released() override;

	virtual void InputAction_AttachmentTwo_Pressed() override;
	virtual void InputAction_AttachmentTwo_Released() override;

	virtual void InputAction_AttachmentThree_Pressed() override;
	virtual void InputAction_AttachmentThree_Released() override;

	virtual void InputAction_AttachmentFour_Pressed() override;
	virtual void InputAction_AttachmentFour_Released() override;

	virtual void InputAxis_LSVertical(float AxisValue) override;
	virtual void InputAxis_LSHorizontal(float AxisValue) override;

	virtual void InputAxis_RSVertical(float AxisValue) override;
	virtual void InputAxis_RSHorizontal(float AxisValue) override;

	virtual void InputAxis_MouseVertical(float AxisValue) override;
	virtual void InputAxis_MouseHorizontal(float AxisValue) override;

	virtual void InputAxis_MouseWheel(float AxisValue) override;
	
////////////////////////////////////////////////////////////////////// INPUT


////////////////////////////////////////////////////////////////////// COMPONENTS
public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	USpringArmComponent* HeadSpringArm;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	USpringArmComponent* FlashLightSpringArm;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	UCameraComponent* HeadCamera;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	USpotLightComponent* FlashLight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	USpotLightComponent* BounceLight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	UPhysicsConstraintComponent* BodyPhysicsComp;

	//A VFX container for any VFX on the player
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Audio, meta = (AllowPrivateAccess = "true"))
	USceneComponent* VFXContainer;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Audio, meta = (AllowPrivateAccess = "true"))
	UParticleSystemComponent* BubblesVFX_Left;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Audio, meta = (AllowPrivateAccess = "true"))
	UParticleSystemComponent* BubblesVFX_Right;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Dust, meta = (AllowPrivateAccess = "true"))
	UParticleSystemComponent* AmbientDust;
////////////////////////////////////////////////////////////////////// COMPONENTS


////////////////////////////////////////////////////////////////////// DELEGATES
public:
	//Update the distance to the signal
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnSignalDistanceUpdated OnSignalDistanceUpdated;

	//Show interact targeting
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnShowInteractTargeting OnShowInteractTargeting;

	//Hide interact targeting
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnHideInteractTargeting OnHideInteractTargeting;

	//Called when we refill oxygen
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnRefilledOxygen OnRefilledOxygen;

	//Display the medium O2 warning in the UI
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnDisplayMediumO2WarningUI OnDisplayMediumO2WarningUI;

	//Display the low O2 warning in the UI
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnDisplayLowO2WarningUI OnDisplayLowO2WarningUI;

	//Delegate for when the character's suffocation updates
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnCharacterUpdateSuffocationUI OnCharacterUpdateSuffocationUI;

	//Display the suffocation warning in the UI
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnDisplaySuffocationWarningUI OnDisplaySuffocationWarningUI;

	//Called when a cinematic starts for this player
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnCinematicStarted OnCinematicStarted;

	//Called when a cinematic ends for this player
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnCinematicEnded OnCinematicEnded;

	//Called when a projectile is shot from the harpoon gun
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnShotProjectile OnShotProjectile;

	//Called when the player begins a long interact
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnPlayerBeginLongInteract OnPlayerBeginLongInteract;

	//Called when the player ends a long interact
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnPlayerEndLongInteract OnPlayerEndLongInteract;
////////////////////////////////////////////////////////////////////// DELEGATES



////////////////////////////////////////////////////////////////////// CONFIG
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	bool bShowDebugTraces;
////////////////////////////////////////////////////////////////////// CONFIG












	




	


	



/*
 *	+-------------------------------+
 *	| SUBSYSTEM => GENERAL			|
 *	+-------------------------------+
 */
 ////////////////////////////////////////////////////////////////////// AUXILIARY
protected:
	void Tick_Other(const float DeltaSeconds);

public:
	// Boolean indicator for flashlight
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Gamepla y")
	bool bFlashlight = true;
	// O2 for the oxygen tank
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float CurrentO2Time;
	// Max O2 for the oxygen tank
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gameplay")
	float MaxO2Time;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bIsO2Refilling;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float O2RefillRate;
	UPROPERTY(BlueprintAssignable, Category = "Gameplay")
	FNoParamDelegate OnO2RefillComplete;
	UFUNCTION(BlueprintCallable, Category = "Gameplay") FORCEINLINE
	bool InitiateO2Refill(const float RefillRate) { O2RefillRate = RefillRate; bIsO2Refilling = true; return true; }
	UFUNCTION(BlueprintCallable, Category = "Gameplay") FORCEINLINE
	bool CancelO2Refill() { bIsO2Refilling = false; return true; }

	//Refills an amount of oxygen to the character
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void RefillOxygen(int32 RefillAmount);

	//Refills all oxygen to the character
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void RefillAllOxygen();

	//Depletes all oxygen for the character
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void DepleteAllOxygen();

	//The time that we play the medium oxygen warning
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float MediumO2WarningTime;
	//Have we displayed the medium O2 warning?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bDisplayedMediumO2Warning;
	//The time that we play the low oxygen warning
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float LowO2WarningTime;
	//Have we displayed the low O2 warning?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bDisplayedLowO2Warning;

	//The current time until we receive suffocation damage
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float CurrentSuffocationTime;
	//The time it takes to take suffocation damage after losing all of our oxygen
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gameplay")
	float MaxSuffocationTime;
	//Have we displayed the suffocation warning?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bDisplayedSuffocationWarning;

	//Handles the O2 changes
	void HandleO2(const float DeltaSeconds);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Gameplay")
	UCurveFloat* GaspCurve;
	//Can this character move right now?
	FORCEINLINE bool CanMove() const override { return !bInteracting; }

	//Can this character change look directions right now?
	UFUNCTION(BlueprintPure, Category = "Movement")
	FORCEINLINE bool CanLook() const { return !bInteracting; }

	//Can this character sprint/jet boost right now?
	UFUNCTION(BlueprintPure, Category = "Movement")
	FORCEINLINE bool CanSprint() const { return !bInteracting; }


	//Receives damage
	virtual void ReceiveDamage(int32 DamageReceived) override;


	//The location of the signal
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Signal")
	FVector SignalLocation;

	//The time between updates that we update the signal
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Signal")
	float SignalUpdateTimeSeconds;

	//Timer handle for updating the signal
	UPROPERTY()
	FTimerHandle UpdateSignalTimerHandle;

	//Updates the distance to the signal
	UFUNCTION(BlueprintCallable, Category = "Signal")
	void UpdateDistanceToSignal();
////////////////////////////////////////////////////////////////////// AUXILIARY


////////////////////////////////////////////////////////////////////// STATE
protected:
	//If the player has infinite oxygen right now
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "State")
	bool bInfiniteOxygen;

public:
	//Sets the infinite oxygen state
	UFUNCTION(BlueprintCallable, Category = "State")
	void SetInfiniteOxygen(bool bNewInfiniteOxygen);

	//Can this character sprint/jet boost right now?
	UFUNCTION(BlueprintPure, Category = "State")
	FORCEINLINE bool HasInfiniteOxygen() const { return bInfiniteOxygen; }
////////////////////////////////////////////////////////////////////// STATE




	
////////////////////////////////////////////////////////////////////// TRACE
public:
	UFUNCTION(BlueprintCallable)
		void AddActorToIgnoreInInteractableTrace(AActor* IgnoredActor);
protected:
	//Does a line trace for an interactable objec
	void TraceForInteractable();
	
	UPROPERTY()
	TArray<AActor*> IgnoredActorsInInteractableTrace;
////////////////////////////////////////////////////////////////////// TRACE








////////////////////////////////////////////////////////////////////// WEAPONS
public:
	UPROPERTY(BlueprintReadOnly, Category = "Weapons")
	bool bIsADS;

	UPROPERTY(BlueprintReadOnly, Category = "Weapons")
	bool bIsFiringPrimary;

	UPROPERTY(BlueprintReadOnly, Category = "Weapons")
	bool bHasHarpoonGun;

	UPROPERTY(BlueprintReadOnly, Category = "Hiding")
	bool bHidesInLocker = false;

	UPROPERTY(BlueprintReadWrite, Category = "Hiding")
	bool bCanHideInLocker = true;

	//Dynamic cross hair tick logic
	void Tick_DynamicCrossHair();

protected:
	//The harpoon weapon for this character
	UPROPERTY(BlueprintReadWrite, Category = "Weapons")
	AANWeaponHarpoon* HarpoonWeapon;

	//The spread modifier for the crosshair
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Crosshair")
	float CrosshairSpreadModifier;

	//The max modifier for the crosshair that we will clamp to
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Crosshair")
	float CrosshairMaxSpread;


public:
	//Gets the harpoon gun through blueprints
	UFUNCTION(BlueprintImplementableEvent, BlueprintPure, Category = "Weapons")
	AANWeaponHarpoon* BP_GetHarpoonGun() const;

	//Gets the harpoon weapon
	UFUNCTION(BlueprintPure, Category = "Weapons")
	AANWeaponHarpoon* GetHarpoonWeapon() const { return HarpoonWeapon; };

	//If this player does have the harpoon gun
	UFUNCTION(BlueprintPure, Category = "Weapons")
	FORCEINLINE bool DoesHaveHarpoonGun() const { return bHasHarpoonGun; };

	//Sets the player having the harpoon gun
	UFUNCTION(BlueprintCallable, Category = "Weapons")
	void SetHasHarpoonGun(bool bNewHasHarpoonGun);

	//Starts ADS
	UFUNCTION(BlueprintCallable, Category = "Weapons")
	void StartADS();

	//Ends ADS
	UFUNCTION(BlueprintCallable, Category = "Weapons")
	void EndADS();

	//Fires the player's weapon
	UFUNCTION(BlueprintCallable, Category = "Weapons")
	void FireWeapon();

	//Notifies the player that the weapon was fired and shot a specific projectile
	UFUNCTION(BlueprintCallable, Category = "Weapons")
	void NotifyWeaponFired(AANBaseProjectile* FiredProjectile);
////////////////////////////////////////////////////////////////////// WEAPONS



////////////////////////////////////////////////////////////////////// WATCH
protected:
	//Whether or not we are viewing the watch right now
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Watch")
	bool bViewingWatch;

public:
	//Starts to look at the player's watch
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Watch")
	void StartViewWatch();

	//Ends looking at the player's watch
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Watch")
	void EndViewWatch();
////////////////////////////////////////////////////////////////////// WATCH

	

	

////////////////////////////////////////////////////////////////////// MOVEMENT
private:
	UCharacterMovementComponent* MyCharacterMovement;
	virtual void OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode) override;
public:
	UPROPERTY(BlueprintReadOnly, Category = "Movement: General")
	bool bIsSprinting = false;

//Movement Functions
public:
	//Kills/stops all active things like movement/ADS
	UFUNCTION(BlueprintCallable, Category = "Movement")
	void KillActiveInputs(bool bZeroOutVelocity);

	//Kills/stops all movement
	UFUNCTION(BlueprintCallable, Category = "Movement")
	void KillMovement(bool bZeroOutVelocity);

	//Kills/stops firing/ADS
	UFUNCTION(BlueprintCallable, Category = "Movement")
	void KillFire();

protected:
	void MoveForward(const float input);
	void MoveRight(const float input);
	void MoveUp(const float input);

	void LookRight_Mouse(const float AxisValue);
	void LookRight_Controller(const float AxisValue);
	void LookRightInternal(const float Value);
	void LookUp_Mouse(const float AxisValue);
	void LookUp_Controller(const float AxisValue);
	void LookUpInternal(const float Value);

	void StartJetBoost();
	void EndJetBoost();

	UPROPERTY(BlueprintReadOnly, Category = "Movement")
	FVector NetMovementVector = FVector::ZeroVector;
	UPROPERTY(BlueprintReadOnly, Category = "Movement")
	FVector JetMovementVector = FVector::ZeroVector;

private:
	FVector MoveForwardInput = FVector::ZeroVector;
	FVector MoveRightInput = FVector::ZeroVector;
	FVector MoveUpInput = FVector::ZeroVector;
	


	
// Swimming
private:
	float CurrentSwimRate;
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement: Swimming")
	UCurveFloat* SwimRateCurve;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement: Swimming")
	FVector2D SwimSpeedRange;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement: Swimming")
	FVector2D SwimForceResetTime;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement: Swimming", meta = (ClampMin = "0.1", ClampMax = "5.0"))
	float JetAcceleration;
	
	UPROPERTY(BlueprintReadOnly, Category = "Movement: Swimming")
	float SwimForceTime = 0.f;
	UPROPERTY(BlueprintReadOnly, Category = "Movement: Swimming")
	float CurrentSwimForceResetTime;

private:
	void Tick_SwimmingMovement(const float DeltaSeconds);

	
// Walking
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Movement: Walking")
	FVector2D WalkSpeedRange;

private:
	void Tick_WalkingMovement(const float DeltaSeconds);
	bool bIsOnLand = false;

	// Ragdoll control
public:
	UFUNCTION(BlueprintCallable, Category = "Movement")
	void SetBodyPhysicsState(const bool bIsArmed);
////////////////////////////////////////////////// Camera
public:
	UCameraShake* UnderWaterCameraShake;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera")
	TSubclassOf<UCameraShake> UnderWaterCameraShakeClass;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera")
	float CameraSensitivity;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera", meta = (ClampMin = 0.0, ClampMax = 1.0))
	float CameraAcceleration = 1.f;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera")
	bool bHeadBobbingEnabled = true;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera", meta = (EditCondition = "bHeadBobbingEnabled"))
	float HeadBobbingMultiplier = 1.f;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Camera", meta = (EditCondition = "bHeadBobbingEnabled"))
	float HeadBobbingSpeed = 1.f;
	

	UPROPERTY(BlueprintReadOnly, Category = "Camera")
	FVector2D CameraRotationRate = FVector2D::ZeroVector;

	// Focus
	AActor* FocusTarget;
	UFUNCTION(BlueprintCallable, Category = "Camera") FORCEINLINE
	bool SetCameraFocus(AActor* TargetActor) { FocusTarget = TargetActor; return TargetActor == nullptr; }
	
private:
	FVector CameraZRotVector;
	FVector LastCameraForwardVector;
	
	void Tick_Camera(const float DeltaSeconds);
////////////////////////////////////////////////// Camera
	void Tick_LockerCheck(const float DeltaSeconds);
////////////////////////////////////////////////////////////////////// MOVEMENT













	
////////////////////////////////////////////////////////////////////// INTERACTION
//Interactable Variables
public:

protected:
	//The range in front of the character that we can interact with objects
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Interaction")
	float InteractionRange;

	//The interactable object we are currently looking at
	//UPROPERTY is invalid for interfaces
	IANInteractable* CurrentLookingAtInteractable;

	//The interactable object we are currently interacting with
	//UPROPERTY is invalid for interfaces
	IANInteractable* CurrentInteractingInteractable;

	//If we are currently interacting with something
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Interaction")
	bool bInteracting;

//Interactable Functions
public:
	//Attempts to interact with an object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	void TryInteract();

	//Manually sets and interacts with an object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	void ManualInteract(TScriptInterface<IANInteractable> objectToInteract);

	//Attempts to end interacting with an object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	void TryEndInteract();

	//Attempts to go back/cancel
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	void TryGoBack();

	//Returns true if we are interacting with an object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	FORCEINLINE bool IsInteracting() const { return bInteracting; };

	//Gets the object that we are currenly interacting with
	IANInteractable* GetCurrentInteractingInteractable() const { return CurrentInteractingInteractable; };

	//If we can start or end interacting
	UFUNCTION(BlueprintPure, Category = "Interaction")
	bool CanStartEndInteract() const;


	UFUNCTION(Category = "Interaction")
	void PutInLocker(UCameraComponent* LockerCamera);

	UFUNCTION(Category = "Interaction")
	void RemoveFromLocker(UCameraComponent* LockerCamera);


////////////////////////////////////////////////////////////////////// INTERACTION


////////////////////////////////////////////////////////////////////// INVENTORY
//Inventory Variables
public:
	//Is the inventory open?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	bool bInventoryOpen;

	//The offset for dropping items in front of the player
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	FVector DropItemOffset;


//Inventory Functions
public:
	//Opens the player's inventory
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void OpenInventory(EANInventoryModes OpenInventoryMode);

	//Closes the player's inventory
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void CloseInventory();

	//Opens the player's inventory manually, used when checking items
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void OpenManualInventory();

	//Closes the player's inventory manually, used when checking items
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void CloseManualInventory();

	//If we can open/close the inventory right now
	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool CanOpenCloseInventory() const;
////////////////////////////////////////////////////////////////////// INVENTORY



////////////////////////////////////////////////////////////////////// INFORMATION/MAP
//Information/Map Variables
public:
	//Is the information panel/map open?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Information")
	bool bInformationOpen;

//Information/Map Functions
public:
	//Opens the information panel/map
	UFUNCTION(BlueprintCallable, Category = "Information")
	void OpenInformation();

	//Closes the information panel/map
	UFUNCTION(BlueprintCallable, Category = "Information")
	void CloseInformation();

	//Opens the information panel/map manually, used in most cases
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void OpenManualInformation();

	//Closes the information panel/amp manually, used in most cases
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void CloseManualInformation();

	//If we can open/close the information panel/map right now
	UFUNCTION(BlueprintPure, Category = "Information")
	bool CanOpenCloseInformation() const;
////////////////////////////////////////////////////////////////////// INFORMATION/MAP


	

////////////////////////////////////////////////////////////////////// ITEMABLE
//Itemable Functions
public:
	//Selects an item and performs a function based on inventory mode
	UFUNCTION(BlueprintCallable, Category = "Itemable")
	bool SelectItem(const FString& SelectedItem, EANInventoryModes InventoryMode);

	//Attempts to insert an item into the current interactable/itemable object
	UFUNCTION(BlueprintCallable, Category = "Itemable")
	bool InsertItem(const FString& InsertedItem);

	//Attempts to use an item
	UFUNCTION(BlueprintCallable, Category = "Itemable")
	bool UseItem(const FString& UsedItem);

	//Attempts to drop an inventory item
	bool DropInventoryItem(FANItem* DroppedInventoryItem);

	void InspectInventoryItem(FANItem* InspectedItem);

	//Attempts to use inventory item
	bool UseInventoryItem(FANItem* UsedInventoryItem);

////////////////////////////////////////////////////////////////////// ITEMABLE






	

////////////////////////////////////////////////////////////////////// AUDIO
public:
	//The sound event for the swim stroke
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* SwimStrokeSFX;

	//The sound event for starting the jet
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* JetBoostStartSFX;

	//The sound event for looping the jet
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* JetBoostLoopSFX;

	//The sound event for stopping the jet
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* JetBoostStopSFX;

	//The sound event for turning on the flashlight
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* FlashlightOnSFX;

	//The sound event for turning on the flashlight
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* FlashlightOffSFX;

	//The sound event for opening the inventory directly to the inventory
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* OpenInventoryDirectSFX;

	//The sound event for opening the inventory when at a puzzle
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* OpenInventoryPuzzleSFX;

	//The sound event for closing the inventory
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* CloseInventorySFX;

	//The sound event for opening the map/information panel
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* OpenInformationSFX;

	//The sound event for closing the map/information panel
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* CloseInformationSFX;

	//The sound event for when O2 is refilled.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* RefillO2SFX;

	//The sound event for when O2 is okay. Call this to reset the other warning SFX.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* StandardO2SFX;

	//The sound event for medium levels of oxygen
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* MediumO2WarningSFX;

	//The sound event for low oxygen
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* LowO2WarningSFX;

	//The sound event for depleted oxygen
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* SuffocationWarningSFX;

////////////////////////////////////////////////////////////////////// AUDIO


////////////////////////////////////////////////////////////////////// RUMBLE
public:
	//The sound event for depleted oxygen
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Rumble")
	UForceFeedbackEffect* OpenInventoryRumbleEffect;

////////////////////////////////////////////////////////////////////// RUMBLE


////////////////////////////////////////////////////////////////////// HELPER
//Helper Functions
public:
	virtual void PreventPauseIssues() override;

	//Gets the player controller base
	UFUNCTION(BlueprintPure, Category = "Helpers")
	AANPlayerControllerBase* GetPlayerControllerBase() const;

	//Gets the inventory system
	UFUNCTION(BlueprintPure, Category = "Helpers")
	UANInventorySystem* GetInventorySystem() const;
////////////////////////////////////////////////////////////////////// HELPER

	/** Global time dilation*/
public:
	UFUNCTION(BlueprintCallable, Category = "Time")
	void ChangeWorldTime(float Time);

	/** Sets the global dilation to 0 or 1 based on the toggle*/
	UFUNCTION(BlueprintCallable, Category = "Time")
	void FreezeTime(bool bToggleFreeze);
};
