// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"

#include "AI/Helpers/ANSecondaryNavData.h"
#include "Engine/TargetPoint.h"

#include "ANEnums.h"
#include "ANStructs.h"

#include "Interface/ANWorldSaveable.h"

#include "ANSecondaryEnemy.generated.h"

class UAkAudioEvent;
class UAkComponent;

class AANMainCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnDeath);
//NavMesh
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSecondaryMoveToComplete, bool, State);

/**
 * 
 */

class AANSecondaryAINavRoom;
UCLASS()
class UNDERWATER_API AANSecondaryEnemy : public ACharacter, public IANWorldSaveable
{
	GENERATED_BODY()

public:
	AANSecondaryEnemy();

	void BeginPlay() override;
	void Tick(float DeltaTime) override;

	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	bool bShouldUseThread = false;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	int32 Health = 100;
	/// <summary>
	/// This is the distance between the player and the enemy when the AI will be activated.
	/// </summary>
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	float MinDistanceToActivate = 5000.0f;
	
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	TArray<ATargetPoint*> CustomPoints;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	int32 DamageAmount = 30;
	
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings")
	bool bIsSpeedBoost = false;

	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings")
	bool bIsPlayerInRange = false;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings")
	AANMainCharacter* LockedTarget = nullptr;
	UPROPERTY(BlueprintReadOnly)
	bool bIsAlive = true;


	//Animation states 
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Animation", EditAnywhere)
	ESecondaryEnemyState CurrentAnimState = ESecondaryEnemyState::Idle;

	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings", EditAnywhere)
	bool HasAttacked = false;

	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings|Movement", EditAnywhere)
	float Speed = 300;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings|Movement", EditAnywhere)
	float RunAwaySpeedMultiplier = 2;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings|Movement", EditAnywhere)
	float PlayerChaseSpeedMultiplier = 2.5;
	UPROPERTY(BlueprintReadWrite, Category = "Enemy Settings|Movement", EditAnywhere)
	float WaitTimeWhenChasingPlayer = 0.01;
	UPROPERTY(BlueprintReadOnly, Category = "Enemy Settings|Movement", EditAnywhere)
	bool bIsWaiting = false;

	//Editor Settings
	UPROPERTY(BlueprintReadWrite, Category = "Editor Settings", EditAnywhere)
	float RangeToCheckForNavUnit = 300;
	UPROPERTY(BlueprintReadWrite, Category = "Editor Settings", EditAnywhere)
	bool bShowPathDebug = false;
	UPROPERTY(BlueprintReadWrite, Category = "Editor Settings", EditAnywhere)
	FVector ImpluseAmount;

	void TakeDamage(float Amount);



	//The Ak component for posting sound events on this character
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UAkComponent* EnemyAkComponent;

	//The audio event that plays on this enemy at all times
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* PersistentSFX;

	//The audio event that plays when the enemy chases you
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* AggroSFX;

	//The audio event that plays when this enemy dies
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* DieSFX;


	void OnDeath();
	UPROPERTY(BlueprintAssignable)
	FOnDeath Death;
	UPROPERTY(BlueprintReadWrite, BlueprintAssignable)
	FOnSecondaryMoveToComplete OnMoveToComplete;


	//AI settings.
	
	//Gets the closest room data nav to the enemy
	UFUNCTION(BlueprintPure, Category = "Enemy")
	AANSecondaryAINavRoom* GetClosestRoomDataNav() const;

	//Gets the spawn source and assigns the spawn data after a delay
	UFUNCTION()
	void AssignSpawnDataAfterDelay();

	//Gets the spawn source trigger box
	UFUNCTION(BlueprintPure, Category = "Enemy")
	AANAISpawnTriggerBox* GetSpawnSourceTriggerBox() const;

	//Assigns spawn data to this enemy
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void AssignSpawnData(const FAISpawnSettings& NewAISpawnSettings);

	//Sets the spawn source Guid
	UFUNCTION(BlueprintCallable, Category = "Enemy")
	void SetSpawnSourceGuid(const FGuid& NewSpawnSourceGuid);
	
	UFUNCTION(BlueprintCallable)
	bool HasPathToPlayer() const;

	UFUNCTION(BlueprintCallable)
	static bool HasReachedTarget(FVector Location);

	UFUNCTION(BlueprintCallable)
	bool MoveToLocation(FVector Location, float Radius = 50);

	UFUNCTION(BlueprintCallable)
	bool MoveToActor(AActor* Target, float Radius = 200, float UpdateRate = 0.4f);

	UFUNCTION(BlueprintCallable)
	FVector FindRandomPointInNavMesh();

	
	//Ai variables.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	AANSecondaryAINavRoom* RoomDataNav;

	void AI_Tick();

	void CustomTick();
	

	FVector CurrentHeading;
	float TurningRate = 1.0;


//Getters and Setters
public:
	//Gets enemy health
	UFUNCTION(BlueprintCallable, Category = "Health")
	FORCEINLINE int32 GetHealth() const { return Health; };

	//Sets enemy health
	UFUNCTION(BlueprintCallable, Category = "Health")
	void SetHealth(int32 NewHealth) { Health = NewHealth; };


//VFX
protected:
	//VFX to play when taking damage
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX")
	UParticleSystem* BloodVFX;


private:
	bool bHasPath = false;
	bool bHasReachedFinalLocation = false;
	bool bNeedsToMove = false;
	int PathCount = 0;
	int TotalPath = 0;
	TArray<FVector> Path;
	TArray<AANSecondaryNavData> ListOfNAvMesh;
	FVector TargetLocation;
	float M_Radius = 50;

	//Controls the movement Scale for the addmovement input function.
	float MovementScaleValue = 1;

	AActor* ActorToMove = nullptr;

	FTimerHandle CustomTickTimerHandle;
	
	bool MoveToLocationTick(FVector Location, float Radius = 50);



	//this is a custom movement when the AI attacks the player.
	//Moves towards the player at higher speed and stop at a distance and again moves at normal speed.
	void CustomMovementWhenAttacking();
	void ResetMovementWhenAttacking();

	//bool to control the custom movement
	bool bHasStoppedMoving = false;
	float ChaseSpeed;
	float RunAwaySpeed;
	float NormalSpeed;
	bool bISAIStuck = false;
	//timer to reset the movement speed;
	//Can a single Ftimerhandle multiple functions inside it? if so we can remove this and reuse the other timerhandle in this class.
	FTimerHandle ResetMovementTimer;


//WorldSaveable Variables
protected:
	//The Guid for saving this world saveable
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "World Saveable")
	FGuid WorldSaveableGuid;

	//The Guid we use for the spawn source (usually a trigger box)
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Saveable")
	FGuid SpawnSourceGuid;

//WorldSaveable Functions
public:
	virtual void BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign) override;
	virtual bool BP_CanSaveToWorldSaveablesMap_Implementation() override;
	virtual void BP_UpdateWorldSaveableState_Implementation() override;
	virtual FGuid BP_GetWorldSaveableGuid_Implementation() override;
	virtual FWorldSaveableData BP_GetWorldSaveableData_Implementation() override;
	virtual FString BP_ConstructSaveableParamsString_Implementation() override;
};
