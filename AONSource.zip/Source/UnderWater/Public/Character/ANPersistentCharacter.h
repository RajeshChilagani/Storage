// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"
#include "AI/Helpers/NavUserCharacter.h"
#include "GameFramework/Character.h"
#include "ANPersistentCharacter.generated.h"

class UAkAudioEvent;
class UAkComponent;
class UParticleSystem;

UENUM(BlueprintType)
enum class EEnemyState : uint8
{
	FreeRoam = 0		UMETA(DisplayName = "Free Roam"),
	Chase = 1			UMETA(DisplayName = "Chase"),
	Investigate = 2		UMETA(DisplayName = "Investigate"),
	VentBait = 3		UMETA(DisplayName = "Vent Bait"),
	Stunned = 4			UMETA(DisplayName = "Stunned"),
	Rage = 5			UMETA(DisplayName = "Rage"),
	Attack_Swing = 6	UMETA(DisplayName = "Swing Attack"),
	Attack_Throw = 7	UMETA(DisplayName = "Throw Attack")
};

UENUM(BlueprintType)
enum class EBattlePhase : uint8
{
	None,
	BattleBegin,
	BattleRage,
	BattleFury
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOneParamDelegate, EEnemyState, AttackState);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnBattlePhaseChanged, EBattlePhase, FinalBattlePhase);

UCLASS()
class UNDERWATER_API AANPersistentCharacter : public ANavUserCharacter
{
	GENERATED_BODY()

////////////////////////////////////////////////////////////////////// CORE
public:
	AANPersistentCharacter();


	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
protected:
	virtual void BeginPlay() override;

public:
	//Spawns the baddy
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Spawn")
	void BP_Spawn(FVector SpawnLocation, FRotator SpawnRotation);

	//Unspawns the baddy
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Spawn")
	void BP_Unspawn();

public:
	UPROPERTY(EditAnywhere, Category = "Debug")
	bool bShowDebugVision = true;
////////////////////////////////////////////////////////////////////// CORE








////////////////////////////////////////////////////////////////////// STATE CONTROL
public:
	UPROPERTY(BlueprintReadWrite, Category = "State Control")
	EEnemyState EnemyState;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "State Control")
	float FullAlertnessThreshold = 0.8f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "State Control")
	float FullAlertnessDropThreshold = 0.6f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "State Control")
	float InvestigateStateAlertnessThreshold = 0.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "State Control")
	float ChaseStateAlertnessThreshold = 0.98f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "State Control")
	float AttackDistanceThreshold = 0.98f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "State Control")
	TArray<ARoom*> SelectedPatrolRooms;

	UPROPERTY(BlueprintAssignable, Category = "State Control")
	FOneParamDelegate OnAttackStateEngaged;

	UPROPERTY(BlueprintReadWrite, Category = "State Control")
	bool bIsEngaging = false;

	UFUNCTION(BlueprintCallable, Category = "State Control")
	void SetPersistence(const bool value) { bIsPersistent = value; }

	UFUNCTION(BlueprintCallable, Category = "State Control")
	bool GetIsPersistent() { return bIsPersistent; }

	UFUNCTION(BlueprintCallable, Category = "State Control")
	bool GetIsBehaviorActive() const;

	UFUNCTION(BlueprintCallable, Category = "State Control")
	void ForceSetAlertness(const float value) { Alertness = FMath::Clamp(value, 0.f, 1.f); }

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float TargetChaseSpeed;

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	float TargetTurnSpeed;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	float BaseChaseSpeed = 200.f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	float BaseTurnSpeed = 3.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bEnableBaddySpawning = false;

protected:
	void Tick_StateControl(const float DeltaTime);

private:
	bool bIsPersistent = false;
////////////////////////////////////////////////////////////////////// STATE CONTROL









////////////////////////////////////////////////////////////////////// VISION
public:
	UPROPERTY(BlueprintReadOnly, Interp, Category = "Vision")
	float Alertness = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float VisionConeAngle = 20.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float VisionConeRange = 20.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float VisionAngleGamma = 20.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float VisionRangeGamma = 20.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision", meta = (EditCondition = "bShowDebugVision"))
	FColor VisionMinColor = FColor::Cyan;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision", meta = (EditCondition = "bShowDebugVision"))
	FColor VisionMaxColor = FColor::Orange;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision", meta = (EditCondition = "bShowDebugVision"))
	float AlertnessGainThreshold = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float AlertnessGainRate = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float AlertnessDropRate = 1.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float PlayerSpeedThreshold = 200.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	float PlayerFlashlightGainMultiplier = 200.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vision")
	bool bCanSeePlayer = false;

	UPROPERTY(BlueprintReadWrite, Category = "Vision")
	FVector PlayerLastSeenLocation;
	
private:
	void Tick_Vision(const float DeltaTime);
////////////////////////////////////////////////////////////////////// VISION
	







////////////////////////////////////////////////////////////////////// MOVEMENT
private:
	class AANMainCharacter* PlayerPawn = nullptr;
protected:
	void Tick_CharacterControl(const float DeltaTime);
////////////////////////////////////////////////////////////////////// MOVEMENT
	






////////////////////////////////////////////////////////////////////// ANIM
public:
	UPROPERTY(BlueprintReadWrite, Interp, Category = "Anim")
	bool bShouldLookAtPlayer = false;

	UPROPERTY(BlueprintReadWrite, Interp, Category = "Anim")
	bool bShouldChildLookAtPlayer = false;

	UPROPERTY(BlueprintReadWrite, Category = "Anim")
	float ChildLookAlertnessThreshold = 0.05f;

	UPROPERTY(BlueprintReadWrite, Category = "Anim")
	float MainLookAlertnessThreshold = 0.2f;

	UPROPERTY(BlueprintReadWrite, Category = "Anim")
	bool bShouldFacePlayer = false;

	UPROPERTY(EditAnywhere, Category = "Anim")
	UAnimMontage* HitReactMontage;

	UPROPERTY(EditAnywhere, Category = "Anim")
	UAnimMontage* ShortRageMontage;
////////////////////////////////////////////////////////////////////// ANIM


//SFX
protected:
	//The Ak component for posting sound events on this character
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UAkComponent* EnemyAkComponent;

	//The audio event that plays on this enemy at all times
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* PersistentSFX;

	//The audio event that plays when the enemy chases you
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* AggroSFX;

	//The audio event that plays when the enemy rages
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* RageSFX;

	//The audio event that plays when the enemy gets hit
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* GetHitSFX;

	//The audio event that plays when the enemy dies
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "SFX")
	UAkAudioEvent* DieSFX;


//VFX
protected:
	//VFX to play when taking damage
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX")
	UParticleSystem* BloodVFX;


//Pawn
public:
	virtual float TakeDamage(float Damage, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;

//Gameplay
public:
	UPROPERTY(EditAnywhere, BlueprintReadwrite, meta = (ClampMin = "0.0", ClampMax = "100.0"))
	float Health = 100.f;

//Final Battle
public:
	UFUNCTION(BlueprintCallable)
	void BeginFinalBattle();

protected:
	UFUNCTION(BlueprintCallable)
	void Stun();
	
	UFUNCTION(BlueprintCallable)
	void UnStun();

	UFUNCTION(BlueprintCallable)
	void ClearUnStunTimer();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void OnStunned();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void OnUnStunned();

	/**Timer to check if baddy has to be stunned */
	FTimerHandle StunCheckTimer;

	/**Time in seconds to check for stun damage */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBattle")
	float BaseStunCheckTimeInSeconds = 10.f;

	/**Time in seconds to check for stun damage */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "FinalBattle")
	float StunCheckTimeInSeconds;

	/**Timer to unstun baddy after the provided stun time */
	FTimerHandle UnStunTimer;

	/**Time in seconds to Unstun baddy*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBattle")
	float StunTimeInSeconds = 20.f;

	/**Current stun damage. Used to stun baddy when reached a target damage */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (ClampMin = "0.0", ClampMax = "300.0"))
	float StunDamage = 0.f;

	/**TargetStunDamage to stun baddy */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (ClampMin = "100.0", ClampMax = "300.0"))
	float TargetStunDamage = 100.f;

	UPROPERTY(BlueprintAssignable)
	FOnBattlePhaseChanged OnFinalBattlePhaseChanged;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	EBattlePhase FinalBattlePhase = EBattlePhase::None;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBattle")
	float BattleRageMul = 1.5f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBattle")
	float BattleFuryMul = 2.5f;

	UFUNCTION(BlueprintCallable)
	void SetBattlePhase(EBattlePhase NewBattlePhase);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void OnTakingDamage();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void OnDeath();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBattle")
	bool bUnstunOnExplosion = false;

	UPROPERTY()
	class UANPersistentAIHealthWidget* HealthWidget;
private:
	UFUNCTION()
	void UpdateBattleProperties();

	UPROPERTY(VisibleAnywhere)
	float BaseStunDamage = 100.f;


};
