// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "ANPersistentAIController.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPersistentAIController : public AAIController
{
	GENERATED_BODY()

public:
	AANPersistentAIController();

////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK
protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaTime) override;
////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK





////////////////////////////////////////////////////////////////////// CONTROL
public:
	UFUNCTION(BlueprintCallable, Category = "Control")
	void BehaviorSetActive(const bool bEnable = true);
////////////////////////////////////////////////////////////////////// CONTROL
	




	
////////////////////////////////////////////////////////////////////// COMPONENTS
public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Config)
	UBehaviorTree* PrimaryTree;
////////////////////////////////////////////////////////////////////// COMPONENTS
};
