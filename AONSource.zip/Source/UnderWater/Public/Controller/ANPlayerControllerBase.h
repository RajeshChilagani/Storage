// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"

#include "ANEnums.h"
#include "ANStructs.h"

#include "ANPlayerControllerBase.generated.h"

class IANSelectable;

class UANDialogueManagerComponent;
class UANHUDWidget;
class UANHUDWidgetBase;
class UANMessagesHUDWidget;
class UANSettingsHUDWidget;

struct FSelectableRow;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPlayerControllerBase : public APlayerController
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANPlayerControllerBase();

	virtual void Tick(float DeltaSeconds) override;
	virtual void SetupInputComponent() override;

//Components
protected:
	//Component for managing dialogue
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	UANDialogueManagerComponent* DialogueManager;


//Initialization Functions
public:
	//Creates the HUD for the player controller on the client.
	UFUNCTION(Client, Reliable, Category = "HUD")
	void Client_CreateHUD();
	virtual void Client_CreateHUD_Implementation();
	//Creates the HUD.
	UFUNCTION(BlueprintImplementableEvent, Category = "HUD")
	void CreateHUD();


//Input Variables
protected:
	//The input mode/type the player is in (game, UI, or game and UI)
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Input")
	EGameInputTypes InputType;

	//The current selectable that we are hovering over in the world
	IANSelectable* CurrentCursorWorldSelectable;

//Input Functions
public:
	//Looks for a selectable object under the mouse
	void TraceCursorForSelectable();

	//Attempts to click the cursor
	void TryCursorClick();

	//Sets the input mode to the specified type. Includes mouse and other UI adjustments.
	UFUNCTION(BlueprintCallable, Category = "Input")
	void SetGameInput(EGameInputTypes NewGameInputType);

	//Sets the game input mode after a short delay. Used for avoiding same-frame input calls of the opposite mode
	void SetGameInputAfterDelay(EGameInputTypes NewGameInputType);

	//Checks if this character is in the game input type
	UFUNCTION(BlueprintPure, Category = "Input")
	bool IsInGameInput() const;

	//Checks if this character is in the UI input type
	UFUNCTION(BlueprintPure, Category = "Input")
	bool IsInUIInput() const;

protected:
	//Unhighlights the active selectable
	void UnhighlightSelectable();

	//Unhighlights the gamepad selectable
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void UnhighlightGamepadSelectable();

	//Note: This CANNOT be a UFUNCTION
	/*Adds a custom input binding. This is used when wanting to parameterize an input.*/
	void AddCustomInput(FInputActionHandlerSignature& ActionHandler, FName ActionName, EInputEvent InputEvent, bool bExecuteWhenPaused);

	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void LSVerticalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void LSHorizontalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void RSVerticalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void RSHorizontalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void MouseVerticalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void MouseHorizontalInput_Axis(float AxisValue);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	void MouseWheelInput_Axis(float AxisValue);

	UFUNCTION(BlueprintCallable, Category = "Inputs")
	virtual void SendAxis(EANInputAxes InputAxis, float AxisValue, EGameInputTypes CheckGameInputType);

	UFUNCTION(BlueprintCallable, Category = "Inputs")
	virtual void SendInput_Pressed(EANInputActions InputAction, EGameInputTypes CheckGameInputType);
	UFUNCTION(BlueprintCallable, Category = "Inputs")
	virtual void SendInput_Released(EANInputActions InputAction, EGameInputTypes CheckGameInputType);

	//Checks if the input is in the proper type, aka, if we are a UI input, if need to be in a UI type
	bool IsInputInProperType(EGameInputTypes CheckGameInputType);

	bool IsInputInGameType(EGameInputTypes CheckGameInputType);

	bool IsInputInUIType(EGameInputTypes CheckGameInputType);

	bool ShouldExecuteWhenPaused(EGameInputTypes CheckGameInputType) const;


//UI Input Functions
public:
	//Processes the input and attempts to call an action
	void ProcessInput(EANInputActions ANInputAction, EInputEvent InputEvent);

	virtual void InputAction_UIConfirm_Pressed();
	virtual void InputAction_UIConfirm_Released();

	virtual void InputAction_UIBack_Pressed();
	virtual void InputAction_UIBack_Released();

	virtual void InputAction_UISpecialOne_Pressed();
	virtual void InputAction_UISpecialOne_Released();

	virtual void InputAction_UISpecialTwo_Pressed();
	virtual void InputAction_UISpecialTwo_Released();

	virtual void InputAction_UITabRightOne_Pressed();
	virtual void InputAction_UITabRightOne_Released();

	virtual void InputAction_UITabLeftOne_Pressed();
	virtual void InputAction_UITabLeftOne_Released();

	virtual void InputAction_UITabRightTwo_Pressed();
	virtual void InputAction_UITabRightTwo_Released();

	virtual void InputAction_UITabLeftTwo_Pressed();
	virtual void InputAction_UITabLeftTwo_Released();

	virtual void InputAction_UIUp_Pressed();
	virtual void InputAction_UIUp_Released();

	virtual void InputAction_UIDown_Pressed();
	virtual void InputAction_UIDown_Released();

	virtual void InputAction_UIRight_Pressed();
	virtual void InputAction_UIRight_Released();

	virtual void InputAction_UILeft_Pressed();
	virtual void InputAction_UILeft_Released();

	virtual void InputAction_UICursorClick_Pressed();
	virtual void InputAction_UICursorClick_Released();

	virtual void InputAction_Pause_Pressed();
	virtual void InputAction_Pause_Released();

	virtual void InputAction_DebugMenu_Pressed();
	virtual void InputAction_DebugMenu_Released();


//Selectable Variables
protected:
	//An array of arrays of selectables
	TArray<TArray<IANSelectable*>> SelectableRows;
	//The justification for the selectables
	EButtonJustifications SelectableJustification;
	//The rox index of selectables we're on
	int32 RowIndex;
	//The column index of selectables we're on
	int32 ColumnIndex;

//Selectable Functions
public:
	//Assigns a new set of selectables, optionally setting the first column and row index
	void AssignSelectables(TArray<TArray<IANSelectable*>> NewSelectableRows, int32 NewRowIndex = INDEX_NONE, int32 NewColumnIndex = INDEX_NONE);

	////Assigns a new set of selectables
	//UFUNCTION(BlueprintCallable, Category = "Selectable")
	//void AssignScriptInterfaceSelectables(TArray<TArray<TScriptInterface<IANSelectable>>> NewSelectableRows);

	//Clears all current selectables
	UFUNCTION(BlueprintCallable, Category = "Selectable")
	void ClearSelectables();

	//Increments the selectable index by a specified column and row increase
	UFUNCTION(BlueprintCallable, Category = "Selectable")
	void IncrementSelectableIndex(int32 ColumnIncrease, int32 RowIncrease);

	//Gets the next selected column index. Used when changing rows since rows might not share the same number of items.
	UFUNCTION()
	int32 GetNextSelectedColumnIndex(int CurrentColumnIndex, int NumItemsInOriginalRow, int NumItemsInCurrentRow, EButtonJustifications CheckButtonJustification);

	//Gets the current selectable
	IANSelectable* GetCurrentSelectable();

	//Confirms the current selectable
	UFUNCTION(BlueprintCallable, Category = "Selectable")
	void ConfirmSelectable();

	//Tries to go back, used for cancelling
	UFUNCTION(BlueprintCallable, Category = "Selectable")
	void GoBack();


//Gameplay Variables
public: 

protected:
	//The player's player number. Will probably always be P1, but if we ever implement multiplayer...
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Player")
	EPlayerNumbers PlayerNumber;

	//The player's HUD widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "UI")
	UANHUDWidget* HUDWidget;

	//The player's messages HUD widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "UI")
	UANMessagesHUDWidget* MessagesHUDWidget;

	//An array of active HUD datas. The one with the highest index is the active HUD that we show.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<FActiveHUDData> ActiveHUDDatas;

	//If a data log is active
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Data Log")
	bool bDataLogActive;


private:
	//Used when we are transitioning between input types
	bool bUpdateInputNextTick;

	//The next input type we will use
	EGameInputTypes NextInputType;

//Gameplay Functions
public:
	//Adds a new HUD to the screen and sets it as the active one, hiding the previous one. Also assigns selectables.
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AddNewHUD(UANHUDWidgetBase* NewHUD);

	//Removes the highest HUD and sets the next in line as the active one. Also assigns selectables.
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void RemoveHighestHUD();

	//Shows the data log with the passed in text and pauses the game
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void ShowDataLog(const FText& DataLogText);


//Pause Game Variables
protected:
	//If we are paused. (Separate from gameplay statics since this helps manage the pause menu too.)
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Pause")
	bool bPaused;

	//If we are in a mode that we can pause in
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Pause")
	bool bInPausableMode;

	//The input type we were in before pausing
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Pause")
	EGameInputTypes InputTypeBeforePause;

//Pause Game Functions
public:
	//Called when we press pause
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Pause")
	void BP_PressPause();

	//Pauses the game
	UFUNCTION(BlueprintCallable, Category = "Pause")
	void PauseGame();

	//Unpauses the game
	UFUNCTION(BlueprintCallable, Category = "Pause")
	void UnpauseGame();

	//Toggles the game pause on/off
	UFUNCTION(BlueprintCallable, Category = "Pause")
	void TogglePauseGame();

	//Sets the in pausable mode value
	UFUNCTION(BlueprintCallable, Category = "Pause")
	void SetInPausableMode(bool bNewInPausableMode) { bInPausableMode = bNewInPausableMode; };


//Getters
public:
	//Gets the player's HUD
	UFUNCTION(BlueprintPure, Category = "UI")
	FORCEINLINE UANHUDWidget* GetHUDWidget() const { return HUDWidget; };

	//Gets the player's messages HUD
	UFUNCTION(BlueprintPure, Category = "UI")
	FORCEINLINE UANMessagesHUDWidget* GetMessagesHUDWidget() const { return MessagesHUDWidget; };

	//Gets the active/highest HUD
	UFUNCTION(BlueprintPure, Category = "UI")
	UANHUDWidgetBase* GetActiveHUDWidget() const;

	//Gets the dialogue manager
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE UANDialogueManagerComponent* GetDialogueManager() const { return DialogueManager; };

	//If we are paused
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsPaused() const { return bPaused; };

	//If we are in a mode that we can pause in
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsInPausableMode() const { return bInPausableMode; };

	//If a data log is active
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsDataLogActive() const { return bDataLogActive; };


//Developer Variables
protected:
	//Is the debug menu open?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Developer")
	bool bDebugMenuOpen;

//Developer Functions
public:
	//Toggles the debug menu
	UFUNCTION(BlueprintCallable, Category = "Developer")
	void ToggleDebugMenu();

protected:
	//Toggles the dev tools panel
	UFUNCTION(BlueprintCallable, Category = "Developer")
	void ToggleDevToolsUI();

	//Toggles the screen messages.
	UFUNCTION(BlueprintCallable, Category = "Developer")
	void ToggleAllScreenMessages();

	//Toggles the UI.
	UFUNCTION(BlueprintCallable, Category = "Developer")
	void ToggleUI();

	//Toggles the controls UI.
	UFUNCTION(BlueprintCallable, Category = "Developer")
	void ToggleControlsUI();
};
