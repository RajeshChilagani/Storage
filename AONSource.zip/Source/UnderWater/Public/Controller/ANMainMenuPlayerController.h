// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Controller/ANPlayerControllerBase.h"
#include "ANMainMenuPlayerController.generated.h"

class UANMainMenuHUDWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANMainMenuPlayerController : public AANPlayerControllerBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANMainMenuPlayerController();


//Gameplay Variables
protected:
	//The main menu HUD widget
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	UANMainMenuHUDWidget* MainMenuHUDWidget;

//Gameplay Functions
public:
	//Assigns the selectables on this controller to the main screen's
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignMainScreenSelectables();

	//Assigns the selectables on this controller to the new game screen's
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignNewGameScreenSelectables();
};
