// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Happening/ItemUse/ANItemUseHappening.h"

#include "ANOxygenRecoveryHappening.generated.h"

UCLASS()
class UNDERWATER_API AANOxygenRecoveryHappening : public AANItemUseHappening
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANOxygenRecoveryHappening();


//Gameplay Functions
public:
	virtual void DoHappening_Implementation() override;

};
