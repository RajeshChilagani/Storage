// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Happening/ItemUse/ANItemUseHappening.h"

#include "ANHealthRecoveryHappening.generated.h"

UCLASS()
class UNDERWATER_API AANHealthRecoveryHappening : public AANItemUseHappening
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANHealthRecoveryHappening();


//Gameplay Functions
public:
	virtual void DoHappening_Implementation() override;

};
