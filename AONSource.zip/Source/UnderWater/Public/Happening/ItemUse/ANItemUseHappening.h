// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Happening/ANGenericHappening.h"

#include "ANItemUseHappening.generated.h"

UCLASS()
class UNDERWATER_API AANItemUseHappening : public AANGenericHappening
{
	GENERATED_BODY()

//Unreal Functions
public:
	AANItemUseHappening();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Gameplay Variables
protected:
	//Integer value used for this happening
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	int32 IntegerValue;

	//Float value used for this happening
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	float FloatValue;

	//Text value used for this happening
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	FText TextValue;


//Gameplay Functions
public:
	//Sets the item use parameters for this happening
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetItemUseParameters(int32 NewIntegerValue, float NewFloatValue, const FText& NewTextValue);

	virtual void DoHappening_Implementation() override;

};
