// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANGenericHappening.generated.h"

class UAkAudioEvent;
class USceneComponent;

class AANCharacterBase;
class UANCondition;

UCLASS()
class UNDERWATER_API AANGenericHappening : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANGenericHappening();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;


//Components
protected:
	//The scene component for this happening. Probably will not use this, but we have it just in case.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Components")
	USceneComponent* HappeningSceneComponent;


//Customizable Variables
protected:
	//The audio event to play when the happening starts
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Happening")
	UAkAudioEvent* AudioEventToPlay;

	//A condition that must be met if it is set for this happening to play
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TSubclassOf<UANCondition> ConditionToVerifySubclass;

	//Text that displays when we can't do a happening
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Happening")
	FText UnableToDoHappeningText;


//Gameplay Variables
protected:
	//If this happening is active
	UPROPERTY(VisibleAnywhere, Category = "Gameplay")
	bool bActive;

	//The character who instigated this event
	UPROPERTY(VisibleAnywhere, Category = "Gameplay")
	AANCharacterBase* InstigatingCharacter;

//Gameplay Functions
public:
	//Initialize/set up the happening
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void InitializeHappening(AANCharacterBase* NewInstigatingCharacter);

	//Checks if we can do this happening
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	bool CanDoHappening();

	//Does the desired effect for this happening
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void DoHappening();
	virtual void DoHappening_Implementation();

	//Ends this happening and destroys it
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void EndHappening();


//Getters
public:
	//Gets if this happening is active
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsActive() const { return bActive; };

	//Gets the unable to do happening text
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE FText GetUnableToDoHappeningText() const { return UnableToDoHappeningText; };

};
