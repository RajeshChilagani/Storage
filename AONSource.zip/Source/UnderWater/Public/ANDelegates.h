#pragma once

#include "CoreMinimal.h"

#include "ANEnums.h"
#include "ANDelegates.generated.h"

class AANBaseProjectile;
class AANCharacterBase;
class AANGenericTrigger;
class AANPickableItem;
class AANPuzzleButton;
class UANCarouselWidget;
class UANSelectableWidget;
class UANTutorialTask;

//Character
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCharacterDeath, AANCharacterBase*, DyingCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnRefilledOxygen, AANCharacterBase*, RefillingCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnCharacterUpdateSuffocationUI, AANCharacterBase*, UpdatingCharacter, float, CurrentSuffocationTime, float, MaxSuffocationTime);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnCharacterUpdateHealthUI, AANCharacterBase*, UpdatingCharacter, int32, CurrentHealth, int32, MaxHealth);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDisplayMediumO2WarningUI, AANCharacterBase*, WarningCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDisplayLowO2WarningUI, AANCharacterBase*, WarningCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDisplaySuffocationWarningUI, AANCharacterBase*, WarningCharacter);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnTakeDamageReset);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnShotProjectile, AANBaseProjectile*, ShotProjectile);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPlayerBeginLongInteract);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPlayerEndLongInteract);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDialogueConversationFinished, UANDialogueConversation*, DialogueConversation);

//Cinematics
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnCinematicStarted);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnCinematicEnded);

//Inventory System
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnItemPickedUp, AANPickableItem*, PickableItem);

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnItemAdded, const FString&, ItemName, int32, Count, EAddItemMethods, AddItemMethod);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnItemRemoved, const FString&, ItemName, int32, Count);

//Interactable Targeting
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnShowInteractTargeting);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnHideInteractTargeting);

//Puzzle System
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPuzzleBeginInteract);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPuzzleEndInteract);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnPuzzleComplete, bool, bInstantComplete);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnPuzzleUncomplete);

//Generic Trigger
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnGenericTriggerTriggered, AANGenericTrigger*, GenericTrigger);

//Tutorial
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTutorialTaskStarted, AANTutorialTask*, StartedTask);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTutorialTaskFinished, AANTutorialTask*, FinishedTask);

//UI
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSelectableWidgetConfirmed, UANSelectableWidget*, ConfirmedSelectableWidget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSelectableWidgetHighlighted, UANSelectableWidget*, HighlightedSelectableWidget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSelectableWidgetUnhighlighted, UANSelectableWidget*, UnhighlightedSelectableWidget);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnCarouselIndexChanged, UANCarouselWidget*, ChangedCarouselWidget, int32, PreviousCarouselIndex, int32, NewCarouselIndex);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWorldButtonConfirmed, AANWorldButton*, ConfirmedWorldButton);

//UI - Signal
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnSignalDistanceUpdated, int32, DistanceToSignal);

//WorldNavRoom
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnWorldNavRoomStateChanged, AANWorldNavRoom*, NavRoom, bool, ActiveState);

USTRUCT()
struct FInventoryDelegates
{
	GENERATED_BODY()
};