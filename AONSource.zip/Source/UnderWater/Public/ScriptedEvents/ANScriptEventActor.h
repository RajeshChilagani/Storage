// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANScriptEventActor.generated.h"

class AANScriptedEvent;

UCLASS()
class UNDERWATER_API AANScriptEventActor : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANScriptEventActor();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;
	UFUNCTION(BlueprintImplementableEvent, meta = (DisplayName = "Play"))
	void Play();
	UFUNCTION(BlueprintImplementableEvent)
	void Cleanup();

	UFUNCTION(BlueprintCallable)
	void MarkCompleted();

	bool IsCompleted()
	{
		return hasCompletedRole;
	}

	void SetScriptedEvent(AANScriptedEvent* scriptedEvent)
	{
		parentEvent = scriptedEvent;
	}

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Scripted Event Actor Properties")
	bool toDestroyActorWhenCompleted;

private:
	AANScriptedEvent* parentEvent;

private:
	bool hasCompletedRole = false;
};
