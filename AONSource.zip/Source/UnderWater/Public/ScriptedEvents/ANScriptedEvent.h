// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Environment/ANGenericTrigger.h"

#include "ANScriptedEvent.generated.h"

class AANScriptEventActor;

UCLASS()
class UNDERWATER_API AANScriptedEvent : public AANGenericTrigger
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AANScriptedEvent();

	virtual void BeginPlay() override;


//Gameplay Functions
public:
	//Check if we can cleanup, and do so if we can
	UFUNCTION(BlueprintCallable, Category = "ScriptedEvent")
	void CheckCanCleanup();

	void Cleanup();

protected:
	virtual void PlayTriggerEvent_Implementation(AActor* OverlappedActor) override;
	
	virtual void DestroyUnplayableTriggerOnLoad() override;


//Customizable Variables
public:
	//Actors to start on event trigger enter
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TArray<AANScriptEventActor*> eventActors;


};
