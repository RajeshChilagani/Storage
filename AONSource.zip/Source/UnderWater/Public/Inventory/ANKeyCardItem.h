// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Systems/ANPickableItem.h"
#include "ANKeyCardItem.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANKeyCardItem : public AANPickableItem
{
	GENERATED_BODY()
private:
	void AddItemToInventory(class UANInventorySystem* IS) override;
	
};
