// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameUserSettings.h"

#include "ANEnums.h"

#include "ANGameUserSettings.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANGameUserSettings : public UGameUserSettings
{
	GENERATED_BODY()
	
//Unreal/Override Functions
public:
	UANGameUserSettings(const FObjectInitializer& ObjectInitializer);

	virtual void ApplyNonResolutionSettings() override;

//Variables
protected:

//CONTROLS
	//If we have inverted the Y axis
	UPROPERTY(Config)
	bool bInvertYAxis;

	//If we have jet boost set to toggle
	UPROPERTY(Config)
	bool bJetBoostToggle;

	//The icon set being used
	UPROPERTY(Config)
	EIconSets IconSet;

	//The mouse horizontal sensitivity level
	UPROPERTY(Config)
	int32 MouseHorizontalSensitivity;

	//The mouse vertical sensitivity level
	UPROPERTY(Config)
	int32 MouseVerticalSensitivity;

	//The gamepad horizontal sensitivity level
	UPROPERTY(Config)
	int32 GamepadHorizontalSensitivity;

	//The gamepad vertical sensitivity level
	UPROPERTY(Config)
	int32 GamepadVerticalSensitivity;

//DISPLAY
	//The color vision deficiency mode
	UPROPERTY(Config)
	EColorDeficiencyMode ColorDeficiencyMode;

	//The quality level for scalability settings
	UPROPERTY(Config)
	int32 QualityLevel;

//AUDIO
	//The SFX volume
	UPROPERTY(Config)
	int32 SFXVolume;

	//The dialogue volume
	UPROPERTY(Config)
	int32 DialogueVolume;

	//The music volume
	UPROPERTY(Config)
	int32 MusicVolume;


//Functions
public:
	//Sets the jet boost toggle
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetInvertYAxis(bool bNewInvertYAxis) { bInvertYAxis = bNewInvertYAxis; };

	//If we have inverted the Y axis
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsInvertYAxis() const { return bInvertYAxis; };


	//Sets the jet boost toggle
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetJetBoostToggle(bool bNewJetBoostToggle) { bJetBoostToggle = bNewJetBoostToggle; };

	//If we have jet boost set to toggle
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsJetBoostToggle() const { return bJetBoostToggle; };


	//Sets the icon set
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetIconSet(EIconSets NewIconSet) { IconSet = NewIconSet; };

	//Gets the icon set
	UFUNCTION(BlueprintPure, Category = "Getters")
	EIconSets GetIconSet() const { return IconSet; };


	//Sets the mouse horizontal sensitivity
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetMouseHorizontalSensitivity(int32 NewMouseHorizontalSensitivity) { MouseHorizontalSensitivity = NewMouseHorizontalSensitivity; };

	//Gets the mouse horizontal sensitivity
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetMouseHorizontalSensitivity() const { return MouseHorizontalSensitivity; };


	//Sets the mouse vertical sensitivity
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetMouseVerticalSensitivity(int32 NewMouseVerticalSensitivity) { MouseVerticalSensitivity = NewMouseVerticalSensitivity; };

	//Gets the mouse vertical sensitivity
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetMouseVerticalSensitivity() const { return MouseVerticalSensitivity; };


	//Sets the gamepad horizontal sensitivity
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetGamepadHorizontalSensitivity(int32 NewGamepadHorizontalSensitivity) { GamepadHorizontalSensitivity = NewGamepadHorizontalSensitivity; };

	//Gets the gamepad horizontal sensitivity
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetGamepadHorizontalSensitivity() const { return GamepadHorizontalSensitivity; };


	//Sets the gamepad vertical sensitivity
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetGamepadVerticalSensitivity(int32 NewGamepadVerticalSensitivity) { GamepadVerticalSensitivity = NewGamepadVerticalSensitivity; };

	//Gets the gamepad vertical sensitivity
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetGamepadVerticalSensitivity() const { return GamepadVerticalSensitivity; };


	//Gets the color vision deficiency mode
	UFUNCTION(BlueprintPure, Category = "Getters")
	EColorDeficiencyMode GetColorDeficiencyMode() const { return ColorDeficiencyMode; };

	//Sets the color vision deficiency mode
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetColorDeficiencyMode(EColorDeficiencyMode NewColorDeficiencyMode) { ColorDeficiencyMode = NewColorDeficiencyMode; };


	//Gets the quality level
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetQualityLevel() const { return QualityLevel; };

	//Sets the quality level
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetQualityLevel(int32 NewQualityLevel) { QualityLevel = NewQualityLevel; };


	//Sets the SFX volume
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetSFXVolume(int32 NewSFXVolume) { SFXVolume = NewSFXVolume; };

	//Gets the SFX volume
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetSFXVolume() const { return SFXVolume; };


	//Sets the Dialogue volume
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetDialogueVolume(int32 NewDialogueVolume) { DialogueVolume = NewDialogueVolume; };

	//Gets the Dialogue volume
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetDialogueVolume() const { return DialogueVolume; };


	//Sets the Music volume
	UFUNCTION(BlueprintCallable, Category = "Getters")
	void SetMusicVolume(int32 NewMusicVolume) { MusicVolume = NewMusicVolume; };

	//Gets the Music volume
	UFUNCTION(BlueprintPure, Category = "Getters")
	int32 GetMusicVolume() const { return MusicVolume; };
};
