// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "Misc/Guid.h"

#include "ANEnums.h"
#include "ANStructs.h"

#include "ANGameplaySaveGame.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANGameplaySaveGame : public USaveGame
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANGameplaySaveGame();


//Gameplay Functions
protected:
	//Generates a random code, optionally capping the random number lower than 9
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	FString GenerateCode(int32 CodeLength, int32 MaxIndex = 9, bool bAllowRepeatNumbers = true);


//Save Game Variables
protected:
	//If this gameplay save file has started being played
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	bool bStarted;

	//The difficulty level that this save file is on
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	EANDifficultyLevels DifficultyLevel;

	//The amount of time the player has played on this run
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	float GameplayTime;

	//The health value we had when we saved
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	int32 SavedAtHealth;

	//The level that we saved at
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	EANLevels SavedAtLevel;

	//The transform (location and rotation) that we saved at
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	FTransform SavedAtTransform;

	//Guids for objects that have saveable strings attached that we can use for loading
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FGuid, FString> SaveableStrings;

	//Guids for world saveable objects that are used for loading
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FGuid, FWorldSaveableData> WorldSaveableDatas;

	//List of saved items
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FString, int32> SavedItems;

	//List of visited rooms
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TArray<FName> VisitedRooms;

	//Saveable bool values
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FName, bool> SaveableBoolValues;

	//Saveable int values
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FName, int32> SaveableIntValues;

	//Saveable float values
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FName, float> SaveableFloatValues;

	//Saveable float values
	UPROPERTY(BlueprintReadWrite, Category = "Save Game")
	TMap<FName, FString> SaveableStringValues;


//Save Game Functions
public:
	//Initializes default values for the save game
	void InitializeDefaultValues(EANDifficultyLevels SelectedDifficultyLevel);

	//Save a saveable object to this gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SaveSaveableString(const FGuid& GuidToSave, const FString& SaveString);

	//Save a world saveable object to this gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SaveWorldSaveable(const FGuid& GuidToSave, const FWorldSaveableData& NewWorldSaveableData);

	//Remove a world saveable object from this gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void RemoveWorldSaveable(const FGuid& GuidToRemove);

	//Sets the started boolean
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetStarted(bool bNewStarted);

	//Sets the gameplay time
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetGameplayTime(float NewGameplayTime);

	//Sets the saved at health
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSavedAtHealth(int32 NewSavedAtHealth);

	//Sets the saved at level
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSavedAtLevel(EANLevels NewSavedAtLevel);

	//Sets the saved at transform
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSavedAtTransform(FTransform NewSavedAtTransform);

	//Adds a saved item to the list
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void AddSavedItem(const FString& ItemName, int32 ItemCount);

	//Clears the saved items list
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void ClearSavedItems();

	//Tries to add a new visited room
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void TryAddVisitedRoom(const FName& NewVisitedRoom);

	//Sets a saveable bool value. If it does not exist in the map, adds it.
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSaveableBoolValue(FName SaveableName, bool bNewBoolValue);

	//Sets a saveable int value. If it does not exist in the map, adds it.
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSaveableIntValue(FName SaveableName, int32 NewIntValue);

	//Sets a saveable float value. If it does not exist in the map, adds it.
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSaveableFloatValue(FName SaveableName, float NewFloatValue);

	//Sets a saveable string value. If it does not exist in the map, adds it.
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSaveableStringValue(FName SaveableName, FString NewStringValue);


//Getters
public:
	//Checks if we have started this gameplay save game
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool HasStarted() const { return bStarted; };

	//Gets the difficulty level
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE EANDifficultyLevels GetDifficultyLevel() const { return DifficultyLevel; };

	//Gets the gameplay time
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE float GetGameplayTime() const { return GameplayTime; };

	//Gets the health that we had when we saved
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE int32 GetSavedAtHealth() const { return SavedAtHealth; };

	//Gets the level that we saved at
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE EANLevels GetSavedAtLevel() const { return SavedAtLevel; };

	//Gets the transform that we saved at
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE FTransform GetSavedAtTransform() const { return SavedAtTransform; };

	//Gets the saveable string for a Guid
	UFUNCTION(BlueprintPure, Category = "Getters")
	FString GetSaveableStringForGuid(const FGuid& GuidToCheck);

	//Gets the world saveable data for a Guid
	UFUNCTION(BlueprintPure, Category = "Getters")
	FWorldSaveableData GetWorldSaveableDataForGuid(const FGuid& GuidToCheck);

	//Gets the world saveable datas as a map.
	const TMap<FGuid, FWorldSaveableData>& GetWorldSaveableDatasMap() const { return WorldSaveableDatas; };

	//Gets the saved items as a map. This map should only be used to initialize the items in the inventory system, not for accessing current items.
	const TMap<FString, int32>& GetSavedItemsMap() const { return SavedItems; };

	//Gets the visited rooms
	UFUNCTION(BlueprintPure, Category = "Getters")
	const TArray<FName>& GetVisitedRooms() const { return VisitedRooms; };

	//Gets a saveable bool value. If it does not exist in the map, returns false.
	UFUNCTION(BlueprintPure, Category = "Save Game")
	bool GetSaveableBoolValue(FName SaveableName, bool& bOutBoolValue) const;

	//Gets a saveable int value. If it does not exist in the map, returns false.
	UFUNCTION(BlueprintPure, Category = "Save Game")
	bool GetSaveableIntValue(FName SaveableName, int32& OutIntValue) const;

	//Gets a saveable float value. If it does not exist in the map, returns false.
	UFUNCTION(BlueprintPure, Category = "Save Game")
	bool GetSaveableFloatValue(FName SaveableName, float& OutFloatValue) const;

	//Gets a saveable float value. If it does not exist in the map, returns false.
	UFUNCTION(BlueprintPure, Category = "Save Game")
	bool GetSaveableStringValue(FName SaveableName, FString& OutStringValue) const;

};
