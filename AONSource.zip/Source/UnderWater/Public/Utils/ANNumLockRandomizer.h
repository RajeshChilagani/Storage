// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "ANNumLockRandomizer.generated.h"

/**
 * A Randomizer class to generate random codes of specified lengths
 */
UCLASS()
class UNDERWATER_API UANNumLockRandomizer : public UObject
{
	GENERATED_BODY()
public:
	UFUNCTION()
	bool IsAValidCode(const FString& Code);
	UFUNCTION()
	FString GetCodeInRangeAsString(int32 Min, int32 Max);
	UFUNCTION()
	FString GenerateRandomCode(uint32 Length);
private:
	TSet<FString> UnlockCodes;
};
