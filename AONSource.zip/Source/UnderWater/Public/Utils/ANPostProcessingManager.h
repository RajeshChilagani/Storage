// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANPostProcessingManager.generated.h"

class APostProcessVolume;

UCLASS()
class UNDERWATER_API AANPostProcessingManager : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANPostProcessingManager();

	UFUNCTION(BlueprintCallable)
	void EnableFocus() const;

	UFUNCTION(BlueprintCallable)
	void DisableFocus() const;

	/** Sets the weight value of post processing material
	*@param	WeightValue	is always clamped between 0 - 1.
	*/
	UFUNCTION(BlueprintCallable)
	void SetFocus(float WeightValue) const;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	APostProcessVolume* FocusPostProcessingVolume;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	APostProcessVolume* FogPostProcessingVolume;
};
