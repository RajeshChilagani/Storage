#pragma once
// Fill out your copyright notice in the Description page of Project Settings.
UENUM(BlueprintType)
enum class EProjectileType :uint8
{
		None,
		HookProjectile,
		HarpoonBolt,
		FlareBolt,
		ExplosiveProjectile
};

