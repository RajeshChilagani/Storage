// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Projectiles/ANBaseProjectile.h"
#include "ANHookProjectile.generated.h"

class UCableComponent;
class UStaticMeshComponent;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANHookProjectile : public AANBaseProjectile
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadOnly)
	bool IsHookAttached = false;
	
public:
	AANHookProjectile();
	
	void OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	UCableComponent* Cable;
	
	void ReleaseHook();

	UStaticMeshComponent* GetMeshComponent()const { return MainMeshComponent; }
	
};
