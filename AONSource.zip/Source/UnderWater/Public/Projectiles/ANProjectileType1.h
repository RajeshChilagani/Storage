// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Projectiles/ANBaseProjectile.h"
#include "ANProjectileType1.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANProjectileType1 : public AANBaseProjectile
{
	GENERATED_BODY()
	
};
