// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Projectiles/ANBaseProjectile.h"
#include "ANRegularProjectile.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANRegularProjectile : public AANBaseProjectile
{
	GENERATED_BODY()

public:
	AANRegularProjectile();

public:
	void OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit) override;

	//Only for Persistent AI
	UPROPERTY(EditAnywhere, Category = "Projectile Settings")
	float StunDamage = 35.f;

private:
	bool bHasHitTarget = false;

};
