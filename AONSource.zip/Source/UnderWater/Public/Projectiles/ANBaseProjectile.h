// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#include "ANDefines.h"

#include "EnumProjectilesTypes.h"
#include "Systems/ANPickableItem.h"
#include "Systems/ANWorldSaveablePickableItem.h"

#include "ANBaseProjectile.generated.h"

class UAkAudioEvent;
class UParticleSystemComponent;
class UProjectileMovementComponent;

class AANCharacterBase;

UCLASS()
class UNDERWATER_API AANBaseProjectile : public AANWorldSaveablePickableItem
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	AANBaseProjectile();
	virtual void Tick(float DeltaTime) override;
	virtual void BeginPlay() override;

public:
	//The owning character, AKA, who shot this
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Weapon")
	AANCharacterBase* CharacterOwner;

	//The type of projectile
	UPROPERTY(EditAnywhere, Category = "Projectile Settings")
	EProjectileType Type = EProjectileType::None;

	/*UPROPERTY(EditAnywhere, Category = "Projectile Settings", BlueprintReadWrite)
		UStaticMeshComponent* RootMeshComponent = nullptr;*/

	//UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Projectile Settings")
	//	UStaticMeshComponent* ProjectileMesh = nullptr;


	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Projectile Settings")
	UParticleSystemComponent* BubbleEffect = nullptr;

	UPROPERTY(VisibleAnywhere, Category = "Projectile Movement")
	UProjectileMovementComponent* ProjectileMovementComponent;

	UPROPERTY(EditAnywhere, Category = "Projectile Settings")
	float ProjectileSpeed = 10000.0f;
	UPROPERTY(EditAnywhere, Category = "Projectile Settings")
	float ImpluseMultipler = 500.0f;

	//The damage that this projectile does
	UPROPERTY(EditAnywhere, Category = "Projectile Settings")
	float ProjectileDamage;

	//The audio event to play when shooting the projectile
	UPROPERTY(EditAnywhere, Category = "SFX")
	UAkAudioEvent* ProjectileShotSFX;

	//The audio event to play when hitting an enemy. (UI sound)
	UPROPERTY(EditAnywhere, Category = "SFX")
	UAkAudioEvent* ProjectileHitConfirmSFX;

protected:


public:
	UStaticMeshComponent* GetStaticMeshComponent() const { return MainMeshComponent; }
	
	UFUNCTION()
	void FireInDirection(const FVector& ShootDirection);

	virtual void ActivateComponent() {};

	UFUNCTION()
	virtual void OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit) {};

	//Called when the projectile is stopped
	UFUNCTION(BlueprintNativeEvent, Category = "Gameplay")
	void OnProjectileStopped();

	//Plays the projectile shot SFX
	void PlayProjectileShotSFX();

	//Sets the character owner
	void SetCharacterOwner(AANCharacterBase* NewCharacterOwner) { CharacterOwner = NewCharacterOwner; };

protected:
	//Destroys this object after handling some special conditions
	void DestroyOnHit();



//WorldSaveable
public:
	void BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign);

};
