#pragma once

/*This class is responsible for all project-set defines*/

#define TRACECHANNEL_INTERACTABLE     ECC_GameTraceChannel3
#define TRACECHANNEL_CURSOR	          ECC_GameTraceChannel4

#define Print(text) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT(text));
#define Print_1(text, val1) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT(text), val1));
#define Print_2(text, val1, val2) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT(text), val1, val2));
#define Print_3(text, val1, val2, val3) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT(text), val1, val2, val3));
#define Print_4(text, val1, val2, val3, val4) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT(text), val1, val2, val3, val4));
#define Print_5(text, val1, val2, val3, val4, val5) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, FString::Printf(TEXT(text), val1, val2, val3, val4, val5));

#define Print_Color(text, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, TEXT(text));
#define Print_1_color(text, val1, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, FString::Printf(TEXT(text), val1));
#define Print_2_color(text, val1, val2, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, FString::Printf(TEXT(text), val1, val2));
#define Print_3_color(text, val1, val2, val3, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, FString::Printf(TEXT(text), val1, val2, val3));
#define Print_4_color(text, val1, val2, val3, val4, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, FString::Printf(TEXT(text), val1, val2, val3, val4));
#define Print_5_color(text, val1, val2, val3, val4, val5, color) if(GEngine) GEngine->AddOnScreenDebugMessage(-1, 5.f, color, FString::Printf(TEXT(text), val1, val2, val3, val4, val5));