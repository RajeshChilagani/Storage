#pragma once

#include "CoreMinimal.h"

#include "Engine/DataTable.h"
#include "Widgets/Layout/Anchors.h"

#include "ANEnums.h"

#include "ANStructs.generated.h"

class ATargetPoint;
class AANWorldNavRoom;
class UAkAudioEvent;
class UAnimMontage;
class UBoxComponent;
class UMaterialInterface;
class USkeletalMesh;
class UTexture2D;

class AANAISpawnPoints;
class AANAISpawnTriggerBox;
class AANCharacterBase;
class AANInspectable;
class AANItemUseHappening;
class AANPickableItem;
class AANSecondaryAINavRoom;
class IANSelectable;
class UANDialogueConversation;
class UANHUDWidgetBase;

/*Math Structs*/

//A Vector
USTRUCT(BlueprintType)
struct UNDERWATER_API FIntVector2D
{
	GENERATED_BODY()

//Gameplay Variables
public:
	//The first (X) value of the vector.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Vector")
	int32 X;

	//The second (Y) value of the vector.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Vector")
	int32 Y;

	FIntVector2D()
	{
		X = 0;
		Y = 0;
	}

	FIntVector2D(int32 NewX, int32 NewY)
	{
		X = NewX;
		Y = NewY;
	}
};


/*Abyss of Neptune Structs*/

//An example struct
USTRUCT(BlueprintType)
struct UNDERWATER_API FExampleStruct
{
	GENERATED_BODY()

//Customizable Variables
public:
	//The character base class type.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character")
	TSubclassOf<AANCharacterBase> CharacterClass;

	//The maximum character health.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character")
	int32 MaxCharacterHealth;

	FExampleStruct()
	{
		MaxCharacterHealth = 100;
	}
};


//Item data
USTRUCT(BlueprintType)
struct FANItem : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnyWhere, BlueprintReadOnly)
	FString ANItemName;

	UPROPERTY(EditAnyWhere, BlueprintReadOnly)
	FText DisplayName;

	UPROPERTY(EditAnyWhere, BlueprintReadOnly)
	FText Description;

	UPROPERTY(EditAnyWhere, BlueprintReadOnly)
	bool bIsCraftable;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UTexture2D* Icon;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UMaterialInterface* MaterialIcon;

	//The item's type.
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EANItemType ItemType;

	//The amount needed to craft an item. Only relevant for materials.
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	int32 MaterialCraftAmount;

	//The ANItemName of the item we will craft when we reach the material craft amount
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	FString CraftItemName;

	//The type of usage we get from using this item directly in the inventory.
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	EANItemInventoryUseTypes InventoryUseType;

	//The associated pickable item. If we ever insert this item in anything or drop it, this pickable item should appear.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<AANPickableItem> PickableItem;

	//The associated item use happening. If we ever insert use an item directly in our inventory, this happening should be instantiated and executed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<AANItemUseHappening> ItemUseHappening;

	//The associated inspectable item. If we have something we can look at in our inventory, this should appear.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<AANInspectable> InspectedItem;

	//The integer value for this item, if needed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 IntegerValue;

	//The float value for this item, if needed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float FloatValue;

	//The text value for this item, if needed.
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText TextValue;


	void OnPostDataImport(const UDataTable* InDataTable, const FName InRowName, TArray<FString>& OutCollectedImportProblems) override
	{
		static const FString ContextString("Item Context String");
		FANItem* ItemData = InDataTable->FindRow<FANItem>(InRowName, ContextString, true);
		if (ItemData)
		{
			ItemData->ANItemName = FString(InRowName.ToString().RightChop(3));
		}
	}
};

//Data for input prompts
USTRUCT(BlueprintType)
struct UNDERWATER_API FInputPromptData
{
	GENERATED_BODY()

//Customizable Variables
public:
	//The input action
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character")
	EANInputActions InputAction;

	//The text displayed with the action
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Character")
	FText ActionDisplayText;

	FInputPromptData()
	{
		InputAction = EANInputActions::UIConfirm;
		ActionDisplayText = FText();
	}

	FInputPromptData(EANInputActions NewInputAction, FText NewActionDisplayText)
	{
		InputAction = NewInputAction;
		ActionDisplayText = NewActionDisplayText;
	}
};

//A single line of dialogue
USTRUCT(BlueprintType)
struct UNDERWATER_API FDialogueLine
{
	GENERATED_BODY()

//Customizable Variables
public:
	//The dialogue audio to play
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	TSoftObjectPtr<UAkAudioEvent> DialogueAudio;

	//The dialogue text
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	FText DialogueText;

	//The amount of time (in seconds) this dialogue is active for
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	float DialogueTime;

	//The color for the dialogue
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	EANMessageColors DialogueColor;

	FDialogueLine()
	{
		DialogueTime = 3.0f;
		DialogueColor = EANMessageColors::White;
	}
};

//Data specific to an individual dialogue conversation
USTRUCT(BlueprintType)
struct UNDERWATER_API FActiveDialogueConversationData
{
	GENERATED_BODY()

public:
	FActiveDialogueConversationData()
	{
		ActiveDialogueID = INDEX_NONE;
		ActiveDialogueConversation = nullptr;
		ActiveDialogueLineIndex = INDEX_NONE;
	}

	FActiveDialogueConversationData(int32 InActiveDialogueID, UANDialogueConversation* InActiveDialogueConversation)
	{
		ActiveDialogueID = InActiveDialogueID;
		ActiveDialogueConversation = InActiveDialogueConversation;
		ActiveDialogueLineIndex = INDEX_NONE;
	}

	bool operator==(const FActiveDialogueConversationData& Other) const
	{
		return ActiveDialogueID == Other.GetActiveDialogueID();
	}

protected:
	//The ID for this conversation. Used so if we have the same conversation playing simultaneously we know which one it is
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Dialogue")
	int32 ActiveDialogueID;
	
public:
	//The active dialogue conversation
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Dialogue")
	UANDialogueConversation* ActiveDialogueConversation;

	//The active dialogue index that we're on
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Dialogue")
	int32 ActiveDialogueLineIndex;

	//The timer handle for the current dialogue, managing moving to the next dialogue line
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Dialogue")
	FTimerHandle ActiveDialogueTimerHandle;

public:
	int32 GetActiveDialogueID() const { return ActiveDialogueID; };
};

//Map room info
USTRUCT(BlueprintType)
struct UNDERWATER_API FMapRoomInfo
{
	GENERATED_BODY()

//Customizable Variables
public:
	//The room name (for lookups/gameplay)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	FName RoomName;

	//The room name (for what we display in the UI)
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	FText RoomDisplayName;

	//The font size for the room
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	int32 RoomFontSize = 24;

	//The anchors we use for the room name text in the UI
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	FAnchors RoomNameTextAnchors;

	//The dialogue audio to play
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Dialogue")
	TSoftObjectPtr<UTexture2D> RoomImage;

	FMapRoomInfo()
	{
		RoomName = NAME_None;
		RoomDisplayName = FText();
		RoomFontSize = 24;
		RoomNameTextAnchors = FAnchors();
		RoomImage = nullptr;
	}
};

//Voltage system parameters for determining what to turn on and off
USTRUCT(BlueprintType)
struct UNDERWATER_API FVoltageParams
{
	GENERATED_BODY()

public:
	FVoltageParams()
	{
		TargetVoltage = 0;
		TargetPowerable = nullptr;
		bShowInListUI = true;
	}

public:
	//Target voltage for this object to be powered on.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Voltage System Params")
	int32 TargetVoltage;

	//An actor that can be powered on. Must use Powerable interface to work.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Voltage System Params")
	AActor* TargetPowerable;

	//Whether or not we want to display this in the UI list
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Voltage System Params")
	bool bShowInListUI;
};

//Data for active HUDs
USTRUCT(BlueprintType)
struct UNDERWATER_API FActiveHUDData
{
	GENERATED_BODY()

public:
	FActiveHUDData()
	{
		LastActiveColumnIndex = INDEX_NONE;
		LastActiveRowIndex = INDEX_NONE;
	}

	FActiveHUDData(UANHUDWidgetBase* NewHUDWidgetBase)
	{
		HUDWidgetBase = NewHUDWidgetBase;
		LastActiveColumnIndex = INDEX_NONE;
		LastActiveRowIndex = INDEX_NONE;
	}


//Gameplay Variables
public:
	//The HUD widget
	UPROPERTY(Transient, BlueprintReadOnly, Category = "Character")
	UANHUDWidgetBase* HUDWidgetBase;

	//The last active selectable rows for this HUD
	TArray<TArray<IANSelectable*>> LastActiveSelectableRows;

	//The last column index
	UPROPERTY(Transient, BlueprintReadOnly, Category = "Character")
	int32 LastActiveColumnIndex;
	
	//The last row index
	UPROPERTY(Transient, BlueprintReadOnly, Category = "Character")
	int32 LastActiveRowIndex;

//Gameplay Functions
public:
	//Updates the selectables
	void UpdateSelectables(TArray<TArray<IANSelectable*>> NewLastSelectableRows, int32 NewLastRowIndex, int32 NewLastColumnIndex)
	{
		LastActiveSelectableRows = NewLastSelectableRows;
		LastActiveRowIndex = NewLastRowIndex;
		LastActiveColumnIndex = NewLastColumnIndex;
	}

	//Returns true if there are valid selectables
	bool HasValidSelectables()
	{
		if (LastActiveSelectableRows.Num() > 0 && LastActiveRowIndex >= 0 && LastActiveColumnIndex >= 0)
		{
			return true;
		}

		return false;
	}

	//Gets the last active selectable
	IANSelectable* GetLastActiveSelectable()
	{
		if (LastActiveSelectableRows.IsValidIndex(LastActiveRowIndex) && LastActiveSelectableRows[LastActiveRowIndex].IsValidIndex(LastActiveColumnIndex))
		{
			return LastActiveSelectableRows[LastActiveRowIndex][LastActiveColumnIndex];
		}

		return nullptr;
	}
};

//Data assigned to world saveable objects
USTRUCT(BlueprintType)
struct UNDERWATER_API FWorldSaveableData
{
	GENERATED_BODY()

//Customizable Variables
public:
	//The class of the world saveable that is to be spawned
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "World Saveable")
	UClass* WorldSaveableClass;

	//The transform where the world saveable is stored
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "World Saveable")
	FTransform WorldSaveableTransform;

	//Params for the saveable transform that we use to initialize data for the object on load
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "World Saveable")
	FString WorldSaveableParams;

	FWorldSaveableData()
	{
		WorldSaveableClass = nullptr;
		WorldSaveableTransform = FTransform();
		WorldSaveableParams = FString("");
	}

	FWorldSaveableData(UClass* InClass, const FTransform& InTransform, const FString& InParams)
	{
		WorldSaveableClass = InClass;
		WorldSaveableTransform = InTransform;
		WorldSaveableParams = InParams;
	}
};

USTRUCT(BlueprintType)
struct UNDERWATER_API FAISpawnSettings
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	TSubclassOf<AActor> EnemyTypeToSpawn;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	int EnemyCount = 0.0f;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	float IntervalBetweenEnemies = 0.0f;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	float MinDistanceToActivate = 5000;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
		float Speed = 300.0f;
	//Speed at which the ai moves after attacking the player
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
		float RunAwaySpeedMultiplier = 1.0f;
	//Speed when chasing the player
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
		float PlayerChaseSpeedMultiplier = 1.0f;
	//Wait time when chasing the player, The ai will wait for few moments before attacking the player
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
		float WaitTimeWhenChasingPlayer = 0.7f;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	ATargetPoint* SpawnLocation =nullptr;
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	TArray<ATargetPoint*> CustomPoints;
	//This is the ref to the  room nav bounds which was spawned in the level.
	UPROPERTY(EditAnywhere, Category = "Group Settings", BlueprintReadWrite)
	AANSecondaryAINavRoom* ANNavRoom;

	void SpawnEnemies() {};

	FAISpawnSettings()
	{

	}

};


USTRUCT(BlueprintType)
struct UNDERWATER_API FNavMeshData
{
	GENERATED_BODY()

public:
	//Everything is stored in a matrix form
	//ID is the box collision location in the matrix.
	//ID is used to get the box collision from the the matrix.
	UPROPERTY(EditAnywhere, Category = "FNavMeshData", BlueprintReadWrite)
	UBoxComponent* BoxComponent;

	//Is this node free rn?
	UPROPERTY(EditAnywhere, Category = "FNavMeshData", BlueprintReadWrite)
	bool bIsFree;

	//Holds the previous node to this node. helps in backtracking the path.
	FVector PreviousNode = FVector(-1,-1,-1);
	
	//A array to store all the Neighbors of this node. Its stores the FVector of the node.
	TArray<FVector> NeighborsList;

	//These will be used for A Star 
	float cost = 1;
	float heuristics = 0;
	float functionValue = INFINITY;


	
	FNavMeshData(UBoxComponent* BoxRef, bool bFree = false) :BoxComponent(BoxRef), bIsFree(bFree)
	{

	}
	FNavMeshData()
	{}
};
