// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ANGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANGameModeBase();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

//Initialization Functions
public:

protected:
	//Creates the HUD UI for each player controller.
	UFUNCTION(BlueprintCallable, Category = "Initialization")
	void CreateHUD();


//Customizable Variables
protected:
	//If we can pause the game in this game mode. (Specifically, open the pause menu.)
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Defaults")
	bool bPausableMode;


//Getters
public:
	//If this is a pausable mode for the pause menu. Separate from the game engine pauseable.
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsPausableMode() const { return bPausableMode; };

};
