// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Game/ANGameModeBase.h"

#include "ANEnums.h"

#include "ANExplorationGameMode.generated.h"

class UANGameplaySaveGame;

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANExplorationGameMode : public AANGameModeBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANExplorationGameMode();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

//Initialization Functions
protected:
	//Loads all necessary shared levels
	UFUNCTION(BlueprintCallable, Category = "Initialization")
	void LoadSharedLevels();

	//Loads the last level the player saved at
	UFUNCTION(BlueprintCallable, Category = "Initialization")
	void LoadSavedAtLevel(EANLevels SavedAtLevel);


//Gameplay Variables
protected:
	//The amount of time we have played this playthrough
	float GameplayTime;


//Save Game Functions
public:
	//Sets objects in the world based on the specified save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetupWorldForSaveGame(UANGameplaySaveGame* LoadedGameplaySaveGame);

	//Sets up objects after a delay
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void DelayedSetupWorldForSaveGame();


//Getters
public:
	//Gets the current gameplay time
	UFUNCTION(BlueprintCallable, Category = "Getters")
	FORCEINLINE float GetGameplayTime() const { return GameplayTime; };

};
