// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"

#include "ANEnums.h"

#include "ANGameInstance.generated.h"

class AANPlayerControllerBase;
class UANInventorySystem;
class UANCraftingSystem;
class UANNumLockRandomizer;
class UANGameplaySaveGame;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANGameInstance : public UGameInstance
{
	GENERATED_BODY()
public:
	void Init() override;

	//Special function to initialize things in blueprints
	UFUNCTION(BlueprintImplementableEvent, Category = "Initialization")
	void BP_Init();

	void Shutdown() override;

	UFUNCTION(BlueprintPure, Category = "Inventory")
	FORCEINLINE UANInventorySystem* GetInventorySystem() const { return m_InventorySystem; };

	UFUNCTION(BlueprintPure, Category = "Crafting")
	FORCEINLINE UANCraftingSystem* GetCraftingSystem() const { return m_CraftingSystem; };

	UPROPERTY(BlueprintReadOnly)
	UANInventorySystem* m_InventorySystem;

	UPROPERTY(BlueprintReadOnly)
	UANNumLockRandomizer* NumLockRandomizer;

private:
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	UANCraftingSystem* m_CraftingSystem;


//Gameplay Variables
protected:
	//This is a crucial boolean for differentiating between a standard game for players or the testing builds we use for ourselves
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	bool bStandardGameFlow;

	//This checks if we have just finished the game. This should be set to true before we head to the credits and reverted to false once we reach the credits.
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	bool bJustFinishedGame;


//Gameplay Functions
public:
	//Clears out the inventory. Usually called on begin play to ensure we duplicate items on a load.
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void ClearInventory();

	//Gets whether we are in a standard game flow or not
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsStandardGameFlow() const { return bStandardGameFlow; };

	//Sets the standard game flow value
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetStandardGameFlow(bool bNewStandardGameFlow) { bStandardGameFlow = bNewStandardGameFlow; };

	//Gets the just finished game value
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE bool IsJustFinishedGame() const { return bJustFinishedGame; };

	//Sets the just finished game value
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetJustFinishedGame(bool bNewJustFinishedGame) { bJustFinishedGame = bNewJustFinishedGame; };

	//Fades in the loading screen
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Loading")
	void FadeInLoadingScreen(AANPlayerControllerBase* PlayerControllerBase, float FadeTime = 0.5f);

	//Fades out the loading screen
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Loading")
	void FadeOutLoadingScreen(AANPlayerControllerBase* PlayerControllerBase, float FadeTime = 0.5f);


//Load Map Functions
public:
	//Loads the game to the last checkpoint
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void LoadLastCheckpoint(UObject* WorldContextObject);


//Saved Game Variables
protected:
	//Our active gameplay save game
	UPROPERTY(BlueprintReadOnly, Category = "Save Game")
	UANGameplaySaveGame* ActiveGameplaySaveGame;

	//Whether or not saving is enabled right now
	UPROPERTY(BlueprintReadOnly, Category = "Save Game")
	bool bSavingEnabled;

//Saved Game Functions
public:
	//Creates a new gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	bool CreateGameplaySaveGame(EANDifficultyLevels DifficultyLevel);

	//Loads the gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	bool LoadGameplaySaveGame();

	//Saves the active gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	bool SaveGameplaySaveGame(UObject* WorldContextObject);

	//Deletes the active gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	bool DeleteGameplaySaveGame();

	//Sets the saving enabled value
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	void SetSavingEnabled(bool bNewSavingEnabled) { bSavingEnabled = bNewSavingEnabled; };

	//Checks if saving is enabled
	UFUNCTION(BlueprintPure, Category = "Save Game")
	FORCEINLINE bool IsSavingEnabled() const { return bSavingEnabled; };

	//Gets the active gameplay save game
	UFUNCTION(BlueprintCallable, Category = "Save Game")
	FORCEINLINE UANGameplaySaveGame* GetActiveGameplaySaveGame() const { return ActiveGameplaySaveGame; };

};
