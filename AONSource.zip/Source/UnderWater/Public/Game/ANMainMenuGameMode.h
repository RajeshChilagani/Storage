// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Game/ANGameModeBase.h"
#include "ANMainMenuGameMode.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API AANMainMenuGameMode : public AANGameModeBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANMainMenuGameMode();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
};
