// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANPersistentAIHealthWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANPersistentAIHealthWidget : public UANWidgetBase
{
	GENERATED_BODY()

//Gameplay Functions
public:
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void BP_UpdateHealthOnScreen(float CurrentHealth);

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable)
	void BP_UpdateStunOnScreen(float CurrentStunDamge, float TargetStunDamage);
};
