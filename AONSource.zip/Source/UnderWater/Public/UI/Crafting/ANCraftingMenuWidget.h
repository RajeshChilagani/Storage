// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANCraftingMenuWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANCraftingMenuWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
};
