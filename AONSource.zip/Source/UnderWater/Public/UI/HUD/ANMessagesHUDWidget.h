// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/HUD/ANHUDWidgetBase.h"

#include "ANEnums.h"

#include "ANMessagesHUDWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANMessagesHUDWidget : public UANHUDWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANMessagesHUDWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Functions
public:
	//Adds a message to the UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_AddMessage(const FText& DisplayText, float DisplayTime, EANMessageColors DisplayColor = EANMessageColors::White);

	//Adds a standard checkpoint message
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_AddCheckpointMessage();

protected:
	//Adds an item to the player's inventory
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	void BP_AddItemToInventoryUI(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod);

};
