// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/HUD/ANHUDWidgetBase.h"
#include "ANLogHUDWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANLogHUDWidget : public UANHUDWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANLogHUDWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	FText CurrentLogText;

//Gameplay Functions
public:
	virtual void AssignDefaultSelectables(AANPlayerControllerBase* AssigningController) override;
	virtual bool ShouldAssignSelectablesOnShow_Implementation() const override;

	//Sets the log text
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void SetLogText(const FText& NewLogText);

	//Fades out the log and destroys it
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void FadeOutAndDestroy();
};
