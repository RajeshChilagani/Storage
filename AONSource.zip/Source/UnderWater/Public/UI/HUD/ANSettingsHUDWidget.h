// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/HUD/ANHUDWidgetBase.h"
#include "ANSettingsHUDWidget.generated.h"

class AANPlayerControllerBase;
class IANSelectable;
class UANGenericTextButtonWidget;
class UANSelectableWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANSettingsHUDWidget : public UANHUDWidgetBase
{
	GENERATED_BODY()

//Unreal Functions
public:
	UANSettingsHUDWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	//A list of the settings menus
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANGenericTextButtonWidget*> SettingsListButtonWidgets;

	//Controls button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANSelectableWidget*> ControlsButtonWidgets;

	//Display button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANSelectableWidget*> DisplayButtonWidgets;

	//Audio button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANSelectableWidget*> AudioButtonWidgets;

//Gameplay Functions
public:
	virtual void AssignDefaultSelectables(AANPlayerControllerBase* AssigningController) override;

	//Assigns the setting list selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignSettingsListButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the controls selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignControlsButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the display selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignDisplayButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the audio selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignAudioButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);


//Getters
public:
	//Gets the settings list button widgets
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANGenericTextButtonWidget*> GetSettingsListButtonWidgets() const { return SettingsListButtonWidgets; };

	//Returns an array of an array of all the settings list button widgets
	TArray<TArray<IANSelectable*>> GetSettingsListButtonWidgetsAsSelectableArray() const;


	//Gets the controls button widgets
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANSelectableWidget*> GetControlsButtonWidgets() const { return ControlsButtonWidgets; };

	//Returns an array of an array of all the controls button widgets
	TArray<TArray<IANSelectable*>> GetControlsButtonWidgetsAsSelectableArray() const;


	//Gets the display button widgets
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANSelectableWidget*> GetDisplayButtonWidgets() const { return DisplayButtonWidgets; };

	//Returns an array of an array of all the display button widgets
	TArray<TArray<IANSelectable*>> GetDisplayButtonWidgetsAsSelectableArray() const;


	//Gets the audio button widgets
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANSelectableWidget*> GetAudioButtonWidgets() const { return AudioButtonWidgets; };

	//Returns an array of an array of all the audio button widgets
	TArray<TArray<IANSelectable*>> GetAudioButtonWidgetsAsSelectableArray() const;

};
