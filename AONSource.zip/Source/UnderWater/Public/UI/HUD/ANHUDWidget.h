// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/HUD/ANHUDWidgetBase.h"

#include "ANDelegates.h"
#include "ANEnums.h"

#include "ANHUDWidget.generated.h"

class AANLevelStreamTrigger;
class UANDebugMenuWidget;
class UANInventoryPanelWidget;
class UANInformationPanelWidget;
class UANTutorialPanelWidget;
class UANDynamicCrosshairWidget;
class UANPersistentAIHealthWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANHUDWidget : public UANHUDWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANHUDWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;


//Gameplay Variables
protected:
	//If the inventory is mid-transition, opening/closing
	UPROPERTY(BlueprintReadWrite, Category = "Inventory")
	bool bInventoryTransitioning;

	//If the information panel/map is mid-transition, opening/closing
	UPROPERTY(BlueprintReadWrite, Category = "Inventory")
	bool bInformationTransitioning;

//Gameplay Functions
public:
	virtual void AssignDefaultSelectables(AANPlayerControllerBase* AssigningController) override;
	virtual bool ShouldAssignSelectablesOnShow_Implementation() const override;
	virtual void TryGoBack_Implementation() override;

	//Shows the inventory UI and sets the inventory mode
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_ShowInventoryUI();

	//Hides the inventory UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_HideInventoryUI();

	//Shows the information panel UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_ShowInformationPanelUI();

	//Hides the information panel UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_HideInformationPanelUI();

	//Shows the reticle UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Crosshair")
	void BP_ShowReticleUI();

	//Hide the reticle UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Crosshair")
	void BP_HideReticleUI();

	//Shows the dynamic cross hair
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Crosshair")
	void BP_ShowDynamicCrosshairUI();

	//Hide the dynamic cross hair
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Crosshair")
	void BP_HideDynamicCrosshairUI();

	//Shows the close prompt UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Prompt")
	void BP_ShowClosePromptUI();

	//Hide the close prompt UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Prompt")
	void BP_HideClosePromptUI();

	//Shows the level streaming UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Level Streaming")
	void BP_ShowLevelStreamingUI();

	//Hide the level streaming UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Level Streaming")
	void BP_HideLevelStreamingUI();


protected:
	//Adds an item to the player's inventory
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	void BP_AddItemToInventoryUI(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod);

	//Removes an item to the player's inventory
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	void BP_RemoveItemFromInventoryUI(const FString& ItemName, int32 Count);


//Getters and Setters
public:
	//Gets the inventory panel widget
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	UANInventoryPanelWidget* GetInventoryPanelWidget();

	//Gets the information panel widget
	UFUNCTION(BlueprintImplementableEvent, Category = "Information")
	UANInformationPanelWidget* GetInformationPanelWidget();

	//Gets the tutorial panel widget
	UFUNCTION(BlueprintImplementableEvent, Category = "Tutorial")
	UANTutorialPanelWidget* GetTutorialPanelWidget();

	//Gets the debug menu widget
	UFUNCTION(BlueprintImplementableEvent, Category = "Debug")
	UANDebugMenuWidget* GetDebugMenuWidget();

	//Gets the dynamic crosshair widget
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Dynamic Cross Hair")
	UANDynamicCrosshairWidget* GetDynamicCrosshairWidget();

	UFUNCTION(BlueprintImplementableEvent, Category = "Persistent AI")
	UANPersistentAIHealthWidget* GetPersistentAIHealthWidget();

	//Gets if the inventory is transitioning
	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool IsInventoryTransitioning() const { return bInventoryTransitioning; };

	//Gets if the information panel/map is transitioning
	UFUNCTION(BlueprintPure, Category = "Information")
	bool IsInformationTransitioning() const { return bInformationTransitioning; };



//Developer Tools
public:
	//Opens the debug menu
	UFUNCTION(BlueprintImplementableEvent, Category = "Developer")
	void BP_OpenDebugMenu();

	//Closes the debug menu
	UFUNCTION(BlueprintImplementableEvent, Category = "Developer")
	void BP_CloseDebugMenu();

	//Toggles the dev tools UI on and off
	UFUNCTION(BlueprintImplementableEvent, Category = "Developer")
	void BP_ToggleDevToolsUI();

	//Toggles all UI on and off
	UFUNCTION(BlueprintImplementableEvent, Category = "Developer")
	void BP_ToggleUI();

	//Toggles the controls UI on and off
	UFUNCTION(BlueprintImplementableEvent, Category = "Developer")
	void BP_ToggleControlsUI();
};
