// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANHUDWidgetBase.generated.h"

class AANPlayerControllerBase;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANHUDWidgetBase : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANHUDWidgetBase(const FObjectInitializer& ObjectInitializer);


//Customizable Variables
protected:
	//If we should assign selectables when we show this HUD
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bAssignSelectablesOnShow;


//Gameplay Functions
public:
	//Shows the HUD
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void ShowHUD();

	//Hides the HUD
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void HideHUD();

	//Removes and destroys the HUD
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void RemoveHUD();

	//Assigns this HUD's default selectables to a player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	virtual void AssignDefaultSelectables(AANPlayerControllerBase* AssigningController);

	//If we should assign the selectables on show
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	bool ShouldAssignSelectablesOnShow() const;

	//Tries to go back in the UI
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void TryGoBack();

};
