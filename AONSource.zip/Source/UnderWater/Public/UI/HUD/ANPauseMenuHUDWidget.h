// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/HUD/ANHUDWidgetBase.h"
#include "ANPauseMenuHUDWidget.generated.h"

class AANPlayerControllerBase;
class IANSelectable;
class UANGenericTextButtonWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANPauseMenuHUDWidget : public UANHUDWidgetBase
{
	GENERATED_BODY()

//Unreal Functions
public:
	UANPauseMenuHUDWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	//A list of the pause menu buttons
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANGenericTextButtonWidget*> PauseMenuButtonWidgets;

	//Reload checkpoint button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANGenericTextButtonWidget*> ReloadCheckpointButtonWidgets;

	//Main menu button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANGenericTextButtonWidget*> MainMenuButtonWidgets;

	//Exit game button widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANGenericTextButtonWidget*> ExitGameButtonWidgets;


//Gameplay Functions
public:
	virtual void AssignDefaultSelectables(AANPlayerControllerBase* AssigningController) override;

	//Assigns the pause menu selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignPauseMenuButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the reload checkpoint selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignReloadCheckpointButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the main menu selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignMainMenuButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);

	//Assigns the exit game selectables to the player controller
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignExitGameButtonSelectables(AANPlayerControllerBase* AssigningPlayerController);


//Getters
public:
	//Gets the pause menu buttons
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANGenericTextButtonWidget*> GetPauseMenuButtonWidgets() const { return PauseMenuButtonWidgets; };

	//Returns an array of an array of all the button menu slot widgets.
	TArray<TArray<IANSelectable*>> GetPauseMenuButtonWidgetsAsSelectableArray() const;


	//Gets the reload checkpoint buttons
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANGenericTextButtonWidget*> GetReloadCheckpointButtonWidgets() const { return ReloadCheckpointButtonWidgets; };

	//Returns an array of an array of all the button menu slot widgets.
	TArray<TArray<IANSelectable*>> GetReloadCheckpointButtonWidgetsAsSelectableArray() const;


	//Gets the main menu buttons
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANGenericTextButtonWidget*> GetMainMenuButtonWidgets() const { return MainMenuButtonWidgets; };

	//Returns an array of an array of all the button menu slot widgets.
	TArray<TArray<IANSelectable*>> GetMainMenuButtonWidgetsAsSelectableArray() const;


	//Gets the exit game buttons
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	FORCEINLINE TArray<UANGenericTextButtonWidget*> GetExitGameButtonWidgets() const { return ExitGameButtonWidgets; };

	//Returns an array of an array of all the button menu slot widgets.
	TArray<TArray<IANSelectable*>> GetExitGameButtonWidgetsAsSelectableArray() const;

};
