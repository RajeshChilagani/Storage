// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "ANWidgetBase.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANWidgetBase : public UUserWidget
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANWidgetBase(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float DeltaTime) override;

};
