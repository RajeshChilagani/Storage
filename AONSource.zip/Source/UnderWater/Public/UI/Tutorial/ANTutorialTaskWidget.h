// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANTutorialTaskWidget.generated.h"

class UANTutorialTask;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANTutorialTaskWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANTutorialTaskWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;


//Gameplay Variables
protected:
	//The tutorial task that is associated with this widget
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	AANTutorialTask* AssociatedTutorialTask;

//Gameplay Functions
public:
	//Assigns a tutorial task to this task widget
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AssignTutorialTask(AANTutorialTask* NewTutorialTask);


//Getters
public:
	//Gets the associated tutorial task for this widget
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE AANTutorialTask* GetAssociatedTutorialTask() const { return AssociatedTutorialTask; };
};
