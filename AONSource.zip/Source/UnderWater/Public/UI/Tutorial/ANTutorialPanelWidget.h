// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANTutorialPanelWidget.generated.h"

class UANTutorialTask;
class UANTutorialTaskWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANTutorialPanelWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANTutorialPanelWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;


//Customizable Variables
public:
	//The time it takes before we remove a completed tutorial task entirely
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	float TimeToRemoveCompletedTutorialTask;


//Gameplay Variables
protected:
	//The tutorial tasks that are currently on-screen
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANTutorialTaskWidget*> ActiveTutorialTaskWidgets;

//Gameplay Functions
public:
	//Creates a tutorial task in the UI
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void BP_CreateTutorialTask(AANTutorialTask* AssociatedTutorialTask);

	//Completes a tutorial task in the UI
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void BP_CompleteTutorialTask(AANTutorialTask* AssociatedTutorialTask);

	//Completes a tutorial task in the UI
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void BP_RemoveTutorialTask(AANTutorialTask* AssociatedTutorialTask);


//Getters
public:
	//Gets all active tutorial tasks
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	TArray<UANTutorialTaskWidget*> GetActiveTutorialTasks() const { return ActiveTutorialTaskWidgets; };

	//Gets the tutorial task widget for a specified tutorial task
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	UANTutorialTaskWidget* GetTutorialTaskWidgetForTutorialTask(AANTutorialTask* AssociatedTutorialTask);

};
