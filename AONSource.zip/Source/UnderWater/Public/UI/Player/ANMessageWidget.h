// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANMessageWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANMessageWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANMessageWidget(const FObjectInitializer& ObjectInitializer);


//Initialization Variables
public:

protected:
	//How long this message displays for before it disappears
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Message", Meta = (ExposeOnSpawn = true, ClampMin = "0.0"))
	float DisplayTime;

	//The text that we want to display for the message
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Message", Meta = (ExposeOnSpawn = true))
	FText DisplayText;

	//The color of the foreground for the message
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Message", Meta = (ExposeOnSpawn = true))
	FLinearColor DisplayColor;

};
