// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANDynamicCrosshairWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANDynamicCrosshairWidget : public UANWidgetBase
{
	GENERATED_BODY()


public:
	UPROPERTY(BlueprintReadWrite,EditAnywhere)
		float CrossHairSpread;
	
	void SetCrossHairSpread(float value) { CrossHairSpread = value; }
};
