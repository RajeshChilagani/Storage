// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANEnums.h"

#include "ANMessageBoxWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANMessageBoxWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANMessageBoxWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

//Initialization Variables
public:


//Gameplay Functions
public:
	//Adds a message to the box
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Messages")
	void BP_AddMessage(const FText& MessageText, float DisplayTime, EANMessageColors DisplayColor = EANMessageColors::White);

};
