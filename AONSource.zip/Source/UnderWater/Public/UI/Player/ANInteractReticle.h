// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANInteractReticle.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInteractReticle : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANInteractReticle(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float DeltaTime) override;

//Gameplay Variables
public:

protected:
	//Whether or we are targeting something right now
	UPROPERTY(VisibleAnywhere, Category = "Targeting")
	bool bTargeting;

//Gameplay Functions
public:
	//Shows that we are targeting an object
	UFUNCTION(BlueprintImplementableEvent, Category = "Targeting")
	void BP_ShowInteractTargeting();

	//Hides the targeting
	UFUNCTION(BlueprintImplementableEvent, Category = "Targeting")
	void BP_HideInteractTargeting();

	//Shows the reticle
	UFUNCTION(BlueprintImplementableEvent, Category = "Targeting")
	void BP_ShowReticle();

	//Hides the reticle
	UFUNCTION(BlueprintImplementableEvent, Category = "Targeting")
	void BP_HideReticle();
};
