// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANPlayerHealthWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANPlayerHealthWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANPlayerHealthWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Functions
public:
	//Updates the health on the screen based on current health and max health
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Health")
	void BP_UpdateHealthOnScreen(int32 CurrentHealth, int32 MaxHealth);

	//Updates the suffocation levels on the screen based on current suffocation time and max suffocation time
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Oxygen")
	void BP_UpdateSuffocationOnScreen(float CurrentSuffocationTime, float MaxSuffocationTime);
};
