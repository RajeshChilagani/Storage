// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANEnums.h"
#include "ANStructs.h"

#include "ANMapRoomWidget.generated.h"

class UTexture2D;

/**
 *
 */
UCLASS()
class UNDERWATER_API UANMapRoomWidget : public UANWidgetBase
{
	GENERATED_BODY()

//Unreal Functions
public:
	UANMapRoomWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	//The name of the room (for gameplay purposes)
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	FName MapRoomName;

	//The display name of the room (visual only, not for gameplay)
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	FText MapRoomDisplayName;

	//The current state of the map room
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	EMapRoomStates MapRoomState;

//Gameplay Functions
public:
	//Sets default values for the map room
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void SetMapRoomDefaults(const FMapRoomInfo& NewMapRoomInfo);

	//Updates the map room state
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void UpdateMapRoomState(EMapRoomStates NewMapRoomState);


//Getters
public:
	//Gets the map room name
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE FName GetMapRoomName() const { return MapRoomName; };

	//Gets the map room state
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE EMapRoomStates GetMapRoomState() const { return MapRoomState; };

};
