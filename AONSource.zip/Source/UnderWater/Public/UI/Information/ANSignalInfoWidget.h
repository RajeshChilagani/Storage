// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANSignalInfoWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANSignalInfoWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANSignalInfoWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

//Gameplay Functions
public:
	//Updates the signal distance
	UFUNCTION(BlueprintImplementableEvent, Category = "Signal")
	void BP_UpdateSignalDistance(int32 NewSignalDistance);
};
