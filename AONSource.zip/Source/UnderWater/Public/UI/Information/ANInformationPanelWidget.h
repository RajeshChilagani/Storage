// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANInformationPanelWidget.generated.h"

class UANMapWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInformationPanelWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANInformationPanelWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:



//Gameplay Functions
public:
	//Gets the map widget
	UFUNCTION(BlueprintImplementableEvent, BlueprintPure, Category = "Getters")
	UANMapWidget* GetMapWidget();
};
