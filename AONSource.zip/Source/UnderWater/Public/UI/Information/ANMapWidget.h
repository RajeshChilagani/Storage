// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANEnums.h"

#include "ANMapWidget.generated.h"

class UANMapLevelData;
class UANMapRoomWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANMapWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANMapWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	//An array of all map room widgets currently assigned to this map
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANMapRoomWidget*> MapRoomWidgets;

	//The current map level data
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	UANMapLevelData* CurrentMapLevelData;

	//The level that the player is in currently. Not necessarily the one that is showing if the player tabs between levels.
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	EANLevels CurrentLevel;

	//The floor that the player is on currently.
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	int32 CurrentFloor;

	//The room name that the player is in currently.
	UPROPERTY(Transient, BlueprintReadWrite, Category = "Gameplay")
	FName CurrentRoomName;

//Gameplay Functions
public:
	//Finds map level data for a specified level and floor
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	UANMapLevelData* BP_RetrieveMapLevelData(EANLevels Level, int32 Floor);

	//Creates the map room widgets with map level data
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_CreateMapRoomWidgets(UANMapLevelData* MapLevelData);

	//Clears the current map
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_ClearMap();

	//Moves to a new room on the map
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void MoveToRoom(EANLevels NewLevel, int32 NewFloor, const FName& NewRoomName);


//Getters
public:
	//Gets the map room widgets
	UFUNCTION(BlueprintPure, Category = "Getters")
	TArray<UANMapRoomWidget*> GetMapRoomWidgets() const { return MapRoomWidgets; };

	//Gets the map room with a specified name from the currently loaded map room widgets
	UFUNCTION(BlueprintPure, Category = "Getters")
	UANMapRoomWidget* GetLoadedMapRoomWidgetWithName(const FName& CheckRoomName) const;

	//Gets the current map room widget based on the current room name
	UFUNCTION(BlueprintPure, Category = "Getters")
	UANMapRoomWidget* GetCurrentMapRoomWidget() const;

	//Gets the current level that the player is in according to the map
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE EANLevels GetCurrentLevel() const { return CurrentLevel; };

	//Gets the current floor that the player is on according to the map
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE int32 GetCurrentFloor() const { return CurrentFloor; };

	//Gets the current room name that the player is in
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE FName GetCurrentRoomName() const { return CurrentRoomName; };

};
