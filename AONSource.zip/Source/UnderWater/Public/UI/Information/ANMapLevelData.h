// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"

#include "ANEnums.h"
#include "ANStructs.h"

#include "ANMapLevelData.generated.h"

class UTexture2D;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANMapLevelData : public UPrimaryDataAsset
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANMapLevelData();

//Customizable Variables
protected:
	//The name to display at the top for this map
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	FText MapDisplayName;

	//The level for this data asset
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	EANLevels MapLevel;

	//The floor for this map data
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	int32 Floor;

	//The outline map image to use for the level
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	TSoftObjectPtr<UTexture2D> MapOutlineImage;

	//The map room infos on this data asset
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Default")
	TArray<FMapRoomInfo> MapRoomInfos;


//Getters
public:
	//Gets all the map room infos
	UFUNCTION(BlueprintPure, Category = "Getters")
	TArray<FMapRoomInfo> GetMapRoomInfos() const { return MapRoomInfos; };
};
