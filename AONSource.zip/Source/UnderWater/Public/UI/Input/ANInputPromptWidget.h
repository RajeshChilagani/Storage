// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANEnums.h"

#include "ANInputPromptWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInputPromptWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANInputPromptWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
protected:
	//The input action for this widget
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	EANInputActions InputAction;

	//The action text to display for this input prompt
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gameplay")
	FText ActionDisplayText;

//Gameplay Functions
public:
	//Sets new values on the input prompt
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetNewValues(EANInputActions NewInputAction, FText NewActionDisplayText);

	//Updates the input prompt, potentially to a new icon
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Gameplay")
	void BP_UpdateInputPrompt();


//Getters
public:
	//Gets this input prompt's input action
	UFUNCTION(BlueprintPure, Category = "Getters")
	EANInputActions GetInputAction() const { return InputAction; };

};
