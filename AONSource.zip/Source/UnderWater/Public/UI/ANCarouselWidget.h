// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANSelectableWidget.h"

#include "ANDelegates.h"

#include "ANCarouselWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANCarouselWidget : public UANSelectableWidget
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANCarouselWidget(const FObjectInitializer& ObjectInitializer);


//Delegates
public:
	//Delegate for the carousel index changing
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnCarouselIndexChanged OnCarouselIndexChanged;


//Customizable Variables
public:
	//The text for this carousel
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	FText CarouselDisplayText;

	//The texts for the individual carousel items
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TArray<FText> CarouselItems;


//Gameplay Variables
protected:
	//The current index we are on in the carousel
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	int32 CurrentCarouselIndex;

//Gameplay Functions
public:
	//Cycles the carousel to the right
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void CycleRight();

	//Cycles the carousel to the left
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void CycleLeft();

	//Sets the index directly to an option
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetIndexDirectly(int32 NewIndex);

protected:
	//Cycles the carousel by the designated index
	void CycleIndex(int32 IndexChange);

	//In the blueprint, cycles to the new index
	UFUNCTION(BlueprintImplementableEvent, Category = "Gameplay")
	void BP_CycleToNewIndex(int32 PreviousIndex, int32 NewIndex);


//Getters
public:
	//Gets the carousel's current index
	UFUNCTION(BlueprintPure, Category = "Gameplay")
	int32 GetCurrentCarouselIndex() const { return CurrentCarouselIndex; };


//Selectable Functions
public:
	virtual void BP_DoPressRightLogic_Implementation() override;
	virtual void BP_DoPressLeftLogic_Implementation() override;
};
