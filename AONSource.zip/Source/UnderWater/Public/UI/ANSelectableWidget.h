// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANDelegates.h"
#include "ANEnums.h"

#include "Interface/ANSelectable.h"

#include "ANSelectableWidget.generated.h"

class UAkAudioEvent;
class USoundBase;

/**
 * A widget that can be selected in the UI, like a button or interactable image.
 */
UCLASS()
class UNDERWATER_API UANSelectableWidget : public UANWidgetBase, public IANSelectable
{
	GENERATED_BODY()


//Unreal Functions
public:
	UANSelectableWidget(const FObjectInitializer& ObjectInitializer);


//Delegates
public:
	//Delegate for confirming the button press
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnSelectableWidgetConfirmed OnSelectableWidgetConfirmed;

	//Delegate for highlighting the button
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnSelectableWidgetHighlighted OnSelectableWidgetHighlighted;

	//Delegate for unhighlighting the button
	UPROPERTY(BlueprintAssignable, BlueprintCallable, Category = "Delegates")
	FOnSelectableWidgetUnhighlighted OnSelectableWidgetUnhighlighted;


//Custom variables
protected:
	//The SFX that plays when you confirm this widget with the A button/enter key.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* ConfirmSFX;

	//The SFX that plays when you move onto this widget.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* HighlightSFX;

	//The SFX that plays when you move away from this widget. Most UI will not implement this.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* UnhighlightSFX;

	//If this selectable has special press up logic
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bPressUpLogic;

	//If this selectable has special press down logic
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bPressDownLogic;

	//If this selectable has special press right logic
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bPressRightLogic;

	//If this selectable has special press left logic
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	bool bPressLeftLogic;

	//The platforms to show this widget on
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TArray<EPlatforms> ValidPlatforms;


//Gameplay Variables
public:
	//The player numbers that are currently selecting/highlighting this widget.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<EPlayerNumbers> HighlightedPlayers;

	//Is at least one player selecting/highlighting this widget right now?
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bHighlighted;


//Getters
public:
	//Gets the valid platforms
	UFUNCTION(BlueprintPure, Category = "Getters")
	TArray<EPlatforms> GetValidPlatforms() const { return ValidPlatforms; };

	//Checks if this is on a valid platform; aka, the platform we are on is not in the hide on platforms
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsValidPlatform() const;


//Selectable Functions
public:
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Highlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual void BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber) override;
	virtual bool BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const override;
	virtual bool BP_CanSelect_Implementation() const override;
	virtual bool BP_HasPressUpLogic_Implementation() const override;
	virtual bool BP_HasPressDownLogic_Implementation() const override;
	virtual bool BP_HasPressRightLogic_Implementation() const override;
	virtual bool BP_HasPressLeftLogic_Implementation() const override;

};
