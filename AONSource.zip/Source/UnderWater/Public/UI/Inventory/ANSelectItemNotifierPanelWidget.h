// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANSelectItemNotifierPanelWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANSelectItemNotifierPanelWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANSelectItemNotifierPanelWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Functions
public:
	//Tries to close the interactable.
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void TryClose();
};
