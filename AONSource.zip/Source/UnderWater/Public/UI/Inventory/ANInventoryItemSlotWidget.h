// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANSelectableWidget.h"
#include "ANInventoryItemSlotWidget.generated.h"

class UANInventoryItemWidget;
class UANInventoryPanelWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInventoryItemSlotWidget : public UANSelectableWidget
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANInventoryItemSlotWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
public:

protected:
	//The UI item widget associated with this slot
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	UANInventoryItemWidget* AssociatedItemWidget;

	//The UI inventory panel widget that this item slot is in
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	UANInventoryPanelWidget* AssociatedInventoryPanelWidget;

	//The number of items contained inside this slot
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 ItemCount;

//Gameplay Functions
public:
	//Assigns an item widget to this slot and sets the default item count. Also properly parents it in the UI.
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void AssignItemWidget(UANInventoryItemWidget* NewItemWidget, int32 DefaultItemCount);

	//Selects this item slot for use in one of many applications
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void SelectItemSlot();

	//Clears the item out of this slot
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void ClearItemSlot();

	//Sets the inventory panel widget for this slot
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void SetInventoryPanelWidget(UANInventoryPanelWidget* NewInventoryPanelWidget);

	//Adds a number of items to this slot, then updates the item widget.
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void AddItemCount(int32 Count);

	//Removes a number of items from this slot, then updates the item widget. If the quantity drops below 0, 
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void RemoveItemCount(int32 Count);

protected:
	//Updates the slot's UI with the new item widget
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	void BP_AssignItemWidget(UANInventoryItemWidget* NewItemWidget);

	//Clears the slot's UI
	UFUNCTION(BlueprintImplementableEvent, Category = "Inventory")
	void BP_ClearItemWidget();


//Selectable Functions
public:
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber) override;

//SFX
protected:
	//The SFX that plays when you confirm this widget but couldn't use the item
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* ConfirmFailedSFX;


//Getters and Setters
public:
	//The UI item widget associated with this slot
	UFUNCTION(BlueprintPure, Category = "Inventory")
	FORCEINLINE UANInventoryItemWidget* GetAssociatedItemWidget() const { return AssociatedItemWidget; };

	//The UI inventory panel widget that this slot is in
	UFUNCTION(BlueprintPure, Category = "Inventory")
	FORCEINLINE UANInventoryPanelWidget* GetAssociatedInventoryPanelWidget() const { return AssociatedInventoryPanelWidget; };

	//Checks if this item is filled with something right now
	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool IsFilled() const;
};
