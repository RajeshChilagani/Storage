// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UI/ANSelectableWidget.h"

#include "ANStructs.h"

#include "ANInventoryItemWidget.generated.h"

class UANInventoryItem;
/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInventoryItemWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANInventoryItemWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
public:

protected:
	//The inventory item name
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory", Meta = (ExposeOnSpawn = true))
	FString InventoryItemName;

//Gameplay Functions
public:
	//Sets partial opacity
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_SetPartialOpacity(bool bPartialOpacity);

protected:
	//Assigns the inventory item in the UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_AssignInventoryItemUI();

	//Updates the inventory item count in the UI
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_UpdateInventoryItemCountUI(int32 NewCount);


//Getters and Setters
public:
	//Gets the inventory item name
	UFUNCTION(BlueprintPure, Category = "Inventory")
	FORCEINLINE FString GetInventoryItemName() const { return InventoryItemName; };

	//Gets the inventory item data row data
	UFUNCTION(BlueprintPure, Category = "Inventory")
	FANItem GetItemData() const;

	//Gets the inventory item data row data as a pointer
	FANItem* GetItemDataPointer() const;

	//Assigns the inventory item to this widget
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void AssignInventoryItem(const FString& NewInventoryItemName);

	//Updates the inventory item count on this widget
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void UpdateInventoryItemCount(int32 NewCount);
};
