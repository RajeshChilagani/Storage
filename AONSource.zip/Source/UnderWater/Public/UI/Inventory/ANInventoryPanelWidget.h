// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"

#include "ANEnums.h"

#include "ANInventoryPanelWidget.generated.h"

class IANItemable;
class IANSelectable;
class UANInventoryItemSlotWidget;
class UANInventoryItem;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANInventoryPanelWidget : public UANWidgetBase
{
	GENERATED_BODY()
	

//Unreal Functions
public:
	UANInventoryPanelWidget(const FObjectInitializer& ObjectInitializer);


//Gameplay Variables
public:

protected:
	//The inventory mode for when this widget opens. This affects what happens when we use items with it open.
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	EANInventoryModes InventoryMode;

	//An array of a row of item slot widgets. (These can contain inventory item data, but are not those; just the slots.)
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	TArray<UANInventoryItemSlotWidget*> InventoryItemSlotWidgetsRow1;

	//An array of a row of item slot widgets. (These can contain inventory item data, but are not those; just the slots.)
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Inventory")
	TArray<UANInventoryItemSlotWidget*> InventoryItemSlotWidgetsRow2;

//Gameplay Functions
public:
	//Sets the selected item name text to a specified item
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_SetSelectedItemNameText(const FString& InventoryItemName);

	//Clears the selected item name text
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_ClearSelectedItemNameText();

	//Adds an item to the inventory panel
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_AddItemToInventoryUI(const FString& InventoryItemName, int32 Count);

	//Removes an item from the inventory panel
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Inventory")
	void BP_RemoveItemFromInventoryUI(const FString& InventoryItemName, int32 Count);

	//Updates the icon opacity based on the itemable
	void UpdateIconOpacityForItemable(IANItemable* Itemable);

	//Updates the icon opacity for all inventory use types
	void UpdateIconOpacityForInventoryUseTypes();

//Getters and Setters
public:
	//Gets the current inventory mode
	UFUNCTION(BlueprintPure, Category = "Inventory")
	FORCEINLINE EANInventoryModes GetInventoryMode() const { return InventoryMode; };

	//Sets the inventory mode
	UFUNCTION(BlueprintCallable, Category = "Inventory")
	void SetInventoryMode(EANInventoryModes NewInventoryMode);

	//Returns a single array of all the item slot widgets. (These can contain inventory item data, but are not those; just the slots.)
	UFUNCTION(BlueprintPure, Category = "Inventory")
	TArray<UANInventoryItemSlotWidget*> GetAllInventoryItemSlotWidgets() const;

	//Returns an array of an array of all the item slot widgets. (These can contain inventory item data, but are not those; just the slots.)
	TArray<TArray<IANSelectable*>> GetAllInventoryItemSlotWidgetsAsSelectableArray() const;

	//Finds the first slot that isn't filled. If no slots are open, returns false
	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool GetFirstUnfilledInventoryItemSlot(UANInventoryItemSlotWidget*& FirstUnfilledInventoryItemSlot) const;

	//Finds the item slot for the according inventory item
	UFUNCTION(BlueprintPure, Category = "Inventory")
	bool GetInventoryItemSlotForInventoryItem(const FString& SearchingInventoryItemName, UANInventoryItemSlotWidget*& CorrespondingInventoryItemSlot) const;
};
