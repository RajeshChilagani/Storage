// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANVoltageSystemItemWidget.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANVoltageSystemItemWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANVoltageSystemItemWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;


//Gameplay Variables
protected:
	//The associated actor for this item widget
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	AActor* AssociatedActor;

	//The target voltage for this item widget
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	int32 TargetVoltage;

	//If this shows that it is powered on
	UPROPERTY(BlueprintReadWrite, Category = "Gameplay")
	bool bPoweredOn;


//Gameplay Functions
public:
	//Sets the default values for this item widget
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void SetDefaultValues(AActor* NewAssociatedActor, int32 NewTargetVoltage);

	//Sets up the default appearance
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_SetupDefaultAppearance();

	//Updates the powered status based on the new voltage
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void UpdatePoweredStatus(int32 NewVoltage);

	//Shows the powered status as on or off
	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Gameplay")
	void BP_ShowPoweredStatus(bool bOn);


//Getters
public:
	//Gets the associated actor
	UFUNCTION(BlueprintPure, Category = "Getters")
	AActor* GetAssociatedActor() const { return AssociatedActor; };

	//Gets the target voltage
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE int32 GetTargetVoltage() const { return TargetVoltage; };

	//Gets if this is powered on
	UFUNCTION(BlueprintPure, Category = "Getters")
	FORCEINLINE bool IsPoweredOn() const { return bPoweredOn; };

};
