// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "UI/ANWidgetBase.h"
#include "ANVoltageSystemPanelWidget.generated.h"

class UANVoltageSystemItemWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANVoltageSystemPanelWidget : public UANWidgetBase
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	UANVoltageSystemPanelWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;


//Gameplay Variables
protected:
	//An array of all child voltage system item widgets
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANVoltageSystemItemWidget*> VoltageSystemItemWidgets;

//Gameplay Functions
public:
	//Updates the powered status for each item based on new voltage
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void UpdatePoweredStatus(int32 NewVoltage);


//Getters
public:
	//Gets the voltage system item widgets
	UFUNCTION(BlueprintPure, Category = "Getters")
	TArray<UANVoltageSystemItemWidget*> GetVoltageSystemItemWidgets() { return VoltageSystemItemWidgets; };
};
