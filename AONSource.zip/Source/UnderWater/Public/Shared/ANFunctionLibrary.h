// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"

#include "ANEnums.h"

#include "ANFunctionLibrary.generated.h"

class UDataTable;

class UANGameInstance;
class UANGameUserSettings;
class UANGameplaySaveGame;
class UANInventorySystem;
class UANSelectableWidget;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UANFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
//Helper Functions
public:
	//Attempts to load a soft object if it hasn't been loaded yet. Returns true if the load was successful.
	UFUNCTION(BlueprintCallable, Category = "Soft Pointers")
	static bool LoadSoftObject(TSoftObjectPtr<UObject> SoftObject);

	//Tries to get a blueprint based on a file path.
	UFUNCTION(Category = "Blueprint")
	static UBlueprint* GetBlueprint(FString FilePath);

	//Gets the game instance from a world context object
	UFUNCTION(BlueprintPure, Category = "Game Instance")
	static UANGameInstance* GetGameInstance(const UObject* WorldContextObject);

	//Gets the active gameplay save game from a world context object
	UFUNCTION(BlueprintPure, Category = "Inventory")
	static UANGameplaySaveGame* GetActiveGameplaySaveGame(const UObject* WorldContextObject);

	//Gets the inventory system from a world context object
	UFUNCTION(BlueprintPure, Category = "Inventory")
	static UANInventorySystem* GetInventorySystem(const UObject* WorldContextObject);

	//Gets the linear color for a message color
	UFUNCTION(BlueprintPure, Category = "Color")
	static FLinearColor GetLinearColorForMessageColor(EANMessageColors MessageColor);

	//Gets the saveable value for a param name in a saveable params string
	UFUNCTION(BlueprintPure, Category = "Saveable")
	static FString GetSaveableParamValue(FString SaveableParamsString, FString ParamName);

	//Makes a saveable param for a param name and value
	UFUNCTION(BlueprintPure, Category = "Saveable")
	static FString MakeSaveableParam(FString ParamName, FString ParamValue);

	//Gets the sublevel names for a level
	UFUNCTION(BlueprintPure, Category = "Levels")
	static TArray<FName> GetSharedSublevelNames();

	//Gets the sublevel names for a level
	UFUNCTION(BlueprintPure, Category = "Levels")
	static TArray<FName> GetSublevelNamesForLevel(EANLevels Level);

	//Gets the Abyss of Neptune game user settings
	UFUNCTION(BlueprintCallable, Category = "Settings")
	static UANGameUserSettings* GetANGameUserSettings();

	//Gets the current project version
	UFUNCTION(BlueprintPure, Category = "Config")
	static FString GetProjectVersion();

	//Sets color deficiency to a specified mode
	UFUNCTION(BlueprintCallable, Category = "Helper")
	static void SetColorDeficiency(EColorDeficiencyMode ColorDeficiencyMode, float Severity, bool bCorrectDeficiency, bool bShowCorrectionWithDeficiency);


//Gameplay Functions
public:
	//Takes a condition class and checks if it is valid, checked against a specific actor
	UFUNCTION(BlueprintPure, Category = "Condition")
	static bool IsConditionValid(TSubclassOf<UANCondition> ConditionToVerifySubclass, AActor* CheckAgainstActor, AActor* InstigatingActor);


//Conversion Functions
public:
	//Converts a settings value of sensitivity to a float modifier
	UFUNCTION(BlueprintPure, Category = "Conversion")
	static float ConvertSensitivityToModifier(int32 SensitivityLevel);

	//Converts a settings value of volume to a float modifier
	UFUNCTION(BlueprintPure, Category = "Conversion")
	static float ConvertVolumeToModifier(int32 VolumeLevel);

	//Gets an action mapping name for an input action
	UFUNCTION(BlueprintPure, Category = "Conversion")
	static FName GetActionMappingForInputAction(EANInputActions InputAction);

	//Converts the color deficiency mode (for blueprint use) to color vision deficiency
	UFUNCTION(BlueprintPure, Category = "Conversion")
	static EColorVisionDeficiency ConvertColorDeficiencyModeToColorVisionDeficiency(EColorDeficiencyMode ColorDeficiencyMode);


//UI Functions
public:
	//Initializes a selectable widget. Adds it to an array and hides it if the platform is invalid.
	UFUNCTION(BlueprintCallable, Category = "UI")
	static void InitializeSelectableWidget(UANSelectableWidget* AddingSelectableWidget, UPARAM(ref) TArray<UANSelectableWidget*>& AddingToArray);


//Platform Functions
public:
	//Gets the current platform
	UFUNCTION(BlueprintPure, Category = "Platform")
	static EPlatforms GetPlatform();

	//Checks if we are playing on a console
	UFUNCTION(BlueprintPure, Category = "Platform")
	static bool IsConsole();

	//Unlocks a specified achievement
	UFUNCTION(BlueprintCallable, Category = "Debug")
	static void UnlockAchievement(EANAchievements AchievementNameToUnlock, UObject* WorldRefObject);

	//Checks if development build
	UFUNCTION(BlueprintCallable, Category = "Debug")
	static bool IsDevelopmentBuild();

	//Finds a row based on Ping Type. Data table should be ContextualPingTypes.
	//UFUNCTION(BlueprintCallable, Category = "Utilities")
	//static bool FindContextualPingTypesRowByType(const UDataTable* ContextualPingTypesDT, EPingType PingType, FContextualPingTypesRow& ContextualPingTypesRow);
};
