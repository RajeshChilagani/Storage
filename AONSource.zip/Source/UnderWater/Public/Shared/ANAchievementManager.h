// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANEnums.h"

#include "ANAchievementManager.generated.h"

class AANPlayerControllerBase;

UCLASS()
class UNDERWATER_API AANAchievementManager : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:
	AANAchievementManager();

	virtual void BeginPlay() override;


//Gameplay Functions
public:
	//Unlocks the specified achievement
	UFUNCTION(BlueprintCallable, Category = "Achievements")
	void UnlockAchievement(EANAchievements AchivementToUnlock);

	//Unlocks the specified achievement via a passed-in name
	UFUNCTION(BlueprintCallable, Category = "Achievements")
	void UnlockAchievementViaName(const FName& AchievementNameToUnlock);

	//Gets a name from the achievement enum
	UFUNCTION(BlueprintPure, Category = "Achievements")
	FName GetAchievementName(EANAchievements AchievementToUnlock);

protected:
	//Unlocks the specified achievement in blueprints using the easy-to-use achievement functions
	UFUNCTION(BlueprintImplementableEvent, Category = "Achievements")
	void UnlockAchievementInBlueprints(AANPlayerControllerBase* UnlockingPlayerController, const FName& AchievementName);

};
