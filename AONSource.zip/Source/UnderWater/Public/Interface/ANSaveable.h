// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Misc/Guid.h"
#include "ANSaveable.generated.h"

UINTERFACE(MinimalAPI)
class UANSaveable : public UInterface
{
	GENERATED_BODY()
};

/**
*
*/
class UNDERWATER_API IANSaveable
{
	GENERATED_BODY()

public:
	//Gets this object's saveable Guid
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Saveable")
	FGuid BP_GetSaveableGuid();
	virtual FGuid BP_GetSaveableGuid_Implementation()
	{
		return FGuid();
	};
	FGuid GetSaveableGuid()
	{
		if (AActor* SaveableAsActor = Cast<AActor>(this))
		{
			return IANSaveable::Execute_BP_GetSaveableGuid(SaveableAsActor);
		}

		return FGuid();
	};

	//Constructs a save string for this object in its current state
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Saveable")
	FString BP_ConstructSaveString();
	virtual FString BP_ConstructSaveString_Implementation()
	{
		return FString();
	}
	FString ConstructSaveString()
	{
		if (AActor* SaveableAsActor = Cast<AActor>(this))
		{
			return IANSaveable::Execute_BP_ConstructSaveString(SaveableAsActor);
		}

		return FString();
	}

	//Saves this object by passing in a string
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Saveable")
	void BP_SaveObject();
	virtual void BP_SaveObject_Implementation()
	{

	};
	void SaveObject()
	{
		if (AActor* SaveableAsActor = Cast<AActor>(this))
		{
			IANSaveable::Execute_BP_SaveObject(SaveableAsActor);
		}
	};

	//Loads this object with a passed in string
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Saveable")
	void BP_LoadObject(const FString& LoadString);
	virtual void BP_LoadObject_Implementation(const FString& LoadString)
	{

	};
	void LoadObject(const FString& LoadString)
	{
		if (AActor* SaveableAsActor = Cast<AActor>(this))
		{
			IANSaveable::Execute_BP_LoadObject(SaveableAsActor, LoadString);
		}
	}

};