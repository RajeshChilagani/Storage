#pragma once

#include "CoreMinimal.h"

#include "ANStructs.h"

#include "ANWorldSaveable.generated.h"

UINTERFACE(MinimalAPI)//, meta = (CannotImplementInterfaceInBlueprint))
class UANWorldSaveable : public UInterface
{
	GENERATED_BODY()
};

/**
*
*/
class UNDERWATER_API IANWorldSaveable
{
	GENERATED_BODY()

public:
	//Initializes the world saveable object with the passed-in parameters
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "World Saveable")
	void BP_InitializeWorldSaveableObject(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign);
	virtual void BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
	{

	}
	void InitializeWorldSaveableObject(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_InitializeWorldSaveableObject(WorldSaveableAsActor, GuidToAssign, WorldSaveableDataToAssign);
		}
	};

	//If this object can be added to the world saveables map for saving and loading
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "World Saveable")
	bool BP_CanSaveToWorldSaveablesMap();
	virtual bool BP_CanSaveToWorldSaveablesMap_Implementation()
	{
		return true;
	}
	bool CanSaveToWorldSaveablesMap()
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_CanSaveToWorldSaveablesMap(WorldSaveableAsActor);
		}

		return false;
	};

	//Updates the world saveable state for this object. Usually calls GetWorldSaveableData then saves it.
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "World Saveable")
	void BP_UpdateWorldSaveableState();
	virtual void BP_UpdateWorldSaveableState_Implementation()
	{

	}
	void UpdateWorldSaveableState()
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_UpdateWorldSaveableState(WorldSaveableAsActor);
		}
	};

	//Gets this object's saveable Guid
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "World Saveable")
	FGuid BP_GetWorldSaveableGuid();
	virtual FGuid BP_GetWorldSaveableGuid_Implementation()
	{
		return FGuid();
	};
	FGuid GetWorldSaveableGuid()
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_GetWorldSaveableGuid(WorldSaveableAsActor);
		}

		return FGuid();
	};

	//Gets world saveable data for this actor
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "WorldSaveable")
	FWorldSaveableData BP_GetWorldSaveableData();
	virtual FWorldSaveableData BP_GetWorldSaveableData_Implementation()
	{
		return FWorldSaveableData();
	}
	FWorldSaveableData GetWorldSaveableData()
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_GetWorldSaveableData(WorldSaveableAsActor);
		}

		return FWorldSaveableData();
	}

	//Constructs a save string for this object in its current state
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "World Saveable")
	FString BP_ConstructSaveableParamsString();
	virtual FString BP_ConstructSaveableParamsString_Implementation()
	{
		return FString();
	}
	FString ConstructSaveableParamsString()
	{
		if (AActor* WorldSaveableAsActor = Cast<AActor>(this))
		{
			return IANWorldSaveable::Execute_BP_ConstructSaveableParamsString(WorldSaveableAsActor);
		}

		return FString();
	}

};