// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"

#include "ANEnums.h"

#include "ANSelectable.generated.h"


UINTERFACE(MinimalAPI)//, meta = (CannotImplementInterfaceInBlueprint))
class UANSelectable : public UInterface
{
	GENERATED_BODY()
};

/**
*An interface for UI-esque selectable objects. May include actual UI widgets or objects in puzzles.
*/
class UNDERWATER_API IANSelectable
{
	GENERATED_BODY()

public:
	//Confirms this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_Confirm(EPlayerNumbers PlayerNumber);
	virtual void BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
	{
		return;
	}
	virtual void Confirm(EPlayerNumbers PlayerNumber)
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_Confirm(SelectableAsObject, PlayerNumber);
		}
	}

	//Highlights this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_Highlight(EPlayerNumbers PlayerNumber);
	virtual void BP_Highlight_Implementation(EPlayerNumbers PlayerNumber)
	{
		return;
	}
	virtual void Highlight(EPlayerNumbers PlayerNumber)
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_Highlight(SelectableAsObject, PlayerNumber);
		}
	}

	//Unhighlights this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_Unhighlight(EPlayerNumbers PlayerNumber);
	virtual void BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber)
	{
		return;
	}
	virtual void Unhighlight(EPlayerNumbers PlayerNumber)
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_Unhighlight(SelectableAsObject, PlayerNumber);
		}
	}

	//Checks if this player number is highlighting this object right now
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_IsPlayerNumberHighlighting(EPlayerNumbers PlayerNumber) const;
	virtual bool BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const
	{
		return false;
	}
	virtual bool IsPlayerNumberHighlighting(EPlayerNumbers PlayerNumber) const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_IsPlayerNumberHighlighting(SelectableAsObject, PlayerNumber);
		}
		return false;
	}

	//Enables this object to be selected
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_EnableSelectable();
	virtual void BP_EnableSelectable_Implementation()
	{
		return;
	}
	virtual void EnableSelectable()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_EnableSelectable(SelectableAsObject);
		}
	}

	//Disables this object from being selected
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_DisableSelectable();
	virtual void BP_DisableSelectable_Implementation()
	{
		return;
	}
	virtual void DisableSelectable()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_DisableSelectable(SelectableAsObject);
		}
	}

	//Checks if this object can be selected
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_CanSelect() const;
	virtual bool BP_CanSelect_Implementation() const
	{
		return false;
	}
	virtual bool CanSelect() const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_CanSelect(SelectableAsObject);
		}
		return false;
	}

	//If this selectable has special logic when pressing up
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_HasPressUpLogic() const;
	virtual bool BP_HasPressUpLogic_Implementation() const
	{
		return false;
	}
	virtual bool HasPressUpLogic() const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_HasPressUpLogic(SelectableAsObject);
		}
		return false;
	}

	//Performs some special logic when pressing up
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_DoPressUpLogic();
	virtual void BP_DoPressUpLogic_Implementation()
	{
		return;
	}
	virtual void DoPressUpLogic()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_DoPressUpLogic(SelectableAsObject);
		}
	}

	//If this selectable has special logic when pressing down
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_HasPressDownLogic() const;
	virtual bool BP_HasPressDownLogic_Implementation() const
	{
		return false;
	}
	virtual bool HasPressDownLogic() const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_HasPressDownLogic(SelectableAsObject);
		}
		return false;
	}

	//Performs some special logic when pressing down
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_DoPressDownLogic();
	virtual void BP_DoPressDownLogic_Implementation()
	{
		return;
	}
	virtual void DoPressDownLogic()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_DoPressDownLogic(SelectableAsObject);
		}
	}

	//If this selectable has special logic when pressing right
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_HasPressRightLogic() const;
	virtual bool BP_HasPressRightLogic_Implementation() const
	{
		return false;
	}
	virtual bool HasPressRightLogic() const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_HasPressRightLogic(SelectableAsObject);
		}
		return false;
	}

	//Performs some special logic when pressing right
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_DoPressRightLogic();
	virtual void BP_DoPressRightLogic_Implementation()
	{
		return;
	}
	virtual void DoPressRightLogic()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_DoPressRightLogic(SelectableAsObject);
		}
	}

	//If this selectable has special logic when pressing left
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	bool BP_HasPressLeftLogic() const;
	virtual bool BP_HasPressLeftLogic_Implementation() const
	{
		return false;
	}
	virtual bool HasPressLeftLogic() const
	{
		if (const UObject* SelectableAsObject = Cast<UObject>(this))
		{
			return Execute_BP_HasPressLeftLogic(SelectableAsObject);
		}
		return false;
	}

	//Performs some special logic when pressing left
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Selectable")
	void BP_DoPressLeftLogic();
	virtual void BP_DoPressLeftLogic_Implementation()
	{
		return;
	}
	virtual void DoPressLeftLogic()
	{
		if (UObject* SelectableAsObject = Cast<UObject>(this))
		{
			Execute_BP_DoPressLeftLogic(SelectableAsObject);
		}
	}

};