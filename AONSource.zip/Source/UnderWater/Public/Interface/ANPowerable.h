#pragma once

#include "CoreMinimal.h"
#include "ANPowerable.generated.h"

UINTERFACE(MinimalAPI)//, meta = (CannotImplementInterfaceInBlueprint))
class UANPowerable : public UInterface
{
	GENERATED_BODY()
};

/**
*
*/
class UNDERWATER_API IANPowerable
{
	GENERATED_BODY()

public:
	//Powers on this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Powerable")
	void BP_PowerOn();
	virtual void BP_PowerOn_Implementation();
	void PowerOn()
	{
		if (AActor* PowerableAsActor = Cast<AActor>(this))
		{
			Execute_BP_PowerOn(PowerableAsActor);
		}
	};

	//Powers off this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Powerable")
	void BP_PowerOff();
	virtual void BP_PowerOff_Implementation();
	void PowerOff()
	{
		if (AActor* PowerableAsActor = Cast<AActor>(this))
		{
			Execute_BP_PowerOff(PowerableAsActor);
		}
	};

	//Checks to see if this item can be inserted or not
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Powerable")
	bool BP_IsPoweredOn();
	virtual bool BP_IsPoweredOn_Implementation();
	bool IsPoweredOn()
	{
		if (AActor* PowerableAsActor = Cast<AActor>(this))
		{
			return Execute_BP_IsPoweredOn(PowerableAsActor);
		}

		return false;
	}

	//Gets the name of this powerable object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Powerable")
	FText BP_GetPowerableName();
	virtual FText BP_GetPowerableName_Implementation();
	FText GetPowerableName()
	{
		if (AActor* PowerableAsActor = Cast<AActor>(this))
		{
			return Execute_BP_GetPowerableName(PowerableAsActor);
		}

		return FText();
	}

};