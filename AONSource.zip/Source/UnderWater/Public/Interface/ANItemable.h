#pragma once

#include "CoreMinimal.h"
#include "ANItemable.generated.h"

class AANCharacterBase;

UINTERFACE(MinimalAPI)//, meta = (CannotImplementInterfaceInBlueprint))
class UANItemable : public UInterface
{
	GENERATED_BODY()
};

/**
*
*/
class UNDERWATER_API IANItemable
{
	GENERATED_BODY()

public:
	//Uses/inserts an item on/in this object, and optionally consumes it from the player's inventory
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Itemable")
	void BP_InsertItem(const FString& InsertedItem, bool bConsumeItem);
	virtual void BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
	{

	};
	void InsertItem(const FString& InsertedItem, bool bConsumeItem)
	{
		if (AActor* ItemableAsActor = Cast<AActor>(this))
		{
			IANItemable::Execute_BP_InsertItem(ItemableAsActor, InsertedItem, bConsumeItem);
		}
	};

	//Checks to see if this item can be inserted or not
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Itemable")
	bool BP_CanInsertItem(const FString& InsertedItem);
	virtual bool BP_CanInsertItem_Implementation(const FString& InsertedItem)
	{
		return true;
	};
	bool CanInsertItem(const FString& InsertedItem)
	{
		if (AActor* ItemableAsActor = Cast<AActor>(this))
		{
			return IANItemable::Execute_BP_CanInsertItem(ItemableAsActor, InsertedItem);
		}

		return false;
	}

	//Takes an item from this object
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Itemable")
	void BP_TakeItem(const FString& TakenItem);
	virtual void BP_TakeItem_Implementation(const FString& TakenItem)
	{

	};
	void TakeItem(const FString& TakenItem)
	{
		if (AActor* ItemableAsActor = Cast<AActor>(this))
		{
			IANItemable::Execute_BP_TakeItem(ItemableAsActor, TakenItem);
		}
	};

};