// �2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "ANInteractable.generated.h"

class AANCharacterBase;

UENUM(BlueprintType)
enum class EInspectAction : uint8
{
	Horizontal
	UMETA(DisplayName = "Rotate based on Horizontal Input"),
	Vertical
	UMETA(DisplayName = "Rotate based on Vertical Input"),
	Zoom
	UMETA(DisplayName = "ZoomIn/ZoomOut"),
};

UINTERFACE(MinimalAPI, meta = (CannotImplementInterfaceInBlueprint))
class UANInteractable : public UInterface
{
	GENERATED_BODY()
};

/**
*
*/
class UNDERWATER_API IANInteractable
{
	GENERATED_BODY()

public:
	//Can we interact with this interactable object right now?
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual bool CanInteract() const
	{
		return true;
	};

	//Begins the interaction with this object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter);
	
	//Ends the interaction with this object
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual void EndInteract(AANCharacterBase* InteractingCharacter);

	//Is this interactable a longer interact, like accessing a battery panel? If so, we will need something to tell us when the interact ends
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual bool IsLongInteract() const
	{
		return false;
	}

	//Is this object being interacted with right now?
	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual bool IsInteracting() const
	{
		return false;
	};

	UFUNCTION(BlueprintCallable, Category = "Interaction")
	virtual void Inspect(float AxisValue, EInspectAction InspectAction)
	{
		
	};

};