#pragma once

/*This class is responsible for storing core enums*/

//The different actions players can make
UENUM(BlueprintType)
enum class EANInputActions : uint8
{
	Fire
	UMETA(DisplayName = "Fire"),
	Aim
	UMETA(DisplayName = "Aim"),
	Interact
	UMETA(DisplayName = "Interact"),
	Flashlight
	UMETA(DisplayName = "Flashlight"),
	Reload
	UMETA(DisplayName = "Reload"),
	Jet
	UMETA(DisplayName = "Jet"),
	Ascend
	UMETA(DisplayName = "Ascend"),
	Descend
	UMETA(DisplayName = "Descend"),
	WatchPeek
	UMETA(DisplayName = "WatchPeek"),
	Inventory
	UMETA(DisplayName = "Inventory"),
	Map
	UMETA(DisplayName = "Map"),
	AttachmentOne
	UMETA(DisplayName = "Attachment One"),
	AttachmentTwo
	UMETA(DisplayName = "Attachment Two"),
	AttachmentThree
	UMETA(DisplayName = "Attachment Three"),
	AttachmentFour
	UMETA(DisplayName = "Attachment Four"),

	UIConfirm
	UMETA(DisplayName = "UI Confirm"),
	UIBack
	UMETA(DisplayName = "UI Back"),
	UISpecialOne
	UMETA(DisplayName = "UI Special One"),
	UISpecialTwo
	UMETA(DisplayName = "UI Special Two"),

	UITabRightOne
	UMETA(DisplayName = "UI Tab Right One"),
	UITabLeftOne
	UMETA(DisplayName = "UI Tab Left One"),
	UITabRightTwo
	UMETA(DisplayName = "UI Tab Right Two"),
	UITabLeftTwo
	UMETA(DisplayName = "UI Tab Left Two"),

	UIUp
	UMETA(DisplayName = "UI Up"),
	UIDown
	UMETA(DisplayName = "UI Down"),
	UIRight
	UMETA(DisplayName = "UI Right"),
	UILeft
	UMETA(DisplayName = "UI Left"),

	UICursorClick
	UMETA(DisplayName = "UI Cursor Click"),

	Pause
	UMETA(DisplayName = "Pause"),

	DebugMenu
	UMETA(DisplayName = "Debug Menu"),

	//Move - not for gameplay actions. Use ANInputAxes instead.
	MoveDisplayOnly
	UMETA(DisplayName = "Move (Display Only)"),
	//Look = not for gameplay actions. Use ANInputAxes instead.
	LookDisplayOnly
	UMETA(DisplayName = "Look (Display Only)"),
};

//The different axes players can use
UENUM(BlueprintType)
enum class EANInputAxes : uint8
{
	LSVertical
	UMETA(DisplayName = "LS Vertical"),
	LSHorizontal
	UMETA(DisplayName = "LS Horizontal"),
	RSVertical
	UMETA(DisplayName = "RS Vertical"),
	RSHorizontal
	UMETA(DisplayName = "RS Horizontal"),
	MouseVertical
	UMETA(DisplayName = "Mouse Vertical"),
	MouseHorizontal
	UMETA(DisplayName = "Mouse Horizontal"),
	MouseWheel
	UMETA(DisplayName = "Mouse Wheel"),
};

//The different maps/levels in the game
UENUM(BlueprintType)
enum class EANLevels : uint8
{
	Tutorial,
	Dormitory,
	Lobby,
	Academics,
	Lab,
};

//The difficulty levels
UENUM(BlueprintType)
enum class EANDifficultyLevels : uint8
{
	Easy,
	Normal,
	Hard,
};

//Different game input types (game vs UI)
UENUM(BlueprintType)
enum class EGameInputTypes : uint8
{
	GameOnly
	UMETA(DisplayName = "Game Only"),
	UIOnly
	UMETA(DisplayName = "UI Only"),
	GameAndUI
	UMETA(DisplayName = "Game and UI"),
	Transition
	UMETA(DisplayName = "Transition"),
};

//Different camera modes which can also affect movement.
UENUM(BlueprintType)
enum class ECameraModes : uint8
{
	Normal
	UMETA(DisplayName = "Normal"),
	LockedOn
	UMETA(DisplayName = "Locked On"),
};

//Different player numbers. Probably won't be needed, but just in case.
UENUM(BlueprintType)
enum class EPlayerNumbers : uint8
{
	P1
	UMETA(DisplayName = "P1"),
	P2
	UMETA(DisplayName = "P2"),
	P3
	UMETA(DisplayName = "P3"),
	P4
	UMETA(DisplayName = "P4"),
};

//Represents justification types for buttons in a layout.
UENUM(BlueprintType)
enum class EButtonJustifications : uint8
{
	Left
	UMETA(DisplayName = "Left"),
	Center
	UMETA(DisplayName = "Center"),
	Right
	UMETA(DisplayName = "Right"),
	Custom
	UMETA(DisplayName = "Custom"),
};

//Represents different sides. Can be used for many different purposes.
UENUM(BlueprintType)
enum class ESides : uint8
{
	Left
	UMETA(DisplayName = "Left"),
	Center
	UMETA(DisplayName = "Center"),
	Right
	UMETA(DisplayName = "Right"),
};

//Different colors that UI messages can show up as
UENUM(BlueprintType)
enum class EANMessageColors : uint8
{
	White,
	Red,
	Cyan,
	Yellow,
	Pink,
	Orange,
};

UENUM(BlueprintType)
enum class EANItemType : uint8
{
	PuzzleItem		UMETA(DisplayName = "Puzzle Item"),
	Consumable      UMETA(DisplayName = "Consumable"),
	Equipment       UMETA(DisplayName = "Equipment"),
	Material        UMETA(DisplayName = "Material")
};

UENUM(BlueprintType)
enum class EANItemEvent : uint8
{
	Add,
	Remove,
	Pick,
	Use
};

//Different effects that can happen when we use an item in the inventory directly
UENUM(BlueprintType)
enum class EANItemInventoryUseTypes : uint8
{
	None,
	Drop,
	Use,
	Inspect,
};

//Different modes for when the inventory is open
UENUM(BlueprintType)
enum class EANInventoryModes : uint8
{
	None,
	Puzzle,
	Use,
};

//Different ways of how we can add an item to the inventory
UENUM(BlueprintType)
enum class EAddItemMethods : uint8
{
	Other,
	PickUp,
	Craft,
};

//Different states of map rooms
UENUM(BlueprintType)
enum class EMapRoomStates : uint8
{
	NeverVisited,
	PreviouslyVisited,
	CurrentlyVisited,
};

//Represents different sides. Can be used for many different purposes.
UENUM(BlueprintType)
enum class EANKeyButtonTypes : uint8
{
	Add
	UMETA(DisplayName = "Add"),
	Delete
	UMETA(DisplayName = "Delete"),
	Confirm
	UMETA(DisplayName = "Confirm"),
};

UENUM(BlueprintType)
enum class EInfoPanelCategory : uint8
{
	Numeric UMETA(DisplayName = "Numeric"),
	Alphabetic UMETA(DisplayName = "Alphabetic"),
	Hydrophyte UMETA(DisplayName = "Aquatic Plants"),
	Watercraft UMETA(DisplayName = "Boat"),
};

//SecondaryEnemy Animation State Enums
UENUM(BlueprintType)
enum class ESecondaryEnemyState :uint8
{
	Idle,
	MoveRandomly,
	Attack,
	AvoidPlayer,
	Dead
};


UENUM(BlueprintType)
enum class EFocusOutlineColor: uint8
{
	NoColor,
	Yellow UMETA(DisplayName = "Yellow"),
	AquaBlue UMETA(DisplayName = "AquaBlue"),
};

//Different platforms
UENUM(BlueprintType)
enum class EPlatforms : uint8
{
	Steam,
	PS4,
};

//Different icon sets
UENUM(BlueprintType)
enum class EIconSets : uint8
{
	KeyboardMouse,
	Xbox,
	PS4,
};

//Different platforms
UENUM(BlueprintType)
enum class EANAchievements : uint8
{
	//Complete the tutorial
	AbyssOfLearning,
	//Get the harpoon gun
	AbyssOfShooting,
	//Complete the Academics Wing
	AbyssOfAcademia,
	//Find 3 logs
	AbyssOfSearching,
	//Find 6 logs
	AbyssOfExploration,
	//Find all logs and complete the game
	AbyssOfCompletion,
	//Complete the game in under 20 minutes
	AbyssOfSpeedrunning,
	//Complete the game without using any healing items
	AbyssOfGrit,
	//Complete the game in easy mode
	AbyssOfMercy,
	//Complete the game in normal mode
	AbyssOfPersistence,
	//Complete the game in hard mode
	AbyssOfMasochism,
	//Find the hidden room
	AbyssOfDevelopers,
};

//Same as EColorVisionDeficiency, but this is BlueprintType so we can use it for settings
UENUM(BlueprintType)
enum class EColorDeficiencyMode : uint8
{
	NormalVision UMETA(DisplayName = "Normal Vision"),
	Deuteranope UMETA(DisplayName = "Deuteranope (green weak/blind) (7% of males, 0.4% of females)"),
	Protanope UMETA(DisplayName = "Protanope (red weak/blind) (2% of males, 0.01% of females)"),
	Tritanope UMETA(DisplayName = "Tritanope (blue weak/bind) (0.0003% of males)"),
};
