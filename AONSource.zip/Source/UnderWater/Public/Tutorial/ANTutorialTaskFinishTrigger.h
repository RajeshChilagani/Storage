// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Environment/ANGenericTrigger.h"

#include "ANTutorialTaskFinishTrigger.generated.h"

class UBoxComponent;

class AANTutorialTask;


UCLASS()
class UNDERWATER_API AANTutorialTaskFinishTrigger : public AANGenericTrigger
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANTutorialTaskFinishTrigger();


//Customizable Variables
public:
	//The tutorial task to finish
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	AANTutorialTask* TutorialTaskToFinish;


//Gameplay Functions
protected:
	virtual void PlayTriggerEvent_Implementation(AActor* OverlappedActor);

};
