// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "ANDelegates.h"
#include "ANStructs.h"

#include "ANTutorialTask.generated.h"

class AANMainCharacter;
class UANDialogueConversation;

UCLASS()
class UNDERWATER_API AANTutorialTask : public AActor
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANTutorialTask();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;


//Customizable Variables
public:
	//The task name/header
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FText TaskName;

	//The description of this task
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	FText TaskDescription;

	//Data for the input prompts to display (blueprintreadwrite so we can pass as variable)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	TArray<FInputPromptData> InputPromptDatas;

	//The dialogue conversation that will play when we start this tutorial task. Will not play anything if not set.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> TutorialStartDialogueConversation;

	//The dialogue conversation that will play when we finish this tutorial task. Will not play anything if not set.
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Defaults")
	TSoftObjectPtr<UANDialogueConversation> TutorialFinishDialogueConversation;


//Delegates
public:
	//When the tutorial task starts
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnTutorialTaskStarted OnTutorialTaskStarted;

	//When the tutorial task finishes
	UPROPERTY(BlueprintAssignable, Category = "Delegates")
	FOnTutorialTaskFinished OnTutorialTaskFinished;


//Gameplay Variables
protected:
	//If this task is active currently
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bActive;

	//If this task is finished
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	bool bFinished;

	//The character performing this task
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	AANMainCharacter* TaskCharacter;

//Gameplay Functions
public:
	//Starts the task
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void StartTask(AANMainCharacter* NewTaskCharacter);

	//Finishes the task
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void FinishTask(AANMainCharacter* NewTaskCharacter);


//Getters
public:
	//Is this task active?
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsActive() const { return bActive; };
	
	//Is this task finished?
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsFinished() const { return bFinished; };
};
