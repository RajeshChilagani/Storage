// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "Environment/ANGenericTrigger.h"

#include "ANTutorialTaskStartTrigger.generated.h"

class UBoxComponent;

class AANTutorialTask;


UCLASS()
class UNDERWATER_API AANTutorialTaskStartTrigger : public AANGenericTrigger
{
	GENERATED_BODY()
	
//Unreal Functions
public:	
	AANTutorialTaskStartTrigger();


//Customizable Variables
public:
	//The tutorial task to start
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Defaults")
	AANTutorialTask* TutorialTaskToStart;


//Gameplay Functions
protected:
	virtual void PlayTriggerEvent_Implementation(AActor* OverlappedActor);

};
