// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "ANHardDriveData.generated.h"


UENUM(BlueprintType)
enum class HardDriveType : uint8
{
	Raid0 UMETA(DisplayName = "Raid Zero"),
	Raid5 UMETA(DisplayName = "Raid Five"),
	Raid010 UMETA(DisplayName = "Raid Ten")
};

/**
 * 
 */
UCLASS(BlueprintType)
class UNDERWATER_API UANHardDriveData : public UDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TMap<HardDriveType, class UMaterialInstance*> AccessMaterialMap;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
		TMap<HardDriveType, FString> AccessItemNameMap;
};
