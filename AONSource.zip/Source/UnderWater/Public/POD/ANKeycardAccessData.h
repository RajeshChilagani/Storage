// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "ANKeycardAccessData.generated.h"

UENUM(BlueprintType)
enum class KeyType : uint8
{
	Level1 UMETA(DisplayName = "KeyCard Level 1"),
	Level2 UMETA(DisplayName = "KeyCard Level 2"),
	Level3 UMETA(DisplayName = "KeyCard Level 3"),
	Level4 UMETA(DisplayName = "KeyCard Level 4"),
	Level5 UMETA(DisplayName = "KeyCard Level 5"),
};

/**
 * DataAsset to store keycards Access Information
 */
UCLASS(BlueprintType)
class UNDERWATER_API UANKeycardAccessData : public UDataAsset
{
	GENERATED_BODY()
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TMap<KeyType, class UMaterialInstance*> AccessMaterialMap;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	TMap<KeyType,FString> AccessItemNameMap;
};
