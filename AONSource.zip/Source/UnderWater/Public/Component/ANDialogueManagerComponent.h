// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "ANDelegates.h"
#include "ANStructs.h"

#include "ANDialogueManagerComponent.generated.h"

class UANDialogueConversation;

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class UNDERWATER_API UANDialogueManagerComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UANDialogueManagerComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;


//Delegates
public:
	//Delegate for when a dialogue conversation finishes
	UPROPERTY(BlueprintAssignable, BlueprintCallable)
	FOnDialogueConversationFinished OnDialogueConversationFinished;


//Gameplay Variables
protected:
	//A list of all active dialogue conversations
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<FActiveDialogueConversationData> ActiveDialogueConversationDatas;

	//A list of dialogue conversations that will play after 
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	TArray<UANDialogueConversation*> QueuedDialogueConversations;


private:
	FActiveDialogueConversationData InvalidDialogueConversationData;

	////The active dialogue conversation
	//UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	//UANDialogueConversation* ActiveDialogueConversation;
	//
	////The index of the line that we're on in the conversation
	//UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Gameplay")
	//int32 ActiveDialogueLineIndex;
	//
	////Timer handle for advancing dialogue
	//FTimerHandle AdvanceDialogueTimerHandle;

//Gameplay Functions
public:
	//Adds a new dialogue conversation
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void AddNewDialogueConversation(UANDialogueConversation* NewDialogueConversation);

	//Starts the dialogue conversation
	UFUNCTION(BlueprintCallable, Category = "Gameplay")
	void StartNewDialogueConversation(UANDialogueConversation* NewDialogueConversation);

	//Advances the dialogue conversation
	UFUNCTION()
	void AdvanceDialogue(int32 DialogueConversationID);

	//Ends the dialogue conversation
	UFUNCTION()
	void EndDialogueConversation(int32 DialogueConversationID);


//Getters
public:
	//Gets the active dialogue conversation data for an ID
	FActiveDialogueConversationData& GetActiveDialogueConversationDataForID(int32 ActiveDialogueID);

	//Gets the array index for the dialogue conversation ID
	int32 GetArrayIndexForID(int32 ActiveDialogueID);

	//If we are playing any dialogue right now
	UFUNCTION(BlueprintPure, Category = "Getters")
	bool IsPlayingDialogue() const;

};
