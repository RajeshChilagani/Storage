// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/TimelineComponent.h"
#include "Interface/ANInteractable.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "GameFramework/Actor.h"
#include "ANLocker.generated.h"

class UAkAudioEvent;
class UBoxComponent;
class UCameraComponent;
class UCurveFloat;
class USceneComponent;
class UStaticMeshComponent;

UCLASS()
class UNDERWATER_API AANLocker : public AANPuzzleInteractable
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANLocker();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

public:	
	//UPROPERTY(EditAnywhere)
	//USceneComponent* RootSceneComponent;

	UPROPERTY(EditAnywhere)
	USceneComponent* LockerSceneComponent;

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UStaticMeshComponent* LockerBack;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UStaticMeshComponent* LockerFront_Right;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UStaticMeshComponent* LockerPivotPoint_Right;
	UPROPERTY(EditAnywhere)
	UCurveFloat* LockerCurve;
	//UPROPERTY(EditAnywhere)
	//UCameraComponent* LockerCamera;
	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	UBoxComponent* Box;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Default")
	bool bStuck;

	bool Open;
	bool ReadyState;
	UPROPERTY(EditAnywhere)
	bool HasPlayer;

	UPROPERTY(EditAnywhere)
	bool bCanEnter = true;
	float RotateValue;
	float CurveFloatValue;
	float TimelineValue;
	FRotator LockerDoorRotation;
	FTimeline MyTimeline;

	UFUNCTION()
	void ControlDoor();

	UFUNCTION()
	void SetState();

	UFUNCTION(BlueprintCallable)
	void ToggleLockerFront();

	UFUNCTION()
	void OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweel, const FHitResult& SweepResult);

	UFUNCTION(BlueprintCallable)
	void PossessPlayer();

	UFUNCTION(BlueprintCallable)
	void DisablePlayer(AANCharacterBase* InteractingCharacter);

	UFUNCTION(BlueprintCallable)
	void EnablePlayer(AANCharacterBase* InteractingCharacter);

	UFUNCTION(BlueprintCallable)
	bool CanEnter();

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Hiding")
	void FailEnterLocker();

	//The sfx to play when we enter the locker
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "SFX")
	UAkAudioEvent* EnterLockerSFX;

	//Interactable Interface
public:
	virtual bool CanInteract() const override;
	virtual void BeginInteract(AANCharacterBase* InteractingCharacter) override;
	virtual void EndInteract(AANCharacterBase* InteractingCharacter) override;
	virtual bool IsLongInteract() const override;
	virtual bool IsInteracting() const override;
};
