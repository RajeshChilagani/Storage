// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "ANStructs.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ANAISpawner.generated.h"



UCLASS()
class UNDERWATER_API AANAISpawner : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANAISpawner();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;


	UPROPERTY(EditAnywhere, Category = "AI Spawn Settings", BlueprintReadWrite)
		TArray<FAISpawnSettings> SpawnGroupSettings;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Wave Setttings")
		TSubclassOf<AANAISpawnPoints> SpawnPointBP;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Wave Setttings")
		TSubclassOf<AANAISpawnTriggerBox> TriggerBoxBP;
	
	UFUNCTION(CallInEditor, Category = "Editor Functions")
		void SpawnANewSpawnPoint();

	//UFUNCTION(CallInEditor, Category = "Editor Functions")
		void SpawnTriggerBox();
	//UFUNCTION(CallInEditor, Category = "Editor Functions")
		void SpawnEnemiesInEditor();
	//UPROPERTY(EditAnywhere, Category = "Editor Functions")
		int GroupIDToSpawnInEditor = 0;
		
	UFUNCTION(BlueprintCallable, BlueprintImplementableEvent)
		FVector GetRandomLocationWithInTheRadius(float Radius, FVector SpawnLocation);
	
	//UFUNCTION()
	//	void SpawnEnemies(const FAISpawnSettings& SpawnSettings, FVector SpawnLocation);
	UFUNCTION(BlueprintCallable)
		void SpawnGroup(int GroupID);
	UFUNCTION(BlueprintCallable)
		void SpawnGroupWithSettings(FAISpawnSettings Settings);
	
	UFUNCTION(BlueprintCallable)
		void SpawnEnemy(const FAISpawnSettings& SpawnSettings);

private:

	int SpawnEnemyCount =0;

	FTimerDelegate SpawnEnemiesDelegate;
	FTimerHandle SpawnEnemiesTimerHandler;
};
