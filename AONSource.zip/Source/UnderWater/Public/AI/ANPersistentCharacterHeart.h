// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Puzzle/ANPuzzleInteractable.h"
#include "ANPersistentCharacterHeart.generated.h"

class AController;
/**
 * 
 */
UCLASS()
class UNDERWATER_API AANPersistentCharacterHeart : public AANPuzzleInteractable
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	void OnStunned();

	UFUNCTION(BlueprintCallable)
	void OnUnStunned();

	UPROPERTY(EditAnywhere, BlueprintReadOnly)
	float DamageToApply = 33.4f;

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void BP_OnStunned();

	UFUNCTION(BlueprintImplementableEvent)
	void BP_OnUnStunned();

	UFUNCTION(BlueprintCallable)
	void ApplyDamage(AController* IController, AActor* DamageCauser);

	UPROPERTY(BlueprintReadWrite)
	class AANPersistentCharacter* OwningActor;

//Interactable Interface
public:
	virtual bool CanInteract() const override;

protected:
	UPROPERTY(BlueprintReadWrite)
	bool bCanInteract = false;
};
