// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/Character.h"
#include "GameFramework/FloatingPawnMovement.h"

#include "EnumAIMode.h"
#include "ANEnemyCharacterBase.generated.h"

class AANPatrolPath;
class UANAlertSystemComponent;
UCLASS()
class UNDERWATER_API AANEnemyCharacterBase : public ACharacter
{
	GENERATED_BODY()

public:
	// Sets default values for this character's properties
	AANEnemyCharacterBase();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	virtual void NotifyActorBeginOverlap(AActor* OtherActor) override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Called to bind functionality to input
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

public:

	UPROPERTY(EditAnywhere, Category = "Alert")
	UANAlertSystemComponent* AlertSystemComponent;

	UPROPERTY(EditAnywhere, Category = "AI")
	class UBehaviorTree* BehaviorTree;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "AI")
	AANPatrolPath* PatrolPath;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "AI")
	EAIMode BotType;

	int health = 1;

	//UFloatingPawnMovement* FloatingMovement;
	void TakeEnemyDamage(int DamageValue, AActor* Instigator);

	void SetBotType(EAIMode NewType);

};
