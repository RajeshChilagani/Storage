// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Room.generated.h"

class ARoom;
class UBoxComponent;
class UBillboardComponent;
class USceneComponent;
class ANavUnit;

USTRUCT(BlueprintType)
struct FRoomConnection
{
	GENERATED_BODY()

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ARoom* OtherRoom;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ANavUnit* FromNavUnit;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ANavUnit* ToNavUnit;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	ARoom* CurrentRoom;

	FRoomConnection Inverse() const
	{
		FRoomConnection newConnection;
		newConnection.CurrentRoom = OtherRoom;
		newConnection.OtherRoom = CurrentRoom;
		newConnection.FromNavUnit = ToNavUnit;
		newConnection.ToNavUnit = FromNavUnit;
		return newConnection;
	}

	FRoomConnection()
	{
		CurrentRoom = nullptr;
		OtherRoom = nullptr;
		FromNavUnit = nullptr;
		ToNavUnit = nullptr;
	}

	bool operator==(const FRoomConnection& b) const
	{
		return OtherRoom == b.OtherRoom && FromNavUnit == b.FromNavUnit;
	}

	operator bool() const
	{
		return CurrentRoom && OtherRoom && FromNavUnit && ToNavUnit;
	}
};



UCLASS()
class UNDERWATER_API ARoom : public AActor
{
	GENERATED_BODY()
	
public:	
	ARoom();

protected:
	virtual void BeginPlay() override;
public:
	virtual void Tick(float DeltaSeconds) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	USceneComponent* SceneRoot;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UBoxComponent* RoomBox;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	UBillboardComponent* Billboard;

	



////////////////////////////////////////////////////////////////////// CONFIG
public:
	FColor DebugLineColor = FColor::White;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	bool bEnableDebug = true;
////////////////////////////////////////////////////////////////////// CONFIG


	


////////////////////////////////////////////////////////////////////// CORE
public:
	UPROPERTY(BlueprintReadOnly, Category = "Core")
	FVector Location;


	

	void RefreshConnectingNavUnits();
	void ShowContainingNavUnits();
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Core")
	TArray<ANavUnit*> ConnectingNavUnits;

	// Connecting Rooms
	void RefreshConnectingRooms();
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Core")
	TArray<FRoomConnection> ConnectingRooms;

	


	// Utility
	bool CheckRoomConnection(ARoom* OtherRoom) const;
	ANavUnit* GetRandomNavUnit();
	ARoom* GetRandomConnectedRoom();
	TArray<ARoom*> GetConnectingRooms(ARoom* RoomToIgnore);
////////////////////////////////////////////////////////////////////// CORE
};
