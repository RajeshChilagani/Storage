// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Engine/Selection.h"
#include "NavUnit.generated.h"


class ARoom;
class USphereComponent;


UCLASS()
class UNDERWATER_API ANavUnit : public AActor
{
	GENERATED_BODY()
	
public:	
	ANavUnit();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;


////////////////////////////////////////////////////////////////////// CONFIG
public:
	FColor DebugLineColor = FColor::Red;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	bool bEnableDebug = true;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config", meta=(EditCondition="bEnableDebug"))
	float DebugLineThickness = 5.f;
////////////////////////////////////////////////////////////////////// CONFIG

	
////////////////////////////////////////////////////////////////////// CORE
public:
	UPROPERTY(BlueprintReadOnly, Category = "Core")
	FVector Location;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Core")
	ARoom* Room;
	
	void ShowConnectedNavUnits();
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Core")
	TArray<ANavUnit*> ConnectingNavUnits;
////////////////////////////////////////////////////////////////////// CORE
};
