// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "Components/BoxComponent.h"
#include "GameFramework/Actor.h"
#include "ANSecondaryNavData.generated.h"

class AANSecondaryAINavRoom;
UCLASS()
class UNDERWATER_API AANSecondaryNavData : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANSecondaryNavData();

	UPROPERTY(BlueprintReadWrite, EditAnywhere)
		UBoxComponent* BoxCollisionComponent;
	
	UPROPERTY(BlueprintReadWrite)
		AANSecondaryAINavRoom* NavVolumeRef = nullptr;

	UPROPERTY(BlueprintReadWrite)
		bool bIsFree = true;
};
