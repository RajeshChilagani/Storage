// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "NavUserCharacter.generated.h"

UENUM(BlueprintType)
enum class ENavTaskStatus : uint8
{
	Reached = 0		UMETA(DisplayName = "Reached"),
	Blocked = 1		UMETA(DisplayName = "Stopped"),
	Cancelled = 2	UMETA(DisplayName = "Cancelled")
};
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnMoveToCompletedDelegate, ENavTaskStatus, CompletionStatus);

class ARoom;
class ANavUnit;
class ANavController;

UCLASS()
class UNDERWATER_API ANavUserCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	ANavUserCharacter();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;



	

////////////////////////////////////////////////////////////////////// CONFIG
public:
	// Nav Config
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	bool bCustomMovementOverride = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	float AcceptanceRadius = 5.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	float SkipRadius = 5.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	float ForceChaseRadius = 5.f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config")
	float TurningRate = 5.f;
	

	// Debug Helpers
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
	bool bShowDebugTag;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
	bool bShowDebugNavTrace;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
	FColor DebugNavTraceColor = FColor::Orange;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Debug")
	float DebugNavTraceThickness = 10.f;
////////////////////////////////////////////////////////////////////// CONFIG



	
	
	
////////////////////////////////////////////////////////////////////// CORE
private:
	// Ref
	bool FindNavController();
	ANavController* GetNavController();
	ANavController* NavController;

	// Current
	ANavUnit* CurrentNavUnit;

	// The To-Do List
	TArray<ARoom*> NavRoomsToCover;
	TArray<ANavUnit*> NavUnitsToCover;
	FVector TargetLocation;
	AActor* TargetActor;
	ANavUnit* LastUnitCovered;

	// Navigation Handling
	bool bIsMoving = false;
	bool bIsTargetActor = false;

	virtual void Tick_AI(const float DeltaSeconds);
public:
	UPROPERTY(BlueprintReadOnly, Category = "Navigation")
	FVector CurrentHeading;
	
	UFUNCTION(BlueprintImplementableEvent, Category = "Navigation")
	void OnTick_AI();

	UPROPERTY(BlueprintAssignable)
	FOnMoveToCompletedDelegate OnMoveToCompleted;

	UFUNCTION(BlueprintCallable, Category = "Navigation")
	FORCEINLINE ANavUnit* GetCurrentNavUnit() { return CurrentNavUnit; }

	UFUNCTION(BlueprintCallable, Category = "Navigation")
	ARoom* GetCurrentRoom();
////////////////////////////////////////////////////////////////////// CORE
	
	


	
////////////////////////////////////////////////////////////////////// NAV PAWN CONTROL
public:
	UFUNCTION(BlueprintCallable, Category = "Custom Navigation")
	bool RefreshNavigation();
	
	UFUNCTION(BlueprintCallable, Category = "Custom Navigation")
	bool MoveToLocation(FVector Location);

	UFUNCTION(BlueprintCallable, Category = "Custom Navigation")
	bool MoveToActor(AActor* Actor);

	UFUNCTION(BlueprintCallable, Category = "Custom Navigation")
	bool StopAllMovement();
////////////////////////////////////////////////////////////////////// NAV PAWN CONTROL








////////////////////////////////////////////////////////////////////// UTILITY
private:
	void Tick_Debug();
	void NavTraceCleanup();
////////////////////////////////////////////////////////////////////// UTILITY
};
