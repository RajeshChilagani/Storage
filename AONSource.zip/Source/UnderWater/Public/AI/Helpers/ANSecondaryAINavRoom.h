// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "ANStructs.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/BoxComponent.h"
#include "Character/ANCustomNavPathFinder.h"
#include "ANSecondaryAINavRoom.generated.h"


//Node record for the Navigation data;
USTRUCT()
struct FNodeRecord
{
	GENERATED_BODY()
	FVector ID;
	FVector PreviousID = FVector(-1,-1,-1);
	float Cost =0;
	float functionCost =0;
	float Heuristics =0;
	FNodeRecord(FVector id) :ID(id)
	{

	}
	FNodeRecord() = default;
	
	inline bool operator ==(const FNodeRecord& other) const
	{
		return other.ID == this->ID;
	}
};

UCLASS()
class UNDERWATER_API AANSecondaryAINavRoom : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AANSecondaryAINavRoom();
protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	/*UPROPERTY()
	class USceneComponent* Root;*/

	UPROPERTY(VisibleAnywhere)
		class UBoxComponent* ANNavRoomBounds;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	//UPROPERTY(BlueprintReadWrite,EditAnywhere)
	UPROPERTY(BlueprintReadWrite)
		FVector MaxIndex;

	UPROPERTY(BlueprintReadWrite)
		TMap<FVector, FNavMeshData> NavPoints;

	UFUNCTION(Category = "Editor Settings", CallInEditor)
		void ToggleGridVisibility();
	UFUNCTION(Category = "Editor Settings", CallInEditor)
		void CreateGrid();
	UFUNCTION(Category = "Editor Settings", CallInEditor)
		void DeleteGrid();
	UPROPERTY(Category = "Editor Settings", EditAnywhere)
		FIntVector GridSize = FIntVector(100,100,100);
	UFUNCTION(Category = "Editor Settings", BlueprintCallable)
	static float GetArea(float x, float y, float z);
	
	UFUNCTION(BlueprintCallable)
		bool IsBoxFree(UBoxComponent* box);

	
	//Different path finding algorithms.

	//A simple BFS without backtracking. 
	TArray<FVector> GenerateBFSPath(FVector StartPoint, FVector EndPoint, bool UseThread = false);

	//A * star
	TArray<FVector> GenerateAStarPath(FVector StartPoint, FVector Endpoint);
	
	UFUNCTION(BlueprintCallable)
	FVector GetNavPointIndexFromLocation(FVector Location);

	FVector FindRandomPoint();
	UFUNCTION(BlueprintCallable)
		bool IsPointValid(FVector Point);
	UFUNCTION(BlueprintCallable)
		bool IsLocationValid(FVector Location);

		
	/// <summary>
	/// Checks if the given location is free in the nav mesh or not
	/// </summary>
	UFUNCTION(BlueprintCallable)
		bool IsLocationFree(FVector Location);



	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	TArray<FNavMeshData > TempArray;
private:

	class AANCustomNavPathFinder* ThreadPathFinder = nullptr;

	FRunnableThread* CurrentRunningThread = nullptr;	
	UFUNCTION()
		void OnBoxOverlapBegin(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	// declare overlap end function
	UFUNCTION()
		void OnBoxOverlapEnd(class UPrimitiveComponent* OverlappedComp, class AActor* OtherActor, class UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	void CreateBoxCollision(FVector Location ,FVector ID);
	UFUNCTION()
		void CalculateFreePath();
private:

	UPROPERTY()
	FVector NavRegionBeginLocation;
};

