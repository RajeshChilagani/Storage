// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"

#include "Room.h"
#include "GameFramework/Actor.h"
#include "NavController.generated.h"

class ANavUnit;

struct FRoomTrace
{
	FRoomConnection RoomConnection;
	FRoomTrace* Parent;

	bool operator==(FRoomTrace* b) const
	{
		return RoomConnection.OtherRoom == b->RoomConnection.OtherRoom && RoomConnection.FromNavUnit == b->RoomConnection.FromNavUnit;
	}
};

struct FSubPath
{
	ANavUnit* CurrentNavUnit = nullptr;
	ANavUnit* LastNavUnit = nullptr;
	float DistanceFromLast = FLT_MAX;
	float DistanceFromTarget = FLT_MAX;
	
	FSubPath* NextSubPaths;
};

UCLASS()
class UNDERWATER_API ANavController : public AActor
{
	GENERATED_BODY()
	
public:	
	ANavController();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;





////////////////////////////////////////////////////////////////////// CONFIG
public:
	UPROPERTY(EditAnywhere, Category = "Debug")
	bool bShowDebug = false;

	UPROPERTY(EditAnywhere, Category = "Config")
	int MaxPointDepth = 100;

	UPROPERTY(EditAnywhere, Category = "Config")
	int MaxRoomDepth = 10;

	UPROPERTY(EditAnywhere, Category = "Config")
	int MaxBranchDepth = 10;
////////////////////////////////////////////////////////////////////// CONFIG




	


////////////////////////////////////////////////////////////////////// CORE
public:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Core")
	TArray<ARoom*> AllRooms;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Core")
	TMap<APawn*, ANavUnit*> RegisteredPawns;
	
	UFUNCTION(BlueprintCallable, Category = "Core")
	ANavUnit* GetClosestNavUnit(FVector Location);

	UFUNCTION(BlueprintCallable, Category = "Core")
	ARoom * GetContainingRoom(FVector Location);

	bool FindPathToTarget(TArray<ANavUnit*>& OutNavTrace, FVector OriginLocation, FVector TargetLocation);
	bool FindRoomTraceToTarget(TArray<FRoomConnection>& OutRoomTrace, ARoom* OriginRoom, ARoom* TargetRoom);

private:
	ANavUnit* GetClosestNavUnitInRoom(FVector Location, ARoom* Room);
	ANavUnit* GetBlindClosestNavUnit(FVector Location);
////////////////////////////////////////////////////////////////////// CORE
	





	



////////////////////////////////////////////////////////////////////// UTILITY
protected:
	void GetAllRoomReferences();
	void RefreshNavRooms();
////////////////////////////////////////////////////////////////////// UTILITY
};