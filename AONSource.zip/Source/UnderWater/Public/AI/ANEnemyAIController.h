// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "AI/ANAlertSystemComponent.h"
#include "EnumAIMode.h"
#include "ANEnemyAIController.generated.h"


class UBehaviorTreeComponent;
class UAISenseConfig_Sight;
class UAISenseConfig_Hearing;
class UANAlertSystemComponent;
/**
 * Base Controller for the Normal Enemy AI
 */
UCLASS()
class UNDERWATER_API AANEnemyAIController : public AAIController
{
	GENERATED_BODY()

		//Unreal Functions
public:
	AANEnemyAIController();


	virtual void OnPossess(class APawn* InPawn) override;
	virtual void OnUnPossess() override;

	UFUNCTION()
		void OnPawnDetected(const TArray<AActor*>& DetectedActors);


public:

	//Behavior Tree component
	UBehaviorTreeComponent* BehaviorTreeComp;

	//UPROPERTY(EditAnywhere, Category = "AI")
	//UBehaviorTree* BehaviorTreeMain;

	UBlackboardComponent* BlackBoardComp;

	//AI PerceptionComponent
	UAIPerceptionComponent* AIPerception;

	UAISenseConfig_Sight* SightConfig;
	UAISenseConfig_Hearing* HearingConfig;

public:

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName CanSeePlayerKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName IsInvestigatingKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName TargetLocationKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName PatrolPathVectorKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName PatrolPathIndexKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName BotModeKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	FName PlayerInMeleeRangeKeyName;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	float AISightRadius = 500.0f;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	float AISightAge = 5.0f;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	float AILooseSightRadius = AISightRadius + 50.0f;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	float AIFieldOfView = 90.0f;

	UPROPERTY(EditDefaultsOnly, Category = "AI")
	float AIHearingRange = 800.0f;

	void SetBlackBoardBotMode(EAIMode NewMode);

};
