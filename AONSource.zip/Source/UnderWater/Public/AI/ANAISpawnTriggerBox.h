// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "ANStructs.h"
#include "CoreMinimal.h"
#include "Engine/TriggerBox.h"
#include "Environment/ANGenericTrigger.h"

#include "ANAISpawnTriggerBox.generated.h"


UCLASS()
class UNDERWATER_API AANAISpawnTriggerBox : public AANGenericTrigger
{
	GENERATED_BODY()
public:
	AANAISpawnTriggerBox();
	void BeginPlay() override;





	UPROPERTY(BlueprintReadWrite)
		bool CanSpawnMultipleTimes = false;

	UPROPERTY(EditAnywhere, Category = "AI Spawn Settings", BlueprintReadWrite)
		FAISpawnSettings SpawnSettings;


private:
	
	int SpawnEnemyCount = 0;



	//functions;

	void PlayTriggerEvent_Implementation(AActor* OverlappedActor) override;
	
	void SpawnEnemies();
	
};
