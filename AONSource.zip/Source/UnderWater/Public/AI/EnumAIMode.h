#include "EnumAIMode.generated.h"
#pragma once
UENUM(BlueprintType)
enum class EAIMode :uint8
{
	Patrol,
	Searching,
	Chasing,
};