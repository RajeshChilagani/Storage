// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ANAlertSystemComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UNDERWATER_API UANAlertSystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	// Sets default values for this component's properties
	UANAlertSystemComponent();

protected:
	// Called when the game starts
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	int MaxAlertPoints = 100;
	int CurrentAlertPoints = 0;

	UFUNCTION(BlueprintCallable, Category = "Alert")
	void SetMaxAlertPoints(int NewMaxAlert);
	UFUNCTION(BlueprintCallable, Category = "Alert")
	int GetMaxAlertPoints();
	UFUNCTION(BlueprintCallable, Category = "Alert")
	void SetCurrentAlertPoints(int NewAlert);
	UFUNCTION(BlueprintCallable, Category = "Alert")
	int GetCurrentAlertPoints();

	UFUNCTION(BlueprintCallable, Category = "Alert")
	void AddAlertPoints(int Points);
	UFUNCTION(BlueprintCallable, Category = "Alert")
	void MinusAlertPoints(int Points);
};
