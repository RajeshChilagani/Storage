// 2021 Abyssmal Games and Synodic Arc

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "BTT_TeleportEnemy.generated.h"

class ARoom;
class AANPersistentCharacter;

/**
 * 
 */
UCLASS()
class UNDERWATER_API UBTT_TeleportEnemy : public UBTTask_BlackboardBase
{
	GENERATED_BODY()

	// Exec
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

public:
	// Params
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	float PostTeleportResetTime = -60.f;
	
	// Keys
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	FBlackboardKeySelector Key_PlayerActor;
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	FBlackboardKeySelector Key_CurrentPlayerRoomTime;
};
