// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Tasks/BTTask_BlackboardBase.h"
#include "BTT_SetMovementConfig.generated.h"

/**
 * 
 */
UCLASS()
class UNDERWATER_API UBTT_SetMovementConfig : public UBTTask_BlackboardBase
{
	GENERATED_BODY()

	// Exec
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;


public:
	// Params
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")		// Allow turning neck to look at player
	bool bShouldLookAtPlayer = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")		// Full-body face player
	bool bShouldFacePlayer = false;
	
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	float MaxSpeed = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	float TurningRate = 1.8f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Blackboard")
	FBlackboardKeySelector Key_MaxChaseSpeed;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Blackboard")
	FBlackboardKeySelector Key_MaxTurnSpeed;
};
