// Fill out your copyright notice in the Description page of Project Settings.


#include "Environment/ANOpeningDoor.h"

#include "Components/BoxComponent.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Components/SceneComponent.h"
#include "Character/ANMainCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/TextRenderComponent.h"

// Sets default values
AANOpeningDoor::AANOpeningDoor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SceneRoot->SetupAttachment(RootComponent);

	DoorMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DoorMesh"));
	DoorMesh->SetupAttachment(SceneRoot);
	DoorMesh->bRenderCustomDepth = false;
	DoorMesh->CustomDepthStencilWriteMask = ERendererStencilMask::ERSM_Default;
	DoorMesh->CustomDepthStencilValue = static_cast<int32>(EFocusOutlineColor::AquaBlue);

	CustomDepthBounds = CreateDefaultSubobject<UBoxComponent>("CustomDepthBounds");
	CustomDepthBounds->SetRelativeLocation(FVector(100.0f, -15.0f, 150.0f));
	CustomDepthBounds->SetBoxExtent(FVector(256, 256, 256));
	CustomDepthBounds->SetupAttachment(SceneRoot);
	CustomDepthBounds->OnComponentBeginOverlap.AddDynamic(this, &AANOpeningDoor::OnCDBBeginOverlap);
	CustomDepthBounds->OnComponentEndOverlap.AddDynamic(this, &AANOpeningDoor::OnCDBEndOverlap);

	DoorRangeBoxComponent = CreateDefaultSubobject<UBoxComponent>(TEXT("DoorRangeBoxComponent"));
	DoorRangeBoxComponent->SetupAttachment(SceneRoot);
	DoorRangeBoxComponent->SetCollisionProfileName(CollisionProfiles::InvisibleTrigger);
	DoorRangeBoxComponent->SetRelativeLocation(FVector(100.0f, -15.0f, 150.0f));
	DoorRangeBoxComponent->SetBoxExtent(FVector(200, 200, 150.0f));

	ClosePosition = FVector(0.0f, 0.0f, 0.0f);
	OpenPosition = FVector(0.0f, 0.0f, 100.0f);
	MoveTime = 1.0f;
	bLockedAtStart = true;
	bPoweredOnAtStart = false;
	bStuck = false;

	bInitialized = false;
	bOpen = false;
	bMoving = false;
	CurrentMoveTime = 0.0f;
	bLocked = true;

	bPoweredOn = true;
}

// Called when the game starts or when spawned
void AANOpeningDoor::BeginPlay()
{
	Super::BeginPlay();
	
	if (!bInitialized)
	{
		if (bPoweredOnAtStart)
		{
			bPoweredOn = true;
		}
		else
		{
			bPoweredOn = false;
			PowerOff();
		}

		if (bLockedAtStart)
		{
			bLocked = true;
		}
		else
		{
			bLocked = false;
			UnlockDoor();
		}

		bInitialized = true;
	}
}

// Called every frame
void AANOpeningDoor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bMoving)
	{
		CurrentMoveTime += DeltaTime;

		FVector StartPosition;
		FVector EndPosition;

		//if moving to open
		if (bOpen)
		{
			StartPosition = ClosePosition;
			EndPosition = OpenPosition;
		}
		//if moving to close
		else if (!bOpen)
		{
			StartPosition = OpenPosition;
			EndPosition = ClosePosition;
		}

		float NewX = FMath::Lerp(StartPosition.X, EndPosition.X, CurrentMoveTime / MoveTime);
		float NewY = FMath::Lerp(StartPosition.Y, EndPosition.Y, CurrentMoveTime / MoveTime);
		float NewZ = FMath::Lerp(StartPosition.Z, EndPosition.Z, CurrentMoveTime / MoveTime);

		if (DoorMesh != nullptr)
		{
			DoorMesh->SetRelativeLocation(FVector(NewX, NewY, NewZ));
		}

		//if we have passed the move time
		if (CurrentMoveTime >= MoveTime)
		{
			bMoving = false;
		}
	}
}

void AANOpeningDoor::OpenDoor_Implementation()
{
	bOpen = true;
	bMoving = true;
	CurrentMoveTime = 0.0f;
}

void AANOpeningDoor::FailOpenDoor_Implementation()
{
}

void AANOpeningDoor::CloseDoor_Implementation()
{
	bOpen = false;
	bMoving = true;
	CurrentMoveTime = 0.0f;
}

void AANOpeningDoor::LockDoor_Implementation()
{
	bLocked = true;

	//If the door is open and it gets locked again, we should shut it instantly so we can't cheese it
	if (bOpen)
	{
		CloseDoor();
	}
}

void AANOpeningDoor::UnlockDoor_Implementation()
{
	bLocked = false;
}

bool AANOpeningDoor::CanOpen() const
{
	return !bLocked && bPoweredOn && !bStuck;
}

bool AANOpeningDoor::CanInteract() const
{
	return !bOpen && !bMoving;
}

void AANOpeningDoor::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (CanOpen())
	{
		OpenDoor();
	}
	else
	{
		FailOpenDoor();
	}
}

void AANOpeningDoor::BaddyInteract()
{
	if (CanOpen())
	{
		OpenDoor();
	}
}

void AANOpeningDoor::EndInteract(AANCharacterBase* InteractingCharacter)
{
}

bool AANOpeningDoor::IsLongInteract() const
{
	return false;
}

bool AANOpeningDoor::IsInteracting() const
{
	return false;
}

void AANOpeningDoor::BP_PowerOn_Implementation()
{
	bPoweredOn = true;
	bInitialized = true; //TODO don't do this long term
}

void AANOpeningDoor::BP_PowerOff_Implementation()
{
	bPoweredOn = false;
	bInitialized = true; //TODO don't do this long term
}

bool AANOpeningDoor::BP_IsPoweredOn_Implementation()
{
	return bPoweredOn;
}

FText AANOpeningDoor::BP_GetPowerableName_Implementation()
{
	return PowerableName;
}

void AANOpeningDoor::OnCDBBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		DoorMesh->bRenderCustomDepth = true;
		DoorMesh->MarkRenderStateDirty();
		OnRenderCustomDepthEnabled();
	}
}

void AANOpeningDoor::OnCDBEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		DoorMesh->bRenderCustomDepth = false;
		DoorMesh->MarkRenderStateDirty();
		OnRenderCustomDepthDisabled();
	}
}