// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANInspectingRoom.h"

// Sets default values
AANInspectingRoom::AANInspectingRoom()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

// Called when the game starts or when spawned
void AANInspectingRoom::BeginPlay()
{
	Super::BeginPlay();
	
}


