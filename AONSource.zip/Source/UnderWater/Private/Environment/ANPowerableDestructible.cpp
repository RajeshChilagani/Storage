// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANPowerableDestructible.h"

#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"

AANPowerableDestructible::AANPowerableDestructible()
{
	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	SceneRoot->SetupAttachment(RootComponent);

	ObjectMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ObjectMesh"));
	ObjectMesh->SetupAttachment(SceneRoot);
}

void AANPowerableDestructible::BeginPlay()
{
	Super::BeginPlay();
}

void AANPowerableDestructible::BP_PowerOn_Implementation()
{
	bPoweredOn = true;
}

void AANPowerableDestructible::BP_PowerOff_Implementation()
{
	bPoweredOn = false;
}

bool AANPowerableDestructible::BP_IsPoweredOn_Implementation()
{
	return bPoweredOn;
}

FText AANPowerableDestructible::BP_GetPowerableName_Implementation()
{
	return PowerableName;
}