// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANLevelStreamTrigger.h"

#include "Engine/ExponentialHeightFog.h"
#include "Engine/PostProcessVolume.h"
#include "Engine/SkyLight.h"
#include "Components/BoxComponent.h"
#include "Engine/LevelStreaming.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Shared/ANFunctionLibrary.h"
#include "UI/HUD/ANHUDWidget.h"

static int32 LatentInfoID = 0;

AANLevelStreamTrigger::AANLevelStreamTrigger()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;

	TriggerBox = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerBox"));
	TriggerBox->SetupAttachment(RootComponent);
	TriggerBox->SetGenerateOverlapEvents(true);
	TriggerBox->SetCollisionProfileName(CollisionProfiles::InvisibleTrigger);
	TriggerBox->SetBoxExtent(FVector(100.0f, 100.0f, 100.0f));
	TriggerBox->OnComponentBeginOverlap.AddDynamic(this, &AANLevelStreamTrigger::OnOverlapBegin);

	bLoadLevel = true;
	LevelToLoad = EANLevels::Lobby;
	bUnloadLevel = false;
	LevelToUnload = EANLevels::Lobby;

	bLoadingLevels = false;
}

#pragma optimize("", off)
void AANLevelStreamTrigger::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
	{
		if (bLoadLevel)
		{
			SetupLoadLevel();
		}

		if (bUnloadLevel)
		{
			UnloadLevel();
		}
	}
}

void AANLevelStreamTrigger::SetupLoadLevel()
{
	//Show level streaming UI
	if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(UGameplayStatics::GetPlayerController(this, 0)))
	{
		if (UANHUDWidget* PlayerHUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			PlayerHUDWidget->BP_ShowLevelStreamingUI();
		}
	}

	//Set timer on a short delay so we have the UI appear
	if (UWorld* MyWorld = GetWorld())
	{
		FTimerHandle StreamLevelTimerHandle;
		FTimerDelegate StreamLevelTimerDelegate = FTimerDelegate::CreateUObject(this, &AANLevelStreamTrigger::LoadLevel);
		MyWorld->GetTimerManager().SetTimer(StreamLevelTimerHandle, StreamLevelTimerDelegate, 0.01f, false);
	}
}

void AANLevelStreamTrigger::LoadLevel()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	TArray<FName> SublevelNames = UANFunctionLibrary::GetSublevelNamesForLevel(LevelToLoad);
	bLoadingLevels = true;

	for (int32 i = 0; i < SublevelNames.Num(); i++)
	{
		FLatentActionInfo LatentInfo;
		LatentInfo.UUID = LatentInfoID;
		LatentInfoID++;
		UGameplayStatics::LoadStreamLevel(MyWorld, SublevelNames[i], true, true, LatentInfo);
	}

	//Hide level streaming UI
	if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(UGameplayStatics::GetPlayerController(this, 0)))
	{
		if (UANHUDWidget* PlayerHUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			PlayerHUDWidget->BP_HideLevelStreamingUI();
		}
	}

	BP_LoadLevel();

	bLoadingLevels = false;
}

void AANLevelStreamTrigger::UnloadLevel()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	TArray<FName> SublevelNames = UANFunctionLibrary::GetSublevelNamesForLevel(LevelToUnload);
	bLoadingLevels = true;

	for (int i = 0; i < SublevelNames.Num(); i++)
	{
		FLatentActionInfo LatentInfo;
		LatentInfo.UUID = LatentInfoID;
		LatentInfoID++;
		UGameplayStatics::UnloadStreamLevel(MyWorld, SublevelNames[i], LatentInfo, true);
	}

	BP_UnloadLevel();

	bLoadingLevels = true;
}
#pragma optimize("", on)
