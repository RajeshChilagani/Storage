// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANItemSpawner.h"

#include "Components/SceneComponent.h"
#include "Engine/World.h"

#include "ANDefines.h"

#include "Systems/ANPickableItem.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Shared/ANFunctionLibrary.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Audio/ANDialogueConversation.h"

FTimerHandle AANItemSpawner::SpawnExplosiveItemTimerHandle;
FTimerHandle AANItemSpawner::SpawnProjectileItemTimerHandle;

AANItemSpawner::AANItemSpawner()
{
	//Set up root
	ItemSpawnPointSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("ItemSpawnPointSceneComponent"));
	ItemSpawnPointSceneComponent->SetupAttachment(MainMeshComponent);

	ItemSpawnTimeSeconds = 30.0f;
	bItemReady = false;
	bPoweredOnAtStart = true;

	bPoweredOn = false;
}

void AANItemSpawner::BeginPlay()
{
	Super::BeginPlay();

	if (bPoweredOnAtStart)
	{
		PowerOn();
	}
	else
	{
		PowerOff();
	}

	NumRemainingSpawns = MaxPossibleSpawns;
}

void AANItemSpawner::Tick(float deltaTime)
{
	Super::Tick(deltaTime);
}

void AANItemSpawner::SpawnItem()
{
	if (PickableItemToSpawn == nullptr)
	{
		return;
	}

	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AANPickableItem* SpawnedPickableItem = Cast<AANPickableItem>(MyWorld->SpawnActor(PickableItemToSpawn, &(ItemSpawnPointSceneComponent->GetComponentTransform()), SpawnParams));
	if (SpawnedPickableItem != nullptr)
	{
		SpawnedPickableItem->OnItemPickedUp.AddDynamic(this, &AANItemSpawner::OnItemPickedUp);
		bItemReady = true;
		NumRemainingSpawns--;
		BP_SpawnedItem();
		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MyWorld->GetFirstPlayerController()))
		{
			if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
			{
				//Load the dialogue conversation
				if (UANFunctionLibrary::LoadSoftObject(ItemSpawnedDialogueConversation))
				{
					DialogueManager->AddNewDialogueConversation(ItemSpawnedDialogueConversation.Get());
				}
			}
		}
	}
}

void AANItemSpawner::OnItemPickedUp(AANPickableItem* PickedUpPickableItem)
{
	BP_OnItemPicked();

	if (UWorld* World = GetWorld())
	{
		FTimerDelegate CoolDownTimerDelegate = FTimerDelegate::CreateUObject(this, &AANItemSpawner::OnCoolDownCompleted);
		World->GetTimerManager().SetTimer(CoolDownTimerHandle, CoolDownTimerDelegate,CoolDownTimeSeconds,false);
		Print("set timer cool down");

		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(World->GetFirstPlayerController()))
		{

			if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
			{
				//Load the dialogue conversation
				if (UANFunctionLibrary::LoadSoftObject(InCoolDownDialogueConversation))
				{
					DialogueManager->AddNewDialogueConversation(InCoolDownDialogueConversation.Get());
				}
			}
		}
	}

	if (PickedUpPickableItem != nullptr)
	{
		PickedUpPickableItem->OnItemPickedUp.RemoveDynamic(this, &AANItemSpawner::OnItemPickedUp);
	}
}

void AANItemSpawner::OnCoolDownCompleted()
{
	bItemReady = false;
	BP_OnCoolDownCompleted();
}

bool AANItemSpawner::CanInteract() const
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return false;
	}

	if (NumRemainingSpawns <= 0)
	{
		return false;
	}

	if (MyWorld->GetTimerManager().IsTimerActive(CoolDownTimerHandle))
	{
		return false;
	}

	bool bTimerHandleActive;
	switch (ItemType)
	{
	case EItemToSpawn::Explosive:
		bTimerHandleActive = MyWorld->GetTimerManager().IsTimerActive(SpawnExplosiveItemTimerHandle);
		break;
	case EItemToSpawn::Projectile:
		bTimerHandleActive = MyWorld->GetTimerManager().IsTimerActive(SpawnProjectileItemTimerHandle);
		break;
	default:
		break;
	}

	if (!bTimerHandleActive && !bItemReady && bPoweredOn)
	{
		return true;
	}

	return false;
}

void AANItemSpawner::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (UWorld* MyWorld = GetWorld())
	{
		switch (ItemType)
		{
		case EItemToSpawn::Explosive:
		{
			FTimerDelegate SpawnItemTimerDelegate = FTimerDelegate::CreateUObject(this, &AANItemSpawner::SpawnItem);
			MyWorld->GetTimerManager().SetTimer(SpawnExplosiveItemTimerHandle, SpawnItemTimerDelegate, ItemSpawnTimeSeconds, false);
			Print("set timer explosive");
		}
			break;
		case EItemToSpawn::Projectile:
		{
			FTimerDelegate SpawnItemTimerDelegate = FTimerDelegate::CreateUObject(this, &AANItemSpawner::SpawnItem);
			MyWorld->GetTimerManager().SetTimer(SpawnProjectileItemTimerHandle, SpawnItemTimerDelegate, ItemSpawnTimeSeconds, false);
			Print("set timer explosive");
		}
			break;
		default:
			break;
		}

		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MyWorld->GetFirstPlayerController()))
		{
			if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
			{
				//Load the dialogue conversation
				if (UANFunctionLibrary::LoadSoftObject(ItemSpawnBeganDialogueConversation))
				{
					DialogueManager->AddNewDialogueConversation(ItemSpawnBeganDialogueConversation.Get());
				}
			}
		}
		
	}
}

void AANItemSpawner::EndInteract(AANCharacterBase* InteractingCharacter)
{

}

bool AANItemSpawner::IsLongInteract() const
{
	return false;
}

bool AANItemSpawner::IsInteracting() const
{
	return false;
}

void AANItemSpawner::BP_PowerOn_Implementation()
{
	bPoweredOn = true;
}

void AANItemSpawner::BP_PowerOff_Implementation()
{
	bPoweredOn = false;

	//Clear the timer if we power off
	if (UWorld* MyWorld = GetWorld())
	{
		if (MyWorld->GetTimerManager().IsTimerActive(SpawnExplosiveItemTimerHandle))
		{
			MyWorld->GetTimerManager().ClearTimer(SpawnExplosiveItemTimerHandle);
		}

		if (MyWorld->GetTimerManager().IsTimerActive(SpawnProjectileItemTimerHandle))
		{
			MyWorld->GetTimerManager().ClearTimer(SpawnProjectileItemTimerHandle);
		}
	}
}

bool AANItemSpawner::BP_IsPoweredOn_Implementation()
{
	return bPoweredOn;
}

FText AANItemSpawner::BP_GetPowerableName_Implementation()
{
	return PowerableName;
}