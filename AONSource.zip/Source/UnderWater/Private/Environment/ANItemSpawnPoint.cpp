// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANItemSpawnPoint.h"

#include "Components/SceneComponent.h"
#include "Components/ChildActorComponent.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"

#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Systems/ANPickableItem.h"

// Sets default values
AANItemSpawnPoint::AANItemSpawnPoint()
{
	//Set up root
	ItemSpawnPointRoot = CreateDefaultSubobject<USceneComponent>(TEXT("ItemSpawnPointRoot"));
	RootComponent = ItemSpawnPointRoot;

	//Set up key button mesh
	CA_PickableItem = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_PickableItem"));
	CA_PickableItem->SetupAttachment(RootComponent);
}

void AANItemSpawnPoint::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	if (!SaveableGuid.IsValid())
	{
		SaveableGuid = FGuid::NewGuid();
	}

	//Ensure we don't have the same Guid anywhere else
	for (TActorIterator<AActor> it(GetWorld()); it; ++it)
	{
		//Don't include self in the check
		if (*it == this)
		{
			continue;
		}

		if (IANSaveable* ActorAsSaveable = Cast<IANSaveable>(*it))
		{
			if (ActorAsSaveable->GetSaveableGuid() == SaveableGuid)
			{
				SaveableGuid = FGuid::NewGuid();
				break;
			}
		}
	}
}

// Called when the game starts or when spawned
void AANItemSpawnPoint::BeginPlay()
{
	Super::BeginPlay();

	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveableString = GameplaySaveGame->GetSaveableStringForGuid(SaveableGuid);

			if (!SaveableString.IsEmpty())
			{
				LoadObject(SaveableString);
			}
		}
	}

	if (CA_PickableItem != nullptr)
	{
		if (AANPickableItem* PickableItem = Cast<AANPickableItem>(CA_PickableItem->GetChildActor()))
		{
			//We might be trying to delete the item with load object, so only do if not pending kill
			if (!PickableItem->IsPendingKill())
			{
				PickableItem->OnItemPickedUp.AddDynamic(this, &AANItemSpawnPoint::PickUpItem);
			}
		}
	}
}

void AANItemSpawnPoint::PickUpItem(AANPickableItem* PickableItem)
{
	bFilled = false;
	SaveObject();
}

FGuid AANItemSpawnPoint::BP_GetSaveableGuid_Implementation()
{
	return SaveableGuid;
}

FString AANItemSpawnPoint::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");

	if (bFilled)
	{
		SaveString = SaveString.Append(SaveableParams::ItemFilledTrue);
	}
	else
	{
		SaveString = SaveString.Append(SaveableParams::ItemFilledFalse);
	}

	return SaveString;
}

void AANItemSpawnPoint::BP_SaveObject_Implementation()
{
	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveString = ConstructSaveString();

			if (!SaveString.IsEmpty())
			{
				GameplaySaveGame->SaveSaveableString(SaveableGuid, SaveString);
			}
		}
	}
}

void AANItemSpawnPoint::BP_LoadObject_Implementation(const FString& LoadString)
{
	//If the item isn't filled, destroy it
	if (LoadString.Contains(SaveableParams::ItemFilledFalse))
	{
		if (CA_PickableItem != nullptr)
		{
			if (CA_PickableItem->GetChildActor() != nullptr)
			{
				CA_PickableItem->GetChildActor()->Destroy();
			}
		}
	}
	
}

