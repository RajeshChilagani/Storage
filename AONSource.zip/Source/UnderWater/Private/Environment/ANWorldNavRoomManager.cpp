// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANWorldNavRoomManager.h"

#include "Environment/ANWorldNavRoom.h"
#include "DrawDebugHelpers.h"

DEFINE_LOG_CATEGORY_STATIC(LogWorldNavRoomManager, All, All);

AANWorldNavRoomManager::AANWorldNavRoomManager()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	DefaultRoomExtents = FVector(256.0f, 256.0f, 256.0f);
}

void AANWorldNavRoomManager::BeginPlay()
{
	Super::BeginPlay();
}

void AANWorldNavRoomManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	DrawDebugRoomsInGame();
}

void AANWorldNavRoomManager::Destroyed()
{
	CleanUpBeforeDestroyed();
	Super::Destroyed();
}

#if WITH_EDITOR
void AANWorldNavRoomManager::CreateNewRoomFromEditor()
{
	CreateNewRoom(SpawningRoomName, DefaultRoomExtents, EditorRoomToSpawn);
}
#endif

bool AANWorldNavRoomManager::IsValidRoomName(const FName& RoomName)
{
	if (RoomName.IsNone() && !RoomName.IsValid())
	{
		return false;
	}
	return true;
}

void AANWorldNavRoomManager::CreateNewRoom(const FName& RoomName, const FVector& RoomExtents, TSubclassOf<AANWorldNavRoom> RoomToSpawn)
{
	UWorld* World = GetWorld();
	check(World);
	if (!WorldNavRoomMap.Contains(RoomName))
	{
		if (IsValidRoomName(RoomName) && RoomToSpawn->IsChildOf(AANWorldNavRoom::StaticClass()))
		{
			FActorSpawnParameters SpawnParameters;
			SpawnParameters.Name = RoomName;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			FTransform SpawnTransform = GetActorTransform();
			AANWorldNavRoom* NavRoom = World->SpawnActor<AANWorldNavRoom>(RoomToSpawn, SpawnTransform, SpawnParameters);
			NavRoom->SetOwner(this);
			NavRoom->AttachToActor(this, FAttachmentTransformRules::KeepWorldTransform);
#if WITH_EDITOR
			NavRoom->SetActorLabel(RoomName.ToString());
#endif
			NavRoom->SetRoomExtents(RoomExtents);
			NavRoom->RoomName = RoomName;
			NavRoom->OnNavRoomStateChanged.AddDynamic(this, &AANWorldNavRoomManager::UpdateCurrentRoomStatus);
			WorldNavRoomMap.Add(RoomName, NavRoom);
		}
	}
	else
	{
		UE_LOG(LogWorldNavRoomManager, Error, TEXT("%s Room already exists"), *RoomName.ToString());
	}
}

void AANWorldNavRoomManager::UpdateCurrentRoomStatus(AANWorldNavRoom* NavRoom, bool ActiveState)
{
	if (ActiveState)
	{
		if (CurrentRoomWithPlayer)
		{
			LastRoomWithPlayer = CurrentRoomWithPlayer;
		}
		CurrentRoomWithPlayer = NavRoom;
	}
	else
	{
		if (NavRoom == CurrentRoomWithPlayer)
		{
			LastRoomWithPlayer = CurrentRoomWithPlayer;
			CurrentRoomWithPlayer = nullptr;
		}
	}
}

AANWorldNavRoom* AANWorldNavRoomManager::GetNavRoomFromName(const FString Name)
{
	FName RoomName(Name);
	if (WorldNavRoomMap.Contains(RoomName))
	{
		return WorldNavRoomMap[RoomName];
	}
	return nullptr;
}
void AANWorldNavRoomManager::RemoveWorldNavRoom(FName RoomName)
{
	if (WorldNavRoomMap.Contains(RoomName))
	{
		WorldNavRoomMap.Remove(RoomName);
	}
}

void AANWorldNavRoomManager::DrawDebugRoomsInGame()
{
	if (bShowDebugDraw)
	{
		FColor DrawColor;
		for (const TPair<FName, AANWorldNavRoom*>& Pair : WorldNavRoomMap)
		{
			AANWorldNavRoom* Room = Pair.Value;
			if (Room == CurrentRoomWithPlayer)
			{
				DrawColor = FColor::Red;
			}
			else if (Room == LastRoomWithPlayer)
			{
				DrawColor = FColor::Purple;
			}
			else
			{
				DrawColor = FColor::Blue;
			}

			DrawDebugBox(GetWorld(), Room->GetActorLocation(), Room->GetRoomExtents(), DrawColor, false, -1, 0, 2);
		}
	}
}
void AANWorldNavRoomManager::CleanUpBeforeDestroyed()
{
	for (TMap<FName, AANWorldNavRoom*>::TIterator It = WorldNavRoomMap.CreateIterator(); It; ++It)
	{
		It->Value->Destroy();
	}
}

