// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANGenericTrigger.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "Components/BoxComponent.h"
#include "EngineUtils.h"

#include "ANConsts.h"

#include "Audio/ANDialogueConversation.h"
#include "Character/ANMainCharacter.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANCondition.h"

AANGenericTrigger::AANGenericTrigger()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	TriggerBox = CreateDefaultSubobject<UBoxComponent>(TEXT("TriggerBox"));
	SetRootComponent(TriggerBox);
	TriggerBox->SetGenerateOverlapEvents(true);
	TriggerBox->SetCollisionProfileName(CollisionProfiles::InvisibleTrigger);
	TriggerBox->SetBoxExtent(FVector(100.0f, 100.0f, 100.0f));
	TriggerBox->OnComponentBeginOverlap.AddDynamic(this, &AANGenericTrigger::OnOverlapBegin);


	SFXAkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("SFXAkComponent"));
	SFXAkComponent->SetupAttachment(RootComponent);

	bRepeatable = false;
	TriggerableClasses.Add(AANMainCharacter::StaticClass());

	bPlayed = false;
}

void AANGenericTrigger::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	if (!SaveableGuid.IsValid())
	{
		SaveableGuid = FGuid::NewGuid();
	}

	//Ensure we don't have the same Guid anywhere else
	for (TActorIterator<AActor> it(GetWorld()); it; ++it)
	{
		//Don't include self in the check
		if (*it == this)
		{
			continue;
		}

		if (IANSaveable* ActorAsSaveable = Cast<IANSaveable>(*it))
		{
			if (ActorAsSaveable->GetSaveableGuid() == SaveableGuid)
			{
				SaveableGuid = FGuid::NewGuid();
				break;
			}
		}
	}
}

void AANGenericTrigger::BeginPlay()
{
	Super::BeginPlay();

	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveableString = GameplaySaveGame->GetSaveableStringForGuid(SaveableGuid);

			if (!SaveableString.IsEmpty())
			{
				LoadObject(SaveableString);
			}
		}
	}

	if (bPlayed && !bRepeatable)
	{
		//DestroyUnplayableTriggerOnLoad();
	}
}

void AANGenericTrigger::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	//If we've already played this event and it's not repeatable, return
	if (bPlayed && !bRepeatable)
	{
		return;
	}

	if (OtherActor == nullptr)
	{
		return;
	}

	//Must be a valid class for the overlap to play the events
	bool bValidTriggerableClass = false;
	for (UClass* TriggerableClass : TriggerableClasses)
	{
		if (OtherActor->IsA(TriggerableClass))
		{
			bValidTriggerableClass = true;
			break;
		}
	}

	if (!bValidTriggerableClass)
	{
		return;
	}

	//Check conditions
	if (!UANFunctionLibrary::IsConditionValid(ConditionToVerifySubclass, OtherActor, this))
	{
		return;
	}

	//Make sure that any special logic for triggering the event is handled
	if (!ShouldPlayTrigger(OtherActor))
	{
		return;
	}

	OnGenericTriggerTriggered.Broadcast(this);

	bPlayed = true;
	PlaySFX(OtherActor);
	PlayDialogue(OtherActor);
	PlayTriggerEvent(OtherActor);
	SaveObject();
}

void AANGenericTrigger::PlaySFX(AActor* OverlappedActor)
{
	if (AudioEventToPlay != nullptr)
	{
		SFXAkComponent->PostAkEvent(AudioEventToPlay, 0, FOnAkPostEventCallback(), FString());
	}
}

void AANGenericTrigger::PlayDialogue(AActor* OverlappedActor)
{
	//Only relevant if the main character enters the trigger. At least for now.
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OverlappedActor))
	{
		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MainCharacter->GetController()))
		{
			if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
			{
				//Load the dialogue conversation
				if (UANFunctionLibrary::LoadSoftObject(DialogueConversation))
				{
					DialogueManager->AddNewDialogueConversation(DialogueConversation.Get());
				}
			}
		}
	}
}

void AANGenericTrigger::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	
}

bool AANGenericTrigger::ShouldPlayTrigger_Implementation(AActor* OverlappedActor) const
{
	return true;
}

void AANGenericTrigger::DestroyUnplayableTriggerOnLoad()
{
	Destroy();
}

FGuid AANGenericTrigger::BP_GetSaveableGuid_Implementation()
{
	return SaveableGuid;
}

FString AANGenericTrigger::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	if (bPlayed)
	{
		SaveString = SaveString.Append(SaveableParams::PlayedTrue);
	}
	else
	{
		SaveString = SaveString.Append(SaveableParams::PlayedFalse);
	}

	return SaveString;
}

void AANGenericTrigger::BP_SaveObject_Implementation()
{
	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveString = ConstructSaveString();

			if (!SaveString.IsEmpty())
			{
				GameplaySaveGame->SaveSaveableString(SaveableGuid, SaveString);
			}
		}
	}
}

void AANGenericTrigger::BP_LoadObject_Implementation(const FString& LoadString)
{
	if (LoadString.Contains(SaveableParams::PlayedTrue))
	{
		bPlayed = true;
	}
	else
	{
		bPlayed = false;
	}
}
