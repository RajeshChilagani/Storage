// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANMapRoom.h"

#include "Components/BoxComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SceneComponent.h"

#include "ANDefines.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Systems/ANPickableItem.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/Information/ANInformationPanelWidget.h"
#include "UI/Information/ANMapWidget.h"

// Sets default values
AANMapRoom::AANMapRoom()
{
	RoomSceneRoot = CreateDefaultSubobject<USceneComponent>("RoomSceneRoot");
	SetRootComponent(RoomSceneRoot);

	BillboardComponent = CreateDefaultSubobject<UBillboardComponent>("BillboardComponent");
	BillboardComponent->SetupAttachment(RootComponent);

	RoomBoxCollider = CreateDefaultSubobject<UBoxComponent>("RoomBoxCollider");
	RoomBoxCollider->SetupAttachment(RootComponent);
	RoomBoxCollider->SetBoxExtent(FVector(100.0f, 100.0f, 100.0f));
	RoomBoxCollider->OnComponentBeginOverlap.AddDynamic(this, &AANMapRoom::OnRoomBeginOverlap);
	RoomBoxCollider->OnComponentEndOverlap.AddDynamic(this, &AANMapRoom::OnRoomEndOverlap);

	ResidingLevel = EANLevels::Dormitory;
	RoomFloor = 1;
	RoomName = NAME_None;
}

void AANMapRoom::BeginPlay()
{
	Super::BeginPlay();
}

void AANMapRoom::OnRoomBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			//Try to add the room to the list of visited rooms
			if (UANGameplaySaveGame* ActiveGameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				ActiveGameplaySaveGame->TryAddVisitedRoom(RoomName);
			}

			//Try to move to the new room in the map UI
			if (AANPlayerControllerBase* PlayerControllerBase = MainCharacter->GetPlayerControllerBase())
			{
				if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
				{
					if (UANInformationPanelWidget* InformationPanelWidget = HUDWidget->GetInformationPanelWidget())
					{
						if (UANMapWidget* MapWidget = InformationPanelWidget->GetMapWidget())
						{
							MapWidget->MoveToRoom(ResidingLevel, RoomFloor, RoomName);
						}
					}
				}
			}
		}
	}
}

void AANMapRoom::OnRoomEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{

}