// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANPushBackVolume.h"

#include "Components/ArrowComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/KismetMathLibrary.h"

#include "Character/ANMainCharacter.h"
#include "Particles/ParticleSystemComponent.h"
#include "Projectiles/ANHookProjectile.h"
#include "Weapon/ANWeaponHarpoon.h"
#include "Weapon/ANWeaponBase.h"

AANPushBackVolume::AANPushBackVolume()
{
	PrimaryActorTick.bCanEverTick = true;

	RootSceneComponent = CreateDefaultSubobject<USceneComponent>("RootSceneComponent");
	SetRootComponent(RootSceneComponent);

	BoxCollider = CreateDefaultSubobject<UBoxComponent>("BoxCollider");
	BoxCollider->SetupAttachment(RootSceneComponent);
	BoxCollider->SetBoxExtent(FVector(50.0f, 50.0f, 50.0f));
	BoxCollider->OnComponentBeginOverlap.AddDynamic(this, &AANPushBackVolume::OnOverlapBegin);
	BoxCollider->OnComponentEndOverlap.AddDynamic(this, &AANPushBackVolume::OnOverlapEnd);

	BubbleVFX = CreateDefaultSubobject<UParticleSystemComponent>("BubbleVFX");
	BubbleVFX->SetupAttachment(RootSceneComponent);

	ArrowComponent = CreateDefaultSubobject<UArrowComponent>("Arrow");
	ArrowComponent->SetupAttachment(RootSceneComponent);
	ArrowComponent->AddLocalRotation(FRotator(90.0f, 0.0f, 0.0f));

	PushSpeed = 500.0f;
}

void AANPushBackVolume::BeginPlay()
{
	Super::BeginPlay();
}

void AANPushBackVolume::Tick(float DeltaTime)
{
	for (int32 i = 0; i < OverlappedActors.Num(); i++)
	{
		if (!OverlappedActors.IsValidIndex(i))
		{
			break;
		}

		if (CanPushBackActor(OverlappedActors[i]))
		{
			PushBackActor(OverlappedActors[i], DeltaTime);
		}
	}
}

void AANPushBackVolume::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (OtherActor != nullptr)
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
		{
			OverlappedActors.Add(MainCharacter);
		}
	}
}

void AANPushBackVolume::OnOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (OtherActor != nullptr)
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
		{
			OverlappedActors.Remove(MainCharacter);
		}
	}
}

bool AANPushBackVolume::CanPushBackActor(AActor* OtherActor)
{
	if (OtherActor == nullptr)
	{
		return false;
	}

	//If the actor is the main character, check for the hook to prevent pushing back
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
	{
		if (AANWeaponHarpoon* HarpoonWeapon = MainCharacter->GetHarpoonWeapon())
		{
			if (AANHookProjectile* Hook = HarpoonWeapon->GetHook())
			{
				if (Hook->IsHookAttached)
				{
					return false;
				}
			}
		}
	}

	return true;
}

void AANPushBackVolume::PushBackActor(AActor* OtherActor, float DeltaTime)
{
	if (OtherActor != nullptr)
	{
		FVector PushBackAmount = GetActorUpVector() * (PushSpeed * DeltaTime); //Use up vector to correlate with the bubble VFX, since it can't be rotated locally
		FVector NewLocation = OtherActor->GetActorLocation() + PushBackAmount;

		OtherActor->SetActorLocation(NewLocation, true);
	}
}
