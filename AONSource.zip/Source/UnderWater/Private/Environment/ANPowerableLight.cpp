// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANPowerableLight.h"

// Sets default values
AANPowerableLight::AANPowerableLight()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	LightOnIntensity = 500.0f;
	LightOffIntensity = 100.0f;
}

// Called when the game starts or when spawned
void AANPowerableLight::BeginPlay()
{
	Super::BeginPlay();
}

void AANPowerableLight::BP_PowerOn_Implementation()
{
	bPoweredOn = true;
}

void AANPowerableLight::BP_PowerOff_Implementation()
{
	bPoweredOn = false;
}

bool AANPowerableLight::BP_IsPoweredOn_Implementation()
{
	return bPoweredOn;
}

FText AANPowerableLight::BP_GetPowerableName_Implementation()
{
	return PowerableName;
}