// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANEnvironmentActor.h"

#include "Components/SceneComponent.h"

AANEnvironmentActor::AANEnvironmentActor()
{
	//Set up root
	EnvironmentRoot = CreateDefaultSubobject<USceneComponent>(TEXT("EnvironmentRoot"));
	RootComponent = EnvironmentRoot;
}

void AANEnvironmentActor::BeginPlay()
{
	Super::BeginPlay();
}

void AANEnvironmentActor::PlayEnvironmentEvent_Implementation()
{

}
