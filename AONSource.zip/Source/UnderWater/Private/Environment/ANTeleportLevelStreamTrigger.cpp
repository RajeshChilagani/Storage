// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANTeleportLevelStreamTrigger.h"

#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerStart.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"

AANTeleportLevelStreamTrigger::AANTeleportLevelStreamTrigger()
	: Super()
{
	bLoadLevel = true;
	bUnloadLevel = true;

	QueueLevelStreamingTime = 1.0f;
	bEnabled = true;;
}

#pragma optimize("", off)
void AANTeleportLevelStreamTrigger::OnOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!bEnabled)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OtherActor))
	{
		//Set timer on a short delay so we have the UI appear
		if (UWorld* MyWorld = GetWorld())
		{
			//Don't allow double level streaming
			if (MyWorld->GetTimerManager().IsTimerActive(QueueLevelStreamingHandle))
			{
				return;
			}

			FTimerDelegate QueueLevelStreamingTimerDelegate = FTimerDelegate::CreateUObject(this, &AANTeleportLevelStreamTrigger::DoLevelStreaming, MainCharacter);
			MyWorld->GetTimerManager().SetTimer(QueueLevelStreamingHandle, QueueLevelStreamingTimerDelegate, QueueLevelStreamingTime, false);

			//Fade in loading screen
			if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
			{
				if (AANPlayerControllerBase* PlayerControllerBase = MainCharacter->GetPlayerControllerBase())
				{
					GameInstance->FadeInLoadingScreen(PlayerControllerBase, 1.0f);
				}
			}
		}
	}
}

void AANTeleportLevelStreamTrigger::DoLevelStreaming(AANMainCharacter* MainCharacter)
{
	if (MainCharacter == nullptr)
	{
		return;
	}

	//Kill any active inputs since we are going to be moving the player manually
	MainCharacter->KillActiveInputs(true);

	//Disable at start so we don't load in an infinite loop
	if (DisableTeleportLevelStreamTrigger != nullptr)
	{
		DisableTeleportLevelStreamTrigger->SetEnabled(false);
	}

	if (bUnloadLevel)
	{
		UnloadLevel();
	}

	if (bLoadLevel)
	{
		LoadLevel();
	}

	//Set actor transform to the new location
	if (TeleportDestination != nullptr)
	{
		MainCharacter->TeleportTo(TeleportDestination->GetActorLocation(), FRotator(0.0f, 0.0f, 0.0f));
		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MainCharacter->GetController()))
		{
			PlayerControllerBase->SetControlRotation(TeleportDestination->GetActorRotation());
		}
	}

	//Re-enabled at end
	if (DisableTeleportLevelStreamTrigger != nullptr)
	{
		DisableTeleportLevelStreamTrigger->SetEnabled(true);
	}

	//Fade out loading screen at end
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (AANPlayerControllerBase* PlayerControllerBase = MainCharacter->GetPlayerControllerBase())
		{
			GameInstance->FadeOutLoadingScreen(PlayerControllerBase, 1.0f);
		}
	}
}
#pragma optimize("", on)

