// 2021 Abyssmal Games and Synodic Arc

#include "Environment/ANWorldNavRoom.h"

#include "Components/BoxComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SceneComponent.h"

#include "ANDefines.h"

#include "AI/Helpers/ANSecondaryAINavRoom.h"
#include "AI/Helpers/Room.h"
#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Environment/ANWorldNavRoomManager.h"
#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Systems/ANPickableItem.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/Information/ANInformationPanelWidget.h"
#include "UI/Information/ANMapWidget.h"

// Sets default values
AANWorldNavRoom::AANWorldNavRoom()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	RoomSceneRoot = CreateDefaultSubobject<USceneComponent>("RoomSceneRoot");
	SetRootComponent(RoomSceneRoot);

	BillboardComponent = CreateDefaultSubobject<UBillboardComponent>("BillboardComponent");
	BillboardComponent->SetupAttachment(RootComponent);

	RoomBounds = CreateDefaultSubobject<UBoxComponent>("RoomBoundingBox");
	RoomBounds->SetupAttachment(RootComponent);
	RoomBounds->SetBoxExtent(FVector(100.0f, 100.0f, 100.0f));
	RoomBounds->OnComponentBeginOverlap.AddDynamic(this, &AANWorldNavRoom::OnRoomBeginOverlap);
	RoomBounds->OnComponentEndOverlap.AddDynamic(this, &AANWorldNavRoom::OnRoomEndOverlap);

	ResidingLevel = EANLevels::Dormitory;
	RoomFloor = 1;
	RoomName = NAME_None;
}

void AANWorldNavRoom::BeginPlay()
{
	Super::BeginPlay();
}

void AANWorldNavRoom::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANWorldNavRoom::Destroyed()
{
	CleanupBeforeDestroyed();
	Super::Destroyed();
}


#if WITH_EDITOR
void AANWorldNavRoom::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	UWorld* World = GetWorld();
	if (PropertyChangedEvent.Property != nullptr)
	{
		const FName PropertyName(PropertyChangedEvent.Property->GetFName());
		if (PropertyName == GET_MEMBER_NAME_CHECKED(AANWorldNavRoom, bAddSecondaryAINavRoom))
		{
			if (bAddSecondaryAINavRoom && !SecondaryAINavRoom)
			{
				FActorSpawnParameters SpawnParameters;
				SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
				FTransform SpawnTransform = GetActorTransform();
				SecondaryAINavRoom = World->SpawnActor<AANSecondaryAINavRoom>(AANSecondaryAINavRoom::StaticClass(), SpawnTransform, SpawnParameters);
				SecondaryAINavRoom->SetOwner(this);
				SecondaryAINavRoom->AttachToActor(this, FAttachmentTransformRules::KeepWorldTransform);
			}
			else
			{
				if (SecondaryAINavRoom)
				{
					SecondaryAINavRoom->Destroy();
					SecondaryAINavRoom = nullptr;
				}
			}
		}

		if (PropertyName == GET_MEMBER_NAME_CHECKED(AANWorldNavRoom, bAddPersistentAINavRoom))
		{
			if (bAddPersistentAINavRoom && !PersistentAINavRoom)
			{
				FActorSpawnParameters SpawnParameters;
				SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
				FTransform SpawnTransform = GetActorTransform();
				PersistentAINavRoom = World->SpawnActor<ARoom>(ARoom::StaticClass(), SpawnTransform, SpawnParameters);
				PersistentAINavRoom->RoomBox->SetBoxExtent(GetRoomExtents());
				PersistentAINavRoom->SetOwner(this);
				PersistentAINavRoom->AttachToActor(this, FAttachmentTransformRules::KeepWorldTransform);
			}
			else
			{
				if (PersistentAINavRoom)
				{
					PersistentAINavRoom->Destroy();
					PersistentAINavRoom = nullptr;
				}
			}
		}
	}
	Super::PostEditChangeProperty(PropertyChangedEvent);
}
#endif

FVector AANWorldNavRoom::GetRoomExtents()
{
	if (RoomBounds)
	{
		return RoomBounds->GetScaledBoxExtent();
	}

	return FVector::ZeroVector;
}

void AANWorldNavRoom::SetRoomExtents(FVector Extent)
{
	if (RoomBounds)
	{
		RoomBounds->SetBoxExtent(Extent);
	}
}

FVector AANWorldNavRoom::GetRoomLocation()
{
	if (RoomBounds)
	{
		return RoomBounds->GetComponentLocation();
	}

	return FVector::ZeroVector;
}

void AANWorldNavRoom::OnRoomBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		bIsPlayerInRoom = true;
		OnNavRoomStateChanged.Broadcast(this, bIsPlayerInRoom);

		//if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		//{
		//	//Try to add the room to the list of visited rooms
		//	if (UANGameplaySaveGame* ActiveGameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		//	{
		//		ActiveGameplaySaveGame->TryAddVisitedRoom(RoomName);
		//	}
		//
		//	//Try to move to the new room in the map UI
		//	if (AANPlayerControllerBase* PlayerControllerBase = Player->GetPlayerControllerBase())
		//	{
		//		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		//		{
		//			if (UANInformationPanelWidget* InformationPanelWidget = HUDWidget->GetInformationPanelWidget())
		//			{
		//				if (UANMapWidget* MapWidget = InformationPanelWidget->GetMapWidget())
		//				{
		//					MapWidget->MoveToRoom(ResidingLevel, RoomFloor, RoomName);
		//				}
		//			}
		//		}
		//	}
		//}

	}
}

void AANWorldNavRoom::OnRoomEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		bIsPlayerInRoom = false;
		OnNavRoomStateChanged.Broadcast(this, bIsPlayerInRoom);
	}
}

void AANWorldNavRoom::CleanupBeforeDestroyed()
{
	if (AANWorldNavRoomManager* WorldNavRoomManager = Cast<AANWorldNavRoomManager>(GetOwner()))
	{
		WorldNavRoomManager->RemoveWorldNavRoom(RoomName);
	}
	if (SecondaryAINavRoom)
	{
		SecondaryAINavRoom->Destroy();
		SecondaryAINavRoom = nullptr;
	}

	if (PersistentAINavRoom)
	{
		PersistentAINavRoom->Destroy();
		PersistentAINavRoom = nullptr;
	}
}

