// 2021 Abyssmal Games and Synodic Arc


#include "Environment/ANMovingStatue.h"

AANMovingStatue::AANMovingStatue()
{
	PrimaryActorTick.bCanEverTick = true;
}

void AANMovingStatue::BeginPlay()
{
	Super::BeginPlay();
}

void AANMovingStatue::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

