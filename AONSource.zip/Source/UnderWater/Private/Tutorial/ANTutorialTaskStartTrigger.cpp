// 2021 Abyssmal Games and Synodic Arc


#include "Tutorial/ANTutorialTaskStartTrigger.h"

#include "Character/ANMainCharacter.h"
#include "Tutorial/ANTutorialTask.h"


// Sets default values
AANTutorialTaskStartTrigger::AANTutorialTaskStartTrigger()
	: Super()
{

}

void AANTutorialTaskStartTrigger::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	if (TutorialTaskToStart != nullptr)
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OverlappedActor))
		{
			TutorialTaskToStart->StartTask(MainCharacter);
			bPlayed = true;
		}
	}
}