// 2021 Abyssmal Games and Synodic Arc


#include "Tutorial/ANTutorialTaskFinishTrigger.h"

#include "Character/ANMainCharacter.h"
#include "Tutorial/ANTutorialTask.h"

// Sets default values
AANTutorialTaskFinishTrigger::AANTutorialTaskFinishTrigger()
	: Super()
{
}

void AANTutorialTaskFinishTrigger::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	if (TutorialTaskToFinish != nullptr)
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(OverlappedActor))
		{
			TutorialTaskToFinish->FinishTask(MainCharacter);
			bPlayed = true;
		}
	}
}