// Fill out your copyright notice in the Description page of Project Settings.


#include "Tutorial/ANTutorialTask.h"

#include "ANDefines.h"

#include "Audio/ANDialogueConversation.h"
#include "Character/ANMainCharacter.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Shared/ANFunctionLibrary.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/Tutorial/ANTutorialPanelWidget.h"

// Sets default values
AANTutorialTask::AANTutorialTask()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;


	//Set defaults
	bActive = false;
	bFinished = false;
}

// Called when the game starts or when spawned
void AANTutorialTask::BeginPlay()
{
	Super::BeginPlay();
}

void AANTutorialTask::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (bActive && TaskCharacter != nullptr)
	{
		FinishTask(TaskCharacter);
	}

	Super::EndPlay(EndPlayReason);
}

// Called every frame
void AANTutorialTask::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANTutorialTask::StartTask(AANMainCharacter* NewTaskCharacter)
{
	//Can't start if this task is active or already finished
	if (bActive || bFinished)
	{
		return;
	}

	if (NewTaskCharacter == nullptr)
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = NewTaskCharacter->GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (UANTutorialPanelWidget* TutorialPanelWidget = HUDWidget->GetTutorialPanelWidget())
			{
				TutorialPanelWidget->BP_CreateTutorialTask(this);
			}
		}

		if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
		{
			//Load the dialogue conversation
			if (UANFunctionLibrary::LoadSoftObject(TutorialStartDialogueConversation))
			{
				DialogueManager->AddNewDialogueConversation(TutorialStartDialogueConversation.Get());
			}
		}
	}

	TaskCharacter = NewTaskCharacter;

	bActive = true;
	OnTutorialTaskStarted.Broadcast(this);
	Print("Task started!");
}

void AANTutorialTask::FinishTask(AANMainCharacter* NewTaskCharacter)
{
	//Can't finish if this task isn't active
	if (!bActive)
	{
		return;
	}

	if (NewTaskCharacter == nullptr)
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = NewTaskCharacter->GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (UANTutorialPanelWidget* TutorialPanelWidget = HUDWidget->GetTutorialPanelWidget())
			{
				TutorialPanelWidget->BP_CompleteTutorialTask(this);
			}
		}

		if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
		{
			//Load the dialogue conversation
			if (UANFunctionLibrary::LoadSoftObject(TutorialFinishDialogueConversation))
			{
				DialogueManager->AddNewDialogueConversation(TutorialFinishDialogueConversation.Get());
			}
		}
	}

	bActive = false;
	bFinished = true;
	OnTutorialTaskFinished.Broadcast(this);
	Print("Task finished!");

	TaskCharacter = nullptr;
}
