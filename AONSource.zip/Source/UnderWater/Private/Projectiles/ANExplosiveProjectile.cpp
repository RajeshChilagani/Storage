// Fill out your copyright notice in the Description page of Project Settings.


#include "Projectiles/ANExplosiveProjectile.h"

void AANExplosiveProjectile::OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	FVector NormalImpulse, const FHitResult& Hit)
{
}
