// Fill out your copyright notice in the Description page of Project Settings.


#include "Projectiles/ANHookProjectile.h"

#include "CableComponent.h"
#include "Particles/ParticleSystemComponent.h"

AANHookProjectile::AANHookProjectile()
{
	Cable = CreateDefaultSubobject<UCableComponent>(TEXT("CableComponent"));
	
	Cable->SetupAttachment(MainMeshComponent);
}

void AANHookProjectile::OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
                                  FVector NormalImpulse, const FHitResult& Hit)
{
	if ((OtherActor != NULL) && (OtherActor != this) && (OtherComp != NULL))
	{
		MainMeshComponent->SetWorldLocation(Hit.Location);
		MainMeshComponent->SetPhysicsLinearVelocity(FVector(0, 0, 0));
		//TODO needs a check here
		//Does collision need phys? if yes dont do this. 
		MainMeshComponent->SetSimulatePhysics(false);
		IsHookAttached = true;
		BubbleEffect->Deactivate();
	}
}

void AANHookProjectile::ReleaseHook()
{
	Cable->bAttachEnd = false;
	Cable->CableLength = 1;
}

