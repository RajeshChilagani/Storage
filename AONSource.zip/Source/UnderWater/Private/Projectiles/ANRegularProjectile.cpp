// Fill out your copyright notice in the Description page of Project Settings.


#include "Projectiles/ANRegularProjectile.h"

#include "DrawDebugHelpers.h"
#include "Runtime/Engine/Classes/Particles/ParticleSystemComponent.h"

#include "AI/Helpers/NavUserCharacter.h"
#include "Character/ANMainCharacter.h"
#include "Character/ANSecondaryEnemy.h"
#include "Puzzle/ANMonsterDoor.h"
#include "Character/ANPersistentCharacter.h"
#include "Controller/ANPlayerControllerBase.h"

AANRegularProjectile::AANRegularProjectile()
	: Super()
{

}

void AANRegularProjectile::OnCompHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
                                     FVector NormalImpulse, const FHitResult& Hit)
{
	if ((OtherActor != NULL) && (OtherActor != this) && (OtherComp != NULL) )
	{
		//Call any blueprint portions for the projectile being stopped
		OnProjectileStopped();

		
		if (AANSecondaryEnemy* SecondaryEnemy = Cast<AANSecondaryEnemy>(OtherActor))
		{
			if (SecondaryEnemy->bIsAlive)
			{
				SecondaryEnemy->TakeDamage(ProjectileDamage);
				BubbleEffect->Deactivate();

				if (CharacterOwner != nullptr)
				{
					CharacterOwner->PostAkAudioEventOnCharacter(ProjectileHitConfirmSFX);
				}

				DestroyOnHit();
			}
		}
		else if(AANPersistentCharacter* Baddy = Cast<AANPersistentCharacter>(OtherActor))
		{
			UWorld* World = GetWorld();
			if (World)
			{
				AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(World->GetFirstPlayerController());
				if (PlayerController)
				{
					Baddy->TakeDamage(StunDamage,FDamageEvent(),PlayerController,this);
				}
			}

			DestroyOnHit();
		}
		else if (AANMonsterDoor* MonsterDoor = Cast<AANMonsterDoor>(OtherActor))
		{
			MonsterDoor->ReceiveDamage(ProjectileDamage);

			if (CharacterOwner != nullptr)
			{
				CharacterOwner->PostAkAudioEventOnCharacter(ProjectileHitConfirmSFX);
			}

			DestroyOnHit();
		}
		else
		{
			MainMeshComponent->AttachToComponent(OtherComp, FAttachmentTransformRules::KeepWorldTransform);
			MainMeshComponent->SetSimulatePhysics(false);
			MainMeshComponent->SetPhysicsLinearVelocity(FVector(0, 0, 0));

			auto Socket = MainMeshComponent->GetSocketLocation("HitLocation");
			auto tempLocation = MainMeshComponent->GetComponentLocation() - Socket;
			MainMeshComponent->SetWorldLocation(Hit.Location + tempLocation);
			CustomDepthBounds->SetWorldLocation(Hit.Location + tempLocation);
			//this->AttachToActor(OtherActor, FRules);

			//this->AttachToComponent(OtherComp, FRules);
			//MainMeshComponent->GetAttachmentRootActor()->AttachToActor();
			//DrawDebugLine(GetWorld(), Socket, Hit.Location, FColor::Red);
			MainMeshComponent->SetCollisionProfileName("NoCollision");


			//MainMeshComponent->SetPhysicsLinearVelocity(FVector(0, 0, 0));
			//TODO needs a check here
			//Does collision need phys? if yes dont do this. 
			//MainMeshComponent->SetSimulatePhysics(false);
			BubbleEffect->Deactivate();

			//Update world saveable state here since we now need to remember where this object landed
			UpdateWorldSaveableState();
		}
	}

}
