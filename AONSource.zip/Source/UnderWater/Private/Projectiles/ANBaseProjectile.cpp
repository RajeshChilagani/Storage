// Fill out your copyright notice in the Description page of Project Settings.

#include "Projectiles/ANBaseProjectile.h"

#include "Components/SphereComponent.h"
#include "Components/BoxComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Particles/ParticleSystemComponent.h"

#include "ANDefines.h"

#include "Character/ANCharacterBase.h"
#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"

AANBaseProjectile::AANBaseProjectile()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	/*if (!MainMeshComponent)
	{
		MainMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>("MainMeshComponent");
		SetRootComponent(MainMeshComponent);
	}*/
	
	if (!BubbleEffect)
	{
		BubbleEffect = CreateDefaultSubobject<UParticleSystemComponent>("Particle System");
		BubbleEffect->SetupAttachment(MainMeshComponent);
	}

	if(!ProjectileMovementComponent)
	{
		ProjectileMovementComponent = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("Projectile Movement Component"));
		ProjectileMovementComponent->SetUpdatedComponent(MainMeshComponent);
		ProjectileMovementComponent->InitialSpeed = 1000.0f;
		ProjectileMovementComponent->MaxSpeed = 3000.0f;
		ProjectileMovementComponent->bRotationFollowsVelocity = false;
		ProjectileMovementComponent->bShouldBounce = false;
		ProjectileMovementComponent->Bounciness = 0.0f;
		ProjectileMovementComponent->ProjectileGravityScale = 0.0f;
	}

	ProjectileDamage = 50.0f;
}

void AANBaseProjectile::BeginPlay()
{
	Super::BeginPlay();

	MainMeshComponent->OnComponentHit.AddDynamic(this, &AANBaseProjectile::OnCompHit);
	//SetRootComponent(MainMeshComponent);
}

void AANBaseProjectile::BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
{
	Super::BP_InitializeWorldSaveableObject_Implementation(GuidToAssign, WorldSaveableDataToAssign);

	//Null out velocity for projectiles created on load
	ProjectileMovementComponent->SetVelocityInLocalSpace(FVector(0.0f, 0.0f, 0.0f));
}

void AANBaseProjectile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANBaseProjectile::FireInDirection(const FVector& ShootDirection)
{
	ProjectileMovementComponent->Velocity = ShootDirection * ProjectileMovementComponent->InitialSpeed;
}

void AANBaseProjectile::OnProjectileStopped_Implementation()
{
	
}

void AANBaseProjectile::PlayProjectileShotSFX()
{
	if (CharacterOwner != nullptr)
	{
		CharacterOwner->PostAkAudioEventOnCharacter(ProjectileShotSFX);
	}
}

void AANBaseProjectile::DestroyOnHit()
{
	//If we hit the object, remove it from the world saveables before destroying itself
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			GameplaySaveGame->RemoveWorldSaveable(WorldSaveableGuid);
		}
	}

	Destroy();
}