// �2021 Abyssmal Games and Synodic Arc


#include "Weapon/ANWeaponHarpoon.h"

#include <string>


#include "CableComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Projectiles/ANBaseProjectile.h"
#include "Projectiles/ANRegularProjectile.h"
#include "Camera/CameraComponent.h"
#include "Systems/ANInventorySystem.h"




void AANWeaponHarpoon::BeginPlay()
{
	Super::BeginPlay();

	if (ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(Player))
		{
			InventorySystemRef = MainCharacter->GetInventorySystem();
			InventorySystemRef->OnItemAdded.AddDynamic(this,&AANWeaponHarpoon::OnItemAddedToInventory);
		}
	}
	
	
	if (TypesOfProjectiles.Num() > 0)
	{
		BulletToSpawn = TypesOfProjectiles[0];
		ProjectileToShowOnTheGun->SetStaticMesh(Cast<AANBaseProjectile>(BulletToSpawn.GetDefaultObject())->GetStaticMeshComponent()->GetStaticMesh());
		//ProjectileToShowOnTheGun->SetupAttachment(GunMesh, "HarpoonProjectileLocation");
		ProjectileToShowOnTheGun->SetWorldLocation(GunMesh->GetSocketLocation(ProjectileLocationOnGun));
		HideProjectileOnGun();
		EProjectileType ProjectileType = BulletToSpawn.GetDefaultObject()->Type;


		if (CanFire(UEnum::GetValueAsString(ProjectileType)))
		{
					ShowProjectileOnGun();
		}

		
	}

	
}

void AANWeaponHarpoon::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	const bool temp = UGameplayStatics::GetPlayerController(GetWorld(), 0)->IsInputKeyDown(EKeys::LeftMouseButton);

	if(UGameplayStatics::GetPlayerController(GetWorld(), 0)->IsInputKeyDown(EKeys::One))
	{
		if (TypesOfProjectiles.Num() > 0)
		{
			ChangeProjectileOnGun(0);
		}
		/*else
		{
			UE_LOG(LogTemp, Error, TEXT("No Projectile at slot 1"));
			BulletToSpawn = nullptr;
		}*/
		
	}
	if (UGameplayStatics::GetPlayerController(GetWorld(), 0)->IsInputKeyDown(EKeys::Two))
	{
		
		if (TypesOfProjectiles.Num() > 1)
		{
		
			ChangeProjectileOnGun(1);
		}
		/*else
		{
			UE_LOG(LogTemp, Error, TEXT("No Projectile at slot 2"));
			BulletToSpawn = nullptr;
		}*/
	}

	if (UGameplayStatics::GetPlayerController(GetWorld(), 0)->IsInputKeyDown(EKeys::Y))
	{
		if(IsHookFired && HookRef)
		{
			HookRef->ReleaseHook();
			IsHookFired = false;
			HookRef = nullptr;
		}
	}
	
	
	if (IsHookFired && temp && !HookRef->IsHookAttached)
	{
		ReelHook();
	}
	else if (IsHookFired && temp && HookRef->IsHookAttached)
	{
		ReelPlayerToTarget();
	}
}

void AANWeaponHarpoon::Fire()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(UGameplayStatics::GetPlayerCharacter(GetWorld(), 0));
	if (MainCharacter == nullptr)
	{
		return;
	}

	if (BulletToSpawn && MainCharacter->bIsADS)
	{
		//check for bullets from the inventory here also
		const EProjectileType ProjectileType = BulletToSpawn.GetDefaultObject()->Type;
		switch (ProjectileType)
		{
			case (EProjectileType::None):
				UE_LOG(LogTemp, Error, TEXT("Projectile can't be none."));
				break;
			case (EProjectileType::HarpoonBolt):
				if (CanFire(UEnum::GetValueAsString(ProjectileType))) //TODO should probably change direct string here
				{
					HideProjectileOnGun();
					RegularFire();
					
					if (FireCameraShake)
						UGameplayStatics::GetPlayerController(GetWorld(), 0)->ClientPlayCameraShake(FireCameraShake);
				}
				break;
			case (EProjectileType::FlareBolt):
				if (CanFire(UEnum::GetValueAsString(ProjectileType)))
				{
					RegularFire();
				}
				break;
			case (EProjectileType::HookProjectile): 
				if (CanFire("Hook"))
				{
					HookFire();
					
					if (FireCameraShake)
						UGameplayStatics::GetPlayerController(GetWorld(), 0)->ClientPlayCameraShake(FireCameraShake);
				}
				break;
			default:
				break;
		}
	}

	// CameraShake
	
}


bool AANWeaponHarpoon::CanFire(FString Name)
{
	//remove the enum type name.
	Name.RemoveAt(0, 17);

	if (ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(Player))
		{
			if (UANInventorySystem* InventorySystem = MainCharacter->GetInventorySystem())
			{
				if (InventorySystem->HasItem(Name))
				{
					return true;
				}
			}
		}
	}

	return false;
}

void AANWeaponHarpoon::ChangeProjectileOnGun(int ID)
{
	if(TypesOfProjectiles.Num()>0)
	{
		
		EProjectileType type = TypesOfProjectiles[ID].GetDefaultObject()->Type;
	if(CanFire(UEnum::GetValueAsString(type)))
	{
		BulletToSpawn = TypesOfProjectiles[ID];
		ProjectileToShowOnTheGun->SetStaticMesh(Cast<AANBaseProjectile>(BulletToSpawn.GetDefaultObject())->GetStaticMeshComponent()->GetStaticMesh());
		ShowProjectileOnGun();
	}
	}
}

void AANWeaponHarpoon::RegularFire()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	if (MyWorld->GetTimeSeconds() > nextFire)
	{
		
		nextFire = MyWorld->GetTimeSeconds() + FireRate;
		
		FVector BulletPos= GunMesh->GetSocketLocation(BulletSpawnSocketName);

		FRotator BulletRotation = GunMesh->GetSocketRotation(BulletSpawnSocketName);

		AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(CharacterOwner);


		
		FVector ForwardVectorOfPlayer =UKismetMathLibrary::GetForwardVector(MainCharacter->HeadCamera->GetComponentToWorld().GetRotation().Rotator());
		FVector Start = MainCharacter->HeadCamera->GetComponentToWorld().GetLocation();
		FVector NormalEnd = Start+ ForwardVectorOfPlayer * 10000.0;


		float Spread = MainCharacter->GetVelocity().Size() + MainCharacter->CameraRotationRate.Size() * 100;

		float clampedSpread = FMath::Clamp(Spread, 0.0f, 80.0f);

		bool bIsSpread = (clampedSpread > 0.5f) ?  true: false;
		float newSpread = UKismetMathLibrary::MapRangeClamped(clampedSpread, 5.0f, 80.0f, 0.0f, 0.1f);

		FVector EndLocationWithSpread = Start + UKismetMathLibrary::RandomUnitVectorInEllipticalConeInRadians(ForwardVectorOfPlayer, newSpread, newSpread)*10000.0;

		FVector End = UKismetMathLibrary::SelectVector(EndLocationWithSpread, NormalEnd, bIsSpread);
		
		FCollisionQueryParams TraceParam;
		FHitResult Hit;
		bool bHit = GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, TraceParam);
		AANBaseProjectile* Bullet = nullptr;// = Cast<AANBaseProjectile>(MyWorld->SpawnActor(BulletToSpawn, &BulletPos, &BulletRotation));
		//DrawDebugLine(GetWorld(), Start,End, FColor::Red,true);
		if(bHit)
		{		
			BulletRotation = UKismetMathLibrary::FindLookAtRotation(BulletPos, Hit.Location);
			FActorSpawnParameters SpawnParameters;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
			FTransform transform =	UKismetMathLibrary::MakeTransform(BulletPos, BulletRotation, FVector(1, 1, 1));
			Bullet = Cast<AANBaseProjectile>(MyWorld->SpawnActor(BulletToSpawn, &transform,SpawnParameters));
		}
		else
		{
			BulletRotation = MainCharacter->HeadCamera->GetComponentRotation();
		
			FActorSpawnParameters SpawnParameters;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
			FTransform transform = UKismetMathLibrary::MakeTransform(BulletPos, BulletRotation, FVector(1, 1, 1));
			Bullet = Cast<AANBaseProjectile>(MyWorld->SpawnActor(BulletToSpawn, &transform, SpawnParameters));
		}
		
		
		//auto mesh = Cast<UStaticMeshComponent>(Bullet->GetRootComponent()); 
		if (Bullet != nullptr)
		{	
			Bullet->SetCharacterOwner(CharacterOwner);
			Bullet->PlayProjectileShotSFX();
			
			UpdateInventory("HarpoonBolt");
			if (MainCharacter)
			{
				
				MainCharacter->NotifyWeaponFired(Bullet);
			}
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("The projectile needs a mesh to add force!"));
		}

		if(CanFire(UEnum::GetValueAsString(EProjectileType::HarpoonBolt)))
			GetWorldTimerManager().SetTimer(VisibilityReset, this, &AANWeaponHarpoon::ShowProjectileOnGun, FireRate, false);
	}
}


void AANWeaponHarpoon::HookFire()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	//TODO fetch the hooks from the inventory! here.

	//if(!IsHookFired)
	{
		IsHookFired = true;
		FVector BulletPos = GunMesh->GetSocketLocation(BulletSpawnSocketName);
		FRotator BulletRotation = GunMesh->GetSocketRotation(BulletSpawnSocketName);

		AANBaseProjectile* Bullet = Cast<AANBaseProjectile>(MyWorld->SpawnActor(BulletToSpawn, &BulletPos, &BulletRotation));
		if (Bullet == nullptr)
		{
			return;
		}

		HookRef = Cast<AANHookProjectile>(Bullet);
		UStaticMeshComponent* mesh = Cast<UStaticMeshComponent>(Bullet->GetRootComponent());

		if (mesh)
		{
			HookRef->Cable->SetAttachEndTo(this,FName(),BulletSpawnSocketName);
			HookRef->Cable->bAttachEnd = true;
			HookRef->Cable->EndLocation = FVector(0,-77.0,4);
			HookRef->FireInDirection(BulletRotation.Vector());

			////adds a delay 
			GetWorldTimerManager().SetTimer(TimerHandle, this, &AANWeaponHarpoon::SetIsHookFire, 0.1f, false);
			UpdateInventory("Hook");
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("The Bullet needs a mesh to add force!"));
		}
	}
}

void AANWeaponHarpoon::UpdateInventory(FString Name)
{
	if (ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0))
	{
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(Player))
		{
			if (UANInventorySystem* InventorySystem = MainCharacter->GetInventorySystem())
			{
				if (InventorySystem->HasItem(Name))
				{
					InventorySystem->RemoveItem(Name, 1);
				}
			}
		}
	}
}

void AANWeaponHarpoon::ReelHook() const
{
	//HookRef->SetActorLocation(FMath::VInterpTo(HookRef->GetActorLocation(), GunMesh->GetSocketLocation(BulletSpawnSocketName), GetWorld()->GetDeltaSeconds(), 0.5));
	//HookRef->SetActorLocation(GunMesh->GetSocketLocation(BulletSpawnSocketName));
	HookRef->GetMeshComponent()->SetWorldLocation(FMath::VInterpTo(HookRef->GetMeshComponent()->GetComponentLocation(), GunMesh->GetSocketLocation(BulletSpawnSocketName), GetWorld()->GetDeltaSeconds(), 0.5));

	Cast<UStaticMeshComponent>(HookRef->GetMeshComponent())->SetPhysicsLinearVelocity(FVector(0,0,0));
}


void AANWeaponHarpoon::ReelPlayerToTarget()
{
	auto temp = GunMesh->GetAttachmentRootActor();
		temp->SetActorLocation(FMath::VInterpTo(temp->GetActorLocation(), HookRef->GetMeshComponent()->GetComponentLocation(), GetWorld()->GetDeltaSeconds(), 0.5));
}

void AANWeaponHarpoon::OnItemAddedToInventory(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod)
{
	if(InventorySystemRef)
	{
		if (InventorySystemRef->GetNumOfItem("HarpoonBolt") == 1)
			ChangeProjectileOnGun(0);
	}
	
}

