// �2021 Abyssmal Games and Synodic Arc


#include "Weapon/ANWeaponBase.h"

#include "Kismet/GameplayStatics.h"

#include "Character/ANCharacterBase.h"

AANWeaponBase::AANWeaponBase()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	Root = CreateDefaultSubobject<USceneComponent>("Root");
	GunMesh = CreateDefaultSubobject<USkeletalMeshComponent>("Gun Mesh");

	SetRootComponent(Root);
	GunMesh->AttachToComponent(Root, FAttachmentTransformRules::KeepRelativeTransform);
	ProjectileToShowOnTheGun = CreateDefaultSubobject<UStaticMeshComponent>("Projectile");
	ProjectileToShowOnTheGun->SetupAttachment(GunMesh);
}

void AANWeaponBase::BeginPlay()
{
	Super::BeginPlay();
	//get the number of bullets from the inventory here.
	
	if (AANCharacterBase* NewCharacterOwner = Cast<AANCharacterBase>(GetParentActor()))
	{
		CharacterOwner = NewCharacterOwner;
	}
}

void AANWeaponBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANWeaponBase::Fire()
{

}

bool AANWeaponBase::CanFire(FString Name)
{
	return true;
}

void AANWeaponBase::HideProjectileOnGun() const
{
	if (ProjectileToShowOnTheGun)
	{
		ProjectileToShowOnTheGun->SetVisibility(false);
	}
}

void AANWeaponBase::ShowProjectileOnGun() const
{
	if (ProjectileToShowOnTheGun)
	{
		ProjectileToShowOnTheGun->SetVisibility(true);
	}
}




