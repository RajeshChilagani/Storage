// 2021 Abyssmal Games and Synodic Arc


#include "Utils/ANPostProcessingManager.h"
#include "Engine/PostProcessVolume.h"

// Sets default values
AANPostProcessingManager::AANPostProcessingManager()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

}

void AANPostProcessingManager::EnableFocus() const
{
	if(FocusPostProcessingVolume && FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num() > 0)
	{
		auto Size = FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num();
		auto& FocusMaterial = FocusPostProcessingVolume->Settings.WeightedBlendables.Array[Size-1];
		FocusMaterial.Weight = 1;
	}
}

void AANPostProcessingManager::DisableFocus() const
{
	if (FocusPostProcessingVolume && FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num() > 0)
	{
		auto Size = FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num();
		auto& FocusMaterial = FocusPostProcessingVolume->Settings.WeightedBlendables.Array[Size-1];
		FocusMaterial.Weight = 0;
	}
}

void AANPostProcessingManager::SetFocus(float WeightValue) const
{
	if (FocusPostProcessingVolume && FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num() > 0)
	{
		auto Size = FocusPostProcessingVolume->Settings.WeightedBlendables.Array.Num();
		auto& FocusMaterial = FocusPostProcessingVolume->Settings.WeightedBlendables.Array[Size - 1];
		FocusMaterial.Weight = FMath::Clamp<float>(WeightValue,0,1);
	}
}

// Called when the game starts or when spawned
void AANPostProcessingManager::BeginPlay()
{
	Super::BeginPlay();
	
}

