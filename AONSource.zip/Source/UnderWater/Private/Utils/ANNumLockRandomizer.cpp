// Fill out your copyright notice in the Description page of Project Settings.


#include "Utils/ANNumLockRandomizer.h"
DEFINE_LOG_CATEGORY_STATIC(LogNumLockRandomizer, All, All);

bool UANNumLockRandomizer::IsAValidCode(const FString& Code)
{
	return UnlockCodes.Contains(Code);
}

FString UANNumLockRandomizer::GetCodeInRangeAsString(int32 Min, int32 Max)
{
	int32 RandomIntInRange = FMath::RandRange(Min, Max);
	FString NewCode = FString::FromInt(RandomIntInRange);
	while (IsAValidCode(NewCode))
	{
		RandomIntInRange = FMath::RandRange(Min, Max);
		NewCode = FString::FromInt(RandomIntInRange);
	}
	return NewCode;
}

FString UANNumLockRandomizer::GenerateRandomCode(uint32 Length)
{
	char Charbuffer[] = {0,0,0,0,0,0};
	memset(Charbuffer, 'X', Length);
	FString NewCode(Charbuffer);
	switch (Length)
	{
	case 4:
		NewCode = GetCodeInRangeAsString(1000, 9999);
		break;
	default:
		break;
	}
	if(NewCode.Contains("X"))
	{
		UE_LOG(LogNumLockRandomizer, Error, TEXT("UnlockCode Could not be generated of length %d"), Length);
	}
	else
	{
		UnlockCodes.Add(NewCode);
	}
	return NewCode;
}
