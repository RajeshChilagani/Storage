// Fill out your copyright notice in the Description page of Project Settings.


#include "Systems/ANCraftingSystem.h"
#include "Systems/ANInventorySystem.h"

DEFINE_LOG_CATEGORY_STATIC(CraftingSystem, All, All)

//FCraftableItem
FCraftableItem::FCraftableItem(FANItem* ItemData)
	:bIsReadyToCraft(false)
	,CraftableItemData(ItemData)
{

}

//UANCraftingSystem
UANCraftingSystem::UANCraftingSystem()
{

}

UANCraftingSystem::~UANCraftingSystem()
{

}

bool UANCraftingSystem::Init(UANInventorySystem* InventorySystem)
{
	//check(InventorySystem);
	//if (!InventorySystem)
	//{
	//	UE_LOG(CraftingSystem, Error, TEXT("Inventory System is nullptr. Failed to initialize Crafting System"));
	//	return false;
	//}
	//SetInventorySystem(InventorySystem);
	//LoadCraftableItems();
	return true;
}

void UANCraftingSystem::UpdateCraftingStatus()
{
	//if (m_InventorySystem)
	//{
	//	for (FCraftableItem& CraftableItem : m_CraftableItems)
	//	{
	//		bool& bReadyToCraft = CraftableItem.bIsReadyToCraft;
	//		TArray<FIngredient>& Ingredientslist = CraftableItem.CraftableItemData->IngredientlistToCraft;
	//		for (FIngredient& Ingredient : Ingredientslist)
	//		{
	//			UANInventoryItem* InventoryItem = m_InventorySystem->GetItem(Ingredient.IngredientName);
	//			if (InventoryItem)
	//			{
	//				bReadyToCraft = InventoryItem->Count == Ingredient.Count;
	//				if (!bReadyToCraft)
	//				{
	//					break;
	//				}
	//			}
	//		}
	//	}
	//}
	//else
	//{
	//	UE_LOG(CraftingSystem, Error, TEXT("Update Failed. Inventory System not found"));
	//}
}

void UANCraftingSystem::CraftFromIndex(int32 IndexOfCraftableItem)
{
	//check(IndexOfCraftableItem < m_CraftableItems.Num());
	//if (IndexOfCraftableItem < m_CraftableItems.Num())
	//{
	//	Craft(m_CraftableItems[IndexOfCraftableItem]);
	//}
}

void UANCraftingSystem::Craft(const FCraftableItem& ItemToBeCrafted)
{
	//if (m_InventorySystem)
	//{
	//	if (ItemToBeCrafted.bIsReadyToCraft)
	//	{
	//		if (auto DataOfItemToBeCrafted = ItemToBeCrafted.CraftableItemData)
	//		{
	//			UANInventoryItem* NewItemToBeAdded = NewObject<UANInventoryItem>();
	//			NewItemToBeAdded->Count = 1;
	//			NewItemToBeAdded->ANItemName = DataOfItemToBeCrafted->ANItemName;
	//			NewItemToBeAdded->UniqueInstanceName = DataOfItemToBeCrafted->ANItemName;
	//			m_InventorySystem->AddItem(NewItemToBeAdded, EAddItemMethods::Craft);
	//
	//			TArray<FIngredient>& Ingredientslist = DataOfItemToBeCrafted->IngredientlistToCraft;
	//			for (FIngredient& Ingredient : Ingredientslist)
	//			{
	//				m_InventorySystem->RemoveItem(Ingredient.IngredientName, Ingredient.Count);
	//			}
	//		}
	//		
	//	}
	//}
	//else
	//{
	//	UE_LOG(CraftingSystem, Error, TEXT("Failed to craft. Inventory System not found"));
	//}
}

void UANCraftingSystem::SetInventorySystem(UANInventorySystem* InventorySystem)
{
	//m_InventorySystem = InventorySystem;
}

void UANCraftingSystem::LoadCraftableItems()
{
	//if (m_InventorySystem)
	//{
	//	UDataTable* ItemDataTable = m_InventorySystem->m_ItemDataTable;
	//	static const FString ContextString("Item Context String");
	//	TArray<FANItem*> OutAllItems;
	//	ItemDataTable->GetAllRows(ContextString, OutAllItems);
	//	for (FANItem* Item :OutAllItems) 
	//	{
	//		if (Item->bIsCraftable)
	//		{
	//			m_CraftableItems.Emplace(Item);
	//		}
	//	}
	//}
}

