// Fill out your copyright notice in the Description page of Project Settings.


#include "Systems/ANInventorySystem.h"

#include "UObject/ConstructorHelpers.h"
#include "Logging/LogMacros.h"

#include "ANDelegates.h"

DEFINE_LOG_CATEGORY_STATIC(LogInventorySystem, All, All);

UANInventorySystem::UANInventorySystem()
{
	LoadItemDataTable();
}

UANInventorySystem::~UANInventorySystem()
{
	
}

void UANInventorySystem::LoadItemDataTable()
{
	static ConstructorHelpers::FObjectFinder<UDataTable> ItemsDataTable(TEXT("DataTable'/Game/DataAssets/DataTables/ANItemsTable.ANItemsTable'"));
	if (ItemsDataTable.Succeeded())
	{
		m_ItemDataTable = ItemsDataTable.Object;
	}
}

void UANInventorySystem::AddItem(const FString& ItemName, int32 Count, EAddItemMethods AddItemMethod)
{
	FANItem* ItemData = GetItemDataFromTable(ItemName);
	if (ItemData == nullptr)
	{
		UE_LOG(LogInventorySystem, Error, TEXT("Failed to Add Item. Cannot add Invalid item"));
		return;
	}

	if (!m_Items.Contains(ItemName))
	{
		m_Items.Add(ItemName, Count);
	}
	else
	{
		m_Items[ItemName] += Count;
	}

	OnItemAdded.Broadcast(ItemName, Count, AddItemMethod);
	TryAutoCraft(ItemData);

	return;
}

void UANInventorySystem::RemoveItem(const FString& ItemName, int32 Count)
{
	if (Count <= 0)
	{
		UE_LOG(LogInventorySystem, Error, TEXT("Invalid Input. Failed to remove item from inventory. Count cannot be zero or less"));
		return;
	}

	if (!m_Items.Contains(ItemName))
	{
		UE_LOG(LogInventorySystem, Warning, TEXT("Cannot remove an item that does not exist in inventory."));
		return;
	}

	if (Count > m_Items[ItemName])
	{
		UE_LOG(LogInventorySystem, Error, TEXT("Failed to remove item. Cannot remove items greater than available in inventory."));
		return;
	}

	m_Items[ItemName] -= Count;
	OnItemRemoved.Broadcast(ItemName, Count);

	if (m_Items[ItemName] <= 0)
	{
		m_Items.Remove(ItemName);
	}
}

void UANInventorySystem::UseItem(const FString& ItemName, int32 Count)
{
	if (Count > 0)
	{
		if (!m_Items.Contains(ItemName))
		{
			UE_LOG(LogInventorySystem, Warning, TEXT("Item does not exist in inventory."));
			return;
		}

		if (m_Items[ItemName] < Count)
		{
			UE_LOG(LogInventorySystem, Error, TEXT("Cannot USE more than available Only %d instances of %s are found in the inventory."), m_Items[ItemName], *ItemName);
			return;
		}

		RemoveItem(ItemName, Count);
	}
	else
	{
		UE_LOG(LogInventorySystem, Error, TEXT("Invalid Input for Count. Cannot use zero or fewer items."));
		return;
	}
}


void UANInventorySystem::SearchInventory(const FString& SearchString, TArray<FString>& Out_Items)
{
	for (auto It = m_Items.CreateIterator(); It; ++It)
	{
		if (It->Key.Contains(SearchString))
		{
			if (!Out_Items.Contains(It->Key))
			{
				Out_Items.Add(It->Key);
			}
		}
	}
}

FANItem* UANInventorySystem::GetItemDataFromTable(const FString& ItemName)
{
	static const FString ContextString("Item Context String");
	FANItem* ItemData = m_ItemDataTable->FindRow<FANItem>(FName(FString("RN_").Append(ItemName)), ContextString, true);
	if (!ItemData)
	{
		UE_LOG(LogInventorySystem, Error, TEXT("There is no item with the name %s in the data table. Check DataTable"), *ItemName);
	}
	return ItemData;
}

FANItem UANInventorySystem::BP_GetItemDataFromTable(const FString& ItemName)
{
	FANItem ItemData = FANItem();
	
	if (m_ItemDataTable == nullptr)
	{
		return ItemData;
	}
	
	static const FString ContextString("Item Context String");
	FANItem* ItemDataPtr = GetItemDataFromTable(ItemName);
	if (ItemDataPtr != nullptr)
	{
		ItemData = *ItemDataPtr;
	}

	return ItemData;
}

bool UANInventorySystem::HasItem(const FString& ItemName)
{
	return m_Items.Contains(ItemName);
}

int32 UANInventorySystem::GetNumOfItem(const FString& ItemName)
{
	if (m_Items.Contains(ItemName))
	{
		return m_Items[ItemName];
	}

	return 0;
}

void UANInventorySystem::TryAutoCraft(const FANItem* MaterialItem)
{
	//Can only auto craft if the item type is material or has a valid material craft amount
	if (MaterialItem == nullptr || MaterialItem->ItemType != EANItemType::Material || MaterialItem->MaterialCraftAmount <= 0
		|| MaterialItem->CraftItemName.IsEmpty())
	{
		return;
	}

	if (!HasItem(MaterialItem->ANItemName))
	{
		UE_LOG(LogInventorySystem, Error, TEXT("Item Not Found."));
		return;
	}

	//If we have enough items, craft the new item
	if (m_Items[MaterialItem->ANItemName] >= MaterialItem->MaterialCraftAmount)
	{
		RemoveItem(MaterialItem->ANItemName, MaterialItem->MaterialCraftAmount);
		AddItem(MaterialItem->CraftItemName, 1, EAddItemMethods::Craft);
	}
}

bool UANInventorySystem::IsAValidItem(const FString& AnItemName)
{
	//At this point there should be a datatable initlialised
	check(m_ItemDataTable);
	if (!m_ItemDataTable)
	{
		UE_LOG(LogInventorySystem, Error, TEXT("ItemDataTable Not Found. Please add a Data Table"));
		return false;
	}
	return GetItemDataFromTable(AnItemName) ? true : false;
}

