// 2021 Abyssmal Games and Synodic Arc


#include "Systems/ANWorldSaveablePickableItem.h"

#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"

AANWorldSaveablePickableItem::AANWorldSaveablePickableItem()
	: Super()
{

}

void AANWorldSaveablePickableItem::BeginPlay()
{
	Super::BeginPlay();

	//If we don't have a Guid at begin play, make one
	if (!WorldSaveableGuid.IsValid())
	{
		WorldSaveableGuid = FGuid::NewGuid();
	}

	//If we can add this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

void AANWorldSaveablePickableItem::AddItemToInventory(UANInventorySystem* IS)
{
	Super::AddItemToInventory(IS);

	//Remove from world saveables map when picked up
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			GameplaySaveGame->RemoveWorldSaveable(WorldSaveableGuid);
		}
	}
}

void AANWorldSaveablePickableItem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANWorldSaveablePickableItem::BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
{
	WorldSaveableGuid = GuidToAssign;
}

bool AANWorldSaveablePickableItem::BP_CanSaveToWorldSaveablesMap_Implementation()
{
	//Do not allow child actors to be added/saved to the saveable map, since we have separate logic for things like item spawn points
	if (IsChildActor())
	{
		return false;
	}

	return true;
}

void AANWorldSaveablePickableItem::BP_UpdateWorldSaveableState_Implementation()
{
	//If we can save this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

FGuid AANWorldSaveablePickableItem::BP_GetWorldSaveableGuid_Implementation()
{
	return WorldSaveableGuid;
}

FWorldSaveableData AANWorldSaveablePickableItem::BP_GetWorldSaveableData_Implementation()
{
	FWorldSaveableData NewWorldSaveableData;
	NewWorldSaveableData.WorldSaveableClass = GetClass();
	NewWorldSaveableData.WorldSaveableTransform = GetActorTransform();
	NewWorldSaveableData.WorldSaveableParams = ConstructSaveableParamsString();
	return NewWorldSaveableData;
}

FString AANWorldSaveablePickableItem::BP_ConstructSaveableParamsString_Implementation()
{
	FString SaveString("");

	return SaveString;
}