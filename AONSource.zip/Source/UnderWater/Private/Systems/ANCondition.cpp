// 2021 Abyssmal Games and Synodic Arc


#include "Systems/ANCondition.h"

UANCondition::UANCondition()
	: Super()
{

}

bool UANCondition::MeetsConditions_Implementation(AActor* CheckActor)
{
	return true;
}