// Fill out your copyright notice in the Description page of Project Settings.


#include "Systems/ANPickableItem.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/BoxComponent.h"

#include "ANConsts.h"

#include "Audio/ANDialogueConversation.h"
#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"
#include "Systems/ANPickableItem.h"

// Sets default values
AANPickableItem::AANPickableItem()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	RootComponent = SceneComponent;

	MainMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PrimaryMesh"));
	MainMeshComponent->SetupAttachment(RootComponent);
	MainMeshComponent->SetCollisionProfileName(CollisionProfiles::InteractableObject);

	//Custom depth pass for focus ability
	MainMeshComponent->bRenderCustomDepth = false;
	MainMeshComponent->CustomDepthStencilWriteMask = ERendererStencilMask::ERSM_Default;
	MainMeshComponent->CustomDepthStencilValue = static_cast<int32>(EFocusOutlineColor::Yellow);

	CustomDepthBounds = CreateDefaultSubobject<UBoxComponent>("CustomDepthBounds");
	CustomDepthBounds->SetBoxExtent(FVector(300.0f, 300.0f, 300.0f));
	CustomDepthBounds->SetupAttachment(RootComponent);
	CustomDepthBounds->OnComponentBeginOverlap.AddDynamic(this, &AANPickableItem::OnCDBBeginOverlap);
	CustomDepthBounds->OnComponentEndOverlap.AddDynamic(this, &AANPickableItem::OnCDBEndOverlap);

}

// Called when the game starts or when spawned
void AANPickableItem::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AANPickableItem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

bool AANPickableItem::ShouldPlayDialogue_Implementation() const
{
	return true;
}

void AANPickableItem::AddItemToInventory(UANInventorySystem* IS)
{
	IS->AddItem(ItemName, Count, EAddItemMethods::PickUp);
	OnItemPickedUp.Broadcast(this);
}

bool AANPickableItem::CanInteract() const
{
	return true;
}

void AANPickableItem::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (InteractingCharacter != nullptr)
	{
		IANInteractable::BeginInteract(InteractingCharacter);
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
			{
				AddItemToInventory(InventorySystem);
				//Try to play associated dialogue
				if (PickedUpItemDialogueConversation != nullptr)
				{
					if (ShouldPlayDialogue())
					{
						//Only relevant if the main character
						if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
						{
							if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MainCharacter->GetController()))
							{
								if (UANDialogueManagerComponent* DialogueManager = PlayerControllerBase->GetDialogueManager())
								{
									DialogueManager->AddNewDialogueConversation(PickedUpItemDialogueConversation);
								}
							}
						}
					}
				}
			}
		}
	}
}

void AANPickableItem::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (InteractingCharacter)
	{
		IANInteractable::EndInteract(InteractingCharacter);
	}
	this->Destroy();
}

bool AANPickableItem::IsLongInteract() const
{
	return false; //Pickups are instant, they should never be long interacts
}

bool AANPickableItem::IsInteracting() const
{
	return false; //Only relevant for long interacts
}

void AANPickableItem::OnCDBBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		MainMeshComponent->bRenderCustomDepth = true;
		MainMeshComponent->MarkRenderStateDirty();
		OnRenderCustomDepthEnabled();
	}
}

void AANPickableItem::OnCDBEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		MainMeshComponent->bRenderCustomDepth = false;
		MainMeshComponent->MarkRenderStateDirty();
		OnRenderCustomDepthDisabled();
	}
}
