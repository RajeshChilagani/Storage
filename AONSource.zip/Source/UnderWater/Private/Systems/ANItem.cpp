// Fill out your copyright notice in the Description page of Project Settings.

//#include "Systems/ANItem.h"
#include "Game/ANGameInstance.h"
#include "Systems/ANInventorySystem.h"
#include <Engine.h>


static UANInventorySystem* IS=nullptr;

void SetInventorySystem()
{
	auto World = GEngine->GetWorld();
	if (World)
	{
		auto GameInstance = World->GetGameInstance();
		if (GameInstance)
		{
			auto ANGameInstance = Cast<UANGameInstance>(GameInstance);
			if (ANGameInstance)
			{
				IS = ANGameInstance->m_InventorySystem;
			}
		}
	}
}

	