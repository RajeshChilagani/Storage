// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/ANMainMenuGameMode.h"

#include "Game/ANGameInstance.h"

AANMainMenuGameMode::AANMainMenuGameMode()
	: Super()
{

}

void AANMainMenuGameMode::BeginPlay()
{
	Super::BeginPlay();

	CreateHUD();

	//If we reached the main menu, we are in the standard game flow.
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		GameInstance->SetStandardGameFlow(true);
	}
}

void AANMainMenuGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}