// �2021 Abyssmal Games and Synodic Arc

#include "Game/ANGameInstance.h"

//#include "AutomationBlueprintFunctionLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Scalability.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANExplorationGameMode.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "SaveGame/ANGameUserSettings.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"
#include "Systems/ANCraftingSystem.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/HUD/ANMessagesHUDWidget.h"
#include "Utils/ANNumLockRandomizer.h"

void UANGameInstance::Init()
{
	Super::Init();

	m_InventorySystem = NewObject<UANInventorySystem>();
	m_CraftingSystem  = NewObject<UANCraftingSystem>();
	m_CraftingSystem->Init(m_InventorySystem);
	//Create NewRandomizer
	NumLockRandomizer = NewObject<UANNumLockRandomizer>();

	//Make sure saving is enabled by default
	bSavingEnabled = true;

	//On startup, load the gameplay save game
	if (LoadGameplaySaveGame())
	{
		//we're good!
	}
	//or create one if it doesn't exist
	else
	{
		CreateGameplaySaveGame(EANDifficultyLevels::Normal);
	}

	//Initialize a few necessary things
	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		UANFunctionLibrary::SetColorDeficiency(ANGameUserSettings->GetColorDeficiencyMode(), 0.75f, true, false);

		//Setting to off for now until I figure this out the right way
		//Scalability::FQualityLevels Quality;
		//Quality.SetFromSingleQualityLevelRelativeToMax(ANGameUserSettings->GetQualityLevel());
		//Scalability::SetQualityLevels(Quality, true);

		//UAutomationBlueprintFunctionLibrary::SetScalabilityQualityLevelRelativeToMax(nullptr, ANGameUserSettings->GetQualityLevel());
	}

	BP_Init();
}

void UANGameInstance::Shutdown()
{
	Super::Shutdown();
}

void UANGameInstance::ClearInventory()
{
	m_InventorySystem = NewObject<UANInventorySystem>();
}

void UANGameInstance::FadeInLoadingScreen_Implementation(AANPlayerControllerBase* PlayerControllerBase, float FadeTime = 0.5f)
{

}

void UANGameInstance::FadeOutLoadingScreen_Implementation(AANPlayerControllerBase* PlayerControllerBase, float FadeTime = 0.5f)
{

}

void UANGameInstance::LoadLastCheckpoint(UObject* WorldContextObject)
{
	//If we don't have a save game with valid data, start from the beginning
	if (ActiveGameplaySaveGame == nullptr)// || ActiveGameplaySaveGame->)
	{
		//Try to create a gameplay save game, but if we fail, do nothing
		if (!CreateGameplaySaveGame(EANDifficultyLevels::Normal))
		{
			Print("Could not create a gameplay save game when trying to reload the last checkpoint");
			return;
		}
	}

	//TODO: probably need special logic here to know which map to load into after loading GameWorld_P. For now, let's just load the tutorial every time for testing
	UGameplayStatics::OpenLevel(WorldContextObject, LevelNames::GameWorld_P);
}

bool UANGameInstance::CreateGameplaySaveGame(EANDifficultyLevels DifficultyLevel)
{
	if (UANGameplaySaveGame* NewGameplaySaveGame = Cast<UANGameplaySaveGame>(UGameplayStatics::CreateSaveGameObject(UANGameplaySaveGame::StaticClass())))
	{
		ClearInventory(); //Make sure to clear the inventory system before creating a new save game
		ActiveGameplaySaveGame = NewGameplaySaveGame;
		ActiveGameplaySaveGame->InitializeDefaultValues(DifficultyLevel);
		return true;
	}

	UE_LOG(LogTemp, Warning, TEXT("Could not create gameplay save game."));
	return false;
}

bool UANGameInstance::LoadGameplaySaveGame()
{
	if (UANGameplaySaveGame* LoadedGameplaySaveGame = Cast<UANGameplaySaveGame>(UGameplayStatics::LoadGameFromSlot(SaveSlots::GameplaySaveGame, 0)))
	{
		ActiveGameplaySaveGame = LoadedGameplaySaveGame;
		return true;
	}

	UE_LOG(LogTemp, Warning, TEXT("Could not load gameplay save game."));
	return false;
}

bool UANGameInstance::SaveGameplaySaveGame(UObject* WorldContextObject)
{
	if (WorldContextObject == nullptr)
	{
		UE_LOG(LogTemp, Warning, TEXT("Empty world context object - could not save gameplay save game."));
		return false;
	}

	//If saving is disabled, don't write to slot
	if (!bSavingEnabled)
	{
		UE_LOG(LogTemp, Warning, TEXT("Tried to save while saving was disabled."));
		return false;
	}

	if (ActiveGameplaySaveGame != nullptr)
	{
		//Set started state
		ActiveGameplaySaveGame->SetStarted(true);

		//Set player health
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(UGameplayStatics::GetPlayerPawn(WorldContextObject, 0)))
		{
			ActiveGameplaySaveGame->SetSavedAtHealth(MainCharacter->GetCurrentHealth());
		}

		//Set gameplay time
		if (AANExplorationGameMode* ExplorationGameMode = Cast<AANExplorationGameMode>(UGameplayStatics::GetGameMode(WorldContextObject)))
		{
			ActiveGameplaySaveGame->SetGameplayTime(ExplorationGameMode->GetGameplayTime());
		}

		//Set inventory items
		if (m_InventorySystem != nullptr)
		{
			ActiveGameplaySaveGame->ClearSavedItems();
			const TMap<FString, int32>& ItemsMap = m_InventorySystem->GetItemsMap();
			for (const TPair<FString, int32>& Pair : ItemsMap)
			{
				ActiveGameplaySaveGame->AddSavedItem(Pair.Key, Pair.Value);
			}
		}

		if (UGameplayStatics::SaveGameToSlot(ActiveGameplaySaveGame, SaveSlots::GameplaySaveGame, 0))
		{
			if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(GetFirstLocalPlayerController()))
			{
				if (UANMessagesHUDWidget* MessagesHUDWidget = PlayerControllerBase->GetMessagesHUDWidget())
				{
					MessagesHUDWidget->BP_AddCheckpointMessage();
				}
			}
			return true;
		}
	}


	UE_LOG(LogTemp, Warning, TEXT("Could not save gameplay save game."));
	return false;
}

bool UANGameInstance::DeleteGameplaySaveGame()
{
	if (UGameplayStatics::DeleteGameInSlot(SaveSlots::GameplaySaveGame, 0))
	{
		return true;
	}

	UE_LOG(LogTemp, Warning, TEXT("Could not delete gameplay save game."));
	return false;
}

//Reference code
//if (UZhengSaveGame* loadedGame = Cast<UZhengSaveGame>(UGameplayStatics::LoadGameFromSlot("ZhengPlayerSettingsSave", 0)))
//{
//	// The operation was successful, so loadedGame now contains the data we saved earlier
//	SaveGameRef = loadedGame;
//
//	if (APlayerController* playerController = Cast<APlayerController>(GetFirstLocalPlayerController()))
//	{
//		if (playerController->PlayerState)
//		{
//			FString playerNameString = playerController->PlayerState->GetPlayerName();
//			SaveGameRef->S_ZhengPlayerInfo.PlayerName = FText::FromString(playerNameString);
//		}
//	}
//
//	//UE_LOG(LogTemp, Warning, TEXT("LOADED: %s"), *LoadedGame->PlayerName);
//	print("Load complete!");
//	return true;
//}
//else
//{
//	print("Unable to load game.");
//	return false;
//}