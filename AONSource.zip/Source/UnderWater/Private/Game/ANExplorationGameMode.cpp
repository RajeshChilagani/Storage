// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/ANExplorationGameMode.h"

#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Character/ANMainCharacter.h"
#include "Character/ANPersistentCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Interface/ANWorldSaveable.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"

AANExplorationGameMode::AANExplorationGameMode()
	: Super()
{
	PrimaryActorTick.bCanEverTick = true;

	GameplayTime = 0.0f;
}

void AANExplorationGameMode::BeginPlay()
{
	Super::BeginPlay();

	UANGameplaySaveGame* GameplaySaveGame = nullptr;
	UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance());
	if (GameInstance == nullptr)
	{
		return;
	}

	//Clear our inventory before we begin play, it will be set in the SetupWorld function
	GameInstance->ClearInventory();

	//Load our gameplay save game
	GameInstance->LoadGameplaySaveGame();

	//Once loaded, get the active gameplay save game
	GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame();

	//Find the last level the player saved in
	EANLevels SavedAtLevel = EANLevels::Tutorial;
	if (GameplaySaveGame != nullptr)
	{
		SavedAtLevel = GameplaySaveGame->GetSavedAtLevel();
	}
	LoadSavedAtLevel(SavedAtLevel);

	//If we're in a standard game flow, set the player's position too
	if (GameInstance->IsStandardGameFlow())
	{
		if (GameplaySaveGame != nullptr)
		{
			if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(UGameplayStatics::GetPlayerPawn(this, 0)))
			{
				MainCharacter->TeleportTo(GameplaySaveGame->GetSavedAtTransform().GetLocation(), FRotator(0.0f, 0.0f, 0.0f));
				if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MainCharacter->GetController()))
				{
					PlayerControllerBase->SetControlRotation(GameplaySaveGame->GetSavedAtTransform().GetRotation().Rotator());
				}
			}
		}
	}

	//Create the HUD
	CreateHUD();

	//Update the world and give items to the player's HUD from saved data
	SetupWorldForSaveGame(GameplaySaveGame);
}

void AANExplorationGameMode::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	GameplayTime += DeltaTime;
}

void AANExplorationGameMode::LoadSharedLevels()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	TArray<FName> SublevelNames = UANFunctionLibrary::GetSharedSublevelNames();

	bool bLoadingLevels = true;

	for (int i = 0; i < SublevelNames.Num(); i++)
	{
		FLatentActionInfo LatentInfo;
		LatentInfo.UUID = i;
		UGameplayStatics::LoadStreamLevel(MyWorld, SublevelNames[i], true, true, LatentInfo);
	}

	bLoadingLevels = false;
}

void AANExplorationGameMode::LoadSavedAtLevel(EANLevels SavedAtLevel)
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	TArray<FName> SharedSublevelNames = UANFunctionLibrary::GetSharedSublevelNames();
	TArray<FName> SublevelNames = UANFunctionLibrary::GetSublevelNamesForLevel(SavedAtLevel);

	SublevelNames.Append(SharedSublevelNames);

	bool bLoadingLevels = true;

	for (int i = 0; i < SublevelNames.Num(); i++)
	{
		FLatentActionInfo LatentInfo;
		LatentInfo.UUID = i;
		UGameplayStatics::LoadStreamLevel(MyWorld, SublevelNames[i], true, true, LatentInfo);
	}

	bLoadingLevels = false;
}

void AANExplorationGameMode::SetupWorldForSaveGame(UANGameplaySaveGame* LoadedGameplaySaveGame)
{
	if (LoadedGameplaySaveGame == nullptr)
	{
		Print("No save game was available to set up the world.");
		return;
	}

	UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance());
	if (GameInstance == nullptr)
	{
		Print("No game instance found.");
		return;
	}

	//Before initializing everything, disable saving
	GameInstance->SetSavingEnabled(false);

	//Get gameplay time
	GameplayTime = LoadedGameplaySaveGame->GetGameplayTime();

	//Add items to the inventory
	const TMap<FString, int32> SavedItemsMap = LoadedGameplaySaveGame->GetSavedItemsMap();
	for (const TPair<FString, int32>& Pair : SavedItemsMap)
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			InventorySystem->AddItem(Pair.Key, Pair.Value, EAddItemMethods::Other);
		}
	}

	UWorld* MyWorld = GetWorld();

	if (MyWorld != nullptr)
	{
		//Spawn world saveables
		const TMap<FGuid, FWorldSaveableData> WorldSaveablesMap = LoadedGameplaySaveGame->GetWorldSaveableDatasMap();
		for (const TPair<FGuid, FWorldSaveableData>& Pair : WorldSaveablesMap)
		{
			const FWorldSaveableData& WorldSaveableData = Pair.Value;
			if (WorldSaveableData.WorldSaveableClass == nullptr)
			{
				continue;
			}

			AActor* SpawnedActor = MyWorld->SpawnActorDeferred<AActor>(WorldSaveableData.WorldSaveableClass, WorldSaveableData.WorldSaveableTransform, nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn);
			if (IANWorldSaveable* ActorAsWorldSaveable = Cast<IANWorldSaveable>(SpawnedActor))
			{
				ActorAsWorldSaveable->InitializeWorldSaveableObject(Pair.Key, Pair.Value);
			}
			SpawnedActor->FinishSpawning(WorldSaveableData.WorldSaveableTransform);
		}
	}


	//Update main character as needed
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(UGameplayStatics::GetPlayerPawn(this, 0)))
	{
		//Set infinite oxygen based on if we've finished the tutorial or not
		bool bUseInfiniteOxygen = true;
		bool bTutorialFinished = false;
		LoadedGameplaySaveGame->GetSaveableBoolValue(SaveableBoolNames::bTutorialFinished, bTutorialFinished);
		if (bTutorialFinished)
		{
			bUseInfiniteOxygen = false;
		}
		else
		{
			bUseInfiniteOxygen = true;
		}
		MainCharacter->SetInfiniteOxygen(bUseInfiniteOxygen);

		MainCharacter->SetHealth(LoadedGameplaySaveGame->GetSavedAtHealth());

		//Set harpoon gun status
		bool bHasHarpoonGun = false;
		LoadedGameplaySaveGame->GetSaveableBoolValue(SaveableBoolNames::bHasHarpoonGun, bHasHarpoonGun);
		MainCharacter->SetHasHarpoonGun(bHasHarpoonGun);
	}

	//Do a delayed world setup for anything that can't be done right now, like initializing the baddy since he might not be spawned in yet
	FTimerHandle TempTimerHandle;
	MyWorld->GetTimerManager().SetTimer(TempTimerHandle, this, &AANExplorationGameMode::DelayedSetupWorldForSaveGame, 3.0f);

	//After initializing everything, set saving back to valid
	GameInstance->SetSavingEnabled(true);
}

void AANExplorationGameMode::DelayedSetupWorldForSaveGame()
{
	UANGameplaySaveGame* GameplaySaveGame = nullptr;
	UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance());
	if (GameInstance == nullptr)
	{
		return;
	}

	GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame();
	if (GameplaySaveGame == nullptr)
	{
		return;
	}

	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	bool bBaddySpawningEnabled = false;
	GameplaySaveGame->GetSaveableBoolValue(SaveableBoolNames::bBaddySpawningEnabled, bBaddySpawningEnabled);
	if (bBaddySpawningEnabled)
	{
		//Enable spawning on the persistent character
		for (TActorIterator<AANPersistentCharacter> it(MyWorld); it; ++it)
		{
			AANPersistentCharacter* PersistentCharacter = *it;
			if (PersistentCharacter == nullptr)
			{
				continue;
			}

			PersistentCharacter->bEnableBaddySpawning = true;
			PersistentCharacter->BP_Spawn(FVector::ZeroVector, FRotator::ZeroRotator);
		}
	}
}