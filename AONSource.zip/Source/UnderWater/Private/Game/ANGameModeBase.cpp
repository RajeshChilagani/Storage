// Fill out your copyright notice in the Description page of Project Settings.


#include "Game/ANGameModeBase.h"

#include "EngineUtils.h"
#include "Engine/World.h"

#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"

AANGameModeBase::AANGameModeBase()
{
	DefaultPawnClass = nullptr;

	bPausableMode = false;
}

void AANGameModeBase::BeginPlay()
{
	Super::BeginPlay();

	//Set the pausable value based on game mode
	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		TPlayerControllerIterator<AANPlayerControllerBase>::LocalOnly It(MyWorld);
		if (It)
		{
			It->SetInPausableMode(bPausableMode);
		}

		//for (FConstPlayerControllerIterator It = pWorld->GetPlayerControllerIterator(); It; ++It)
		//{
		//	APlayerController* PlayerController = (*It).Get();
		//	if (PlayerController != nullptr && PlayerController->IsLocalPlayerController())
		//	{
		//		return PlayerController;
		//	}
		//}

		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (AANPlayerControllerBase* FirstPlayerController = Cast<AANPlayerControllerBase>(MyWorld->GetFirstPlayerController()))
			{
				GameInstance->FadeOutLoadingScreen(FirstPlayerController);
			}
		}
	}
}

void AANGameModeBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANGameModeBase::CreateHUD()
{
	if (UWorld* MyWorld = GetWorld())
	{
		if (AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(MyWorld->GetFirstPlayerController()))
		{
			PlayerController->Client_CreateHUD();
		}
	}
}