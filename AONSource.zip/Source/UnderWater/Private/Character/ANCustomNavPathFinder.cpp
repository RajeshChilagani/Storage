// 2021 Abyssmal Games and Synodic Arc


#include "Character/ANCustomNavPathFinder.h"
#include "ANDefines.h"
#include "AI/Helpers/ANSecondaryAINavRoom.h"
#include "Components/BoxComponent.h"



AANCustomNavPathFinder::AANCustomNavPathFinder(FVector startPoint, FVector endPoint,
	TMap<FVector, FNavMeshData> NavData, FIntVector gridSize, FVector origin): StartPoint(startPoint),
EndPoint(endPoint),NavPoints(NavData),NavRegionBeginLocation(origin),GridSize(gridSize)
{
}

uint32 AANCustomNavPathFinder::Run()
{
	bStopThread = false;
	bIsPathFindingComplete = false;
	while (!bStopThread && !bIsPathFindingComplete)
	{

		//first check if the navpoint has some points in them
		if (NavPoints.Num() > 0)
		{
			StartPoint = GetNavPointIndexFromLocation(StartPoint);
			EndPoint = GetNavPointIndexFromLocation(EndPoint);

			if (IsPointValid(StartPoint) && IsPointValid(EndPoint))
			{
				NavPoints[StartPoint].bIsFree = true;
			}
			else
			{
				TArray<FVector> EmptyPath;
				//Print("failed here check starting point!!! or ending point");
				FoundPath = EmptyPath;
				bIsPathFindingComplete = true;
				return 0;
			}

			TArray<FNodeRecord> OpenList;
			TArray<FNodeRecord> ClosedList;
			TArray<FVector> Path;

			//First node so we just set everything to 0 
			//NavPoints[StartPoint].bIsFree = true;
			//NavPoints[StartPoint].cost = 0;
			//NavPoints[StartPoint].functionValue = 0;
			//NavPoints[StartPoint].PreviousNode = FVector(-1,-1,-1);

			//Add the first node to the openlist;
			OpenList.Emplace(StartPoint);

			while (OpenList.Num() > 0)
			{

				//TODO: Possible optimization with PQueue. to avoid this for loop
				//to find the lowest 
				int winner = 0;
				for (int i = 0; i < OpenList.Num(); i++)
				{
					if (OpenList[i].functionCost < OpenList[winner].functionCost)
					{
						winner = i;
					}
				}



				FNodeRecord currentNode = OpenList[winner];

				if (currentNode.ID == EndPoint)
				{
					//build the path to return here.
					if (Path.Num() > 0)
					{
						Path.Empty();
					}
					FNodeRecord temp = currentNode;

					while (IsPointValid(temp.ID) && temp.ID != StartPoint)
					{
						Path.Emplace(temp.ID);

						FNodeRecord Previous;
						Previous.ID = temp.PreviousID;
						FNodeRecord* predicateValue = ClosedList.FindByPredicate([Previous](FNodeRecord NodeRecord) {return NodeRecord == Previous; });
						if (predicateValue != nullptr)
						{
							temp = *predicateValue;
						}

					}
					Path.Emplace(StartPoint);
					Algo::Reverse(Path);
					FoundPath = Path;
					bIsPathFindingComplete = true;
					return  0;

				}


				OpenList.Remove(currentNode);
				ClosedList.Emplace(currentNode);
				auto neighbors = NavPoints[currentNode.ID].NeighborsList;

				for (auto Element : neighbors)
				{


					FNodeRecord tempNode;
					tempNode.Cost = 0;
					tempNode.ID = Element;
					if (!ClosedList.Contains(Element) && NavPoints[Element].bIsFree)
					{
						tempNode.Cost = currentNode.Cost + NavPoints[Element].cost;
						if (OpenList.Contains(Element))
						{

							FNodeRecord* FNodeRecordRef = OpenList.FindByPredicate([tempNode](FNodeRecord NodeRecord) {return (tempNode == NodeRecord); });
							if (tempNode.Cost < FNodeRecordRef->Cost)
							{

								OpenList.Remove(FNodeRecordRef->ID);
							}
							else
								continue;
						}
						//Currently using a manhattan distance.

						tempNode.Heuristics = { abs(NavPoints[Element].BoxComponent->GetComponentToWorld().GetLocation().X - NavPoints[EndPoint].BoxComponent->GetComponentToWorld().GetLocation().X) +
												abs(NavPoints[Element].BoxComponent->GetComponentToWorld().GetLocation().Y - NavPoints[EndPoint].BoxComponent->GetComponentToWorld().GetLocation().Y) +
												abs(NavPoints[Element].BoxComponent->GetComponentToWorld().GetLocation().Z - NavPoints[EndPoint].BoxComponent->GetComponentToWorld().GetLocation().Z) };
						tempNode.functionCost = tempNode.Heuristics + tempNode.Cost;
						tempNode.PreviousID = currentNode.ID;

						OpenList.Emplace(tempNode);

					}

				}
			}
			///Failed to find a path here.
			TArray<FVector> EmptyPath;
			bIsPathFindingComplete = true;
			FoundPath = EmptyPath;
			return 0;
		}

		///Failed to find a path here.
		TArray<FVector> EmptyPath;
		FoundPath = EmptyPath;
		bIsPathFindingComplete = true;
		return 0;
	}
	TArray<FVector> EmptyPath;
	FoundPath = EmptyPath;
	bIsPathFindingComplete = true;
	return 0;
}


void AANCustomNavPathFinder::Stop()
{
	
	
}

void AANCustomNavPathFinder::Exit()
{
	//Print("Closed a thread");
}

TArray<FVector> AANCustomNavPathFinder::GetPath() const
{
	return FoundPath;
}

bool AANCustomNavPathFinder::IsPathFindingComplete() const
{
	return bIsPathFindingComplete;
}

void AANCustomNavPathFinder::StopThread()
{
	bStopThread = true;
}

FVector AANCustomNavPathFinder::GetNavPointIndexFromLocation(FVector Location)
{
	if (NavPoints.Num() > 0)
	{
		const FVector NavPointExtents = FVector(GridSize);
		const FVector Distance = Location - (NavRegionBeginLocation);

		FVector comLoc = NavPoints[FVector(0, 0, 0)].BoxComponent->GetComponentToWorld().GetLocation();

		const int IndexX = Distance.X / (NavPointExtents.X * 2);
		const int IndexY = Distance.Y / (NavPointExtents.Y * 2);
		const int IndexZ = Distance.Z / (NavPointExtents.Z * 2);

		return FVector(IndexX, IndexY, IndexZ);
	}
	return FVector(-1, -1, -1);
	//}
	return FVector(-1, -1, -1);
}

bool AANCustomNavPathFinder::IsPointValid(FVector Point) const
{
	return NavPoints.Contains(Point);
}



//This BFS
	//if (NavPoints.Num() > 0)
	//{

	//	StartPoint = GetNavPointIndexFromLocation(StartPoint);
	//	EndPoint = GetNavPointIndexFromLocation(EndPoint);

	//	if (IsPointValid(StartPoint) && IsPointValid(EndPoint))
	//	{
	//		NavPoints[StartPoint].bIsFree = true;
	//	}
	//	else
	//	{
	//		TArray<FVector> EmptyPath;
	//		FoundPath = EmptyPath;
	//		bIsPathFindingComplete = true;
	//		return 0;
	//		//Print("failed here check starting point!!! or ending point");
	//	}
	//	TSet<FVector> ExploredPoint;
	//	TArray<FVector> Path = { StartPoint };
	//	TArray<TArray<FVector>> Queue = { Path };

	//	while (Queue.Num() > 0)
	//	{

	//		Path = Queue[0];
	//		Queue.RemoveAt(0);
	//		FVector LastPoint = Path.Last(0);
	//		if (LastPoint == EndPoint)
	//		{
	//			FoundPath = Path;
	//			bIsPathFindingComplete = true;
	//			return 0;
	//		}
	//		//Get all faces
	//		else if (!ExploredPoint.Contains(LastPoint) && IsPointValid(LastPoint) && NavPoints[LastPoint].bIsFree)
	//		{

	//			//TODO Compute diagonals
	//			FVector Diagonal_one = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z);
	//			FVector Diagonal_two = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z);
	//			FVector Diagonal_three = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z);
	//			FVector Diagonal_four = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z);

	//			FVector Diagonal_five = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z + 1);
	//			FVector Diagonal_six = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z - 1);
	//			FVector Diagonal_seven = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z - 1);
	//			FVector Diagonal_eight = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z + 1);

	//			FVector Diagonal_nine = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z + 1);
	//			FVector Diagonal_one_one = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z - 1);
	//			FVector Diagonal_one_two = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z - 1);
	//			FVector Diagonal_one_three = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z + 1);

	//			FVector Diagonal_one_four = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z + 1);
	//			FVector Diagonal_one_seven = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z - 1);
	//			FVector Diagonal_one_five = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z - 1);
	//			FVector Diagonal_one_one_one = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z + 1);
	//			FVector Diagonal_one_six = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z - 1);
	//			FVector Diagonal_one_one_two = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z + 1);
	//			FVector Diagonal_one_nine = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z - 1);
	//			FVector Diagonal_one_eight = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z + 1);



	//			FVector Left = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z);
	//			FVector Right = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z);
	//			FVector Top = FVector(LastPoint.X, LastPoint.Y, LastPoint.Z + 1);
	//			FVector Bottom = FVector(LastPoint.X, LastPoint.Y, LastPoint.Z - 1);
	//			FVector Forward = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z);
	//			FVector Backward = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z);


	//			TArray<FVector> AdjList = { Left, Right, Top,Bottom, Forward,Backward };

	//			AdjList.Add(Diagonal_one);
	//			AdjList.Add(Diagonal_two);
	//			AdjList.Add(Diagonal_three);
	//			AdjList.Add(Diagonal_four);
	//			AdjList.Add(Diagonal_five);
	//			AdjList.Add(Diagonal_six);
	//			AdjList.Add(Diagonal_seven);
	//			AdjList.Add(Diagonal_eight);
	//			AdjList.Add(Diagonal_nine);
	//			AdjList.Add(Diagonal_one_one);
	//			AdjList.Add(Diagonal_one_two);
	//			AdjList.Add(Diagonal_one_three);
	//			AdjList.Add(Diagonal_one_four);
	//			AdjList.Add(Diagonal_one_five);
	//			AdjList.Add(Diagonal_one_six);
	//			AdjList.Add(Diagonal_one_seven);
	//			AdjList.Add(Diagonal_one_one_two);
	//			AdjList.Add(Diagonal_one_eight);
	//			AdjList.Add(Diagonal_one_nine);
	//			AdjList.Add(Diagonal_one_one_one);






	//			for (int i = 0; i < AdjList.Num(); i++)
	//			{
	//				if (!ExploredPoint.Contains(AdjList[i]))
	//				{
	//					TArray<FVector> NewPath = { Path };
	//					NewPath.Add(AdjList[i]);
	//					Queue.Add(NewPath);

	//				}
	//			}
	//			ExploredPoint.Add(LastPoint);
	//		}

	//	}
	//	//Failed
	//	Path.Empty();
	//	FoundPath = Path;
	//	bIsPathFindingComplete = true;
	//	return 0;
	//}
	//TArray<FVector> EmptyPath;
	//FoundPath = EmptyPath;
	//bIsPathFindingComplete = true;