// Fill out your copyright notice in the Description page of Project Settings.

#include "Character/ANSecondaryEnemy.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "AI/ANAISpawnTriggerBox.h"
#include "AI/Helpers/ANSecondaryAINavRoom.h"
#include "Character/ANMainCharacter.h"
#include "Game/ANGameInstance.h"
#include "Shared/ANFunctionLibrary.h"
#include "SaveGame/ANGameplaySaveGame.h"

AANSecondaryEnemy::AANSecondaryEnemy()
	: Super()
{
	PrimaryActorTick.bCanEverTick = true;

	EnemyAkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("EnemyAkComponent"));
	EnemyAkComponent->SetupAttachment(RootComponent);
}

void AANSecondaryEnemy::BeginPlay()
{
	Super::BeginPlay();

	GetCharacterMovement()->MaxSwimSpeed = Speed;
	TargetLocation = FVector(-1,-1,-1);

	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		MyWorld->GetTimerManager().SetTimer(CustomTickTimerHandle, this, &AANSecondaryEnemy::CustomTick, 0.5f, true);
	}

	if (EnemyAkComponent != nullptr && PersistentSFX != nullptr)
	{
		EnemyAkComponent->PostAkEvent(PersistentSFX, 0, FOnAkPostEventCallback(), FString());
	}
	ChaseSpeed = Speed * PlayerChaseSpeedMultiplier;
	RunAwaySpeed = Speed * RunAwaySpeedMultiplier;
	NormalSpeed = Speed;

	//If we don't have a Guid at begin play, make one
	if (!WorldSaveableGuid.IsValid())
	{
		WorldSaveableGuid = FGuid::NewGuid();
	}
	else
	{
		//If we did have a pre-existing Guid, find the spawn source for it and assign data that way (but do so after a delay due to race conditions)
		FTimerHandle TempTimerHandle;
		MyWorld->GetTimerManager().SetTimer(TempTimerHandle, this, &AANSecondaryEnemy::AssignSpawnDataAfterDelay, 3.0f);
	}

	//If we can add this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

void AANSecondaryEnemy::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	AI_Tick();
	CustomMovementWhenAttacking();
}

void AANSecondaryEnemy::TakeDamage(float Amount)
{
	Health -= Amount;

	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr && BloodVFX != nullptr)
	{
		UGameplayStatics::SpawnEmitterAtLocation(MyWorld, BloodVFX, GetActorLocation());
	}

	if (Health < 1)
	{
		Health = 0;
		OnDeath();
	}
	else
	{
		//Only update saveable state if not at full health after taking damage, because we will remove it on death
		UpdateWorldSaveableState();
	}
}

void AANSecondaryEnemy::OnDeath()
{
	bIsAlive = false;
	Death.Broadcast();
	if (EnemyAkComponent != nullptr && DieSFX != nullptr)
	{
		EnemyAkComponent->PostAkEvent(DieSFX, 0, FOnAkPostEventCallback(), FString());
	}

	//Remove from world saveables map when picked up
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			GameplaySaveGame->RemoveWorldSaveable(WorldSaveableGuid);
		}
	}
}

AANSecondaryAINavRoom* AANSecondaryEnemy::GetClosestRoomDataNav() const
{
	float ShortestDistance = 999999.9f;
	AANSecondaryAINavRoom* ClosestDataRoomNav = nullptr;

	//Ensure we don't have the same Guid anywhere else
	for (TActorIterator<AANSecondaryAINavRoom> it(GetWorld()); it; ++it)
	{
		float Distance = FVector::Dist(GetActorLocation(), it->GetActorLocation());
		if (Distance < ShortestDistance)
		{
			ShortestDistance = Distance;
			ClosestDataRoomNav = *it;
		}
	}

	return ClosestDataRoomNav;
}

void AANSecondaryEnemy::AssignSpawnDataAfterDelay()
{
	if (AANAISpawnTriggerBox* SpawnSourceTriggerBox = GetSpawnSourceTriggerBox())
	{
		AssignSpawnData(SpawnSourceTriggerBox->SpawnSettings);
	}
}

AANAISpawnTriggerBox* AANSecondaryEnemy::GetSpawnSourceTriggerBox() const
{
	//Find the Guid that matches the spawn source Guid
	for (TActorIterator<AANAISpawnTriggerBox> it(GetWorld()); it; ++it)
	{
		if (it->GetSaveableGuid() == SpawnSourceGuid)
		{
			return *it;
		}
	}

	return nullptr;
}

void AANSecondaryEnemy::AssignSpawnData(const FAISpawnSettings& NewAISpawnSettings)
{
	Speed = NewAISpawnSettings.Speed;
	RunAwaySpeedMultiplier = NewAISpawnSettings.Speed;
	PlayerChaseSpeedMultiplier = NewAISpawnSettings.PlayerChaseSpeedMultiplier;
	WaitTimeWhenChasingPlayer = NewAISpawnSettings.WaitTimeWhenChasingPlayer;
	CustomPoints = NewAISpawnSettings.CustomPoints;
	RoomDataNav = NewAISpawnSettings.ANNavRoom;
	MinDistanceToActivate = NewAISpawnSettings.MinDistanceToActivate;
}

void AANSecondaryEnemy::SetSpawnSourceGuid(const FGuid& NewSpawnSourceGuid)
{
	SpawnSourceGuid = NewSpawnSourceGuid;
}

bool AANSecondaryEnemy::HasPathToPlayer() const
{
	if(CurrentAnimState == ESecondaryEnemyState::Attack && LockedTarget)
	{

		auto Location = LockedTarget->GetActorLocation();
		if (RoomDataNav->IsPointValid(RoomDataNav->GetNavPointIndexFromLocation(Location)))
		{
			const TArray<FVector> HasPath = RoomDataNav->GenerateAStarPath(GetActorLocation(), Location);
			if(HasPath.Num()>0)
			{
				return true;
			}
		}
		else
		{
			return false;
		}
		
	}
	return false;
}

bool AANSecondaryEnemy::HasReachedTarget(FVector Location)
{
	return false;
}

bool AANSecondaryEnemy::MoveToLocation(FVector Location, float Radius)
{
	ActorToMove = nullptr;
	if (Location == TargetLocation)
	{
		//Print_1("Reached!!!! %d", bHasReachedFinalLocation);
		bNeedsToMove = true;
		if(bHasReachedFinalLocation)
		{
			TargetLocation = FVector(-1, -1, -1);
			if (Path.Num() > 0)
				Path.Empty();

			bHasPath = false;
			bNeedsToMove = false;
		}
		return  bHasReachedFinalLocation;
	}
	TargetLocation = Location;
	M_Radius = Radius;
	bNeedsToMove = true;
	bHasReachedFinalLocation = false;
	return false;
}

bool AANSecondaryEnemy::MoveToActor(AActor* Target, float Radius,float UpdateRate)
{
	if(Target == nullptr)
	{
		ActorToMove = Target;
		bNeedsToMove = false;
		bHasReachedFinalLocation = true;
		bHasPath = false;
		if(Path.Num()>0)
		{
			Path.Empty();
		}
		return true;
	}

	if(ActorToMove == Target)
	{
		//Print_1("Reached!!!! %d", bHasReachedFinalLocation);
		bNeedsToMove = true;
		if (bHasReachedFinalLocation)
		{
			TargetLocation = FVector(-1, -1, -1);
			if (Path.Num() > 0)
				Path.Empty();
			ActorToMove = nullptr;
			bHasPath = false;
			bNeedsToMove = false;
		}
		return  bHasReachedFinalLocation;
	}
	ActorToMove = Target;
	TargetLocation = Target->GetActorLocation();
	M_Radius = Radius;
	bNeedsToMove = true;
	bHasReachedFinalLocation = false;
	return false;
}


FVector AANSecondaryEnemy::FindRandomPointInNavMesh()
{
	if (RoomDataNav)
		return RoomDataNav->FindRandomPoint();

	else
	{
		//Print("Check the AI, it doesn't have a nav room data, placed some random ai in map somewhere?")
		return FVector(-1,-1,-1);
	}

}

void AANSecondaryEnemy::AI_Tick()
{

	if(CurrentAnimState == ESecondaryEnemyState::MoveRandomly)
	{
		Speed = NormalSpeed;
	}
	if(bNeedsToMove && RoomDataNav->IsPointValid(RoomDataNav->GetNavPointIndexFromLocation(TargetLocation)))
		MoveToLocationTick(TargetLocation, M_Radius);
	else
	{
		bHasReachedFinalLocation = true;
		ActorToMove = nullptr;
	}
}

void AANSecondaryEnemy::CustomTick()
{
	if (ActorToMove)
	{
		TargetLocation = ActorToMove->GetActorLocation();
		if (RoomDataNav->IsPointValid(RoomDataNav->GetNavPointIndexFromLocation(TargetLocation)))
		{
			bHasPath = false;
			bNeedsToMove = true;
			M_Radius = 0;
			if(Path.Num()>0)
			{
				Path.Empty();
			}
			MoveToLocationTick(TargetLocation, M_Radius);
		}
	}
}

bool AANSecondaryEnemy::MoveToLocationTick(FVector Location, float Radius)
{
	if (RoomDataNav)
	{
		if (!bHasPath && bNeedsToMove)
		{
			if(Path.Num()>0)
			{
				Path.Empty();
			}
			
			//Path = RoomDataNav->GenerateBFSPath(GetActorLocation(), Location, bShouldUseThread);
			Path = RoomDataNav->GenerateAStarPath(GetActorLocation(), Location);

			if (Path.Num() > 0)
			{
			
				PathCount = 1;
				bHasPath = true;
				if(bShowPathDebug)
				{
					for (FVector Element : Path)
					{
						if(RoomDataNav->IsPointValid(Element))
						{
							
						//FVector Location = RoomDataNav->NavPointWithDic[Element]->GetActorLocation();
						////DrawDebugSphere(GetWorld(), Location, 50, 32, FColor::Red, false, 2);
						//DrawDebugBox(GetWorld(), Location, RoomDataNav->NavPointWithDic[Element]->BoxCollisionComponent->GetScaledBoxExtent(), FColor::Red, false, 2);
							FVector debugLoc = RoomDataNav->NavPoints[Element].BoxComponent->GetComponentToWorld().GetLocation();
							//DrawDebugSphere(GetWorld(), Location, 50, 32, FColor::Red, false, 2);
							DrawDebugBox(GetWorld(), debugLoc, RoomDataNav->NavPoints[Element].BoxComponent->GetScaledBoxExtent(), FColor::Red, false, 2);
						}
					}
				}
			}
			else
			{
				//Print("Path cant be found!");
				
				OnMoveToComplete.Broadcast(false);
			}
		}
		if (bHasPath && bNeedsToMove)
		{
			/*for (FVector Element : Path)
			{
				if(RoomDataNav->IsPointValid(Element))
				{
					TArray<AActor*> Actors;
					RoomDataNav->NavPoints[Element].BoxComponent->GetOverlappingActors(Actors);
					if(Actors.Num()>1)
					{
						Path.Empty();
						bHasPath = false;
						return false;
					}
				}
				if (RoomDataNav->IsPointValid(Element) && !RoomDataNav->NavPoints[Element].bIsFree)
				{
					Path.Empty();
					bHasPath = false;
					return false;
				}
			}*/
			if(PathCount<Path.Num())
			{
				
			if (PathCount == Path.Num()-1)
			{
				Location = RoomDataNav->NavPoints[Path[PathCount]].BoxComponent->GetComponentToWorld().GetLocation();
				/*if (UKismetMathLibrary::IsPointInBox(Location, WorldRoom->GetActorLocation(),
					RoomDataNav->GetBoxExtent()))*/
				{
					
					FVector Distance = Location - GetActorLocation();
					FVector Normalized = Distance.Size() > 1 ? Distance.GetSafeNormal() : Distance;


					CurrentHeading = FMath::VInterpTo(CurrentHeading, Normalized, GetWorld()->GetDeltaSeconds(),
						TurningRate);

					if (Distance.Size() < Radius)
					{
						
						bHasReachedFinalLocation = true;
						bNeedsToMove = false;
						M_Radius = 50;
						if (Path.Num() > 0)
							Path.Empty();
						bHasPath = false;
						TargetLocation = FVector(-1,-1,-1);
						OnMoveToComplete.Broadcast(true);
						return true;
					}
					else
					{
						bNeedsToMove = true;
						
						AddMovementInput(CurrentHeading, MovementScaleValue);
					}
				}

			}
			else
			{
				Location = RoomDataNav->NavPoints[Path[PathCount]].BoxComponent->GetComponentToWorld().GetLocation();
				/*if (UKismetMathLibrary::IsPointInBox(Location, WorldRoom->GetActorLocation(),
					RoomDataNav->GetBoxExtent()))*/
				{
					//Print("IsMovingtriggerd");
					FVector Distance = Location - GetActorLocation();
					FVector Normalized = Distance.Size() > 1 ? Distance.GetSafeNormal() : Distance;


					CurrentHeading = FMath::VInterpTo(CurrentHeading, Normalized, GetWorld()->GetDeltaSeconds(),
						TurningRate);

					if (Distance.Size() < RoomDataNav->GridSize.Y * 2)
					{
						bNeedsToMove = true;
						//OnMoveToComplete.Broadcast(false);
						PathCount++;
					}
					else
					{
						bNeedsToMove = true;
					//	OnMoveToComplete.Broadcast(false);
						AddMovementInput(CurrentHeading, MovementScaleValue);
					}
				}
			}

			}
		}
	}
	else
	{
		Print_Color("enemy missing nav room data!", FColor::Red);
		return false;
	}

	return false;
}

void AANSecondaryEnemy::CustomMovementWhenAttacking()
{
	//Only when the enemy is attacking the player. 
	if(CurrentAnimState == ESecondaryEnemyState::Attack)
	{
		if (LockedTarget != nullptr)
		{
			//check if the player is close enough
			if (FVector::Distance(this->GetActorLocation(), LockedTarget->GetActorLocation()) < 400 && !bHasStoppedMoving)
			{
				bHasStoppedMoving = true;
				//reset the speed;
				Speed = ChaseSpeed / PlayerChaseSpeedMultiplier;
				MovementScaleValue = 0;
				
				ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);

				FRotator const LookAtRotation = UKismetMathLibrary::FindLookAtRotation(
					this->GetActorLocation(), Player->GetActorLocation());
				this->SetActorRotation(LookAtRotation);
				bIsWaiting = true;
				GetWorld()->GetTimerManager().SetTimer(ResetMovementTimer, this, &AANSecondaryEnemy::ResetMovementWhenAttacking, WaitTimeWhenChasingPlayer, false);

			}
			else if (FVector::Distance(this->GetActorLocation(), LockedTarget->GetActorLocation()) > 400)
			{

				Speed = ChaseSpeed;
			}
		}
	}


	
	//reset the bhasstoppedmoving bool here when the ai attacks and moves to a random location
	if( CurrentAnimState == ESecondaryEnemyState::AvoidPlayer)
	{
		bHasStoppedMoving = false;
	}
}

void AANSecondaryEnemy::ResetMovementWhenAttacking()
{
	Speed = RunAwaySpeed;
	MovementScaleValue = 1;
	bIsWaiting = false;
}


void AANSecondaryEnemy::BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
{
	WorldSaveableGuid = GuidToAssign;

	FString WorldSaveableParams = WorldSaveableDataToAssign.WorldSaveableParams;

	//Restore health
	if (WorldSaveableParams.Contains(SaveableParams::Health))
	{
		FString HealthAsString = UANFunctionLibrary::GetSaveableParamValue(WorldSaveableParams, SaveableParams::Health);
		if (!HealthAsString.IsEmpty())
		{
			int32 HealthAsInt = -1;
			HealthAsInt = FCString::Atoi(*HealthAsString);
			if (HealthAsInt > 0)
			{
				SetHealth(HealthAsInt);
			}
		}
	}
	
	//Restore spawn source guid
	if (WorldSaveableParams.Contains(SaveableParams::Guid))
	{
		FString SavedSpawnSourceGuid = UANFunctionLibrary::GetSaveableParamValue(WorldSaveableParams, SaveableParams::Guid);
		if (!SavedSpawnSourceGuid.IsEmpty())
		{
			FGuid::Parse(SavedSpawnSourceGuid, SpawnSourceGuid);
		}
	}
}

bool AANSecondaryEnemy::BP_CanSaveToWorldSaveablesMap_Implementation()
{
	//Do not allow child actors to be added/saved to the saveable map, since we have separate logic for things like item spawn points
	if (IsChildActor())
	{
		return false;
	}

	return true;
}

void AANSecondaryEnemy::BP_UpdateWorldSaveableState_Implementation()
{
	//If we can save this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

FGuid AANSecondaryEnemy::BP_GetWorldSaveableGuid_Implementation()
{
	return WorldSaveableGuid;
}

FWorldSaveableData AANSecondaryEnemy::BP_GetWorldSaveableData_Implementation()
{
	FWorldSaveableData NewWorldSaveableData;
	NewWorldSaveableData.WorldSaveableClass = GetClass();
	NewWorldSaveableData.WorldSaveableTransform = GetActorTransform();
	NewWorldSaveableData.WorldSaveableParams = ConstructSaveableParamsString();
	return NewWorldSaveableData;
}

FString AANSecondaryEnemy::BP_ConstructSaveableParamsString_Implementation()
{
	FString SaveString("");

	//Save health
	SaveString.Append(UANFunctionLibrary::MakeSaveableParam(SaveableParams::Health, FString::FromInt(Health)));

	//Save spawn source guid
	SaveString.Append(UANFunctionLibrary::MakeSaveableParam(SaveableParams::Guid, SpawnSourceGuid.ToString()));

	return SaveString;
}