// Created by Vishal Naidu (GitHub: Vieper1) | naiduvishal13@gmail.com | Vishal.Naidu@utah.edu

#include "Character/ANMainCharacter.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "Components/AudioComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"
#include "Particles/ParticleSystemComponent.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "AI/ANLocker.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Environment/ANInspectingRoom.h"
#include "Game/ANGameInstance.h"
#include "Happening/ItemUse/ANItemUseHappening.h"
#include "Interact/ANInspectable.h"
#include "Interface/ANInteractable.h"
#include "Interface/ANItemable.h"
#include "SaveGame/ANGameUserSettings.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"
#include "Systems/ANPickableItem.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/HUD/ANMessagesHUDWidget.h"
#include "UI/Inventory/ANInventoryPanelWidget.h"

#include "Weapon/ANWeaponHarpoon.h"




///////////////////////////////////////////////////////////////////// AUXILIARY
void AANMainCharacter::Tick_Other(const float DeltaSeconds)
{
	AmbientDust->SetVectorParameter("Velocity", GetVelocity());
	AmbientDust->SetVectorParameter("Velocity2", GetVelocity());
	AmbientDust->SetVectorParameter("Velocity3", GetVelocity());
	AmbientDust->SetVectorParameter("Velocity4", GetVelocity());
}
////////////////////////////////////////////////////////////////////// AUXILIARY







void AANMainCharacter::AddActorToIgnoreInInteractableTrace(AActor* IgnoredActor)
{
	if (IgnoredActor)
	{
		if (IgnoredActorsInInteractableTrace.Contains(IgnoredActor))
			return;

		IgnoredActorsInInteractableTrace.Add(IgnoredActor);

	}
}

////////////////////////////////////////////////////////////////////// TRACE
void AANMainCharacter::TraceForInteractable()
{
	UWorld* MyWorld = this->GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	FHitResult Hit;
	FCollisionQueryParams QueryParams = FCollisionQueryParams::DefaultQueryParam;
	QueryParams.AddIgnoredActors(IgnoredActorsInInteractableTrace);

	AANPlayerControllerBase* playerController = GetPlayerControllerBase();
	if (!playerController) return;
	
	APlayerCameraManager* Manager = playerController->PlayerCameraManager;//                     ->GetViewTarget()->GetComponents<UCameraComponent>(Cameras);
	//GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, Camera->GetForwardVector().ToText().ToString());
	//todo should update 750 to be a customizable parameter
		FVector StartTraceLocation = Manager->GetCameraLocation();// HeadCamera->GetComponentLocation();
		FVector EndTraceLocation = Manager->GetCameraLocation() + (Manager->GetActorForwardVector() * InteractionRange);//HeadCamera->GetComponentLocation() + (HeadCamera->GetForwardVector() * InteractionRange);

		MyWorld->LineTraceSingleByChannel(Hit, StartTraceLocation, EndTraceLocation, TRACECHANNEL_INTERACTABLE, QueryParams);

		if (bShowDebugTraces)
		{
			DrawDebugLine(GetWorld(), StartTraceLocation, EndTraceLocation, FColor::Green, false, 1, 0, 1);
		}
	IANInteractable* FoundInteractable = nullptr;
	if (Hit.bBlockingHit)
	{
		if (Hit.Actor.IsValid())
		{
			if (IANInteractable* Interactable = Cast<IANInteractable>(Hit.GetActor()))
			{
				if (Interactable->CanInteract())
				{
					FoundInteractable = Interactable;
				}
			}
		}
	}

	if (FoundInteractable != CurrentLookingAtInteractable)
	{
		CurrentLookingAtInteractable = FoundInteractable;
		
		//Broadcast to the UI
		if (CurrentLookingAtInteractable != nullptr)
		{
			OnShowInteractTargeting.Broadcast();
		}
		else
		{
			OnHideInteractTargeting.Broadcast();
		}
	}
}
////////////////////////////////////////////////////////////////////// TRACE



////////////////////////////////////////////////////////////////////// WEAPON
void AANMainCharacter::SetHasHarpoonGun(bool bNewHasHarpoonGun)
{
	bHasHarpoonGun = bNewHasHarpoonGun;

	AANWeaponHarpoon* HarpoonGun = BP_GetHarpoonGun();
	if (HarpoonGun != nullptr)
	{
		if (bHasHarpoonGun)
		{
			HarpoonGun->SetActorHiddenInGame(false);
		}
		else
		{
			HarpoonGun->SetActorHiddenInGame(true);
		}
	}
}



void AANMainCharacter::StartADS()
{
	bIsADS = true;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			HUDWidget->BP_ShowDynamicCrosshairUI();
		}
	}
}

void AANMainCharacter::EndADS()
{
	bIsADS = false;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			HUDWidget->BP_HideDynamicCrosshairUI();
		}
	}
}

void AANMainCharacter::FireWeapon()
{
	if (!bHasHarpoonGun)
	{
		return;
	}

	if (HarpoonWeapon != nullptr)
	{
		HarpoonWeapon->Fire();
	}
}

void AANMainCharacter::NotifyWeaponFired(AANBaseProjectile* ShotProjectile)
{
	OnShotProjectile.Broadcast(ShotProjectile);
}
////////////////////////////////////////////////////////////////////// WEAPON


////////////////////////////////////////////////////////////////////// WATCH
void AANMainCharacter::StartViewWatch_Implementation()
{
	bViewingWatch = true;
}

void AANMainCharacter::EndViewWatch_Implementation()
{
	bViewingWatch = false;
}
////////////////////////////////////////////////////////////////////// WATCH









////////////////////////////////////////////////////////////////////// CAMERA
void AANMainCharacter::Tick_Camera(const float DeltaSeconds)
{
	// Controller Input To Camera Rotation Mapping
	AddControllerYawInput(CameraRotationRate.X * CameraSensitivity);
	AddControllerPitchInput(CameraRotationRate.Y * CameraSensitivity);
	if (MyCharacterMovement->MovementMode == EMovementMode::MOVE_Swimming)
		CameraRotationRate *= 1 - CameraAcceleration;

	// Camera Clamping
	FRotator cameraRot = GetControlRotation();
	cameraRot.Pitch = FMath::ClampAngle(cameraRot.Pitch, -80, 80);
	GetPlayerControllerBase()->SetControlRotation(cameraRot);

	// Head Bobbing
	if (bHeadBobbingEnabled)
	{
		const FVector CameraForwardVector2D = HeadCamera->GetForwardVector().GetSafeNormal2D();
		CameraZRotVector = FVector::CrossProduct(CameraForwardVector2D, LastCameraForwardVector.GetSafeNormal2D());

		const FRotator headRotation = HeadCamera->GetRelativeRotation();
		const FRotator newRotation = FRotator(headRotation.Pitch, headRotation.Yaw, 
			FMath::FInterpTo(headRotation.Roll, 
				MyCharacterMovement->MovementMode == EMovementMode::MOVE_Swimming ? CameraZRotVector.Z * -HeadBobbingMultiplier : 0,
				DeltaSeconds, HeadBobbingSpeed));
		HeadCamera->SetRelativeRotation(newRotation);
		LastCameraForwardVector = HeadCamera->GetForwardVector();
	}

	// Focus - Yet to implement
	if (FocusTarget)
		GEngine->AddOnScreenDebugMessage(-1, 0, FColor::Green, TEXT("Focusing"));
}
////////////////////////////////////////////////////////////////////// CAMERA




////////////////////////////////////////////////////////////////////// MOVEMENT
void AANMainCharacter::Tick_SwimmingMovement(const float DeltaSeconds)
{
	const FVector totalInputVector = MoveForwardInput + MoveRightInput + MoveUpInput;
	NetMovementVector = totalInputVector.Size() > 1 ? totalInputVector.GetSafeNormal() : totalInputVector;
	
	if (NetMovementVector.Size() > 0.1f)
	{
		if (bIsSprinting)
		{
			JetMovementVector = FMath::VInterpTo(JetMovementVector, NetMovementVector, DeltaSeconds, JetAcceleration);
			AddMovementInput(JetMovementVector, 1);
		}
		else
		{
			// Play Random stroke sound
			if (SwimForceTime == 0.f)
			{
				PostAkAudioEventOnCharacter(SwimStrokeSFX);
			}
				

			// Stroke time
			SwimForceTime += DeltaSeconds;

			// Stroke cut-off time
			if (SwimForceTime > CurrentSwimForceResetTime)
			{
				SwimForceTime = 0.f;
				const float randomResetTime = UKismetMathLibrary::RandomFloatInRange(SwimForceResetTime.X, SwimForceResetTime.Y);
				CurrentSwimForceResetTime = bIsSprinting ? randomResetTime * 0.4f : randomResetTime;
			}

			// Read curve
			CurrentSwimRate = SwimRateCurve->GetFloatValue(SwimForceTime);

			// Set Input
			AddMovementInput(NetMovementVector, CurrentSwimRate);
			JetMovementVector = FMath::VInterpTo(JetMovementVector, NetMovementVector, DeltaSeconds, JetAcceleration);
		}
	}
	else
	{
		//SwimForceTime = 0.f;
		CurrentSwimRate = 0.f;
	}
}

void AANMainCharacter::RefillOxygen(int32 RefillAmount)
{
	CurrentO2Time += RefillAmount;
	if (CurrentO2Time > MaxO2Time)
	{
		CurrentO2Time = MaxO2Time;
	}

	bIsO2Refilling = false;
	bDisplayedMediumO2Warning = false;
	bDisplayedLowO2Warning = false;
	bDisplayedSuffocationWarning = false;
	CurrentSuffocationTime = MaxSuffocationTime;
	OnCharacterUpdateSuffocationUI.Broadcast(this, CurrentSuffocationTime, MaxSuffocationTime);

	PostAkAudioEventOnCharacter(RefillO2SFX);
	PostAkAudioEventOnCharacter(StandardO2SFX);

	OnRefilledOxygen.Broadcast(this);
}

void AANMainCharacter::RefillAllOxygen()
{
	CurrentO2Time = MaxO2Time;
	bIsO2Refilling = false;
	bDisplayedMediumO2Warning = false;
	bDisplayedLowO2Warning = false;
	bDisplayedSuffocationWarning = false;
	CurrentSuffocationTime = MaxSuffocationTime;
	OnCharacterUpdateSuffocationUI.Broadcast(this, CurrentSuffocationTime, MaxSuffocationTime);

	PostAkAudioEventOnCharacter(RefillO2SFX);
	PostAkAudioEventOnCharacter(StandardO2SFX);

	OnRefilledOxygen.Broadcast(this);
}

void AANMainCharacter::DepleteAllOxygen()
{
	CurrentO2Time = 0.0f;
}

void AANMainCharacter::HandleO2(const float DeltaSeconds)
{
	//If refilling, do not lose O2, gain instead
	if (bIsO2Refilling)
	{
		CurrentO2Time -= DeltaSeconds * -O2RefillRate;
		if (CurrentO2Time >= MaxO2Time)
		{
			CurrentO2Time = MaxO2Time;
			bIsO2Refilling = false;
			OnO2RefillComplete.Broadcast();
		}

		if (bDisplayedMediumO2Warning && CurrentO2Time >= MediumO2WarningTime)
		{
			bDisplayedMediumO2Warning = false;
		}

		if (bDisplayedLowO2Warning && CurrentO2Time >= LowO2WarningTime)
		{
			bDisplayedLowO2Warning = false;
		}

		if (bDisplayedSuffocationWarning && CurrentO2Time > 0.0f)
		{
			bDisplayedSuffocationWarning = false;
		}
		return;
	}

	//Check to display warnings
	if (!bDisplayedMediumO2Warning && CurrentO2Time < MediumO2WarningTime)
	{
		bDisplayedMediumO2Warning = true;
		OnDisplayMediumO2WarningUI.Broadcast(this);
		PostAkAudioEventOnCharacter(MediumO2WarningSFX);
	}

	if (!bDisplayedLowO2Warning && CurrentO2Time < LowO2WarningTime)
	{
		bDisplayedLowO2Warning = true;
		OnDisplayLowO2WarningUI.Broadcast(this);
		PostAkAudioEventOnCharacter(LowO2WarningSFX);
	}

	//If out of oxygen
	if (CurrentO2Time <= 0.0f)
	{
		if (!bDisplayedSuffocationWarning)
		{
			bDisplayedSuffocationWarning = true;
			OnDisplaySuffocationWarningUI.Broadcast(this);
			PostAkAudioEventOnCharacter(SuffocationWarningSFX);
		}

		CurrentSuffocationTime -= DeltaSeconds;
		OnCharacterUpdateSuffocationUI.Broadcast(this, CurrentSuffocationTime, MaxSuffocationTime);
		if (CurrentSuffocationTime < 0.0f)
		{
			Die();
		}
	}
	//If normal case
	else
	{
		//If we don't have infinite oxygen, deplete as normal
		if (!bInfiniteOxygen)
		{
			CurrentO2Time -= DeltaSeconds;
		}
	}
}

void AANMainCharacter::UpdateDistanceToSignal()
{
	FVector CurrentLocation = GetActorLocation();

	float DistanceToSignal = FVector::Dist(SignalLocation, CurrentLocation);
	DistanceToSignal /= 100.0f;
	OnSignalDistanceUpdated.Broadcast((int32)DistanceToSignal);
}

void AANMainCharacter::ReceiveDamage(int32 DamageReceived)
{
	Super::ReceiveDamage(DamageReceived);

	//If we are doing any kind of interaction, try to go back in it. Yes, 3 try go backs is kind of hacky...
	TryGoBack();
	TryGoBack();
	TryGoBack();
}

void AANMainCharacter::SetInfiniteOxygen(bool bNewInfiniteOxygen)
{
	bInfiniteOxygen = bNewInfiniteOxygen;
}

void AANMainCharacter::Tick_WalkingMovement(const float DeltaSeconds)
{
	const float forwardInputSize = MoveForwardInput.Size();
	NetMovementVector = MoveForwardInput.GetSafeNormal2D() * forwardInputSize + MoveRightInput;
	AddMovementInput(NetMovementVector);
}

//void AANMainCharacter::Tick_LockerCheck(const float DeltaSeconds) {
//
//	//FHitResult Hit;
//	//FVector Start = HeadCamera->GetComponentLocation();
//
//	//FVector ForwardVector = HeadCamera->GetForwardVector();
//	//FVector End = ((ForwardVector * 200.f) + Start);
//	//FCollisionQueryParams CollisionParams;
//
//	//DrawDebugLine(GetWorld(), Start, End, FColor::Green, false, 1, 0, 1);
//
//	//if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, CollisionParams))
//	//{
//	//	if (Hit.bBlockingHit)
//	//	{
//	//		if (Hit.GetActor()->GetClass()->IsChildOf(AANLocker::StaticClass()))
//	//		{
//
//	//			CurrentLocker = Cast<AANLocker>(Hit.GetActor());
//
//	//		}
//	//	}
//	//}
//	//else
//	//{
//	//	CurrentLocker = NULL;
//	//}
//}

void AANMainCharacter::OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode)
{
	// Debug
	switch (MyCharacterMovement->MovementMode)
	{
	case EMovementMode::MOVE_Swimming:
		GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Swimming"));
		break;
	case EMovementMode::MOVE_Walking:
		GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Walking"));
		break;
	case EMovementMode::MOVE_Falling:
		GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Falling"));
		break;
	default:
		GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Other"));
		break;
	}
	
	APlayerCameraManager* cameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0);
	if (cameraManager == nullptr)
	{
		return;
	}

	if (MyCharacterMovement->MovementMode == EMovementMode::MOVE_Swimming)
	{
		UnderWaterCameraShake = cameraManager->PlayCameraShake(UnderWaterCameraShakeClass, 1.f);
		bUseControllerRotationPitch = true;
	}
	else
	{
		if (UnderWaterCameraShake && cameraManager)
			cameraManager->StopCameraShake(UnderWaterCameraShake, false);
		bUseControllerRotationPitch = false;
	}
}

void AANMainCharacter::KillActiveInputs(bool bZeroOutVelocity)
{
	KillMovement(bZeroOutVelocity);
	KillFire();
}

void AANMainCharacter::KillMovement(bool bZeroOutVelocity)
{
	EndJetBoost(); //End jet boost
	MoveForwardInput = FVector::ZeroVector;
	MoveRightInput = FVector::ZeroVector;
	MoveUpInput = FVector::ZeroVector;
	if (bZeroOutVelocity)
	{
		MyCharacterMovement->Velocity = FVector::ZeroVector;
	}
}

void AANMainCharacter::KillFire()
{
	bIsADS = false;
	bIsFiringPrimary = false;
}




////////////////////////////////////////////////// Inputs
void AANMainCharacter::MoveForward(const float input) { MoveForwardInput = HeadCamera->GetForwardVector() * input; }
void AANMainCharacter::MoveRight(const float input) { MoveRightInput = HeadCamera->GetRightVector() * input; }
void AANMainCharacter::MoveUp(const float input) { MoveUpInput = FVector::UpVector * input; }


// Jet
void AANMainCharacter::InputAction_Jet_Pressed()
{
	UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings();

	//Toggle mode
	if (ANGameUserSettings != nullptr && ANGameUserSettings->IsJetBoostToggle())
	{
		if (!bIsSprinting)
		{
			StartJetBoost();
		}
		else
		{
			EndJetBoost();
		}
	}
	//Hold mode
	else
	{
		StartJetBoost();
	}
}

void AANMainCharacter::InputAction_Jet_Released()
{
	UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings();

	//Toggle mode
	if (ANGameUserSettings != nullptr && ANGameUserSettings->IsJetBoostToggle())
	{
		//Do nothing on release
	}
	//Hold mode
	else
	{
		EndJetBoost();
	}
}

void AANMainCharacter::StartJetBoost()
{
	if (!bIsSprinting)
	{
		UCharacterMovementComponent* characterMovement = GetCharacterMovement();
		characterMovement->MaxWalkSpeed = WalkSpeedRange.Y;
		characterMovement->MaxSwimSpeed = SwimSpeedRange.Y;
		bIsSprinting = true;
		PostAkAudioEventOnCharacter(JetBoostStartSFX);
		PostAkAudioEventOnCharacter(JetBoostLoopSFX);
	}
}

void AANMainCharacter::EndJetBoost()
{
	if (bIsSprinting)
	{
		UCharacterMovementComponent* characterMovement = GetCharacterMovement();
		characterMovement->MaxWalkSpeed = WalkSpeedRange.X;
		characterMovement->MaxSwimSpeed = SwimSpeedRange.X;
		bIsSprinting = false;
		PostAkAudioEventOnCharacter(JetBoostStopSFX);
	}
}


void AANMainCharacter::LookRight_Mouse(const float AxisValue)
{
	float Rate = AxisValue;

	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		int32 Sensitivity = ANGameUserSettings->GetMouseHorizontalSensitivity();
		float SensitivityModifier = UANFunctionLibrary::ConvertSensitivityToModifier(Sensitivity);
		Rate *= SensitivityModifier;
	}

	LookRightInternal(Rate);
}

void AANMainCharacter::LookRight_Controller(const float AxisValue)
{
	if (WorldRef == nullptr)
	{
		return;
	}

	float Rate = AxisValue * ControllerAimHorizontalSensitivity * WorldRef->GetDeltaSeconds();

	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		int32 Sensitivity = ANGameUserSettings->GetGamepadHorizontalSensitivity();
		float SensitivityModifier = UANFunctionLibrary::ConvertSensitivityToModifier(Sensitivity);
		Rate *= SensitivityModifier;
	}

	LookRightInternal(Rate);
}

void AANMainCharacter::LookRightInternal(const float Value)
{
	float Rate = Value;

	if (MyCharacterMovement->MovementMode == EMovementMode::MOVE_Swimming)
	{
		Rate = Value * CameraAcceleration;
	}
	else
	{
		Rate = Value;
	}

	CameraRotationRate.X += Rate;
}


void AANMainCharacter::LookUp_Mouse(const float AxisValue)
{
	float Rate = AxisValue;

	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		int32 Sensitivity = ANGameUserSettings->GetMouseVerticalSensitivity();
		float SensitivityModifier = UANFunctionLibrary::ConvertSensitivityToModifier(Sensitivity);
		Rate *= SensitivityModifier;
	}

	LookUpInternal(Rate);
}

void AANMainCharacter::LookUp_Controller(const float AxisValue)
{
	if (WorldRef == nullptr)
	{
		return;
	}

	float Rate = AxisValue * ControllerAimVerticalSensitivity * WorldRef->GetDeltaSeconds();

	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		int32 Sensitivity = ANGameUserSettings->GetGamepadVerticalSensitivity();
		float SensitivityModifier = UANFunctionLibrary::ConvertSensitivityToModifier(Sensitivity);
		Rate *= SensitivityModifier;
	}

	LookUpInternal(Rate);
}

void AANMainCharacter::LookUpInternal(const float Value)
{
	float Rate = Value;

	if (MyCharacterMovement->MovementMode == EMovementMode::MOVE_Swimming)
	{
		Rate = Value * CameraAcceleration;
	}
	else
	{
		Rate = Value;
	}

	if (UANGameUserSettings* ANGameUserSettings = UANFunctionLibrary::GetANGameUserSettings())
	{
		if (ANGameUserSettings->IsInvertYAxis())
		{
			Rate *= -1.0f;
		}
	}

	CameraRotationRate.Y += Rate;
}
////////////////////////////////////////////////// Inputs
////////////////////////////////////////////////////////////////////// MOVEMENT











////////////////////////////////////////////////////////////////////// INTERACTION
void AANMainCharacter::TryInteract()
{
	if (!CanStartEndInteract())
	{
		return;
	}

	//Set here like this so if we end up setting another interactable before the execution chain ends, we can continue using this
	IANInteractable* CurrentTryLookingAtInteractable = CurrentLookingAtInteractable;
	
	if (CurrentTryLookingAtInteractable != nullptr)
	{
		if (CurrentTryLookingAtInteractable->CanInteract())
		{
			//If a long interact, return true if we begin the interaction
			if (CurrentTryLookingAtInteractable->IsLongInteract())
			{
				CurrentInteractingInteractable = CurrentTryLookingAtInteractable;
				CurrentTryLookingAtInteractable->BeginInteract(this);
				EndADS(); //End ADS when beginning long interact
				OnPlayerBeginLongInteract.Broadcast();
				bInteracting = true;
				KillActiveInputs(true); //Kill all movement/firing/etc once we start to interact
			}
			//Else if instant, try to begin interact and then end interaction
			else
			{
				CurrentTryLookingAtInteractable->BeginInteract(this);
				CurrentTryLookingAtInteractable->EndInteract(this);
			}
		}
	}
		
}

void AANMainCharacter::ManualInteract(TScriptInterface<IANInteractable> objectToInteract)
{
	if (!CanStartEndInteract())
	{
		return;
	}

	//Feed the object directly since we are bypassing the line trace
	if (objectToInteract)
	{
		CurrentLookingAtInteractable = Cast<IANInteractable>(objectToInteract.GetObject());
		//TryInteract should now work with the new object
		TryInteract();
	}
}

void AANMainCharacter::TryGoBack()
{
	if (!CanStartEndInteract())
	{
		return;
	}

	//If we are interacting with something, end that interaction
	if (CurrentInteractingInteractable != nullptr)
	{
		//TODO we may need to change this to "Back" or something similar if we don't always end interaction with this button
		CurrentInteractingInteractable->EndInteract(this);
	}
	//If we are viewing our inventory on its own, close it
	else if (CurrentInteractingInteractable == nullptr && bInventoryOpen)
	{
		CloseManualInventory();
	}
	//If we are viewing the information panel/map on its own, close it
	else if (CurrentInteractingInteractable == nullptr && bInformationOpen)
	{
		CloseManualInformation();
	}
}

void AANMainCharacter::TryEndInteract()
{
	OnPlayerEndLongInteract.Broadcast();
	CurrentInteractingInteractable = nullptr;
	bInteracting = false;
}

bool AANMainCharacter::CanStartEndInteract() const
{
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			//Don't allow interaction if the inventory is transitioning
			if (HUDWidget->IsInventoryTransitioning())
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	return false;
}

////////////////////////////////////////////////////////////////////// INTERACTION


////////////////////////////////////////////////////////////////////// INVENTORY

void AANMainCharacter::OpenInventory(EANInventoryModes OpenInventoryMode)
{
	if (!CanOpenCloseInventory())
	{
		return;
	}

	//End ADS when opening inventory
	EndADS();

	bInventoryOpen = true;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if(UANInventoryPanelWidget* InventoryPanelWidget = HUDWidget->GetInventoryPanelWidget())
			{
				HUDWidget->BP_ShowInventoryUI();

				switch (OpenInventoryMode)
				{
				case (EANInventoryModes::Puzzle):
					PostAkAudioEventOnCharacter(OpenInventoryPuzzleSFX);
					if (IANItemable* InteractableAsItemable = Cast<IANItemable>(CurrentInteractingInteractable))
					{
						InventoryPanelWidget->UpdateIconOpacityForItemable(InteractableAsItemable);
					}
					break;
				case (EANInventoryModes::Use):
					PostAkAudioEventOnCharacter(OpenInventoryDirectSFX);
					InventoryPanelWidget->UpdateIconOpacityForInventoryUseTypes();
					break;
				default:
					break;
				}

				InventoryPanelWidget->SetInventoryMode(OpenInventoryMode);
				PlayerControllerBase->AssignSelectables(InventoryPanelWidget->GetAllInventoryItemSlotWidgetsAsSelectableArray());
			}
		}
	}
}

void AANMainCharacter::CloseInventory()
{
	if (!CanOpenCloseInventory())
	{
		return;
	}

	bInventoryOpen = false;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (UANInventoryPanelWidget* InventoryPanelWidget = HUDWidget->GetInventoryPanelWidget())
			{
				EANInventoryModes PreviousInventoryMode = InventoryPanelWidget->GetInventoryMode();

				HUDWidget->BP_HideInventoryUI();
				PostAkAudioEventOnCharacter(CloseInventorySFX);

				InventoryPanelWidget->SetInventoryMode(EANInventoryModes::None);
				PlayerControllerBase->ClearSelectables();
			}
		}
	}
}

void AANMainCharacter::OpenManualInventory()
{
	if (!CanOpenCloseInventory())
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		//end inputs for movement here
		EndJetBoost(); //End jet boosting
		MoveForwardInput = FVector::ZeroVector;
		MoveRightInput = FVector::ZeroVector;
		MoveUpInput = FVector::ZeroVector;
		KillFire(); //End firing/ADS

		PlayerControllerBase->SetGameInput(EGameInputTypes::UIOnly);
		StartViewWatch();
		OpenInventory(EANInventoryModes::Use);

		PlayRumble(OpenInventoryRumbleEffect, RumbleNames::OpenInventory, false);
	}
}

void AANMainCharacter::CloseManualInventory()
{
	if (!CanOpenCloseInventory())
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		PlayerControllerBase->SetGameInput(EGameInputTypes::GameOnly);
		EndViewWatch();
		CloseInventory();
	}
}

bool AANMainCharacter::CanOpenCloseInventory() const
{
	//Only allow inventory to open if we don't have information panel/map open
	if (bInformationOpen)
	{
		return false;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (HUDWidget->IsInventoryTransitioning())
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	return false;
}
////////////////////////////////////////////////////////////////////// INVENTORY




////////////////////////////////////////////////////////////////////// INFORMATION/MAP
void AANMainCharacter::OpenInformation()
{
	if (!CanOpenCloseInformation())
	{
		return;
	}

	//End ADS when opening information
	EndADS();

	bInformationOpen = true;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (UANInformationPanelWidget* InformationPanelWidget = HUDWidget->GetInformationPanelWidget())
			{
				HUDWidget->BP_ShowInformationPanelUI();
				PostAkAudioEventOnCharacter(OpenInformationSFX);
			}
		}
	}
}

void AANMainCharacter::CloseInformation()
{
	if (!CanOpenCloseInformation())
	{
		return;
	}

	bInformationOpen = false;
	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (UANInformationPanelWidget* InformationPanelWidget = HUDWidget->GetInformationPanelWidget())
			{
				HUDWidget->BP_HideInformationPanelUI();
				PostAkAudioEventOnCharacter(CloseInformationSFX);
				PlayerControllerBase->ClearSelectables();
			}
		}
	}
}

void AANMainCharacter::OpenManualInformation()
{
	if (!CanOpenCloseInformation())
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		//end inputs for movement here
		EndJetBoost(); //End jet boosting
		MoveForwardInput = FVector::ZeroVector;
		MoveRightInput = FVector::ZeroVector;
		MoveUpInput = FVector::ZeroVector;
		KillFire(); //End firing/ADS

		PlayerControllerBase->SetGameInput(EGameInputTypes::UIOnly);
		StartViewWatch();
		OpenInformation();

		PlayRumble(OpenInventoryRumbleEffect, RumbleNames::OpenInventory, false);
	}
}

void AANMainCharacter::CloseManualInformation()
{
	if (!CanOpenCloseInformation())
	{
		return;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		PlayerControllerBase->SetGameInput(EGameInputTypes::GameOnly);
		EndViewWatch();
		CloseInformation();
	}
}

bool AANMainCharacter::CanOpenCloseInformation() const
{
	//Only allow information to open if we aren't interacting with something
	if (bInteracting || bInventoryOpen)
	{
		return false;
	}

	if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
	{
		if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
		{
			if (HUDWidget->IsInformationTransitioning())
			{
				return false;
			}
			else
			{
				return true;
			}
		}
	}

	return false;
}
////////////////////////////////////////////////////////////////////// INFORMATION/MAP






////////////////////////////////////////////////////////////////////// ITEMABLE
#pragma optimize("", off)

bool AANMainCharacter::SelectItem(const FString& SelectedItem, EANInventoryModes InventoryMode)
{
	switch (InventoryMode)
	{
	case (EANInventoryModes::Puzzle):
		return InsertItem(SelectedItem);
		break;
	case (EANInventoryModes::Use):
		return UseItem(SelectedItem);
		break;
	default:
		break;
	}
	return false;
}

bool AANMainCharacter::InsertItem(const FString& InsertedItem)
{
	if (CurrentInteractingInteractable != nullptr)
	{
		if (IANItemable* Itemable = Cast<IANItemable>(CurrentInteractingInteractable))
		{
			if (Itemable->CanInsertItem(InsertedItem))
			{
				Itemable->InsertItem(InsertedItem, true);
				return true;
			}
		}
	}

	return false;
}

bool AANMainCharacter::UseItem(const FString& UsedItem)
{
	//TODO
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			if (FANItem* Item = InventorySystem->GetItemDataFromTable(UsedItem))
			{
				switch (Item->InventoryUseType)
				{
				case (EANItemInventoryUseTypes::Drop):
					if (DropInventoryItem(Item))
					{
						InventorySystem->UseItem(Item->ANItemName, 1);
						return true;
					}
					break;
				case (EANItemInventoryUseTypes::Use):
					if (UseInventoryItem(Item))
					{
						InventorySystem->UseItem(Item->ANItemName, 1);
						return true;
					}
					break;
				case (EANItemInventoryUseTypes::Inspect):
					InspectInventoryItem(Item);
					return true;
				default:
					break;
				}

			}
		}
	}

	return false;
}

bool AANMainCharacter::DropInventoryItem(FANItem* DroppedInventoryItem)
{
	UWorld* MyWorld = GetWorld();
	if (DroppedInventoryItem == nullptr || DroppedInventoryItem->PickableItem == nullptr || MyWorld == nullptr)
	{
		return false;
	}

	FTransform ItemSpawnTransform = this->GetTransform();
	FVector AdditionalForwardOffset = ItemSpawnTransform.TransformVector(DropItemOffset);
	ItemSpawnTransform.SetLocation(ItemSpawnTransform.GetLocation() + AdditionalForwardOffset);

	FActorSpawnParameters ItemSpawnParams;
	ItemSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButDontSpawnIfColliding;

	AANPickableItem* SpawnedPickableItem = MyWorld->SpawnActor<AANPickableItem>(DroppedInventoryItem->PickableItem, ItemSpawnTransform, ItemSpawnParams);
	if (SpawnedPickableItem != nullptr)
	{
		return true;
	}

	return false;
}

void AANMainCharacter::InspectInventoryItem(FANItem* InspectedItem)
{
	if (InspectedItem->InspectedItem != nullptr)
	{
		UWorld* MyWorld = GetWorld();
		if (MyWorld == nullptr)
		{
			return;
		}

		FTransform InspectedItemSpawnTransform = this->GetTransform();
		FVector AdditionalForwardOffset = InspectedItemSpawnTransform.TransformVector(FVector(100.f,0.f,100.f));
		InspectedItemSpawnTransform.SetLocation(InspectedItemSpawnTransform.GetLocation() + AdditionalForwardOffset);
		FActorSpawnParameters ItemSpawnParams;
		ItemSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AANInspectable* Inspectable = MyWorld->SpawnActor<AANInspectable>(InspectedItem->InspectedItem, InspectedItemSpawnTransform, ItemSpawnParams);
		if (Inspectable == nullptr)
		{
			return;
		}

		if (AANInspectingRoom* Room = Cast<AANInspectingRoom>(UGameplayStatics::GetActorOfClass(MyWorld, AANInspectingRoom::StaticClass())))
		{
			Inspectable->SpawnLocation = Room->InspectableSpawnLocation;
		}
		Inspectable->SetActorLocation(Inspectable->SpawnLocation);
		CurrentLookingAtInteractable = Inspectable;
		TryInteract();
	}
}

bool AANMainCharacter::UseInventoryItem(FANItem* UsedInventoryItem)
{
	UWorld* MyWorld = GetWorld();

	if (UsedInventoryItem == nullptr || UsedInventoryItem->ItemUseHappening == nullptr || MyWorld == nullptr)
	{
		return false;
	}

	FTransform UseSpawnTransform = FTransform();
	FActorSpawnParameters UseSpawnParams;
	UseSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AANItemUseHappening* SpawnedItemUseHappening = MyWorld->SpawnActor<AANItemUseHappening>(UsedInventoryItem->ItemUseHappening, UseSpawnTransform, UseSpawnParams);
	if (SpawnedItemUseHappening != nullptr)
	{
		SpawnedItemUseHappening->InitializeHappening(this);

		//If we can't do the happening, send a failure message, destroy it, and return false
		if (!SpawnedItemUseHappening->CanDoHappening())
		{
			if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(GetPlayerControllerBase()))
			{
				if (UANMessagesHUDWidget* MessagesHUDWidget = PlayerControllerBase->GetMessagesHUDWidget())
				{
					MessagesHUDWidget->BP_AddMessage(SpawnedItemUseHappening->GetUnableToDoHappeningText(), 3.0f);
				}
			}

			SpawnedItemUseHappening->Destroy();
			return false;
		}

		SpawnedItemUseHappening->SetItemUseParameters(UsedInventoryItem->IntegerValue, UsedInventoryItem->FloatValue, UsedInventoryItem->TextValue);
		SpawnedItemUseHappening->DoHappening();
		return true;
	}

	return false;
}
#pragma optimize("", on)

////////////////////////////////////////////////////////////////////// ITEMABLE


////////////////////////////////////////////////////////////////////// HELPER
void AANMainCharacter::PreventPauseIssues()
{
	Super::PreventPauseIssues();

	KillActiveInputs(false); //Don't zero out velocity
	EndADS(); //End ADS on pause
}

AANPlayerControllerBase* AANMainCharacter::GetPlayerControllerBase() const
{
	if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(GetController()))
	{
		return PlayerControllerBase;
	}

	return nullptr;
}

UANInventorySystem* AANMainCharacter::GetInventorySystem() const
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			return InventorySystem;
		}
	}

	return nullptr;
}
void AANMainCharacter::ChangeWorldTime(float Time)
{
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), Time);
}
void AANMainCharacter::FreezeTime(bool bToggleFreeze)
{
	float Time = bToggleFreeze ? 0 : 1;
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), Time);
}


void AANMainCharacter::PutInLocker(UCameraComponent* LockerCamera) {
	bHidesInLocker = true;
	//GetPlayerControllerBase()->SetViewTargetWithBlend(LockerCamera->GetOwner());
}

void AANMainCharacter::RemoveFromLocker(UCameraComponent* LockerCamera) {
	bHidesInLocker = false;
	//GetPlayerControllerBase()->SetViewTargetWithBlend(this);
}
////////////////////////////////////////////////////////////////////// HELPER