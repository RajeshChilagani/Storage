// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1


#include "Character/ANPersistentCharacter.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "BrainComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystem.h"
#include "Projectiles/ANBaseProjectile.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPersistentAIController.h"
#include "Controller/ANPlayerControllerBase.h"
#include "UI/AI/ANPersistentAIHealthWidget.h"
#include "UI/HUD/ANHUDWidget.h"

// Sets default values
AANPersistentCharacter::AANPersistentCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
	AIControllerClass = AANPersistentAIController::StaticClass();

	EnemyAkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("EnemyAkComponent"));
	EnemyAkComponent->SetupAttachment(RootComponent);

//Final Battle
	TargetChaseSpeed = BaseChaseSpeed;
	TargetTurnSpeed = BaseTurnSpeed;
	TargetStunDamage = BaseStunDamage;
	StunCheckTimeInSeconds = BaseStunCheckTimeInSeconds;

}

////////////////////////////////////////////////////////////////////// CORE
void AANPersistentCharacter::BeginPlay()
{
	Super::BeginPlay();

	TArray<AActor*> outActors;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), AANMainCharacter::StaticClass(), outActors);
	if (outActors.Num() > 0)
	{
		PlayerPawn = Cast<AANMainCharacter>(outActors[0]);
	}

	if (PlayerPawn)
	{
		PlayerPawn->AddActorToIgnoreInInteractableTrace(this);
	}

	if (EnemyAkComponent != nullptr && PersistentSFX != nullptr)
	{
		EnemyAkComponent->PostAkEvent(PersistentSFX, 0, FOnAkPostEventCallback(), FString());
	}
	StunDamage = TargetStunDamage;
}

void AANPersistentCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	Tick_CharacterControl(DeltaTime);
	Tick_Vision(DeltaTime);
	Tick_StateControl(DeltaTime);
}

void AANPersistentCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}
////////////////////////////////////////////////////////////////////// CORE








////////////////////////////////////////////////////////////////////// STATE CONTROL
void AANPersistentCharacter::Tick_StateControl(const float DeltaTime)
{
	if (bIsEngaging) return;
	if (EnemyState == EEnemyState::Stunned)
		return;

	// Child Look
	bShouldChildLookAtPlayer = Alertness > ChildLookAlertnessThreshold;
	bShouldLookAtPlayer = Alertness > MainLookAlertnessThreshold;

	// Persistence
	if (bIsPersistent)
	{
		Alertness = 1.f;

		if (EnemyState != EEnemyState::Chase || EnemyState != EEnemyState::Rage)
		{
			EnemyState = EEnemyState::Chase;
		}

		return;
	}

	if (
		Alertness > InvestigateStateAlertnessThreshold &&
		Alertness < ChaseStateAlertnessThreshold &&

		EnemyState != EEnemyState::Investigate &&
		EnemyState != EEnemyState::Chase &&
		EnemyState != EEnemyState::Rage/* &&
		EnemyState != EEnemyState::Attack_Swing*/
		)
	{
		EnemyState = EEnemyState::Investigate;
	}


	if (
		Alertness > ChaseStateAlertnessThreshold &&
		EnemyState != EEnemyState::Chase &&
		EnemyState != EEnemyState::Rage/* &&
		EnemyState != EEnemyState::Attack_Swing*/
		)
	{
		EnemyState = EEnemyState::Chase;
	}
	if (PlayerPawn != nullptr) {
		if (PlayerPawn->bHidesInLocker &&
			(
				EnemyState == EEnemyState::Chase ||
				EnemyState == EEnemyState::Rage
				)
			) {
			EnemyState = EEnemyState::Investigate;
		}
	}

	//// Attack State(s)
	//if (!PlayerPawn)
	//{
	//	UE_LOG(LogTemp, Warning, TEXT("PlayerRef not found!"));
	//	return;
	//}

	//const FVector playerLocation = PlayerPawn->GetActorLocation();
	//const FVector myLocation = GetActorLocation();
	//const float distance = (playerLocation - myLocation).Size();
	//
	//if (
	//	Alertness > ChaseStateAlertnessThreshold &&
	//	EnemyState != EEnemyState::Attack_Swing &&
	//	(EnemyState == EEnemyState::Chase || EnemyState == EEnemyState::Rage) &&
	//	distance < AttackDistanceThreshold
	//){
	//	EnemyState = EEnemyState::Attack_Swing;
	//	OnAttackStateEngaged.Broadcast(EEnemyState::Attack_Swing);
	//}
}

bool AANPersistentCharacter::GetIsBehaviorActive() const
{
	AController* controller = GetController();
	if (!controller)
		return false;
	
	AANPersistentAIController* aiController = Cast<AANPersistentAIController>(controller);
	UBrainComponent* brain = aiController->GetBrainComponent();
	if (brain)
		return brain->IsRunning();

	return false;
}
////////////////////////////////////////////////////////////////////// STATE CONTROL








////////////////////////////////////////////////////////////////////// VISION
void AANPersistentCharacter::Tick_Vision(const float DeltaTime)
{
	if (!PlayerPawn)
	{
		UE_LOG(LogTemp, Warning, TEXT("Player reference not found!"));
		return;
	}

	const FVector myLocation = GetActorLocation();
	const FVector targetLocation = PlayerPawn->GetActorLocation();
	
	FHitResult hit;
	FCollisionQueryParams queryParams;
	queryParams.AddIgnoredActor(this);
	GetWorld()->LineTraceSingleByChannel(hit, myLocation, targetLocation, ECollisionChannel::ECC_Camera, queryParams);

	bool bShouldGain = false;
	if (hit.bBlockingHit && hit.Actor == PlayerPawn)
	{
		const FVector playerVelocity = PlayerPawn->GetVelocity();
		const float playerSpeed = playerVelocity.Size();

		// Gain by Angle & Distance
		const FVector distance = targetLocation - myLocation;
		const FVector direction = distance.GetSafeNormal();
		
		const float fDistance = distance.Size();
		const float fAngle = FMath::Acos(FVector::DotProduct(GetActorForwardVector(), direction)) * 180 / PI;

		const float fDistComp = FMath::Pow(1 - FMath::Clamp<float>(fDistance / VisionConeRange, 0, 1), VisionRangeGamma);
		const float fAngleComp = FMath::Pow(1 - FMath::Clamp<float>(fAngle / VisionConeAngle, 0, 1), VisionAngleGamma);

		// Gain by PlayerSpeed
		const float fPlayerSpeedComp = playerSpeed / PlayerSpeedThreshold / fDistance;
		const float fCombinedComp = fDistComp * fAngleComp;

		// Gain by Flashlight
		const float fFlashlightComp = PlayerPawn->bFlashlight ? PlayerFlashlightGainMultiplier / fDistance : 0.f;

		// NET GAIN Formula
		const float fGain = (fCombinedComp + fPlayerSpeedComp + fFlashlightComp) * AlertnessGainRate;
		GEngine->AddOnScreenDebugMessage(-1, 0, FColor::White, FString::Printf(TEXT("Alertness Gain (CombinedGain) = %f | (SpeedGain) = %f | (FlashlightGain) = %f"), fCombinedComp, fPlayerSpeedComp, fFlashlightComp));
		
		// Apply Gain
		bShouldGain = fGain > AlertnessGainThreshold;
		if (bShouldGain) Alertness = FMath::Clamp<float>(Alertness + fGain, 0, 1);

		// Set Last Seen Location
		PlayerLastSeenLocation = targetLocation;

		// Draw Debug Vision Indicator
		const FColor combinedColor = UKismetMathLibrary::LinearColorLerp(VisionMinColor, VisionMaxColor, fCombinedComp * 5.f).ToFColor(false);
		if (bShowDebugVision)
			DrawDebugLine(GetWorld(), hit.TraceStart, hit.TraceEnd, combinedColor, false, -1, 0, 5);

		bCanSeePlayer = true;
	}
	else
		bCanSeePlayer = false;

	if (!bShouldGain) Alertness = FMath::Clamp<float>(Alertness - AlertnessDropRate, 0, 1);

	GEngine->AddOnScreenDebugMessage(-1, 0, FColor::White, FString::Printf(TEXT("%f"), Alertness));
}
////////////////////////////////////////////////////////////////////// VISION










////////////////////////////////////////////////////////////////////// MOVEMENT
void AANPersistentCharacter::Tick_CharacterControl(const float DeltaTime)
{
	if (bShouldFacePlayer)
	{
		if (PlayerPawn)
		{
			const FRotator currentRot = GetActorRotation();
			const FRotator lookAtRot = UKismetMathLibrary::FindLookAtRotation(GetActorLocation(), PlayerPawn->GetActorLocation());
			SetActorRotation(FMath::RInterpTo(currentRot, lookAtRot, DeltaTime, TurningRate));
		}
		else
			UE_LOG(LogTemp, Warning, TEXT("PlayerRef not found!"));
		
	}
}

float AANPersistentCharacter::TakeDamage(float Damage, FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser)
{
	UWorld* World = GetWorld();
	if (AANBaseProjectile* Projectile = Cast<AANBaseProjectile>(DamageCauser))
	{
		if (EnemyAkComponent != nullptr && GetHitSFX != nullptr)
		{
			EnemyAkComponent->PostAkEvent(GetHitSFX, 0, FOnAkPostEventCallback(), FString());
		}

		if (EnemyState == EEnemyState::Stunned)
			return Damage;

		// Full Alert
		ForceSetAlertness(1);
		USkeletalMeshComponent* baddyMesh = GetMesh();

		if (UKismetMathLibrary::RandomFloat() < 0.36f)
		{
			if (ShortRageMontage)
				PlayAnimMontage(ShortRageMontage, 1, FName("0"));
		}
		else
		{
			if (HitReactMontage)
				PlayAnimMontage(HitReactMontage, 1, FName("0"));
		}
			
		if (UCharacterMovementComponent* MovementCom = GetCharacterMovement())
		{
			MovementCom->Velocity *= -0.2f;
		}
		if (World)
		{
			if (World->GetTimerManager().IsTimerActive(StunCheckTimer))
			{
				StunDamage -= Damage;
				if (HealthWidget)
				{
					HealthWidget->BP_UpdateStunOnScreen(StunDamage, TargetStunDamage);
				}
				if (StunDamage <=0)
				{
					Stun();
				}
			}
			else
			{
				Print("Begin Stun Check Timer");
				FTimerDelegate TimerDelegate = FTimerDelegate::CreateLambda([this]() {
				StunDamage = TargetStunDamage;
				if (HealthWidget)
				{
					HealthWidget->BP_UpdateStunOnScreen(StunDamage, TargetStunDamage);
				}});
				World->GetTimerManager().SetTimer(StunCheckTimer, TimerDelegate, StunCheckTimeInSeconds, false);
				StunDamage -= Damage;
				if (HealthWidget)
				{
					HealthWidget->BP_UpdateStunOnScreen(StunDamage, TargetStunDamage);
				}
			}

			if (BloodVFX != nullptr)
			{
				UGameplayStatics::SpawnEmitterAtLocation(World, BloodVFX, GetActorLocation());
			}
		}
	}
	else if (AANMainCharacter* Diver = Cast<AANMainCharacter>(DamageCauser))
	{
		Print("Explosive Damage");
		if (World)
		{
			World->GetTimerManager().ClearTimer(UnStunTimer);
		}
		Health -= Damage;
		if (HealthWidget)
		{
			HealthWidget->BP_UpdateHealthOnScreen(FMath::Clamp(Health,0.0f,100.f));
		}
		OnTakingDamage();

		if (FinalBattlePhase == EBattlePhase::BattleFury && Health <= 0)
		{
			Print("Baddy Died");
			if (HealthWidget)
			{
				HealthWidget->SetVisibility(ESlateVisibility::Hidden);
			}

			if (EnemyAkComponent != nullptr && DieSFX != nullptr)
			{
				EnemyAkComponent->PostAkEvent(DieSFX, 0, FOnAkPostEventCallback(), FString());
			}
			OnDeath();
		}
		else
		{
			if (FinalBattlePhase == EBattlePhase::BattleBegin)
			{
				SetBattlePhase(EBattlePhase::BattleRage);
			}
			else if (FinalBattlePhase == EBattlePhase::BattleRage)
			{
				SetBattlePhase(EBattlePhase::BattleFury);
				bUnstunOnExplosion = true;
			}
			if (bUnstunOnExplosion)
			{
				UnStun();
			}
		}
	}
	return Damage;
}

void AANPersistentCharacter::BeginFinalBattle()
{
	Print("Final Battle Began");
	SetBattlePhase(EBattlePhase::BattleBegin);
}

void AANPersistentCharacter::Stun()
{
	UWorld* World = GetWorld();
	Print("Baddy Stunned");
	StunDamage = TargetStunDamage;
	World->GetTimerManager().ClearTimer(StunCheckTimer);
	OnStunned();
	FTimerDelegate TimerDelegate = FTimerDelegate::CreateLambda([this]() {UnStun(); });
	World->GetTimerManager().SetTimer(UnStunTimer, TimerDelegate, StunTimeInSeconds, false);
}

void AANPersistentCharacter::UnStun()
{
	if (EnemyState != EEnemyState::Stunned)
	{
		Print("Invalid call to Unstun Baddy. Baddy is not in a stunned state");
		return;
	}
	StunDamage = TargetStunDamage;
	if (HealthWidget)
	{
		HealthWidget->BP_UpdateStunOnScreen(StunDamage, TargetStunDamage);
	}
	UWorld* World = GetWorld();
	if (World)
	{
		FTimerManager& TimerManager = World->GetTimerManager();
		if (TimerManager.IsTimerActive(UnStunTimer))
		{
			World->GetTimerManager().ClearTimer(UnStunTimer);
		}
	}
	OnUnStunned();
}

void AANPersistentCharacter::SetBattlePhase(EBattlePhase NewPhase)
{
	FinalBattlePhase = NewPhase;
	if (FinalBattlePhase == EBattlePhase::BattleBegin && !HealthWidget)
	{
		if (UWorld* World = GetWorld())
		{
			if (AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(World->GetFirstPlayerController()))
			{
				if (UANHUDWidget* Hud = PlayerController->GetHUDWidget())
				{
					HealthWidget = Hud->GetPersistentAIHealthWidget();
					HealthWidget->SetVisibility(ESlateVisibility::Visible);
				}
			}
		}
	}
	UpdateBattleProperties();
	OnFinalBattlePhaseChanged.Broadcast(FinalBattlePhase);
}

void AANPersistentCharacter::ClearUnStunTimer()
{
	if (UWorld* World = GetWorld())
	{
		FTimerManager& TimerManager = World->GetTimerManager();
		if (TimerManager.IsTimerActive(UnStunTimer))
		{
			World->GetTimerManager().ClearTimer(UnStunTimer);
		}
	}
}

void AANPersistentCharacter::UpdateBattleProperties()
{
	if (FinalBattlePhase == EBattlePhase::BattleBegin)
	{
		TargetStunDamage = BaseStunDamage;
		TargetChaseSpeed = BaseChaseSpeed;
		TargetTurnSpeed  = BaseTurnSpeed;
		StunCheckTimeInSeconds = BaseStunCheckTimeInSeconds;
		StunDamage = TargetStunDamage;
	}
	else if (FinalBattlePhase == EBattlePhase::BattleRage)
	{
		TargetStunDamage = BaseStunDamage * BattleRageMul;
		TargetChaseSpeed = BaseChaseSpeed * BattleRageMul;
		TargetTurnSpeed  = BaseTurnSpeed  * BattleRageMul;
		StunCheckTimeInSeconds = BaseStunCheckTimeInSeconds * BattleRageMul;
		StunDamage = TargetStunDamage;
	}
	else if (FinalBattlePhase == EBattlePhase::BattleFury)
	{
		TargetStunDamage  =	BaseStunDamage * BattleFuryMul;
		TargetChaseSpeed  = BaseChaseSpeed * BattleFuryMul;
		TargetTurnSpeed   = BaseTurnSpeed  * BattleFuryMul;
		StunCheckTimeInSeconds = BaseStunCheckTimeInSeconds * BattleFuryMul;
		StunDamage = TargetStunDamage;
	}
}
////////////////////////////////////////////////////////////////////// MOVEMENT