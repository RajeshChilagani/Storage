// Fill out your copyright notice in the Description page of Project Settings.


#include "Character/ANMainCharacter.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "Components/AudioComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SpotLightComponent.h"
#include "Engine/DataTable.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/SpringArmComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystemComponent.h"
#include "PhysicsEngine/PhysicsConstraintComponent.h"

#include "ANDefines.h"

#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Interface/ANInteractable.h"
#include "Interface/ANSelectable.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/Player/ANDynamicCrosshairWidget.h"

////////////////////////////////////////////////////////////////////// INIT
AANMainCharacter::AANMainCharacter()
	: Super()
{
	// Spring Arm
	HeadSpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("HeadSpringArm"));
	HeadSpringArm->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	HeadSpringArm->bUsePawnControlRotation = true;
	HeadSpringArm->bInheritPitch = true;
	HeadSpringArm->bInheritYaw = true;
	HeadSpringArm->bInheritRoll = false;

	// PhysicsConstraint
	BodyPhysicsComp = CreateDefaultSubobject<UPhysicsConstraintComponent>(TEXT("BodyPhysicsConstraint"));
	BodyPhysicsComp->SetupAttachment(RootComponent);

	// Camera
	HeadCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("HeadCamera"));
	HeadCamera->SetupAttachment(HeadSpringArm, USpringArmComponent::SocketName);
	HeadCamera->bUsePawnControlRotation = false;

	// SpotLight
	FlashLightSpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("FlashLightSpringArm"));
	FlashLightSpringArm->SetupAttachment(HeadCamera);
	FlashLightSpringArm->bEnableCameraRotationLag = true;
	
	FlashLight = CreateDefaultSubobject<USpotLightComponent>(TEXT("FlashLight"));
	FlashLight->SetupAttachment(FlashLightSpringArm, USpringArmComponent::SocketName);

	BounceLight = CreateDefaultSubobject<USpotLightComponent>(TEXT("BounceLight"));
	BounceLight->SetupAttachment(FlashLightSpringArm, USpringArmComponent::SocketName);

	// VFX
	VFXContainer = CreateDefaultSubobject<USceneComponent>(TEXT("VFXContainer"));
	VFXContainer->SetupAttachment(RootComponent);

	BubblesVFX_Left = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("BubblesVFX_Left"));
	BubblesVFX_Left->SetupAttachment(VFXContainer);
	BubblesVFX_Left->SetRelativeLocation(FVector(10.0f, -5.0f, 0.0f));
	BubblesVFX_Left->SetRelativeRotation(FRotator(0.0f, 0.0f, -90.0f));
	BubblesVFX_Left->SetRelativeScale3D(FVector(0.5f, 0.5f, 0.5f));

	BubblesVFX_Right = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("BubblesVFX_Right"));
	BubblesVFX_Right->SetupAttachment(VFXContainer);
	BubblesVFX_Right->SetRelativeLocation(FVector(10.0f, 5.0f, 0.0f));
	BubblesVFX_Right->SetRelativeRotation(FRotator(0.0f, 0.0f, 90.0f));
	BubblesVFX_Right->SetRelativeScale3D(FVector(0.5f, 0.5f, 0.5f));
	
	AmbientDust = CreateDefaultSubobject<UParticleSystemComponent>(TEXT("AmbientDust"));
	AmbientDust->SetupAttachment(RootComponent);

	// General config
	ControllerAimVerticalSensitivity = 40.0f;
	ControllerAimHorizontalSensitivity = 80.0f;

	bUseControllerRotationPitch = false;
	bUseControllerRotationRoll = false;
	bUseControllerRotationYaw = false;


	//Set defaults from CharacterBase
	MaxHealth = 3;
	CurrentHealth = 3;

	//Set defaults
	CurrentO2Time = 10.0f;
	MaxO2Time = 300.0f;
	bIsO2Refilling = false;
	O2RefillRate = 10.0f;

	MediumO2WarningTime = 100.0f;
	bDisplayedMediumO2Warning = false;
	LowO2WarningTime = 30.0f;
	bDisplayedLowO2Warning = false;

	MaxSuffocationTime = 30.0f;
	CurrentSuffocationTime = 30.0f;
	bDisplayedSuffocationWarning = false;

	SignalLocation = FVector(-5774.0f, -8632.0f, -6142.0f);
	SignalUpdateTimeSeconds = 0.5f;

	bInfiniteOxygen = false;

	bIsADS = false;
	bIsFiringPrimary = false;
	bHasHarpoonGun = false;
	CrosshairSpreadModifier = 0.25f;
	CrosshairMaxSpread = 80.0f;

	bViewingWatch = false;

	InteractionRange = 250.0f;
	CurrentLookingAtInteractable = nullptr;
	CurrentInteractingInteractable = nullptr;
	bInteracting = false;

	bInventoryOpen = false;
	DropItemOffset = FVector(100.0f, 0.0f, 0.0f);

	bInformationOpen = false;

	CameraSensitivity = 1.f;
	LastCameraForwardVector = HeadCamera->GetForwardVector();
	MyCharacterMovement = GetCharacterMovement();
}

void AANMainCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}
////////////////////////////////////////////////////////////////////// INIT



////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK
void AANMainCharacter::BeginPlay()
{
	Super::BeginPlay();

	APlayerCameraManager* playerCameraManager = UGameplayStatics::GetPlayerCameraManager(GetWorld(), 0);
	FlashLightSpringArm->AttachToComponent(playerCameraManager->GetTransformComponent(), FAttachmentTransformRules::KeepRelativeTransform);

	UCharacterMovementComponent* characterMovement = GetCharacterMovement();
	characterMovement->MaxWalkSpeed = WalkSpeedRange.X;
	characterMovement->MaxSwimSpeed = SwimSpeedRange.X;
	CurrentSwimForceResetTime = SwimForceResetTime.Y;
	CurrentO2Time = MaxO2Time;
	CurrentSuffocationTime = MaxSuffocationTime;

	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		FTimerDelegate UpdateSignalTimerDelegate = FTimerDelegate::CreateUObject(this, &AANMainCharacter::UpdateDistanceToSignal);
		MyWorld->GetTimerManager().SetTimer(UpdateSignalTimerHandle, UpdateSignalTimerDelegate, SignalUpdateTimeSeconds, true);
	}

	AddActorToIgnoreInInteractableTrace(this);
}

void AANMainCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	//Lowers oxygen
	HandleO2(DeltaSeconds);

	MyCharacterMovement = GetCharacterMovement();
	if (CanMove())
	{
		switch (MyCharacterMovement->MovementMode)
		{
		case EMovementMode::MOVE_Swimming:
			Tick_SwimmingMovement(DeltaSeconds);
			break;
		case EMovementMode::MOVE_Walking:
			Tick_WalkingMovement(DeltaSeconds);
			break;
		default:
			break;
		}
	}
	Tick_Camera(DeltaSeconds);
	Tick_Other(DeltaSeconds);
	Tick_DynamicCrossHair();
	//Tick_LockerCheck(DeltaSeconds);
	TraceForInteractable();
}
////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK







////////////////////////////////////////////////////////////////////// BODY
void AANMainCharacter::SetBodyPhysicsState(const bool bIsArmed)
{
	USkeletalMeshComponent* meshComp = GetMesh();
	meshComp->SetAllBodiesBelowSimulatePhysics(FName("pelvis"), true, true);
	if (bIsArmed)
	{
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("pelvis"), 0.f);
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("upperarm_l"), 0.f);
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("upperarm_r"), 0.f);
	}
	else
	{
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("pelvis"), 0.f);
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("upperarm_l"), 0.f);
		meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("upperarm_r"), 0.f);
	}

	meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("thigh_l"), 0.0f);
	meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("thigh_r"), 0.0f);
	meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("foot_l"), 1.0f);
	meshComp->SetAllBodiesBelowPhysicsBlendWeight(FName("foot_r"), 1.0f);
}
////////////////////////////////////////////////////////////////////// BODY









////////////////////////////////////////////////////////////////////// INPUT
void AANMainCharacter::SetGameInput(EGameInputTypes NewGameInputType)
{
	if (AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(GetController()))
	{
		PlayerController->SetGameInput(NewGameInputType);
	}
}

bool AANMainCharacter::IsInGameInput() const
{
	if (AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(GetController()))
	{
		return PlayerController->IsInGameInput();
	}

	return false;
}

bool AANMainCharacter::IsInUIInput() const
{
	if (AANPlayerControllerBase* PlayerController = Cast<AANPlayerControllerBase>(GetController()))
	{
		return PlayerController->IsInUIInput();
	}

	return false;
}


// Weapons
void AANMainCharacter::InputAction_Aim_Pressed()
{
	StartADS();
}
void AANMainCharacter::InputAction_Aim_Released()
{
	EndADS();
}

void AANMainCharacter::Tick_DynamicCrossHair()
{
	if (bIsADS)
	{
		if (UWorld* MyWorld = GetWorld())
		{
			float Spread = GetVelocity().Size() + CameraRotationRate.Size() * 100;
			Spread *= CrosshairSpreadModifier;

			float clampedSpread = FMath::Clamp(Spread, 0.0f, CrosshairMaxSpread);

			if (AANPlayerControllerBase* PlayerControllerBase = GetPlayerControllerBase())
			{
				if (UANHUDWidget* HUDWidget = Cast<UANHUDWidget>(PlayerControllerBase->GetHUDWidget()))
				{
					if (UANDynamicCrosshairWidget* DynamicCrosshair = HUDWidget->GetDynamicCrosshairWidget())
					{
						DynamicCrosshair->SetCrossHairSpread(clampedSpread);
					}
				}
			}
		}
	}
}


void AANMainCharacter::InputAction_Fire_Pressed() { bIsFiringPrimary = true; }
void AANMainCharacter::InputAction_Fire_Released() { bIsFiringPrimary = false; }


// Environment Interaction
void AANMainCharacter::InputAction_Interact_Pressed()
{
	TryInteract();
}

void AANMainCharacter::InputAction_Interact_Released()
{

}

// FlashLight
void AANMainCharacter::InputAction_Flashlight_Pressed() 
{ 
	if (FlashLight->IsVisible())
	{
		FlashLight->SetVisibility(false);
		BounceLight->SetVisibility(false);

		bFlashlight = false;
		PostAkAudioEventOnCharacter(FlashlightOffSFX);
	}
	else
	{
		FlashLight->SetVisibility(true);
		BounceLight->SetVisibility(true);
		bFlashlight = true;
		PostAkAudioEventOnCharacter(FlashlightOnSFX);
	}
}

void AANMainCharacter::InputAction_Flashlight_Released() 
{  
}

void AANMainCharacter::TurnOnFlashlight()
{
	FlashLight->SetVisibility(true);
	BounceLight->SetVisibility(true);

	bFlashlight = true;
}

void AANMainCharacter::TurnOffFlashlight()
{
	FlashLight->SetVisibility(false);
	BounceLight->SetVisibility(false);

	bFlashlight = false;
}

void AANMainCharacter::InputAction_Reload_Pressed()
{

}

void AANMainCharacter::InputAction_Reload_Released()
{

}

void AANMainCharacter::InputAction_Inventory_Pressed()
{
	//Only allow inventory to open if we aren't interacting with something (and in some cases, the inventory will be open from another situation)
	if (!bInteracting)
	{
		//Inventory is open, so close it
		if (bInventoryOpen)
		{
			CloseManualInventory();
		}
		//Inventory is closed, so open it
		else
		{
			OpenManualInventory();
		}
	}
}

void AANMainCharacter::InputAction_Inventory_Released()
{

}

void AANMainCharacter::InputAction_Map_Pressed()
{
	//Map/Info is open, so close it
	if (bInformationOpen)
	{
		CloseManualInformation();
	}
	//Map/Info is closed, so open it
	else
	{
		OpenManualInformation();
	}
}

void AANMainCharacter::InputAction_Map_Released()
{

}

void AANMainCharacter::InputAction_AttachmentOne_Pressed()
{

}

void AANMainCharacter::InputAction_AttachmentOne_Released()
{

}

void AANMainCharacter::InputAction_AttachmentTwo_Pressed()
{

}

void AANMainCharacter::InputAction_AttachmentTwo_Released()
{

}

void AANMainCharacter::InputAction_AttachmentThree_Pressed()
{

}

void AANMainCharacter::InputAction_AttachmentThree_Released()
{

}

void AANMainCharacter::InputAction_AttachmentFour_Pressed()
{

}

void AANMainCharacter::InputAction_AttachmentFour_Released()
{

}



// Locomotion
void AANMainCharacter::InputAxis_LSVertical(float AxisValue) { MoveForward(AxisValue); }
void AANMainCharacter::InputAxis_LSHorizontal(float AxisValue) { MoveRight(AxisValue); }

void AANMainCharacter::InputAction_Ascend_Pressed() { MoveUp(1.f); }
void AANMainCharacter::InputAction_Ascend_Released() { MoveUp(0.f); }

void AANMainCharacter::InputAction_Descend_Pressed() { MoveUp(-1.f); }
void AANMainCharacter::InputAction_Descend_Released() { MoveUp(0.f); }

// Camera
void AANMainCharacter::InputAxis_RSVertical(float AxisValue) 
{ 
	if (bInteracting)
	{
		if (CurrentInteractingInteractable)
		{
			CurrentInteractingInteractable->Inspect(AxisValue, EInspectAction::Vertical);
		}
	}
	else
	{
		LookUp_Controller(AxisValue);
	}
}

void AANMainCharacter::InputAxis_RSHorizontal(float AxisValue) 
{
	if (bInteracting)
	{
		if (CurrentInteractingInteractable)
		{
			CurrentInteractingInteractable->Inspect(AxisValue, EInspectAction::Horizontal);
		}
	}
	else
	{
		LookRight_Controller(AxisValue);
	}
}

void AANMainCharacter::InputAxis_MouseVertical(float AxisValue) 
{ 
	if (bInteracting)
	{
		if (CurrentInteractingInteractable)
		{
			CurrentInteractingInteractable->Inspect(AxisValue, EInspectAction::Vertical);
		}
	}
	else
	{
		LookUp_Mouse(AxisValue); 
	}
}

void AANMainCharacter::InputAxis_MouseHorizontal(float AxisValue) 
{ 
	if (bInteracting)
	{
		if (CurrentInteractingInteractable)
		{
			CurrentInteractingInteractable->Inspect(AxisValue, EInspectAction::Horizontal);
		}
	}
	else
	{
		LookRight_Mouse(AxisValue);
	}
}

void AANMainCharacter::InputAxis_MouseWheel(float AxisValue)
{
	if (bInteracting)
	{
		if (CurrentInteractingInteractable)
		{
			CurrentInteractingInteractable->Inspect(AxisValue, EInspectAction::Zoom);
		}
	}
}

////////////////////////////////////////////////////////////////////// INPUT
