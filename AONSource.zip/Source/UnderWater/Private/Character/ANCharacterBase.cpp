// Fill out your copyright notice in the Description page of Project Settings.


#include "Character/ANCharacterBase.h"

#include "AkAudioEvent.h"
#include "AkComponent.h"
#include "AkGameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/ForceFeedbackEffect.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

#include "ANDefines.h"

#include "Controller/ANPlayerControllerBase.h"

// Sets default values
AANCharacterBase::AANCharacterBase()
	: Super()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	CharacterAkComponent = CreateDefaultSubobject<UAkComponent>(TEXT("CharacterAkComponent"));
	CharacterAkComponent->SetupAttachment(RootComponent);

	MaxHealth = 1;
	bAlive = true;
	CurrentHealth = 0;
}

// Called when the game starts or when spawned
void AANCharacterBase::BeginPlay()
{
	Super::BeginPlay();

	if (GetWorld())
	{
		WorldRef = GetWorld();
	}

	//If current health has not been set, set to max health
	if (CurrentHealth <= 0)
	{
		CurrentHealth = MaxHealth;
	}
}

// Called every frame
void AANCharacterBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void AANCharacterBase::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	//Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void AANCharacterBase::ProcessInput(EANInputActions ANInputAction, EInputEvent InputEvent)
{
	//Follow the below format when setting up for a base class
	switch (InputEvent)
	{
	case(EInputEvent::IE_Pressed):
		switch (ANInputAction)
		{
		case(EANInputActions::Fire):
			InputAction_Fire_Pressed();
			break;
		case(EANInputActions::Aim):
			InputAction_Aim_Pressed();
			break;
		case(EANInputActions::Interact):
			InputAction_Interact_Pressed();
			break;
		case(EANInputActions::Flashlight):
			InputAction_Flashlight_Pressed();
			break;
		case(EANInputActions::Reload):
			InputAction_Reload_Pressed();
			break;
		case(EANInputActions::Jet):
			InputAction_Jet_Pressed();
			break;
		case(EANInputActions::Ascend):
			InputAction_Ascend_Pressed();
			break;
		case(EANInputActions::Descend):
			InputAction_Descend_Pressed();
			break;
		case(EANInputActions::Inventory):
			InputAction_Inventory_Pressed();
			break;
		case(EANInputActions::Map):
			InputAction_Map_Pressed();
			break;
		case(EANInputActions::AttachmentOne):
			InputAction_AttachmentOne_Pressed();
			break;
		case(EANInputActions::AttachmentTwo):
			InputAction_AttachmentTwo_Pressed();
			break;
		case(EANInputActions::AttachmentThree):
			InputAction_AttachmentThree_Pressed();
			break;
		case(EANInputActions::AttachmentFour):
			InputAction_AttachmentFour_Pressed();
			break;

		default:
			break;
		}
		break;
	case(EInputEvent::IE_Released):
		switch (ANInputAction)
		{
		case(EANInputActions::Fire):
			InputAction_Fire_Released();
			break;
		case(EANInputActions::Aim):
			InputAction_Aim_Released();
			break;
		case(EANInputActions::Interact):
			InputAction_Interact_Released();
			break;
		case(EANInputActions::Flashlight):
			InputAction_Flashlight_Released();
			break;
		case(EANInputActions::Reload):
			InputAction_Reload_Released();
			break;
		case(EANInputActions::Jet):
			InputAction_Jet_Released();
			break;
		case(EANInputActions::Ascend):
			InputAction_Ascend_Released();
			break;
		case(EANInputActions::Descend):
			InputAction_Descend_Released();
			break;
		case(EANInputActions::Inventory):
			InputAction_Inventory_Released();
			break;
		case(EANInputActions::Map):
			InputAction_Map_Released();
			break;
		case(EANInputActions::AttachmentOne):
			InputAction_AttachmentOne_Released();
			break;
		case(EANInputActions::AttachmentTwo):
			InputAction_AttachmentTwo_Released();
			break;
		case(EANInputActions::AttachmentThree):
			InputAction_AttachmentThree_Released();
			break;
		case(EANInputActions::AttachmentFour):
			InputAction_AttachmentFour_Released();
			break;

		default:
			break;
		}
		break;
	default:
		break;
	}
}

void AANCharacterBase::ProcessAxis(EANInputAxes ANInputAxis, float AxisValue)
{
	switch (ANInputAxis)
	{
	case(EANInputAxes::LSVertical):
		InputAxis_LSVertical(AxisValue);
		break;
	case(EANInputAxes::LSHorizontal):
		InputAxis_LSHorizontal(AxisValue);
		break;
	case(EANInputAxes::RSVertical):
		InputAxis_RSVertical(AxisValue);
		break;
	case(EANInputAxes::RSHorizontal):
		InputAxis_RSHorizontal(AxisValue);
		break;
	case(EANInputAxes::MouseVertical):
		InputAxis_MouseVertical(AxisValue);
		break;
	case(EANInputAxes::MouseHorizontal):
		InputAxis_MouseHorizontal(AxisValue);
		break;
	case(EANInputAxes::MouseWheel):
		InputAxis_MouseWheel(AxisValue);
		break;
	default:
		break;
	}
}

void AANCharacterBase::InputAction_Fire_Pressed()
{
	
}

void AANCharacterBase::InputAction_Fire_Released()
{

}

void AANCharacterBase::InputAction_Aim_Pressed()
{
	Print("Aim test.");
}

void AANCharacterBase::InputAction_Aim_Released()
{

}

void AANCharacterBase::InputAction_Interact_Pressed()
{

}

void AANCharacterBase::InputAction_Interact_Released()
{

}

void AANCharacterBase::InputAction_Flashlight_Pressed()
{

}

void AANCharacterBase::InputAction_Flashlight_Released()
{

}

void AANCharacterBase::InputAction_Reload_Pressed()
{

}

void AANCharacterBase::InputAction_Reload_Released()
{

}

void AANCharacterBase::InputAction_Jet_Pressed()
{

}

void AANCharacterBase::InputAction_Jet_Released()
{

}

void AANCharacterBase::InputAction_Ascend_Pressed()
{

}

void AANCharacterBase::InputAction_Ascend_Released()
{

}

void AANCharacterBase::InputAction_Descend_Pressed()
{

}

void AANCharacterBase::InputAction_Descend_Released()
{

}

void AANCharacterBase::InputAction_Inventory_Pressed()
{

}

void AANCharacterBase::InputAction_Inventory_Released()
{

}

void AANCharacterBase::InputAction_Map_Pressed()
{

}

void AANCharacterBase::InputAction_Map_Released()
{

}

void AANCharacterBase::InputAction_AttachmentOne_Pressed()
{

}

void AANCharacterBase::InputAction_AttachmentOne_Released()
{

}

void AANCharacterBase::InputAction_AttachmentTwo_Pressed()
{

}

void AANCharacterBase::InputAction_AttachmentTwo_Released()
{

}

void AANCharacterBase::InputAction_AttachmentThree_Pressed()
{

}

void AANCharacterBase::InputAction_AttachmentThree_Released()
{

}

void AANCharacterBase::InputAction_AttachmentFour_Pressed()
{

}

void AANCharacterBase::InputAction_AttachmentFour_Released()
{

}

void AANCharacterBase::InputAxis_LSVertical(float AxisValue)
{
	
}

void AANCharacterBase::InputAxis_LSHorizontal(float AxisValue)
{

}

void AANCharacterBase::InputAxis_RSVertical(float AxisValue)
{

}

void AANCharacterBase::InputAxis_RSHorizontal(float AxisValue)
{

}

void AANCharacterBase::InputAxis_MouseVertical(float AxisValue)
{

}

void AANCharacterBase::InputAxis_MouseHorizontal(float AxisValue)
{

}

void AANCharacterBase::InputAxis_MouseWheel(float AxisValue)
{

}

void AANCharacterBase::SetViewTargetWithBlend(AActor* NewBlendTarget)
{
	if (APlayerController* PlayerController = Cast<APlayerController>(GetController()))
	{
		PlayerController->SetViewTargetWithBlend(NewBlendTarget);
	}
}


void AANCharacterBase::MoveCharacter(float XValue, float YValue)
{
	//Need to make sure we can actually move
	if (!CanMove())
	{
		return;
	}

	FRotator NewRotator(0.0f, GetControlRotation().Yaw, 0.0f);
	FVector WorldDirectionForward = UKismetMathLibrary::GetForwardVector(NewRotator);
	FVector WorldDirectionRight = UKismetMathLibrary::GetRightVector(NewRotator);

	AddMovementInput(WorldDirectionForward, YValue);
	AddMovementInput(WorldDirectionRight, XValue);
}

bool AANCharacterBase::CanMove() const
{
	//Need to change to this to proper variable checking
	//if (bAlive && !bAttacking && !bDodging && !GetCharacterMovement()->IsFalling())
	if (bAlive)
	{
		return true;
	}

	return false;
}

void AANCharacterBase::PreventPauseIssues()
{

}

void AANCharacterBase::ReceiveDamage(int32 DamageReceived)
{
	CurrentHealth -= DamageReceived;
	UAkGameplayStatics::PostEvent(ReceiveDamageSFX, this, 0, FOnAkPostEventCallback());

	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr && BloodVFX != nullptr)
	{
		UGameplayStatics::SpawnEmitterAtLocation(MyWorld, BloodVFX, GetActorLocation());
	}

	if (CurrentHealth <= 0)
	{
		CurrentHealth = 0;
		Die();
	}

	OnCharacterUpdateHealthUI.Broadcast(this, CurrentHealth, MaxHealth);

	//TODO: If we want to re-introduce auto-recovering health, do it here
}

void AANCharacterBase::SetHealth(int32 NewHealthValue)
{
	CurrentHealth = NewHealthValue;

	if (CurrentHealth <= 0)
	{
		CurrentHealth = 1;
	}
	else if (CurrentHealth > MaxHealth)
	{
		CurrentHealth = MaxHealth;
	}

	OnCharacterUpdateHealthUI.Broadcast(this, CurrentHealth, MaxHealth);
}

void AANCharacterBase::RecoverHealth(int32 HealthRecovered)
{
	CurrentHealth += HealthRecovered;

	if (CurrentHealth > MaxHealth)
	{
		CurrentHealth = MaxHealth;
	}

	OnCharacterUpdateHealthUI.Broadcast(this, CurrentHealth, MaxHealth);
}

void AANCharacterBase::ResetHealthTimer()
{
	OnTakeDamageReset.Broadcast();
}

void AANCharacterBase::StartHealthResetCoolDown()
{
	if (GetWorld()->GetTimerManager().IsTimerActive(HealthResetTimerHandle))
	{
		GetWorld()->GetTimerManager().ClearTimer(HealthResetTimerHandle);
		
	}
	GetWorldTimerManager().SetTimer(HealthResetTimerHandle, this, &AANCharacterBase::ResetHealthTimer, TimeToResetDamage, false);

}

void AANCharacterBase::Die()
{
	//if already dead, do not post death again
	if (!bAlive)
	{
		return;
	}

	Print("Character died!");
	bAlive = false;
	if (DieSFX != nullptr)
	{
		PostAkAudioEventOnCharacter(DieSFX);
	}
	OnCharacterDeath.Broadcast(this);
}

void AANCharacterBase::PlayRumble(UForceFeedbackEffect* RumbleEffect, const FName& RumbleTag, bool bLooping)
{
	if (APlayerController* PlayerController = Cast<APlayerController>(GetController()))
	{
		FForceFeedbackParameters RumbleParams;
		RumbleParams.bLooping = bLooping;
		RumbleParams.Tag = RumbleTag;
		PlayerController->ClientPlayForceFeedback(RumbleEffect, RumbleParams);
	}
}

void AANCharacterBase::StopRumble(UForceFeedbackEffect* RumbleEffect, const FName& RumbleTag)
{
	if (APlayerController* PlayerController = Cast<APlayerController>(GetController()))
	{
		PlayerController->ClientStopForceFeedback(RumbleEffect, RumbleTag);
	}
}

void AANCharacterBase::PostAkAudioEventOnCharacter(UAkAudioEvent* AudioEvent)
{
	if (AudioEvent == nullptr || CharacterAkComponent == nullptr)
	{
		return;
	}

	CharacterAkComponent->PostAkEvent(AudioEvent, 0, FOnAkPostEventCallback(), FString());
}