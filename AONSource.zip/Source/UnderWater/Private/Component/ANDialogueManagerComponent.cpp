// Fill out your copyright notice in the Description page of Project Settings.


#include "Component/ANDialogueManagerComponent.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"

#include "ANDefines.h"
#include "ANStructs.h"

#include "Audio/ANDialogueConversation.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Shared/ANFunctionLibrary.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/HUD/ANMessagesHUDWidget.h"

static int32 NextDialogueID = 0;

UANDialogueManagerComponent::UANDialogueManagerComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UANDialogueManagerComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UANDialogueManagerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UANDialogueManagerComponent::AddNewDialogueConversation(UANDialogueConversation* NewDialogueConversation)
{
	if (NewDialogueConversation == nullptr)
	{
		return;
	}

	//If we can overlap, automatically add to the active dialogues
	if (NewDialogueConversation->CanOverlap())
	{
		StartNewDialogueConversation(NewDialogueConversation);
		return;
	}

	//If we are already playing a dialogue, add to our queued list
	if (IsPlayingDialogue())
	{
		QueuedDialogueConversations.Add(NewDialogueConversation);
		return;
	}
	else
	{
		//Otherwise, we can start right away
		StartNewDialogueConversation(NewDialogueConversation);
		return;
	}
}

void UANDialogueManagerComponent::StartNewDialogueConversation(UANDialogueConversation* NewDialogueConversation)
{
	if (NewDialogueConversation == nullptr)
	{
		return;
	}

	FActiveDialogueConversationData NewActiveDialogueConversationData = FActiveDialogueConversationData(NextDialogueID, NewDialogueConversation);
	NextDialogueID++;

	ActiveDialogueConversationDatas.Add(NewActiveDialogueConversationData);

	AdvanceDialogue(NewActiveDialogueConversationData.GetActiveDialogueID());
}

void UANDialogueManagerComponent::AdvanceDialogue(int32 DialogueConversationID)
{
	FActiveDialogueConversationData& ActiveDialogueConversationData = GetActiveDialogueConversationDataForID(DialogueConversationID);

	if (ActiveDialogueConversationData.ActiveDialogueConversation == nullptr)
	{
		Print("No active dialogue conversation! Removing.");
		ActiveDialogueConversationDatas.Remove(ActiveDialogueConversationData);
		return;
	}
	
	AANPlayerControllerBase* OwningPlayerController = Cast<AANPlayerControllerBase>(GetOwner());
	if (OwningPlayerController == nullptr)
	{
		Print("Invalid player controller/owner.");
		return;
	}
	
	ActiveDialogueConversationData.ActiveDialogueLineIndex++;
	if (ActiveDialogueConversationData.ActiveDialogueConversation->GetDialogueLines().IsValidIndex(ActiveDialogueConversationData.ActiveDialogueLineIndex))
	{
		//Don't use address here, the soft object can make the address stale
		FDialogueLine ActiveDialogueLine = ActiveDialogueConversationData.ActiveDialogueConversation->GetDialogueLines()[ActiveDialogueConversationData.ActiveDialogueLineIndex];
	
		//If the dialogue has a negative timer, skip it and go to the next one
		if (ActiveDialogueLine.DialogueTime <= 0.0f)
		{
			AdvanceDialogue(ActiveDialogueConversationData.GetActiveDialogueID());
			return;
		}
	
		//Play SFX event
		if (UANFunctionLibrary::LoadSoftObject(ActiveDialogueLine.DialogueAudio))
		{
			UAkGameplayStatics::PostEventAttached(ActiveDialogueLine.DialogueAudio.Get(), OwningPlayerController->GetPawn());
		}
	
		//Show subtitles
		if (UANMessagesHUDWidget* MessagesHUDWidget = OwningPlayerController->GetMessagesHUDWidget())
		{
			MessagesHUDWidget->BP_AddMessage(ActiveDialogueLine.DialogueText, ActiveDialogueLine.DialogueTime, ActiveDialogueLine.DialogueColor);
		}
	
		//Recursively call the next line
		if (UWorld* MyWorld = GetWorld())
		{
			FTimerDelegate AdvanceDialogueTimerDelegate = FTimerDelegate::CreateUObject(this, &UANDialogueManagerComponent::AdvanceDialogue, ActiveDialogueConversationData.GetActiveDialogueID());
			MyWorld->GetTimerManager().SetTimer(ActiveDialogueConversationData.ActiveDialogueTimerHandle, AdvanceDialogueTimerDelegate, ActiveDialogueLine.DialogueTime, false);
			Print("set timer");
		}
	}
	else
	{
		//End dialogue if the index for the event is not valid, means we have done all the lines
		EndDialogueConversation(ActiveDialogueConversationData.GetActiveDialogueID());
	}
}

void UANDialogueManagerComponent::EndDialogueConversation(int32 DialogueConversationID)
{
	FActiveDialogueConversationData& ActiveDialogueConversationData = GetActiveDialogueConversationDataForID(DialogueConversationID);

	//Notify that we have finished the specified dialogue conversation
	OnDialogueConversationFinished.Broadcast(ActiveDialogueConversationData.ActiveDialogueConversation);

	//Remove from the list of active dialogues
	int32 RemoveIndex = GetArrayIndexForID(ActiveDialogueConversationData.GetActiveDialogueID());
	if (ActiveDialogueConversationDatas.IsValidIndex(RemoveIndex))
	{
		ActiveDialogueConversationDatas.RemoveAt(RemoveIndex);
	}

	//If we have any queued dialogue conversations, start the first and remove it from the list
	if (QueuedDialogueConversations.Num() > 0)
	{
		StartNewDialogueConversation(QueuedDialogueConversations[0]);
		QueuedDialogueConversations.RemoveAt(0);
	}
}

FActiveDialogueConversationData& UANDialogueManagerComponent::GetActiveDialogueConversationDataForID(int32 ActiveDialogueID)
{
	for (FActiveDialogueConversationData& ActiveDialogueConversationData : ActiveDialogueConversationDatas)
	{
		if (ActiveDialogueConversationData.GetActiveDialogueID() == ActiveDialogueID)
		{
			return ActiveDialogueConversationData;
		}
	}

	return InvalidDialogueConversationData;
}

int32 UANDialogueManagerComponent::GetArrayIndexForID(int32 ActiveDialogueID)
{
	for (int32 i = 0; i < ActiveDialogueConversationDatas.Num(); i++)
	{
		if (ActiveDialogueConversationDatas[i].GetActiveDialogueID() == ActiveDialogueID)
		{
			return i;
		}
	}

	return INDEX_NONE;
}


bool UANDialogueManagerComponent::IsPlayingDialogue() const
{
	for (const FActiveDialogueConversationData& ActiveDialogueConversationData : ActiveDialogueConversationDatas)
	{
		if (UANDialogueConversation* DialogueConversation = ActiveDialogueConversationData.ActiveDialogueConversation)
		{
			return true;
		}
	}

	return false;
}