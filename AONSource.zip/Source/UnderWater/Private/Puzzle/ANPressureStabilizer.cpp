// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANPressureStabilizer.h"
#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Puzzle/ANOxygenStation.h"
#include "Components/WidgetComponent.h"

bool AANPressureStabilizer::CanInteract() const
{
	return !bInteracting && !IsPuzzleComplete();
}
void AANPressureStabilizer::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		//Long interact
		MainCharacter->SetViewTargetWithBlend(this);
		MainCharacter->SetGameInput(EGameInputTypes::UIOnly);
		MainCharacter->SetActorHiddenInGame(true); //Hide character in case they would block the camera

		bInteracting = true;
		bPuzzleCameraActive = true;
	}

}

void AANPressureStabilizer::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		MainCharacter->SetViewTargetWithBlend(MainCharacter);
		MainCharacter->SetGameInput(EGameInputTypes::GameOnly);
		MainCharacter->SetActorHiddenInGame(false); //Unhide the character

		bInteracting = false;
		bPuzzleCameraActive = false;
		MainCharacter->TryEndInteract();
		//Make the player interact with the oxygen station
		MainCharacter->ManualInteract(OxygenStationRef);
	}
}

bool AANPressureStabilizer::IsLongInteract() const
{
	return true;
}

bool AANPressureStabilizer::IsInteracting() const
{
	return bInteracting;
}
