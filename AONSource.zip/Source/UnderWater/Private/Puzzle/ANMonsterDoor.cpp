// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANMonsterDoor.h"

#include "Components/SceneComponent.h"

AANMonsterDoor::AANMonsterDoor()
	: Super()
{
	MonsterDoorRootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("MonsterDoorRootComponent"));
	RootComponent = MonsterDoorRootComponent;

	StartPulseScale = FVector(1.5f, 1.5f, 3.0f);
	EndPulseScale = FVector(1.5f, 1.5f, 4.0f);
	PulseTimeSeconds = 1.0f;
	DiminishScale = FVector(0.0f, 0.0f, 0.0f);
	DiminishTimeSeconds = 1.0f;

	bPulseReversing = false;
	CurrentTimeSeconds = 0.0f;
	CurrentScale = FVector(0.0f, 0.0f, 0.0f);
	bDiminishing = false;
	ScaleAtDiminshStart = FVector(0.0f, 0.0f, 0.0f);
}

void AANMonsterDoor::BeginPlay()
{
	Super::BeginPlay();
}

void AANMonsterDoor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	CurrentTimeSeconds += DeltaTime;

	if (!IsPuzzleComplete())
	{
		float Alpha = CurrentTimeSeconds / PulseTimeSeconds;

		if (!bPulseReversing)
		{
			CurrentScale = FMath::Lerp(StartPulseScale, EndPulseScale, Alpha);
		}
		else
		{
			CurrentScale = FMath::Lerp(EndPulseScale, StartPulseScale, Alpha);
		}

		BP_UpdateScale(CurrentScale);

		if (CurrentTimeSeconds > PulseTimeSeconds)
		{
			CurrentTimeSeconds = 0.0f;
			bPulseReversing = !bPulseReversing;
		}
	}
	else
	{
		if (bDiminishing)
		{
			float Alpha = CurrentTimeSeconds / DiminishTimeSeconds;

			CurrentScale = FMath::Lerp(ScaleAtDiminshStart, DiminishScale, Alpha);
			BP_UpdateScale(CurrentScale);

			if (CurrentTimeSeconds > DiminishTimeSeconds)
			{
				CurrentTimeSeconds = 0.0f;
				bDiminishing = false;
				BP_EndDiminish();
			}
		}
	}
}

void AANMonsterDoor::CompletePuzzle_Implementation(bool bInstantComplete)
{
	if (IsPuzzleComplete())
	{
		return;
	}

	if (!bInstantComplete)
	{
		bDiminishing = true;
		ScaleAtDiminshStart = CurrentScale;
		CurrentTimeSeconds = 0.0f;
	}
	else
	{
		BP_EndDiminish();
	}

	AANPuzzleObjectBase::CompletePuzzle_Implementation(bInstantComplete);
}

void AANMonsterDoor::ReceiveDamage(int32 DamageAmount)
{
	if (DamageAmount <= 0 || IsPuzzleComplete())
	{
		return;
	}

	CompletePuzzle(false);
}