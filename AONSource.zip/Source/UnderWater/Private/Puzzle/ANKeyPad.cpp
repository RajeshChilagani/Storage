// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANKeyPad.h"

#include "Components/ChildActorComponent.h"
#include "Components/DecalComponent.h"
#include "Components/StaticMeshComponent.h"

#include "ANConsts.h"
#include "ANDefines.h"
#include "ANEnums.h"

#include "Interface/ANSelectable.h"
#include "Puzzle/ANKeyButton.h"
#include "Shared/ANFunctionLibrary.h"

#define NUM_LOCK_LENGTH 4

// Sets default values
AANKeyPad::AANKeyPad()
	: Super()
{
	//Set up root
	KeyPadRoot = CreateDefaultSubobject<USceneComponent>(TEXT("KeyPadRoot"));
	RootComponent = KeyPadRoot;

	//Set up key pad mesh
	KeyPadMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("KeyPadMesh"));
	//KeyButtonMesh->SetRelativeLocation(FVector(0.0f, 0.0f, -50.0f));
	//KeyButtonMesh->SetRelativeRotation(FRotator(-10.0f, 0.0f, 0.0f));
	//KeyButtonMesh->SetGenerateOverlapEvents(false);
	//KeyButtonMesh->SetCollisionProfileName(CollisionProfiles::InteractableObject);
	KeyPadMesh->SetupAttachment(RootComponent); //Need to attach in order for transform variables to show


	//Create the keys
	CA_OneKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_OneKeyButton"));
	CA_OneKeyButton->SetRelativeLocation(FVector(1.0f, 8.0f, 8.0f));
	CA_OneKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_OneKeyButton->SetupAttachment(KeyPadMesh);

	CA_TwoKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_TwoKeyButton"));
	CA_TwoKeyButton->SetRelativeLocation(FVector(1.0f, 0.0f, 8.0f));
	CA_TwoKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_TwoKeyButton->SetupAttachment(KeyPadMesh);

	CA_ThreeKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_ThreeKeyButton"));
	CA_ThreeKeyButton->SetRelativeLocation(FVector(1.0f, -8.0f, 8.0f));
	CA_ThreeKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_ThreeKeyButton->SetupAttachment(KeyPadMesh);

	CA_FourKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_FourKeyButton"));
	CA_FourKeyButton->SetRelativeLocation(FVector(1.0f, 8.0f, 0.0f));
	CA_FourKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_FourKeyButton->SetupAttachment(KeyPadMesh);

	CA_FiveKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_FiveKeyButton"));
	CA_FiveKeyButton->SetRelativeLocation(FVector(1.0f, 0.0f, 0.0f));
	CA_FiveKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_FiveKeyButton->SetupAttachment(KeyPadMesh);

	CA_SixKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_SixKeyButton"));
	CA_SixKeyButton->SetRelativeLocation(FVector(1.0f, -8.0f, 0.0f));
	CA_SixKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_SixKeyButton->SetupAttachment(KeyPadMesh);

	CA_SevenKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_SevenKeyButton"));
	CA_SevenKeyButton->SetRelativeLocation(FVector(1.0f, 8.0f, -8.0f));
	CA_SevenKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_SevenKeyButton->SetupAttachment(KeyPadMesh);

	CA_EightKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_EightKeyButton"));
	CA_EightKeyButton->SetRelativeLocation(FVector(1.0f, 0.0f, -8.0f));
	CA_EightKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_EightKeyButton->SetupAttachment(KeyPadMesh);

	CA_NineKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_NineKeyButton"));
	CA_NineKeyButton->SetRelativeLocation(FVector(1.0f, -8.0f, -8.0f));
	CA_NineKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_NineKeyButton->SetupAttachment(KeyPadMesh);

	CA_XKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_XKeyButton"));
	CA_XKeyButton->SetRelativeLocation(FVector(1.0f, 8.0f, -16.0f));
	CA_XKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_XKeyButton->SetupAttachment(KeyPadMesh);

	CA_ZeroKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_ZeroKeyButton"));
	CA_ZeroKeyButton->SetRelativeLocation(FVector(1.0f, 0.0f, -16.0f));
	CA_ZeroKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_ZeroKeyButton->SetupAttachment(KeyPadMesh);

	CA_EnterKeyButton = CreateDefaultSubobject<UChildActorComponent>(TEXT("CA_EnterKeyButton"));
	CA_EnterKeyButton->SetRelativeLocation(FVector(1.0f, -8.0f, -16.0f));
	CA_EnterKeyButton->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f));
	CA_EnterKeyButton->SetupAttachment(KeyPadMesh);


	//Get key button class
	//TSubclassOf<AActor> KeyButtonClass;
	//UBlueprint* GeneratedBlueprint = UANFunctionLibrary::GetBlueprint(FilePaths::KeyButton_BP_Path);
	//if (GeneratedBlueprint != nullptr && GeneratedBlueprint->GeneratedClass != nullptr)
	//{
	//	if (KeyButtonClass = GeneratedBlueprint->GeneratedClass)
	//	{
	//		CA_ZeroKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_OneKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_TwoKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_ThreeKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_FourKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_FiveKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_SixKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_SevenKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_EightKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_NineKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_XKeyButton->SetChildActorClass(KeyButtonClass);
	//		CA_EnterKeyButton->SetChildActorClass(KeyButtonClass);
	//	}
	//}

	//Create decal components for the current code
	CurrentCodeSlotOneDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("CurrentCodeSlotOneDecal"));
	CurrentCodeSlotOneDecal->SetRelativeLocation(FVector(1.0f, 6.0f, 16.0f));
	CurrentCodeSlotOneDecal->SetRelativeRotation(FRotator(180.0f, 0.0f, -90.0f));
	CurrentCodeSlotOneDecal->DecalSize = FVector(2.0f, 2.0f, 2.0f);
	CurrentCodeSlotOneDecal->SetupAttachment(KeyPadMesh);

	CurrentCodeSlotTwoDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("CurrentCodeSlotTwoDecal"));
	CurrentCodeSlotTwoDecal->SetRelativeLocation(FVector(1.0f, 2.0f, 16.0f));
	CurrentCodeSlotTwoDecal->SetRelativeRotation(FRotator(180.0f, 0.0f, -90.0f));
	CurrentCodeSlotTwoDecal->DecalSize = FVector(2.0f, 2.0f, 2.0f);
	CurrentCodeSlotTwoDecal->SetupAttachment(KeyPadMesh);

	CurrentCodeSlotThreeDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("CurrentCodeSlotThreeDecal"));
	CurrentCodeSlotThreeDecal->SetRelativeLocation(FVector(1.0f, -2.0f, 16.0f));
	CurrentCodeSlotThreeDecal->SetRelativeRotation(FRotator(180.0f, 0.0f, -90.0f));
	CurrentCodeSlotThreeDecal->DecalSize = FVector(2.0f, 2.0f, 2.0f);
	CurrentCodeSlotThreeDecal->SetupAttachment(KeyPadMesh);

	CurrentCodeSlotFourDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("CurrentCodeSlotFourDecal"));
	CurrentCodeSlotFourDecal->SetRelativeLocation(FVector(1.0f, -6.0f, 16.0f));
	CurrentCodeSlotFourDecal->SetRelativeRotation(FRotator(180.0f, 0.0f, -90.0f));
	CurrentCodeSlotFourDecal->DecalSize = FVector(2.0f, 2.0f, 2.0f);
	CurrentCodeSlotFourDecal->SetupAttachment(KeyPadMesh);

}

// Called when the game starts or when spawned
void AANKeyPad::BeginPlay()
{
	Super::BeginPlay();
	
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_OneKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_TwoKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_ThreeKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_FourKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_FiveKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_SixKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_SevenKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_EightKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_NineKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_XKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_ZeroKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
	if (AANKeyButton* KeyButton = Cast<AANKeyButton>(CA_EnterKeyButton->GetChildActor()))
	{
		KeyButton->AssignKeyPad(this);
		KeyButtons.Add(KeyButton);
	}
}

// Called every frame
void AANKeyPad::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AANKeyPad::AddNumber(FString NewNumber)
{
	if (CurrentUnlockCode.Len() < NUM_LOCK_LENGTH)
	{
		CurrentUnlockCode.Append(NewNumber);
		BP_UpdateNumberOnPanel();
	}

	//if (CurrentUnlockCode.Len() == NUM_LOCK_LENGTH)
	//{
	//	if (CheckNumber())
	//	{
	//		CompletePuzzle();
	//	}
	//}
}

void AANKeyPad::DeleteNumber()
{
	if (CurrentUnlockCode.Len() > 0)
	{
		CurrentUnlockCode = CurrentUnlockCode.LeftChop(1);
		BP_UpdateNumberOnPanel();
	}
}

void AANKeyPad::ConfirmNumber()
{
	if (CheckNumber())
	{
		Print("Number correct!");
		CompletePuzzle(false);
	}
}

bool AANKeyPad::CheckNumber() const
{
	if (CurrentUnlockCode.Equals(UnlockCode))
	{
		return true;
	}

	return false;
}

TArray<IANSelectable*> AANKeyPad::GetAllKeyButtonsAsSelectables() const
{
	TArray<IANSelectable*> KeyButtonSelectables;
	for (int32 i = 0; i < KeyButtons.Num(); i++)
	{
		if (IANSelectable* KeyButtonSelectable = Cast<IANSelectable>(KeyButtons[i]))
		{
			KeyButtonSelectables.Add(KeyButtonSelectable);
		}
	}

	return KeyButtonSelectables;
}

TArray<TArray<IANSelectable*>> AANKeyPad::GetAllKeyButtonsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;
	TArray<IANSelectable*> RowSelectables;

	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_OneKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_TwoKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_ThreeKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_FourKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_FiveKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_SixKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_SevenKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_EightKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_NineKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_XKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_ZeroKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	if (IANSelectable* Selectable = Cast<IANSelectable>(Cast<AANKeyButton>(CA_EnterKeyButton->GetChildActor())))
	{
		RowSelectables.Add(Selectable);
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	return AllSelectables;
}

void AANKeyPad::AssignUnlockCode(const FString& NewUnlockCode)
{
	UnlockCode = NewUnlockCode;
}