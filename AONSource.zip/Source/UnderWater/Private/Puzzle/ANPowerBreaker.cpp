// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANPowerBreaker.h"

#include "ANConsts.h"

#include "Interface/ANPowerable.h"

AANPowerBreaker::AANPowerBreaker()
	: Super()
{

}

void AANPowerBreaker::AlterPowerState()
{
	if (bPowerStateOn)
	{
		for (AActor* PowerableObjectAsActor : PowerableObjectsAsActors)
		{
			if (IANPowerable* PowerableObject = Cast<IANPowerable>(PowerableObjectAsActor))
			{
				PowerableObject->PowerOff();
			}
		}
		bPowerStateOn = false;
	}
	else
	{
		for (AActor* PowerableObjectAsActor : PowerableObjectsAsActors)
		{
			if (IANPowerable* PowerableObject = Cast<IANPowerable>(PowerableObjectAsActor))
			{
				PowerableObject->PowerOn();
			}
		}
		bPowerStateOn = true;
	}

	SaveObject();
}

void AANPowerBreaker::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	AlterPowerState();
}

bool AANPowerBreaker::IsLongInteract() const
{
	return false;
}

FString AANPowerBreaker::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	SaveString = SaveString.Append(Super::BP_ConstructSaveString_Implementation());

	if (bPowerStateOn)
	{
		SaveString = SaveString.Append(SaveableParams::PowerStateOnTrue);
	}
	else
	{
		SaveString = SaveString.Append(SaveableParams::PowerStateOnFalse);
	}

	return SaveString;
}

void AANPowerBreaker::BP_LoadObject_Implementation(const FString& LoadString)
{
	Super::BP_LoadObject_Implementation(LoadString);
	if (LoadString.Contains(SaveableParams::PowerStateOnTrue))
	{
		bPowerStateOn = !true; //doing reverse here because of how AlterPowerState toggles
		AlterPowerState();
	}
	else
	{
		bPowerStateOn = !false; //doing reverse here because of how AlterPowerState toggles
		AlterPowerState();
	}
}