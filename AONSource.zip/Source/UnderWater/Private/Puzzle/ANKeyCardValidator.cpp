// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANKeyCardValidator.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"

#include "Controller/ANPlayerControllerBase.h"
#include "Environment/AnOpeningDoor.h"
#include "Game/ANGameInstance.h"
#include "Systems/ANInventorySystem.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/HUD/ANMessagesHUDWidget.h"

AANKeyCardValidator::AANKeyCardValidator()
	: Super()
{
	AccessTextTimeSeconds = 1.5f;
}

void AANKeyCardValidator::BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* IS = GameInstance->GetInventorySystem())
		{
			if (FANItem* Item = IS->GetItemDataFromTable(InsertedItem))
			{
				KeyType KeyCard = static_cast<KeyType>(Item->IntegerValue);
				FText AccessMessage;
				UAkAudioEvent* AudioEventToPlay = nullptr;
				if ((KeyCard >= AccessKeyType))
				{
					if (TargetDoor)
					{
						AccessMessage = AccessGrantedText;
						AudioEventToPlay = AccessGrantedSFX;
						OnActivation();
						CompletePuzzle(false); //complete puzzle automatically saves the object
						EndInteract(LongInteractingCharacter);
					}
				}
				else
				{
					AccessMessage = AccessDeniedText;
					AudioEventToPlay = AccessDeniedSFX;
				}

				AANPlayerControllerBase* PlayerController = GameInstance->GetWorld()->GetFirstPlayerController<AANPlayerControllerBase>();
				if (PlayerController)
				{
					UANMessagesHUDWidget* MessagesHUDWidget = PlayerController->GetMessagesHUDWidget();
					MessagesHUDWidget->BP_AddMessage(AccessMessage, AccessTextTimeSeconds);

					if (AudioEventToPlay != nullptr)
					{
						UAkGameplayStatics::PostEventAttached(AudioEventToPlay, this);
					}
				}
			}
		}
	}
}

void AANKeyCardValidator::CompletePuzzle_Implementation(bool bInstantComplete)
{
	Super::CompletePuzzle_Implementation(bInstantComplete);

	if (TargetDoor != nullptr)
	{
		TargetDoor->UnlockDoor();
	}
}