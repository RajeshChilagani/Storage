// 2021 Abyssmal Games and Synodic Arc

#include "Puzzle/ANScreenButton.h"

#include "Components/TextRenderComponent.h"

// Sets default values
AANScreenButton::AANScreenButton()
	: Super()
{
	WorldButtonMesh->SetRelativeScale3D(FVector(1.0f, 1.0f, 1.0f));

	ScreenButtonText = CreateDefaultSubobject<UTextRenderComponent>(TEXT("ScreenButtonText"));
	ScreenButtonText->SetWorldSize(6.0f);
	ScreenButtonText->SetupAttachment(RootComponent);
}