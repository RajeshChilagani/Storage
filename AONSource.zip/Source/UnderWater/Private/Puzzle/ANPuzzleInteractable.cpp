// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANPuzzleInteractable.h"

#include "Camera/CameraComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SpotLightComponent.h"
#include "Components/BoxComponent.h"
#include "Engine/World.h"

#include "ANDefines.h"
#include "ANEnums.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Systems/ANInventorySystem.h"
#include "UI/HUD/ANHUDWidget.h"

AANPuzzleInteractable::AANPuzzleInteractable()
	: Super()
{
	PuzzleRootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = PuzzleRootComponent;

	PuzzleCameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("PuzzleCameraCom"));
	PuzzleCameraComponent->SetupAttachment(RootComponent);
	PuzzleCameraComponent->SetRelativeLocation(FVector(-100.0f, 0.0f, 0.0f));
	PuzzleCameraComponent->SetRelativeRotation(FRotator(0.0f, 0.0f, 0.0f));

	SpotLightComponent = CreateDefaultSubobject<USpotLightComponent>(TEXT("SpotLightComponent"));
	SpotLightComponent->SetRelativeLocation(FVector(-150.0f, 0.0f, 0.0f));
	SpotLightComponent->SetRelativeRotation(FRotator(0.0f, 0.0f, 0.0f));
	SpotLightComponent->SetVisibility(false);
	SpotLightComponent->SetIntensity(10.0f);
	SpotLightComponent->SetLightColor(FLinearColor(1.0f, 0.79f, 0.52f, 1.0f)); //Tan-yellow
	SpotLightComponent->SetAttenuationRadius(1500.0f);
	SpotLightComponent->SetInnerConeAngle(20.0f);
	SpotLightComponent->SetOuterConeAngle(47.0f);
	SpotLightComponent->SetVolumetricScatteringIntensity(1.0f);
	SpotLightComponent->bUseInverseSquaredFalloff = false;
	SpotLightComponent->SetAffectTranslucentLighting(false);
	SpotLightComponent->SetCastRaytracedShadow(false);
	SpotLightComponent->SetAffectReflection(false);
	SpotLightComponent->SetAffectGlobalIllumination(false);
	SpotLightComponent->SetupAttachment(RootComponent);

	MainMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PrimaryMesh"));
	MainMeshComponent->SetupAttachment(RootComponent);
	// Custom depth pass for focus ability
	MainMeshComponent->bRenderCustomDepth = false;
	MainMeshComponent->CustomDepthStencilWriteMask = ERendererStencilMask::ERSM_Default;
	MainMeshComponent->CustomDepthStencilValue = static_cast<int32>(EFocusOutlineColor::AquaBlue);

	CustomDepthBounds = CreateDefaultSubobject<UBoxComponent>(TEXT("DepthStencilBounds"));
	CustomDepthBounds->SetBoxExtent(FVector(256, 256, 256));
	CustomDepthBounds->SetupAttachment(RootComponent);
	CustomDepthBounds->OnComponentBeginOverlap.AddDynamic(this, &AANPuzzleInteractable::OnCDBBeginOverlap);
	CustomDepthBounds->OnComponentEndOverlap.AddDynamic(this, &AANPuzzleInteractable::OnCDBEndOverlap);

	bInteracting = false;
	LongInteractingCharacter = nullptr;
	bPuzzleCameraActive = false;
	bIsCameraNeeded = true;
	bDisplayClosePrompt = true;
	bOpensInventory = false;
}

bool AANPuzzleInteractable::CanInteract() const
{
	return !bInteracting && !IsPuzzleComplete();
}

void AANPuzzleInteractable::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		IANInteractable::BeginInteract(InteractingCharacter);
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
		{
			MainCharacter->SetViewTargetWithBlend(this);
			if (bOpensInventory)
			{
				MainCharacter->OpenInventory(EANInventoryModes::Puzzle);
			}

			if (bDisplayClosePrompt)
			{
				if (AANPlayerControllerBase* PlayerControllerBase = MainCharacter->GetPlayerControllerBase())
				{
					if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
					{
						HUDWidget->BP_ShowClosePromptUI();
					}
				}
			}

			MainCharacter->SetGameInput(EGameInputTypes::UIOnly);
			MainCharacter->SetActorHiddenInGame(true); //Hide character in case they would block the camera

			OnPuzzleBeginInteract.Broadcast();

			LongInteractingCharacter = MainCharacter;
			SpotLightComponent->SetVisibility(true);
			bPuzzleCameraActive = true;
			bInteracting = true;
		}
	}
}

void AANPuzzleInteractable::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		IANInteractable::EndInteract(InteractingCharacter);
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
		{
			MainCharacter->SetViewTargetWithBlend(MainCharacter);
			MainCharacter->SetGameInput(EGameInputTypes::GameOnly);
			MainCharacter->SetActorHiddenInGame(false); //Unhide the character

			OnPuzzleEndInteract.Broadcast();

			LongInteractingCharacter = nullptr;
			SpotLightComponent->SetVisibility(false);
			bPuzzleCameraActive = false;
			bInteracting = false;
			if (bOpensInventory)
			{
				MainCharacter->CloseInventory();
			}

			if (bDisplayClosePrompt)
			{
				if (AANPlayerControllerBase* PlayerControllerBase = MainCharacter->GetPlayerControllerBase())
				{
					if (UANHUDWidget* HUDWidget = PlayerControllerBase->GetHUDWidget())
					{
						HUDWidget->BP_HideClosePromptUI();
					}
				}
			}

			MainCharacter->TryEndInteract();
		}
	}
}

bool AANPuzzleInteractable::IsLongInteract() const
{
	return true;
}

bool AANPuzzleInteractable::IsInteracting() const
{
	return bInteracting;
}

void AANPuzzleInteractable::BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			if (bConsumeItem)
			{
				InventorySystem->UseItem(InsertedItem, 1);
			}
			EndInteract(LongInteractingCharacter);
			SaveObject();
		}
	}
}

bool AANPuzzleInteractable::BP_CanInsertItem_Implementation(const FString& InsertedItem)
{
	if (InsertableItemNames.Contains(InsertedItem))
	{
		return true;
	}

	return false;
}

void AANPuzzleInteractable::BP_TakeItem_Implementation(const FString& TakenItem)
{
	
}

void AANPuzzleInteractable::SetDepthStencilState(bool bEnable)
{
	MainMeshComponent->bRenderCustomDepth = bEnable;
	MainMeshComponent->MarkRenderStateDirty();
	if (bEnable)
	{
		OnRenderCustomDepthEnabled();
	}
	else
	{
		OnRenderCustomDepthDisabled();
	}
}

void AANPuzzleInteractable::OnCDBBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		SetDepthStencilState(true);
	}
}

void AANPuzzleInteractable::OnCDBEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (AANMainCharacter* Player = Cast<AANMainCharacter>(OtherActor))
	{
		SetDepthStencilState(false);
	}
}

