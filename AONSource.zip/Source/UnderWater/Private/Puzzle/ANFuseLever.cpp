// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANFuseLever.h"
#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
void AANFuseLever::BeginInteract(AANCharacterBase* InteractingCharacter)
{
    ToggleFuse();
}
bool AANFuseLever::IsLongInteract() const
{
    return false;
}
