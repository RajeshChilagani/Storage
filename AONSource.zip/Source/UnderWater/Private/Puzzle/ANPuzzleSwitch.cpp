// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANPuzzleSwitch.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"

#include "ANDefines.h"

#include "Puzzle/ANToggleSwitchesPuzzle.h"

// Sets default values
AANPuzzleSwitch::AANPuzzleSwitch()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
}

// Called when the game starts or when spawned
void AANPuzzleSwitch::BeginPlay()
{
	Super::BeginPlay();
}

void AANPuzzleSwitch::SwitchToggle()
{
	bToggleState = !bToggleState;
	if (OwnerTogglesPuzzle)
	{
		OwnerTogglesPuzzle->ToggleStateChanged(this);
	}
	OnToggleSwitch();
}

void AANPuzzleSwitch::BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
{
	Print("Toggle Switch");
	SwitchToggle();
	UAkGameplayStatics::PostEventAttached(ConfirmSFX, this);
}

void AANPuzzleSwitch::BP_Highlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Add(PlayerNumber);
	if (HighlightedPlayers.Num() > 0)
	{
		bHighlighted = true;
	}

	UAkGameplayStatics::PostEventAttached(HighlightSFX, this);
}

void AANPuzzleSwitch::BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Remove(PlayerNumber);
	if (HighlightedPlayers.Num() == 0)
	{
		bHighlighted = false;
	}

	UAkGameplayStatics::PostEventAttached(UnhighlightSFX, this);
}



