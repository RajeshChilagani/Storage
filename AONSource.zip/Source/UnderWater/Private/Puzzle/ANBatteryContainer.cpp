// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANBatteryContainer.h"

#include "Components/SceneComponent.h"
#include "Components/SpotLightComponent.h"

#include "ANConsts.h"
#include "ANDefines.h"
#include "ANEnums.h"
#include "ANStructs.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Environment/ANOpeningDoor.h"
#include "Game/ANGameInstance.h"
#include "Interface/ANItemable.h"
#include "Puzzle/ANVoltageSystem.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Systems/ANInventorySystem.h"
#include "Systems/ANPickableItem.h"


// Sets default values
AANBatteryContainer::AANBatteryContainer()
	: AANPuzzleInteractable()
{
	CurrentVoltage = 0;
	bFilled = false;
}

// Called when the game starts or when spawned
void AANBatteryContainer::BeginPlay()
{
	Super::BeginPlay();
}

void AANBatteryContainer::SetVoltageSystemRef(AANVoltageSystem* NewVoltageSystem)
{
	VoltageSystem = NewVoltageSystem;
}

bool AANBatteryContainer::CanInteract() const
{
	return !bInteracting && !IsPuzzleComplete();
}

void AANBatteryContainer::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		//Quick interact
		if (!IsLongInteract())
		{
			if (!CurrentItemName.IsEmpty())
			{
				TakeItem(CurrentItemName);
			}
		}
		//Long interact
		else
		{
			MainCharacter->SetViewTargetWithBlend(this);
			MainCharacter->OpenInventory(EANInventoryModes::Puzzle);
			MainCharacter->SetGameInput(EGameInputTypes::UIOnly);
			MainCharacter->SetActorHiddenInGame(true); //Hide character in case they would block the camera

			bInteracting = true;
			LongInteractingCharacter = MainCharacter;
			SpotLightComponent->SetVisibility(true);
			bPuzzleCameraActive = true;
		}	
	}
}

void AANBatteryContainer::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		MainCharacter->SetViewTargetWithBlend(MainCharacter);
		MainCharacter->SetGameInput(EGameInputTypes::GameOnly);
		MainCharacter->SetActorHiddenInGame(false); //Unhide the character

		bInteracting = false;
		LongInteractingCharacter = nullptr;
		SpotLightComponent->SetVisibility(false);
		bPuzzleCameraActive = false;
		MainCharacter->CloseInventory();
		MainCharacter->TryEndInteract();
	}
}

bool AANBatteryContainer::IsLongInteract() const
{
	if (bFilled)
	{
		return false; //If filled, instantly pick up the inserted item
	}
	else
	{
		return true; //The battery container is a long interact type, we have to select an object to insert
	}
}

bool AANBatteryContainer::IsInteracting() const
{
	return bInteracting;
}

void AANBatteryContainer::BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			if (FANItem* InsertedItemData = InventorySystem->GetItemDataFromTable(InsertedItem))
			{
				if (bConsumeItem)
				{
					InventorySystem->UseItem(InsertedItem, 1);
				}
				CurrentItemName = InsertedItem;
				bFilled = true;
				CurrentVoltage = InsertedItemData->IntegerValue;
				/*if (InsertedItemData->PickableItem != nullptr)
				{
					if (UWorld* MyWorld = GetWorld())
					{
						FActorSpawnParameters SpawnParams;
						SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
						if (AActor* SpawnedActor = MyWorld->SpawnActor<AActor>(InsertedItemData->PickableItem, FTransform(), SpawnParams))
						{
							FAttachmentTransformRules AttachmentRules = FAttachmentTransformRules(EAttachmentRule::SnapToTarget, false);
							SpawnedActor->AttachToComponent(InsertedBatterySceneComponent, AttachmentRules);
							CurrentItemActor = SpawnedActor;
						}
					}
				}*/
				BP_InsertBattery(InsertedItem);

				EndInteract(LongInteractingCharacter);
				if (VoltageSystem != nullptr)
				{
					//Update the voltage system's voltage
					VoltageSystem->UpdateVoltage();
					//Use consume item to check if we play the SFX or not, since not consuming will happen at load object in begin play
					VoltageSystem->CheckVoltage(bConsumeItem);
				}
			}
		}
	}

	if (VoltageSystem != nullptr)
	{
		VoltageSystem->SaveObject();
	}
}

void AANBatteryContainer::BP_TakeItem_Implementation(const FString& TakenItem)
{
	if (!CurrentItemName.Equals(TakenItem))
	{
		return;
	}

	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			InventorySystem->AddItem(TakenItem, 1, EAddItemMethods::PickUp);
			CurrentItemName = FString("");
			bFilled = false;
			CurrentVoltage = 0;
			if (CurrentItemActor != nullptr)
			{
				CurrentItemActor->Destroy();
				CurrentItemActor = nullptr;
			}

			BP_RemoveBattery();
			EndInteract(LongInteractingCharacter);
			if (VoltageSystem != nullptr)
			{
				VoltageSystem->UpdateVoltage();
				VoltageSystem->CheckVoltage(true);
			}
		}
	}

	if (VoltageSystem != nullptr)
	{
		VoltageSystem->SaveObject();
	}
}

FString AANBatteryContainer::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	FString SaveableUnlockCode(SaveableParams::InsertedItem);

	if (!CurrentItemName.IsEmpty())
	{
		SaveableUnlockCode = SaveableUnlockCode.Append(CurrentItemName);
	}

	SaveableUnlockCode = SaveableUnlockCode.Append(";");
	SaveString = SaveString.Append(SaveableUnlockCode);

	return SaveString;
}

void AANBatteryContainer::BP_SaveObject_Implementation()
{
	//Do not save the battery container.
}

void AANBatteryContainer::BP_LoadObject_Implementation(const FString& LoadString)
{
	//Do not load the battery container.
}