// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANInformationPanel.h"

#include <Components/StaticMeshComponent.h>
#include <Components/WidgetComponent.h>
#include <Components/TextRenderComponent.h>
#include "UObject/ConstructorHelpers.h"

AANInformationPanel::AANInformationPanel()
{
	PrimaryActorTick.bCanEverTick = false;
	PanelMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PanelMesh"));
	PanelMesh->SetupAttachment(RootComponent);
	WidgetBP = CreateDefaultSubobject<UWidgetComponent>(TEXT("WidgetBP"));
	static ConstructorHelpers::FClassFinder<UUserWidget> WidgetBPClassFinder(TEXT("/Game/UI/Game/Puzzles/InfoPanelWidget_WBP"));
	if (WidgetBPClassFinder.Succeeded())
	{
		WidgetBP->SetWidgetClass(WidgetBPClassFinder.Class);
	}
	else
	{
		UE_LOG(LogTemp, Error, TEXT("Widget Blueprint Ref not found"));
	}
	WidgetBP->SetWidgetSpace(EWidgetSpace::World);
	WidgetBP->SetDrawSize(FVector2D(768,300));
	WidgetBP->SetupAttachment(PanelMesh);
	WidgetBP->InitWidget();
}

void AANInformationPanel::BeginPlay()
{
	Super::BeginPlay();
}

void AANInformationPanel::UpdatePanelItems(const TArray<UTexture*>& NewTextures, const TArray<FText>& NewDescriptions)
{
	Textures = NewTextures;
	Descriptions = NewDescriptions;
}

