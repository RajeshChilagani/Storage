// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANLockerHiding.h"
#include "Components/PrimitiveComponent.h"
#include "GameFramework/Actor.h"

// Sets default values for this component's properties
UANLockerHiding::UANLockerHiding()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UANLockerHiding::BeginPlay()
{
	Super::BeginPlay();
	//if (CurveFloat)
	//{
	//	FOnTimelineFloat TimelineCallback;
	//	FOnTimelineEventStatic TimelineFinishedCallback;

	//	TimelineCallback.BindUFunction(this, FName("ControlDoor"));
	//	TimelineFinishedCallback.BindUFunction(this, FName{ TEXT("SetState") });
	//	Timeline.AddInterpFloat(CurveFloat, TimelineCallback);
	//	Timeline.SetTimelineFinishedFunc(TimelineFinishedCallback);
	//}
	// ...
	
}


// Called every frame
void UANLockerHiding::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	Timeline.TickTimeline(DeltaTime);
	// ...
}


void UANLockerHiding::OpenLocker_Implementation() {
	//AActor* myParent = GetOwner();
	//TArray<UStaticMeshComponent*> Components;
	//UStaticMeshComponent* lockerFront = nullptr;
	//UStaticMeshComponent* pivotPoint = nullptr;
	//myParent->GetComponents<UStaticMeshComponent>(Components);
	//for (int32 i = 0; i < Components.Num(); i++)
	//{
	//	if (Components[i]->GetFName() == "lockerfront") {
	//		lockerFront = Components[i];
	//	}
	//	if (Components[i]->GetFName() == "pivotPoint") {
	//		pivotPoint = Components[i];
	//	}
	//
	//}
	//if (lockerFront)
	//	lockerFront->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	//bool pressed = true;
	//if (pressed) {
	//	Timeline.PlayFromStart();
	//	pressed = false;
	//}
	//else {
	//	Timeline.ReverseFromEnd();
	//	pressed = true;
	//}

	//Timeline
	

}


