// Fill out your copyright notice in the Description page of Project Settings.

#include "Puzzle/ANVoltageSystem.h"

#include "Components/ChildActorComponent.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"

#include "ANConsts.h"

#include "Puzzle/ANBatteryContainer.h"
#include "Puzzle/ANVoltagePanel.h"
#include "Shared/ANFunctionLibrary.h"

// Sets default values
AANVoltageSystem::AANVoltageSystem()
	: Super()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	VoltageSystemRoot = CreateDefaultSubobject<USceneComponent>(TEXT("VoltageSystemRoot"));
	RootComponent = VoltageSystemRoot;

	ControlPanelMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ControlPanelMesh"));
	ControlPanelMesh->SetupAttachment(RootComponent);
	ControlPanelMesh->AddLocalOffset(FVector(-50.0f, 0.0f, 0.0f));

	BatteryContainer0_CA = CreateDefaultSubobject<UChildActorComponent>(TEXT("BatteryContainer0_CA"));
	BatteryContainer0_CA->SetupAttachment(ControlPanelMesh);
	BatteryContainer0_CA->AddLocalOffset(FVector(24.0f, 149.0f, 87.0f));
	BatteryContainer0_CA->AddLocalRotation(FRotator(-7.5f, 35.0f, 0.0f));

	BatteryContainer1_CA = CreateDefaultSubobject<UChildActorComponent>(TEXT("BatteryContainer1_CA"));
	BatteryContainer1_CA->SetupAttachment(ControlPanelMesh);
	BatteryContainer1_CA->AddLocalOffset(FVector(70.0f, 0.0f, 90.0f));
	BatteryContainer1_CA->AddLocalRotation(FRotator(0.0f, 0.0f, 0.0f));

	BatteryContainer2_CA = CreateDefaultSubobject<UChildActorComponent>(TEXT("BatteryContainer2_CA"));
	BatteryContainer2_CA->SetupAttachment(ControlPanelMesh);
	BatteryContainer2_CA->AddLocalOffset(FVector(24.0f, -149.0f, 87.0f));
	BatteryContainer2_CA->AddLocalRotation(FRotator(-7.5f, -35.0f, 0.0f));

	VoltagePanel_CA = CreateDefaultSubobject<UChildActorComponent>(TEXT("VoltagePanel_CA"));
	VoltagePanel_CA->SetupAttachment(RootComponent);
	VoltagePanel_CA->AddLocalOffset(FVector(-160.0f, 0.0f, 210.0f));
	VoltagePanel_CA->AddLocalRotation(FRotator(0.0f, 0.0f, 0.0f));

	bLoaded = false;
	CurrentVoltage = 0;
	NumPoweredOnObjects = 0;
}

void AANVoltageSystem::BeginPlay()
{
	//Dispatch powerables' begin play first, so we can overwrite their progress with the voltage system's afterwards
	for (FVoltageParams& Target : Targets)
	{
		if (Target.TargetPowerable == nullptr)
		{
			continue;
		}

		if (!Target.TargetPowerable->HasActorBegunPlay())
		{
			Target.TargetPowerable->DispatchBeginPlay();
		}
	}

	//Set voltage system ref on all battery container children
	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(0))
	{
		BatteryContainer->SetVoltageSystemRef(this);
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(1))
	{
		BatteryContainer->SetVoltageSystemRef(this);
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(2))
	{
		BatteryContainer->SetVoltageSystemRef(this);
	}

	//Do loading and other puzzle object begin play events
	Super::BeginPlay();

	//If we haven't loaded, we need to set defaults
	if (!bLoaded)
	{
		if (!DefaultBattery0.IsEmpty())
		{
			InsertBattery(DefaultBattery0, false, 0);
		}

		if (!DefaultBattery1.IsEmpty())
		{
			InsertBattery(DefaultBattery1, false, 1);
		}

		if (!DefaultBattery2.IsEmpty())
		{
			InsertBattery(DefaultBattery2, false, 2);
		}
	}

	//Create the items in the UI for the voltage panel UI before we check voltage
	if (AANVoltagePanel* VoltagePanel = GetVoltagePanel())
	{
		VoltagePanel->BP_InitializeVoltagePanel();
		VoltagePanel->BP_CreateItemsUI(Targets);
	}

	//Check voltage after begin play to set everything
	CheckVoltage(false); //Will also call VoltagePanel's UpdatePanelsUI
}

void AANVoltageSystem::UpdateVoltage()
{
	int32 NewVoltage = 0;

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(0))
	{
		NewVoltage += BatteryContainer->GetCurrentVoltage();
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(1))
	{
		NewVoltage += BatteryContainer->GetCurrentVoltage();
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(2))
	{
		NewVoltage += BatteryContainer->GetCurrentVoltage();
	}

	CurrentVoltage = NewVoltage;
}

void AANVoltageSystem::InsertBattery(const FString& ItemName, bool bConsumeItem, int32 BatteryIndex)
{
	if (ItemName.IsEmpty())
	{
		return;
	}

	AANBatteryContainer* BatteryContainer = GetBatteryContainer(BatteryIndex);
	if (BatteryContainer == nullptr)
	{
		return;
	}

	BatteryContainer->InsertItem(ItemName, bConsumeItem);
}

AANBatteryContainer* AANVoltageSystem::GetBatteryContainer(int32 BatteryIndex) const
{
	UChildActorComponent* BatteryContainer_CA = nullptr;
	switch (BatteryIndex)
	{
	case(0):
		BatteryContainer_CA = BatteryContainer0_CA;
		break;
	case(1):
		BatteryContainer_CA = BatteryContainer1_CA;
		break;
	case(2):
		BatteryContainer_CA = BatteryContainer2_CA;
		break;
	default:
		break;
	}
	
	if (BatteryContainer_CA == nullptr)
	{
		return nullptr;
	}

	if (AANBatteryContainer* BatteryContainer = Cast<AANBatteryContainer>(BatteryContainer_CA->GetChildActor()))
	{
		return BatteryContainer;
	}
	
	return nullptr;
}

AANVoltagePanel* AANVoltageSystem::GetVoltagePanel() const
{
	if (VoltagePanel_CA != nullptr)
	{
		if (AANVoltagePanel* VoltagePanel = Cast<AANVoltagePanel>(VoltagePanel_CA->GetChildActor()))
		{
			return VoltagePanel;
		}
	}

	return nullptr;
}

FString AANVoltageSystem::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(0))
	{
		SaveString.Append(UANFunctionLibrary::MakeSaveableParam(SaveableParams::Battery0, FString::FromInt(BatteryContainer->GetCurrentVoltage())));
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(1))
	{
		SaveString.Append(UANFunctionLibrary::MakeSaveableParam(SaveableParams::Battery1, FString::FromInt(BatteryContainer->GetCurrentVoltage())));
	}

	if (AANBatteryContainer* BatteryContainer = GetBatteryContainer(2))
	{
		SaveString.Append(UANFunctionLibrary::MakeSaveableParam(SaveableParams::Battery2, FString::FromInt(BatteryContainer->GetCurrentVoltage())));
	}

	return SaveString;
}

void AANVoltageSystem::BP_LoadObject_Implementation(const FString& LoadString)
{
	if (LoadString.Contains(SaveableParams::Battery0))
	{
		FString BatteryVoltageString = UANFunctionLibrary::GetSaveableParamValue(LoadString, SaveableParams::Battery0);
		FString BatteryItemName("Battery");
		BatteryItemName.Append(BatteryVoltageString);
		BatteryItemName.Append("V");
		InsertBattery(BatteryItemName, false, 0);
	}

	if (LoadString.Contains(SaveableParams::Battery1))
	{
		FString BatteryVoltageString = UANFunctionLibrary::GetSaveableParamValue(LoadString, SaveableParams::Battery1);
		FString BatteryItemName("Battery");
		BatteryItemName.Append(BatteryVoltageString);
		BatteryItemName.Append("V");
		InsertBattery(BatteryItemName, false, 1);
	}

	if (LoadString.Contains(SaveableParams::Battery2))
	{
		FString BatteryVoltageString = UANFunctionLibrary::GetSaveableParamValue(LoadString, SaveableParams::Battery2);
		FString BatteryItemName("Battery");
		BatteryItemName.Append(BatteryVoltageString);
		BatteryItemName.Append("V");
		InsertBattery(BatteryItemName, false, 2);
	}

	bLoaded = true;
}
