// 2021 Abyssmal Games and Synodic Arc

#include "Puzzle/ANWorldButton.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"
#include "ANDefines.h"

// Sets default values
AANWorldButton::AANWorldButton()
	: Super()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Set up root
	WorldButtonRoot = CreateDefaultSubobject<USceneComponent>(TEXT("WorldButtonRoot"));
	RootComponent = WorldButtonRoot;

	//Set up world button mesh
	WorldButtonMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("WorldButtonMesh"));
	WorldButtonMesh->SetRelativeScale3D(FVector(0.1f, 0.3f, 0.03f));
	WorldButtonMesh->SetCollisionProfileName(CollisionProfiles::WorldSelectable);
	WorldButtonMesh->SetupAttachment(RootComponent);

	bEnabled = false;
	bHighlighted = false;
}

// Called when the game starts or when spawned
void AANWorldButton::BeginPlay()
{
	Super::BeginPlay();
}

void AANWorldButton::PressButton()
{
	OnWorldButtonConfirmed.Broadcast(this);
}

void AANWorldButton::BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
{
	if (ConfirmSFX != nullptr)
	{
		if (APawn* OwningPawn = UGameplayStatics::GetPlayerPawn(this, 0))
		{
			UAkGameplayStatics::PostEventAttached(ConfirmSFX, OwningPawn);
		}
	}

	PressButton();

	Print("Button confirm!");
}

void AANWorldButton::BP_Highlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Add(PlayerNumber);
	if (HighlightedPlayers.Num() > 0)
	{
		bHighlighted = true;
	}

	if (HighlightSFX != nullptr)
	{
		if (APawn* OwningPawn = UGameplayStatics::GetPlayerPawn(this, 0))
		{
			UAkGameplayStatics::PostEventAttached(HighlightSFX, OwningPawn);
		}
	}

	Print("Button highlighted!");
}

void AANWorldButton::BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Remove(PlayerNumber);
	if (HighlightedPlayers.Num() == 0)
	{
		bHighlighted = false;
	}

	if (UnhighlightSFX != nullptr)
	{
		if (APawn* OwningPawn = UGameplayStatics::GetPlayerPawn(this, 0))
		{
			UAkGameplayStatics::PostEventAttached(UnhighlightSFX, OwningPawn);
		}
	}

	Print("Button unhighlighted!");
}

bool AANWorldButton::BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const
{
	for (int32 i = 0; i < HighlightedPlayers.Num(); i++)
	{
		if (HighlightedPlayers[i] == PlayerNumber)
		{
			return true;
		}
	}

	return false;
}

void AANWorldButton::BP_EnableSelectable_Implementation()
{
	bEnabled = true;
}

void AANWorldButton::BP_DisableSelectable_Implementation()
{
	bEnabled = false;
}

bool AANWorldButton::BP_CanSelect_Implementation() const
{
	return bEnabled;
}

