// 2021 Abyssmal Games and Synodic Arc

#include "Puzzle/ANPuzzleButton.h"

#include "Components/DecalComponent.h"

// Sets default values
AANPuzzleButton::AANPuzzleButton()
	: Super()
{
	PuzzleButtonDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("PuzzleButtonDecal"));
	PuzzleButtonDecal->AddLocalOffset(FVector(0.0f, 0.0f, 80.0f));
	PuzzleButtonDecal->AddLocalRotation(FRotator(-90.0f, -90.0f, 80.0f));
	PuzzleButtonDecal->SetRelativeScale3D(FVector(0.5f, 0.3f, 10.0f));
	PuzzleButtonDecal->DecalSize = FVector(52.0f, 52.0f, 32.0f);
	PuzzleButtonDecal->SetupAttachment(WorldButtonMesh);
}
