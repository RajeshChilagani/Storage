// Fill out your copyright notice in the Description page of Project Setting


#include "Puzzle/ANOxygenStation.h"

#include "Components/SceneComponent.h"
#include "Components/SpotLightComponent.h"

#include "ANEnums.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Game/ANGameInstance.h"
#include "Interface/ANSelectable.h"
#include "Puzzle/ANPressureStabilizer.h"
#include "Puzzle/ANScreenButton.h"
#include "Systems/ANInventorySystem.h"

AANOxygenStation::AANOxygenStation()
	: Super()
{
	SaveTransformSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SaveTransformSceneComponent"));
	SaveTransformSceneComponent->SetupAttachment(RootComponent);
	SaveTransformSceneComponent->AddLocalOffset(FVector(-200.0f, 0.0f, 150.0f));

	SaveLevel = EANLevels::Dormitory;
}

void AANOxygenStation::EnableScreenButtons()
{
	for (AANScreenButton* ScreenButton : ScreenButtons)
	{
		ScreenButton->EnableSelectable();
	}
}

void AANOxygenStation::DisableScreenButtons()
{
	for (AANScreenButton* ScreenButton : ScreenButtons)
	{
		ScreenButton->DisableSelectable();
	}
}

TArray<TArray<IANSelectable*>> AANOxygenStation::GetScreenButtonsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < ScreenButtons.Num(); i++)
	{
		TArray<IANSelectable*> RowSelectables;

		if (IANSelectable* Selectable = Cast<IANSelectable>(ScreenButtons[i]))
		{
			RowSelectables.Add(Selectable);
			AllSelectables.Add(RowSelectables);
		}
	}
	
	return AllSelectables;
}

bool AANOxygenStation::CanInteract() const
{
	return !bInteracting;
}

void AANOxygenStation::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		if (!IsPuzzleComplete())
		{
			MainCharacter->OpenInventory(EANInventoryModes::Puzzle);
		}
		else
		{
			EnableScreenButtons();
			if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
			{
				PlayerControllerBase->AssignSelectables(GetScreenButtonsAsSelectableArray());
			}
		}

		MainCharacter->SetViewTargetWithBlend(this);
		MainCharacter->SetGameInput(EGameInputTypes::UIOnly);
		MainCharacter->SetActorHiddenInGame(true); //Hide character in case they would block the camera

		LongInteractingCharacter = MainCharacter;
		SpotLightComponent->SetVisibility(true);
		bPuzzleCameraActive = true;
		bInteracting = true;
	}
}

void AANOxygenStation::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		return;
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		if (!IsPuzzleComplete())
		{
			MainCharacter->CloseInventory();
		}
		else
		{
			BP_UnhighlightAllScreenButtons();
			DisableScreenButtons();
			if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
			{
				PlayerControllerBase->ClearSelectables();
			}
		}

		MainCharacter->SetViewTargetWithBlend(MainCharacter);
		MainCharacter->SetGameInput(EGameInputTypes::GameOnly);
		MainCharacter->SetActorHiddenInGame(false); //Unhide the character

		LongInteractingCharacter = nullptr;
		SpotLightComponent->SetVisibility(false);
		bPuzzleCameraActive = false;
		bInteracting = false;
		//MainCharacter->CloseInventory(); //probably okay in all cases?
		MainCharacter->TryEndInteract();
	}
}

bool AANOxygenStation::IsLongInteract() const
{
	return true;
}

bool AANOxygenStation::IsInteracting() const
{
	return bInteracting;
}

void AANOxygenStation::BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(LongInteractingCharacter))
			{
				if (bConsumeItem)
				{
					InventorySystem->UseItem(InsertedItem, 1);
				}
				CompletePuzzle(false);

				//Now set to the new set of selectables after closing the inventory
				MainCharacter->CloseInventory();
				EnableScreenButtons();
				if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(MainCharacter->GetController()))
				{
					PlayerControllerBase->AssignSelectables(GetScreenButtonsAsSelectableArray());
				}
			}
		}
	}
}
