// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANKeyButton.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Puzzle/ANKeyPad.h"

// Sets default values
AANKeyButton::AANKeyButton()
	: Super()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Set up root
	KeyButtonRoot = CreateDefaultSubobject<USceneComponent>(TEXT("KeyButtonRoot"));
	RootComponent = KeyButtonRoot;

	//Set up key button mesh
	KeyButtonMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("KeyButtonMesh"));
	KeyButtonMesh->SetCollisionProfileName(CollisionProfiles::WorldSelectable);
	KeyButtonMesh->SetupAttachment(RootComponent); //Need to attach in order for transform variables to show

	bEnabled = false;
	KeyButtonType = EANKeyButtonTypes::Add;
	bHighlighted = false;
}

// Called when the game starts or when spawned
void AANKeyButton::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void AANKeyButton::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANKeyButton::PressKey()
{
	if (AssociatedKeyPad != nullptr)
	{
		switch (KeyButtonType)
		{
		case(EANKeyButtonTypes::Add):
			AssociatedKeyPad->AddNumber(KeyString);
			break;
		case(EANKeyButtonTypes::Delete):
			AssociatedKeyPad->DeleteNumber();
			break;
		case(EANKeyButtonTypes::Confirm):
			AssociatedKeyPad->ConfirmNumber();
			break;
		}
	}
}

void AANKeyButton::AssignKeyPad(AANKeyPad* NewKeyPad)
{
	AssociatedKeyPad = NewKeyPad;
}

void AANKeyButton::BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
{
	UAkGameplayStatics::PostEventAttached(ConfirmSFX, this);

	PressKey();

	Print("Button confirm!");
}

void AANKeyButton::BP_Highlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Add(PlayerNumber);
	if (HighlightedPlayers.Num() > 0)
	{
		bHighlighted = true;
	}

	UAkGameplayStatics::PostEventAttached(HighlightSFX, this);

	Print("Button highlighted!");
}

void AANKeyButton::BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Remove(PlayerNumber);
	if (HighlightedPlayers.Num() == 0)
	{
		bHighlighted = false;
	}

	UAkGameplayStatics::PostEventAttached(UnhighlightSFX, this);

	Print("Button unhighlighted!");
}

bool AANKeyButton::BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const
{
	for (int32 i = 0; i < HighlightedPlayers.Num(); i++)
	{
		if (HighlightedPlayers[i] == PlayerNumber)
		{
			return true;
		}
	}

	return false;
}

void AANKeyButton::BP_EnableSelectable_Implementation()
{
	bEnabled = true;
}

void AANKeyButton::BP_DisableSelectable_Implementation()
{
	bEnabled = false;
}

bool AANKeyButton::BP_CanSelect_Implementation() const
{
	return bEnabled;
}

