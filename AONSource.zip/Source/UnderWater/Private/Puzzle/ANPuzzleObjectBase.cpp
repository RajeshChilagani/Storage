// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANPuzzleObjectBase.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"

#include "Game/ANGameInstance.h"
#include "Interface/ANSaveable.h"
#include "SaveGame/ANGameplaySaveGame.h"

// Sets default values
AANPuzzleObjectBase::AANPuzzleObjectBase()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//Set defaults
	bPuzzleComplete = false;

}

void AANPuzzleObjectBase::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	if (!SaveableGuid.IsValid())
	{
		SaveableGuid = FGuid::NewGuid();
	}

	//Ensure we don't have the same Guid anywhere else
	for (TActorIterator<AActor> it(GetWorld()); it; ++it)
	{
		//Don't include self in the check
		if (*it == this)
		{
			continue;
		}

		if (IANSaveable* ActorAsSaveable = Cast<IANSaveable>(*it))
		{
			if (ActorAsSaveable->GetSaveableGuid() == SaveableGuid)
			{
				SaveableGuid = FGuid::NewGuid();
				break;
			}
		}
	}
}

// Called when the game starts or when spawned
void AANPuzzleObjectBase::BeginPlay()
{
	Super::BeginPlay();

	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveableString = GameplaySaveGame->GetSaveableStringForGuid(SaveableGuid);

			if (!SaveableString.IsEmpty())
			{
				LoadObject(SaveableString);
			}
		}
	}
}

// Called every frame
void AANPuzzleObjectBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANPuzzleObjectBase::CompletePuzzle_Implementation(bool bInstantComplete)
{
	if (bPuzzleComplete)
	{
		return;
	}

	bPuzzleComplete = true;
	OnPuzzleComplete.Broadcast(bInstantComplete);
	//Only save again if we didn't instantly complete it (which is usually through loading an object)
	if (!bInstantComplete)
	{
		if (PuzzleCompleteSFX != nullptr)
		{
			APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(this, 0);
			UAkGameplayStatics::PostEventAttached(PuzzleCompleteSFX, PlayerPawn);
		}
		SaveObject();
	}
}

void AANPuzzleObjectBase::UncompletePuzzle_Implementation()
{
	if (!bPuzzleComplete)
	{
		return;
	}

	bPuzzleComplete = false;
	OnPuzzleUncomplete.Broadcast();
	SaveObject();
}

FGuid AANPuzzleObjectBase::BP_GetSaveableGuid_Implementation()
{
	return SaveableGuid;
}

FString AANPuzzleObjectBase::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	if (bPuzzleComplete)
	{
		SaveString = SaveString.Append(SaveableParams::CompleteTrue);
	}
	else
	{
		SaveString = SaveString.Append(SaveableParams::CompleteFalse);
	}

	return SaveString;
}

void AANPuzzleObjectBase::BP_SaveObject_Implementation()
{
	if (const UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			FString SaveString = ConstructSaveString();

			if (!SaveString.IsEmpty())
			{
				GameplaySaveGame->SaveSaveableString(SaveableGuid, SaveString);
			}
		}
	}
}

void AANPuzzleObjectBase::BP_LoadObject_Implementation(const FString& LoadString)
{
	if (LoadString.Contains(SaveableParams::CompleteTrue))
	{
		CompletePuzzle(true);
	}
	else
	{
		UncompletePuzzle();
	}
}
