// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANPuzzleTarget.h"


// Sets default values
AANPuzzleTarget::AANPuzzleTarget()
	: NumOfDependencies(0)
	, bIsOnAllDependenciesSolvedInvoked(false)
	, bShouldResetTarget(false)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void AANPuzzleTarget::BeginPlay()
{
	Super::BeginPlay();
	NumOfDependencies = Dependencies.Num();
}

// Called every frame
void AANPuzzleTarget::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	//@TODO Not an ideal way to iterate over all dependencies every tick. we can use events to avoid this in future if performance becomes a concern
	NumOfDependencies = Dependencies.Num();
	for (auto PuzzleItem : Dependencies)
	{
		if (PuzzleItem->IsPuzzleComplete())
		{
			NumOfDependencies -= 1;
		}
	}

	if (!NumOfDependencies && !bIsOnAllDependenciesSolvedInvoked)
	{
		OnAllDependenciesSolved();
		bIsOnAllDependenciesSolvedInvoked = true;
		bShouldResetTarget = true;
	}
	else if (NumOfDependencies && bShouldResetTarget)
	{
		ResetTargetToUnsolved();
		bShouldResetTarget = false;
		bIsOnAllDependenciesSolvedInvoked = false;
	}
}

