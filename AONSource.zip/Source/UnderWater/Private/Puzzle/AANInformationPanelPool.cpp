// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/AANInformationPanelPool.h"
#include "UObject/ConstructorHelpers.h"

#include "Components/SceneComponent.h"
#include "Components/ChildActorComponent.h"
#include "Puzzle/ANInformationPanel.h"
#include "Puzzle/ANNumLockPuzzle.h"


static class UDataTable* InfoPanelTable = nullptr;

AANInformationPanelPool::AANInformationPanelPool()
	:PanelActorsCount(4)
{
	PrimaryActorTick.bCanEverTick = false;
	InfoPanelPoolRoot = CreateDefaultSubobject<USceneComponent>("InfoPanelRoot");
	RootComponent = InfoPanelPoolRoot;
	PanelActors.Reserve(PanelActorsCount);
	for (int i = 0; i < PanelActorsCount; ++i)
	{
		FString Name("Panel");
		Name.Append(FString::FromInt(i));
		auto* ActorComponent = CreateDefaultSubobject<UChildActorComponent>(*Name);
		ActorComponent->SetupAttachment(RootComponent);
		ActorComponent->SetChildActorClass(PanelActorClass);
		ActorComponent->CreateChildActor();
		PanelActors.Add(ActorComponent);
	}
	LoadTexturesTable();
	LoadCategoryInfoMap();
}

void AANInformationPanelPool::BeginPlay()
{
	if (TargetNumLock)
	{
		if (!TargetNumLock->HasActorBegunPlay())
		{
			TargetNumLock->DispatchBeginPlay();
		}
		FString& NumericCode = TargetNumLock->UnlockCode;
		for (int i = 0; i < PanelActors.Num(); ++i)
		{
			if (AANInformationPanel* Panel = Cast<AANInformationPanel>(PanelActors[i]->GetChildActor()))
			{
				TArray<UTexture*> OutTextures;
				OutTextures.Reserve(PanelActorsCount);
				OutTextures.AddDefaulted(PanelActorsCount);
				TArray<FText> OutDescriptions;
				OutDescriptions.Reserve(PanelActorsCount);
				OutDescriptions.AddDefaulted(PanelActorsCount);
				LoadPanelItems(FString(1,&NumericCode[i]), i, OutTextures,OutDescriptions);
				Panel->UpdatePanelItems(OutTextures,OutDescriptions);
			}
		}
	}

	Super::BeginPlay();
}

void AANInformationPanelPool::LoadPanelItems(const FString& NumericValue, int32 NumericValuePostion, UPARAM(ref) TArray<UTexture*>& Out_Textures, UPARAM(ref) TArray<FText>& Out_Descriptions)
{ 
	if (Out_Textures.Num() == PanelActorsCount)
	{
		Out_Textures[NumericValuePostion] = GetTextureFromInfoTable(FName(NumericValue));
		RefreshCategoryInfoMap();
		auto CategoryMapIterator = InfoPanelCategoryMap.CreateIterator();
		for (int i = 0; i < Out_Textures.Num(); ++i)
		{
			if (i == NumericValuePostion)
				continue;
			FString RowName;
			int32 id;
			FANInfoPanel InfoData;
			switch (CategoryMapIterator.Key())
			{
			case EInfoPanelCategory::Alphabetic:
				id = --(CategoryMapIterator.Value());
				RowName = FString("Alphabetic").Append(FString::FromInt(id));
				if (GetPanelInfoData(FName(RowName), InfoData))
				{
					Out_Textures[i] = InfoData.InfoTexture;
					Out_Descriptions[i] = InfoData.Description;
				}
				++CategoryMapIterator;
				break;
			case EInfoPanelCategory::Hydrophyte:
				id = --(CategoryMapIterator.Value());
				RowName = FString("Hydrophyte").Append(FString::FromInt(id));
				if (GetPanelInfoData(FName(RowName), InfoData))
				{
					Out_Textures[i] = InfoData.InfoTexture;
					Out_Descriptions[i] = InfoData.Description;
				}
				++CategoryMapIterator;
				break;
			case EInfoPanelCategory::Watercraft:
				id = --(CategoryMapIterator.Value());
				RowName = FString("Watercraft").Append(FString::FromInt(id));
				if (GetPanelInfoData(FName(RowName), InfoData))
				{
					Out_Textures[i] = InfoData.InfoTexture;
					Out_Descriptions[i] = InfoData.Description;
				}
				++CategoryMapIterator;
				break;
			default:
				break;
			}
		}
	}
}

UTexture* AANInformationPanelPool::GetTextureFromInfoTable(FName RowName)
{
	FANInfoPanel InfoPanelData;
	bool IsSuccess = GetPanelInfoData(RowName, InfoPanelData);
	return IsSuccess ? InfoPanelData.InfoTexture : nullptr;
}

void AANInformationPanelPool::LoadTexturesTable()
{
	if (!InfoPanelTable)
	{
		static ConstructorHelpers::FObjectFinder<UDataTable> Table(TEXT("DataTable'/Game/DataAssets/DataTables/ANInfoPanelTable.ANInfoPanelTable'"));
		check(Table.Succeeded());
		if (Table.Succeeded())
		{
			InfoPanelTable = Table.Object;
		}
	}
}

bool AANInformationPanelPool::GetPanelInfoData(FName RowName, FANInfoPanel& Out_InfoObject)
{
	static const FString ContextString("Item Context String");
	FANInfoPanel* InfoData = InfoPanelTable->FindRow<FANInfoPanel>(RowName, ContextString, true);
	if (!InfoData)
	{
		UE_LOG(LogTemp, Error, TEXT("There is no item with the name %s in the data table. Check DataTable"), *(RowName.ToString()));
		return false;
	}	
	Out_InfoObject = *InfoData;
	return true;
}

void AANInformationPanelPool::RefreshCategoryInfoMap()
{
	for (auto Info : InfoPanelCategoryMap)
	{
		if (Info.Value <= 0)
		{
			InfoPanelCategoryMap.Remove(Info.Key);
		}
	}
	if (InfoPanelCategoryMap.Num() < PanelActorsCount - 1)
	{
		InfoPanelCategoryMap.Empty();
		LoadCategoryInfoMap();
	}
}

void AANInformationPanelPool::LoadCategoryInfoMap()
{
	check(InfoPanelTable);
	static const FString ContextString("Item Context String");
	InfoPanelTable->ForeachRow<FANInfoPanel>(ContextString, [this](const FName& Key, const FANInfoPanel& Value) {
		// Excluding Numeric as it will be determined for Code.
		if (Value.Category != EInfoPanelCategory::Numeric)
		{
			auto& Count = InfoPanelCategoryMap.FindOrAdd(Value.Category);
			Count++;
		}
	});
}
