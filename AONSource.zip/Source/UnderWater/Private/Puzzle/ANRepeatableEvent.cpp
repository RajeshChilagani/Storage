// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANRepeatableEvent.h"

#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"

AANRepeatableEvent::AANRepeatableEvent()
{
	EventRepeatTimeSeconds = 30.0f;
	bPlayEventAtStart = false;
}

void AANRepeatableEvent::BeginPlay()
{
	Super::BeginPlay();
	
	//If we don't have a Guid at begin play, make one
	if (!WorldSaveableGuid.IsValid())
	{
		WorldSaveableGuid = FGuid::NewGuid();
	}

	//If we need to play at the start, do so here
	if (bPlayEventAtStart)
	{
		PlayEvent();
	}

	//Start the repeatable event timer
	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		FTimerDelegate RepeatEventTimerDelegate = FTimerDelegate::CreateUObject(this, &AANRepeatableEvent::PlayEvent);
		MyWorld->GetTimerManager().SetTimer(RepeatTimerHandle, RepeatEventTimerDelegate, EventRepeatTimeSeconds, true);
	}

	//If we can add this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

void AANRepeatableEvent::PlayEvent_Implementation()
{

}

void AANRepeatableEvent::RemoveEvent()
{
	//Remove from world saveables map removed/destroyed
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			GameplaySaveGame->RemoveWorldSaveable(WorldSaveableGuid);
		}
	}

	UWorld* MyWorld = GetWorld();
	if (MyWorld != nullptr)
	{
		MyWorld->GetTimerManager().ClearTimer(RepeatTimerHandle);
	}

	Destroy();
}

void AANRepeatableEvent::BP_InitializeWorldSaveableObject_Implementation(const FGuid& GuidToAssign, const FWorldSaveableData& WorldSaveableDataToAssign)
{
	WorldSaveableGuid = GuidToAssign;
}

bool AANRepeatableEvent::BP_CanSaveToWorldSaveablesMap_Implementation()
{
	return true;
}

void AANRepeatableEvent::BP_UpdateWorldSaveableState_Implementation()
{
	//If we can save this object to the world saveables map, do so
	if (CanSaveToWorldSaveablesMap())
	{
		if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
		{
			if (UANGameplaySaveGame* GameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
			{
				GameplaySaveGame->SaveWorldSaveable(WorldSaveableGuid, GetWorldSaveableData());
			}
		}
	}
}

FGuid AANRepeatableEvent::BP_GetWorldSaveableGuid_Implementation()
{
	return WorldSaveableGuid;
}

FWorldSaveableData AANRepeatableEvent::BP_GetWorldSaveableData_Implementation()
{
	FWorldSaveableData NewWorldSaveableData;
	NewWorldSaveableData.WorldSaveableClass = GetClass();
	NewWorldSaveableData.WorldSaveableTransform = GetActorTransform();
	NewWorldSaveableData.WorldSaveableParams = ConstructSaveableParamsString();
	return NewWorldSaveableData;
}

FString AANRepeatableEvent::BP_ConstructSaveableParamsString_Implementation()
{
	FString SaveString("");

	return SaveString;
}