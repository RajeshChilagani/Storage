// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANToggleSwitchesPuzzle.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Character/ANCharacterBase.h"
#include "Puzzle/ANPuzzleSwitch.h"

AANToggleSwitchesPuzzle::AANToggleSwitchesPuzzle()
	: Super()
{
	RowLength = 3;
}

void AANToggleSwitchesPuzzle::ToggleStateChanged(AANPuzzleSwitch* Switch)
{
	if (Switch)
	{
		UpdateToggles(Switch);
	}
}

void AANToggleSwitchesPuzzle::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	AANPuzzleInteractable::BeginInteract(InteractingCharacter);

	TArray<TArray<IANSelectable*>> AllSelectables;
	TArray<IANSelectable*> RowSelectables;
	int32 RowSize = 0;
	for (int32 i = 0; i < PuzzleSwitches.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(PuzzleSwitches[i]))
		{
			RowSelectables.Add(Selectable);
			RowSize++;
		}

		if (RowSize == RowLength)
		{
			AllSelectables.Add(RowSelectables);
			RowSelectables.Empty();
			RowSize = 0;
		}
	}
	
	if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
	{
		PlayerControllerBase->AssignSelectables(AllSelectables);
	}
}

void AANToggleSwitchesPuzzle::EndInteract(AANCharacterBase* InteractingCharacter)
{
	AANPuzzleInteractable::EndInteract(InteractingCharacter);
	if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
	{
		PlayerControllerBase->ClearSelectables();
	}
}
