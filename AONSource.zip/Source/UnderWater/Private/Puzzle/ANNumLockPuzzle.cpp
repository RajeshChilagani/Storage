// Fill out your copyright notice in the Description page of Project Settings.


#include "Puzzle/ANNumLockPuzzle.h"

#include "Components/ChildActorComponent.h"
#include "Components/StaticMeshComponent.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Interface/ANSelectable.h"
#include "Puzzle/ANKeyPad.h"
#include "Shared/ANFunctionLibrary.h"
#include "Game/ANGameInstance.h"
#include "Utils/ANNumLockRandomizer.h"
#include "SaveGame/ANGameplaySaveGame.h"

DEFINE_LOG_CATEGORY_STATIC(LogNumLockPuzzle, All, All);

// Sets default values
AANNumLockPuzzle::AANNumLockPuzzle()
	: Super()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	UnlockCodeLength = 4;
	UnlockCode = "";

	Hinge = CreateDefaultSubobject<USceneComponent>(TEXT("Hinge"));
	Hinge->SetupAttachment(MainMeshComponent);
	Hinge->SetRelativeLocation(FVector(-28,18,8));

	DoorMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LockerDoor"));
	DoorMesh->SetupAttachment(Hinge);

	KeyPadActor = CreateDefaultSubobject<UChildActorComponent>(TEXT("KeyPad"));
	KeyPadActor->SetupAttachment(DoorMesh);
	if (KeyPadClass)
	{
		KeyPadActor->SetChildActorClass(KeyPadClass);
		KeyPadActor->CreateChildActor();
	}
}

// Called when the game starts or when spawned
void AANNumLockPuzzle::BeginPlay()
{
	Super::BeginPlay();

	if (UWorld* MyWorld = GetWorld())
	{
		if (bRandomizeCodes)
		{
			if (UANGameInstance* GameInstance = Cast<UANGameInstance>(MyWorld->GetGameInstance()))
			{
				if (UnlockCode.IsEmpty())
				{
					if (UANGameplaySaveGame* SaveGame = GameInstance->GetActiveGameplaySaveGame())
					{
						SaveGame->GetSaveableStringValue(FName(IndexCodeValue),UnlockCode);
					}
					//UnlockCode = GameInstance->NumLockRandomizer->GenerateRandomCode(UnlockCodeLength); // - Old way to set random codes.
				}
			}
		}
		if (auto KPChildActor = Cast<AANKeyPad>(KeyPadActor->GetChildActor()))
		{
			KeyPad = KPChildActor;
			KeyPad->AssignUnlockCode(UnlockCode);
			KeyPad->OnPuzzleComplete.AddDynamic(this, &AANNumLockPuzzle::CompletePuzzle);
		}
	}

}

// Called every frame
void AANNumLockPuzzle::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

#if WITH_EDITOR
bool AANNumLockPuzzle::CanEditChange(const FProperty* InProperty) const
{
	const bool ParentCheck = Super::CanEditChange(InProperty);

	if (InProperty->GetFName() == GET_MEMBER_NAME_CHECKED(AANNumLockPuzzle, KeyCardType))
	{
		return ParentCheck && !bSpawnAnyActor;
	}

	return ParentCheck;
}
#endif 

bool AANNumLockPuzzle::CanInteract() const
{
	return !bInteracting && !IsPuzzleComplete();
}

TArray<IANSelectable*> AANNumLockPuzzle::GetAllKeyButtonsAsSelectables() const
{
	if (KeyPad != nullptr)
	{
		return KeyPad->GetAllKeyButtonsAsSelectables();
	}

	TArray<IANSelectable*> EmptySelectables;
	return EmptySelectables;
}

TArray<TArray<IANSelectable*>> AANNumLockPuzzle::GetAllKeyButtonsAsSelectableArray() const
{
	if (KeyPad != nullptr)
	{
		return KeyPad->GetAllKeyButtonsAsSelectableArray();
	}

	TArray<TArray<IANSelectable*>> EmptySelectables;
	return EmptySelectables;
}

void AANNumLockPuzzle::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		Super::BeginInteract(InteractingCharacter);

		TArray<IANSelectable*> KeyButtonSelectables = GetAllKeyButtonsAsSelectables();
		for (int32 i = 0; i < KeyButtonSelectables.Num(); i++)
		{
			KeyButtonSelectables[i]->EnableSelectable();
		}

		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
		{
			PlayerControllerBase->AssignSelectables(GetAllKeyButtonsAsSelectableArray());
		}

		BP_OnBeginInteraction();
	}
}

void AANNumLockPuzzle::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		Super::EndInteract(InteractingCharacter);

		TArray<IANSelectable*> KeyButtonSelectables = GetAllKeyButtonsAsSelectables();
		for (int32 i = 0; i < KeyButtonSelectables.Num(); i++)
		{
			KeyButtonSelectables[i]->DisableSelectable();
		}

		if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
		{
			PlayerControllerBase->ClearSelectables();
		}
	}
}

bool AANNumLockPuzzle::IsLongInteract() const
{
	return true;
}

bool AANNumLockPuzzle::IsInteracting() const
{
	return bInteracting;
}

FString AANNumLockPuzzle::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	SaveString = SaveString.Append(Super::BP_ConstructSaveString_Implementation());

	FString SaveableUnlockCode(SaveableParams::UnlockCode);
	SaveableUnlockCode = SaveableUnlockCode.Append(UnlockCode);
	SaveableUnlockCode = SaveableUnlockCode.Append(";");

	SaveString = SaveString.Append(SaveableUnlockCode);

	return SaveString;
}

void AANNumLockPuzzle::BP_LoadObject_Implementation(const FString& LoadString)
{
	Super::BP_LoadObject_Implementation(LoadString);
	if (LoadString.Contains(SaveableParams::UnlockCode))
	{
		FString UnlockCodeString = LoadString;
		int32 UnlockCodeStartIndex = UnlockCodeString.Find(SaveableParams::UnlockCode);
		UnlockCodeString = UnlockCodeString.RightChop(UnlockCodeStartIndex + SaveableParams::UnlockCode.Len());
		int32 SemicolonStartIndex = UnlockCodeString.Find(";");
		UnlockCodeString = UnlockCodeString.LeftChop(UnlockCodeString.Len() - SemicolonStartIndex);

		UnlockCode = UnlockCodeString; //TODO Update later to set Unlock Code in a different location
	}
}