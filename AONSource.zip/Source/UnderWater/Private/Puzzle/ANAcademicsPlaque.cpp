// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle/ANAcademicsPlaque.h"

#include "ANConsts.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "Environment/ANMovingStatue.h"
#include "Game/ANGameInstance.h"
#include "Interface/ANItemable.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"

AANAcademicsPlaque::AANAcademicsPlaque() :
	AANPuzzleInteractable()
{
	HardrivePositions.Reserve(3);	
	bPoweredOn = false;
}

void AANAcademicsPlaque::BeginPlay()
{
	Super::BeginPlay();
	if (bPoweredOnAtStart)
	{
		bPoweredOn = true;
	}
	else
	{
		bPoweredOn = false;
	}
}

bool AANAcademicsPlaque::CanInteract() const
{
	return !bInteracting && !IsPuzzleComplete();
}

void AANAcademicsPlaque::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	bOpensInventory = bPoweredOn;
	AANPuzzleInteractable::BeginInteract(InteractingCharacter);
}

void AANAcademicsPlaque::EndInteract(AANCharacterBase* InteractingCharacter)
{
	AANPuzzleInteractable::EndInteract(InteractingCharacter);
}

bool AANAcademicsPlaque::IsInteracting() const
{
	return bInteracting;
}

bool AANAcademicsPlaque::IsLongInteract() const
{
	return true;
}

void AANAcademicsPlaque::BP_InsertItem_Implementation(const FString& InsertedItem, bool bConsumeItem)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(GetGameInstance()))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			if (FANItem* InsertedItemData = InventorySystem->GetItemDataFromTable(InsertedItem))
			{
				if (bConsumeItem)
				{
					InventorySystem->UseItem(InsertedItem, 1);
				}
				NumInteractions++;
				
				if (NumInteractions >= 3)
				{
					CompletePuzzle(false);
				}
				else
				{
					//Complete Puzzle will also save for us, so only do this if we didn't complete the puzzle
					SaveObject();
				}
				EndInteract(LongInteractingCharacter);
				BP_InsertDrive(false);
				if (MovingStatue != nullptr)
				{
					MovingStatue->BP_UpdateState(NumInteractions, false);
				}
			}
		}
	}
}

void AANAcademicsPlaque::BP_PowerOn_Implementation()
{
	bPoweredOn = true;
}

void AANAcademicsPlaque::BP_PowerOff_Implementation()
{
	bPoweredOn = false;
}

bool AANAcademicsPlaque::BP_IsPoweredOn_Implementation()
{
	return bPoweredOn;
}

FText AANAcademicsPlaque::BP_GetPowerableName_Implementation()
{
	return PowerableName;
}

FString AANAcademicsPlaque::BP_ConstructSaveString_Implementation()
{
	FString SaveString("");
	if (IsPuzzleComplete())
	{
		SaveString = SaveString.Append(SaveableParams::CompleteTrue);
	}
	else
	{
		SaveString = SaveString.Append(SaveableParams::CompleteFalse);
	}

	FString NumInteractionsString(SaveableParams::NumInteractions);
	NumInteractionsString = NumInteractionsString.Append(FString::FromInt(NumInteractions));
	NumInteractionsString = NumInteractionsString.Append(";");
	SaveString = SaveString.Append(NumInteractionsString);

	return SaveString;
}

void AANAcademicsPlaque::BP_LoadObject_Implementation(const FString& LoadString)
{
	if (LoadString.Contains(SaveableParams::CompleteTrue))
	{
		CompletePuzzle(true);
	}
	else
	{
		UncompletePuzzle();
	}

	FString NumInteractionsString = UANFunctionLibrary::GetSaveableParamValue(LoadString, SaveableParams::NumInteractions);
	if (!NumInteractionsString.IsEmpty())
	{
		int32 NumInteractionsAsInt = INDEX_NONE;
		NumInteractionsAsInt = FCString::Atoi(*NumInteractionsString);
		if (NumInteractionsAsInt >= 0)
		{
			NumInteractions = NumInteractionsAsInt;
			BP_InsertDrive(true);
			if (MovingStatue != nullptr)
			{
				MovingStatue->BP_UpdateState(NumInteractions, true);
			}
		}
	}
}
