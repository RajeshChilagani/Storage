// 2021 Abyssmal Games and Synodic Arc


#include "Puzzle\ANVoltagePanel.h"

AANVoltagePanel::AANVoltagePanel()
	: Super()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

void AANVoltagePanel::BeginPlay()
{
	Super::BeginPlay();
	
}

void AANVoltagePanel::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

