// 2021 Abyssmal Games and Synodic Arc


#include "Happening/ItemUse/ANItemUseHappening.h"

#include "Character/ANCharacterBase.h"

AANItemUseHappening::AANItemUseHappening()
	: Super()
{
	IntegerValue = 0;
	FloatValue = 0.0f;
}

void AANItemUseHappening::BeginPlay()
{
	Super::BeginPlay();
}

void AANItemUseHappening::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANItemUseHappening::SetItemUseParameters(int32 NewIntegerValue, float NewFloatValue, const FText& NewTextValue)
{
	IntegerValue = NewIntegerValue;
	FloatValue = NewFloatValue;
	TextValue = NewTextValue;
}

void AANItemUseHappening::DoHappening_Implementation()
{
	Super::DoHappening_Implementation();
}