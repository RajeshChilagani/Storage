// 2021 Abyssmal Games and Synodic Arc


#include "Happening/ItemUse/ANHealthRecoveryHappening.h"

#include "Character/ANCharacterBase.h"

AANHealthRecoveryHappening::AANHealthRecoveryHappening()
	: Super()
{

}

void AANHealthRecoveryHappening::DoHappening_Implementation()
{
	Super::DoHappening_Implementation();

	if (InstigatingCharacter != nullptr)
	{
		InstigatingCharacter->RecoverHealth(IntegerValue);
	}
	EndHappening();
}
