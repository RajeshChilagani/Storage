// 2021 Abyssmal Games and Synodic Arc

#include "Happening/ItemUse/ANOxygenRecoveryHappening.h"

#include "ANConsts.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameplaySaveGame.h"

AANOxygenRecoveryHappening::AANOxygenRecoveryHappening()
	: Super()
{

}

void AANOxygenRecoveryHappening::DoHappening_Implementation()
{
	Super::DoHappening_Implementation();

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InstigatingCharacter))
	{
		MainCharacter->RefillOxygen(IntegerValue);
	}

	EndHappening();
}
