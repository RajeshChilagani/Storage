// 2021 Abyssmal Games and Synodic Arc


#include "Happening/ANGenericHappening.h"

#include "Components/SceneComponent.h"

#include "AkAudioEvent.h"

#include "Character/ANCharacterBase.h"
#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANCondition.h"

AANGenericHappening::AANGenericHappening()
{
	HappeningSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("HappeningSceneComponent"));
	HappeningSceneComponent->SetupAttachment(RootComponent);

	bActive = false;
}

void AANGenericHappening::BeginPlay()
{
	Super::BeginPlay();
}

void AANGenericHappening::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void AANGenericHappening::InitializeHappening(AANCharacterBase* NewInstigatingCharacter)
{
	bActive = true;
	InstigatingCharacter = NewInstigatingCharacter;
}

bool AANGenericHappening::CanDoHappening_Implementation()
{
	return UANFunctionLibrary::IsConditionValid(ConditionToVerifySubclass, InstigatingCharacter, this);
}

void AANGenericHappening::DoHappening_Implementation()
{
	if (InstigatingCharacter != nullptr && AudioEventToPlay != nullptr)
	{
		InstigatingCharacter->PostAkAudioEventOnCharacter(AudioEventToPlay);
	}
}

void AANGenericHappening::EndHappening()
{
	bActive = false;
}