// 2021 Abyssmal Games and Synodic Arc


#include "Shared/ANAchievementManager.h"

#include "ANConsts.h"

#include "Controller/ANPlayerControllerBase.h"

// Sets default values
AANAchievementManager::AANAchievementManager()
{
}

// Called when the game starts or when spawned
void AANAchievementManager::BeginPlay()
{
	Super::BeginPlay();
}

void AANAchievementManager::UnlockAchievement(EANAchievements AchivementToUnlock)
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	AANPlayerControllerBase* PlayerControllerBase = MyWorld->GetFirstPlayerController<AANPlayerControllerBase>();
	if (PlayerControllerBase == nullptr)
	{
		return;
	}

	FName AchievementName = GetAchievementName(AchivementToUnlock);

	UnlockAchievementInBlueprints(PlayerControllerBase, AchievementName);
}

void AANAchievementManager::UnlockAchievementViaName(const FName& AchievementNameToUnlock)
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	AANPlayerControllerBase* PlayerControllerBase = MyWorld->GetFirstPlayerController<AANPlayerControllerBase>();
	if (PlayerControllerBase == nullptr)
	{
		return;
	}

	UnlockAchievementInBlueprints(PlayerControllerBase, AchievementNameToUnlock);
}

FName AANAchievementManager::GetAchievementName(EANAchievements AchievementToUnlock)
{
	switch (AchievementToUnlock)
	{
	case(EANAchievements::AbyssOfLearning):
		return AchievementNames::AbyssOfLearning;
	case(EANAchievements::AbyssOfShooting):
		return AchievementNames::AbyssOfShooting;
	case(EANAchievements::AbyssOfAcademia):
		return AchievementNames::AbyssOfAcademia;
	case(EANAchievements::AbyssOfSearching):
		return AchievementNames::AbyssOfSearching;
	case(EANAchievements::AbyssOfExploration):
		return AchievementNames::AbyssOfExploration;
	case(EANAchievements::AbyssOfCompletion):
		return AchievementNames::AbyssOfCompletion;
	case(EANAchievements::AbyssOfSpeedrunning):
		return AchievementNames::AbyssOfSpeedrunning;
	case(EANAchievements::AbyssOfGrit):
		return AchievementNames::AbyssOfGrit;
	case(EANAchievements::AbyssOfMercy):
		return AchievementNames::AbyssOfMercy;
	case(EANAchievements::AbyssOfPersistence):
		return AchievementNames::AbyssOfPersistence;
	case(EANAchievements::AbyssOfMasochism):
		return AchievementNames::AbyssOfMasochism;
	case(EANAchievements::AbyssOfDevelopers):
		return AchievementNames::AbyssOfDevelopers;
	default:
		break;
	}

	return NAME_None;
}

//void UAchievementFunctionLibrary::BeginPlay()
//{
//	Super::BeginPlay();
//
//	//Cache all the available achievements
//	QueryAchievements();
//}

//void AANAchievementManager::UpdateAchievementProgress(const FString& Id, float Percent)
//{
//	//Get the online sub system
//	IOnlineSubsystem* OnlineSub = IOnlineSubsystem::Get();
//
//	if (OnlineSub)
//	{
//		//Get the Identity from the sub system 
//		//Meaning our player's profile and various online services
//		IOnlineIdentityPtr Identity = OnlineSub->GetIdentityInterface();
//
//		if (Identity.IsValid())
//		{
//			//Get a thread-safe pointer (for more info check out this link: https://docs.unrealengine.com/latest/INT/API/Runtime/Core/Templates/TSharedPtr/index.html )
//			TSharedPtr<const FUniqueNetId> UserId = Identity->GetUniquePlayerId(0);
//
//			//Get the achievements interface for this platform
//			IOnlineAchievementsPtr Achievements = OnlineSub->GetAchievementsInterface();
//
//
//			if (Achievements.IsValid() && (!AchievementsWriteObjectPtr.IsValid() || !AchievementsWriteObjectPtr->WriteState != EOnlineAsyncTaskState::InProgress))
//			{
//				//Make a shared pointer for achievement writing
//				AchievementsWriteObjectPtr = MakeShareable(new FOnlineAchievementsWrite());
//
//				//Sets the progress of the desired achievement - does nothing if the id is not valid
//				AchievementsWriteObjectPtr->SetFloatStat(*Id, Percent);
//
//				//Write the achievements progress
//				FOnlineAchievementsWriteRef AchievementsWriteObjectRef = AchievementsWriteObjectPtr.ToSharedRef();
//				Achievements->WriteAchievements(*UserId, AchievementsWriteObjectRef);
//			}
//		}
//	}
//}
//
//void AANAchievementManager::WinGameAchievement()
//{
//	UpdateAchievementProgress(ACH_WIN_ONE_GAME, 100.f);
//}
//
//void AANAchievementManager::WinManyGamesAchievement()
//{
//	UpdateAchievementProgress(AC_WIN_100_GAMES, 100.f);
//}
//
//void AANAchievementManager::TravelFarAwayAchievement()
//{
//	UpdateAchievementProgress(AC_TRAVEL_FAR_SINGLE, 100.f);
//}