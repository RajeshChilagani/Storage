// Fill out your copyright notice in the Description page of Project Settings.


#include "Shared/ANFunctionLibrary.h"

#include "Blueprint/WidgetBlueprintLibrary.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"

#include "Game/ANGameInstance.h"
#include "SaveGame/ANGameUserSettings.h"
#include "SaveGame/ANGameplaySaveGame.h"
#include "Shared/ANAchievementManager.h"
#include "Systems/ANInventorySystem.h"
#include "Systems/ANCondition.h"
#include "UI/ANSelectableWidget.h"

bool UANFunctionLibrary::LoadSoftObject(TSoftObjectPtr<UObject> SoftObject)
{
	if (!SoftObject.IsValid())
	{
		SoftObject.LoadSynchronous();
	}

	return SoftObject.IsValid();
}

UBlueprint* UANFunctionLibrary::GetBlueprint(FString FilePath)
{
	FStringAssetReference AssetRef = FilePath;
	UObject* ItemObj = nullptr;
	UBlueprint* GeneratedBlueprint = nullptr;

	ItemObj = AssetRef.ResolveObject();

	if (!ItemObj)
	{
		ItemObj = AssetRef.TryLoad();
	}

	GeneratedBlueprint = Cast<UBlueprint>(ItemObj);

	return GeneratedBlueprint;
}

UANGameInstance* UANFunctionLibrary::GetGameInstance(const UObject* WorldContextObject)
{
	UANGameInstance* GameInstance = Cast<UANGameInstance>(UGameplayStatics::GetGameInstance(WorldContextObject));
	return GameInstance;
}

UANGameplaySaveGame* UANFunctionLibrary::GetActiveGameplaySaveGame(const UObject* WorldContextObject)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(UGameplayStatics::GetGameInstance(WorldContextObject)))
	{
		if (UANGameplaySaveGame* ActiveGameplaySaveGame = GameInstance->GetActiveGameplaySaveGame())
		{
			return ActiveGameplaySaveGame;
		}
	}

	return nullptr;
}

UANInventorySystem* UANFunctionLibrary::GetInventorySystem(const UObject* WorldContextObject)
{
	if (WorldContextObject == nullptr)
	{
		return nullptr;
	}

	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(UGameplayStatics::GetGameInstance(WorldContextObject)))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			return InventorySystem;
		}
	}

	return nullptr;
}

FLinearColor UANFunctionLibrary::GetLinearColorForMessageColor(EANMessageColors MessageColor)
{
	FLinearColor ReturnColor = FLinearColor::White;

	switch (MessageColor)
	{
	case(EANMessageColors::White):
		ReturnColor = FLinearColor::White;
		break;
	case(EANMessageColors::Red):
		ReturnColor = FLinearColor::Red;
		break;
	case(EANMessageColors::Cyan):
		ReturnColor = FLinearColor(0.0f, 1.0f, 1.0f);
		break;
	case(EANMessageColors::Yellow):
		ReturnColor = FLinearColor::Yellow;
		break;
	case(EANMessageColors::Pink):
		ReturnColor = FLinearColor(0.75f, 0.0f, 0.0f);
		break;
	case(EANMessageColors::Orange):
		ReturnColor = FLinearColor(1.0f, 0.6f, 0.0f);
		break;
	}

	return ReturnColor;
}

FString UANFunctionLibrary::GetSaveableParamValue(FString SaveableParamsString, FString ParamName)
{
	FString ParamValueString = SaveableParamsString;
	int32 ParamNameStartIndex = ParamValueString.Find(ParamName);
	ParamValueString = ParamValueString.RightChop(ParamNameStartIndex + ParamName.Len());
	int32 SemicolonStartIndex = ParamValueString.Find(";");
	ParamValueString = ParamValueString.LeftChop(ParamValueString.Len() - SemicolonStartIndex);

	return ParamValueString;
}

FString UANFunctionLibrary::MakeSaveableParam(FString ParamName, FString ParamValue)
{
	FString NewParam(ParamName);
	NewParam = NewParam.Append(ParamValue);
	NewParam = NewParam.Append(";");

	return NewParam;
}

TArray<FName> UANFunctionLibrary::GetSharedSublevelNames()
{
	TArray<FName> SharedSublevelNames;

	SharedSublevelNames.Add(LevelNames::GameWorld_Shared);
	SharedSublevelNames.Add(LevelNames::GameWorld_Transitions);

	SharedSublevelNames.Add(LevelNames::Exterior_SL_Audio);
	SharedSublevelNames.Add(LevelNames::Exterior_SL_Foliage);
	SharedSublevelNames.Add(LevelNames::Exterior_SL_Geometry);
	SharedSublevelNames.Add(LevelNames::Exterior_SL_Lighting);

	return SharedSublevelNames;
}

TArray<FName> UANFunctionLibrary::GetSublevelNamesForLevel(EANLevels Level)
{
	TArray<FName> LevelSublevelNames;

	switch (Level)
	{
	case(EANLevels::Tutorial):
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Audio);
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Foliage);
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Geometry);
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Lighting);
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Props);
		LevelSublevelNames.Add(LevelNames::Tutorial_SL_Puzzles);
		break;
	case(EANLevels::Dormitory):
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Audio);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Foliage);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_FX);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Geometry);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Lighting);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Props);
		LevelSublevelNames.Add(LevelNames::Dormitory_SL_Puzzles);
		break;
	case(EANLevels::Lobby):
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Audio);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Foliage);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_FX);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Geometry);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Lighting);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Props);
		LevelSublevelNames.Add(LevelNames::Lobby_SL_Puzzles);
		break;
	case(EANLevels::Academics):
		LevelSublevelNames.Add(LevelNames::Academics_SL_AI);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Audio);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Foliage);
		LevelSublevelNames.Add(LevelNames::Academics_SL_FX);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Geometry);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Lighting);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Props);
		LevelSublevelNames.Add(LevelNames::Academics_SL_Puzzles);
		LevelSublevelNames.Add(LevelNames::Academics_SL_ScriptedEvents);
		break;
	case(EANLevels::Lab):
		LevelSublevelNames.Add(LevelNames::Lab_SL_AI);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Audio);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Foliage);
		LevelSublevelNames.Add(LevelNames::Lab_SL_FX);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Geometry);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Lighting);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Props);
		LevelSublevelNames.Add(LevelNames::Lab_SL_Puzzles);
		LevelSublevelNames.Add(LevelNames::Lab_SL_ScriptedEvents);
		break;
	default:
		break;
	}

	return LevelSublevelNames;
}

UANGameUserSettings* UANFunctionLibrary::GetANGameUserSettings()
{
	if (UANGameUserSettings* ANGameUserSettings = Cast<UANGameUserSettings>(GEngine->GetGameUserSettings()))
	{
		return ANGameUserSettings;
	}

	return nullptr;
}

FString UANFunctionLibrary::GetProjectVersion()
{
	FString ProjectVersion;
	if (GConfig)
	{
		GConfig->GetString(TEXT("/Script/EngineSettings.GeneralProjectSettings"), TEXT("ProjectVersion"), ProjectVersion, GGameIni);
	}
	return ProjectVersion;
}

void UANFunctionLibrary::SetColorDeficiency(EColorDeficiencyMode ColorDeficiencyMode, float Severity, bool bCorrectDeficiency, bool bShowCorrectionWithDeficiency)
{
	EColorVisionDeficiency ColorVisionDeficiency = ConvertColorDeficiencyModeToColorVisionDeficiency(ColorDeficiencyMode);
	UWidgetBlueprintLibrary::SetColorVisionDeficiencyType(ColorVisionDeficiency, Severity, bCorrectDeficiency, bShowCorrectionWithDeficiency);
}

bool UANFunctionLibrary::IsConditionValid(TSubclassOf<UANCondition> ConditionToVerifySubclass, AActor* CheckAgainstActor, AActor* InstigatingActor)
{
	//Check conditions
	if (ConditionToVerifySubclass != nullptr)
	{
		UClass* ConditionToVerifyClass = ConditionToVerifySubclass.Get();
		if (ConditionToVerifyClass != nullptr)
		{
			UANCondition* Condition = NewObject<UANCondition>(InstigatingActor, ConditionToVerifyClass, FName(ConditionToVerifyClass->GetName()));
			if (Condition != nullptr)
			{
				if (Condition->MeetsConditions(CheckAgainstActor))
				{
					return true;
				}
				else
				{
					return false;
				}
				//TODO: Should we destroy the condition manually here?
			}
		}
	}

	////Check conditions
	//if (!ConditionToVerifySoftClass.IsNull())
	//{
	//	UClass* ConditionToVerifyClass = ConditionToVerifySoftClass.Get();
	//	if (ConditionToVerifyClass != nullptr)
	//	{
	//		UANCondition* Condition = NewObject<UANCondition>(InstigatingActor, ConditionToVerifyClass, FName(ConditionToVerifyClass->GetName()));
	//		if (Condition != nullptr)
	//		{
	//			if (Condition->MeetsConditions(CheckAgainstActor))
	//			{
	//				return true;
	//			}
	//			else
	//			{
	//				return false;
	//			}
	//			//TODO: Should we destroy the condition manually here?
	//		}
	//	}
	//}

	//If we don't have a valid condition, assume that the condition is always valid
	return true;
}

float UANFunctionLibrary::ConvertSensitivityToModifier(int32 SensitivityLevel)
{
	float Modifier = 1.0f;

	switch (SensitivityLevel)
	{
	case(0):
		Modifier = 0.5f;
		break;
	case(1):
		Modifier = 0.75f;
		break;
	case(2):
		Modifier = 1.0f;
		break;
	case(3):
		Modifier = 1.25f;
		break;
	case(4):
		Modifier = 1.5f;
		break;
	default:
		break;
	}

	return Modifier;
}

float UANFunctionLibrary::ConvertVolumeToModifier(int32 VolumeLevel)
{
	float Modifier = 100.0f;

	switch (VolumeLevel)
	{
	case(0):
		Modifier = 0.0f;
		break;
	case(1):
		Modifier = 25.0f;
		break;
	case(2):
		Modifier = 50.0f;
		break;
	case(3):
		Modifier = 75.0f;
		break;
	case(4):
		Modifier = 100.0f;
		break;
	default:
		break;
	}

	return Modifier;
}

FName UANFunctionLibrary::GetActionMappingForInputAction(EANInputActions InputAction)
{
	switch (InputAction)
	{
	case(EANInputActions::Fire):
		return ActionMappings::Fire;
	case(EANInputActions::Aim):
		return ActionMappings::Aim;
	case(EANInputActions::Interact):
		return ActionMappings::Interact;
	case(EANInputActions::Flashlight):
		return ActionMappings::Flashlight;
	case(EANInputActions::Reload):
		return ActionMappings::Reload;
	case(EANInputActions::Jet):
		return ActionMappings::Jet;
	case(EANInputActions::Map):
		return ActionMappings::Map;
	case(EANInputActions::Ascend):
		return ActionMappings::Ascend;
	case(EANInputActions::Descend):
		return ActionMappings::Descend;
	case(EANInputActions::Inventory):
		return ActionMappings::Inventory;
	case(EANInputActions::AttachmentOne):
		return ActionMappings::AttachmentOne;
	case(EANInputActions::AttachmentTwo):
		return ActionMappings::AttachmentTwo;
	case(EANInputActions::AttachmentThree):
		return ActionMappings::AttachmentThree;
	case(EANInputActions::AttachmentFour):
		return ActionMappings::AttachmentFour;
	case(EANInputActions::UIConfirm):
		return ActionMappings::UIConfirm;
	case(EANInputActions::UIBack):
		return ActionMappings::UIBack;
	case(EANInputActions::UISpecialOne):
		return ActionMappings::UISpecialOne;
	case(EANInputActions::UISpecialTwo):
		return ActionMappings::UISpecialTwo;
	case(EANInputActions::UITabRightOne):
		return ActionMappings::UITabRightOne;
	case(EANInputActions::UITabLeftOne):
		return ActionMappings::UITabLeftOne;
	case(EANInputActions::UITabRightTwo):
		return ActionMappings::UITabRightTwo;
	case(EANInputActions::UITabLeftTwo):
		return ActionMappings::UITabLeftTwo;
	case(EANInputActions::UIUp):
		return ActionMappings::UIUp;
	case(EANInputActions::UIDown):
		return ActionMappings::UIDown;
	case(EANInputActions::UIRight):
		return ActionMappings::UIRight;
	case(EANInputActions::UILeft):
		return ActionMappings::UILeft;
	case(EANInputActions::UICursorClick):
		return ActionMappings::UICursorClick;
	case(EANInputActions::Pause):
		return ActionMappings::Pause;
	case(EANInputActions::DebugMenu):
		return ActionMappings::DebugMenu;
	}

	return NAME_None;
}

EColorVisionDeficiency UANFunctionLibrary::ConvertColorDeficiencyModeToColorVisionDeficiency(EColorDeficiencyMode ColorDeficiencyMode)
{
	switch (ColorDeficiencyMode)
	{
	case(EColorDeficiencyMode::NormalVision):
		return EColorVisionDeficiency::NormalVision;
	case(EColorDeficiencyMode::Deuteranope):
		return EColorVisionDeficiency::Deuteranope;
	case(EColorDeficiencyMode::Protanope):
		return EColorVisionDeficiency::Protanope;
	case(EColorDeficiencyMode::Tritanope):
		return EColorVisionDeficiency::Tritanope;
	default:
		break;
	}
	
	return EColorVisionDeficiency::NormalVision;
}

void UANFunctionLibrary::InitializeSelectableWidget(UANSelectableWidget* AddingSelectableWidget, TArray<UANSelectableWidget*>& AddingToArray)
{
	if (AddingSelectableWidget == nullptr)
	{
		return;
	}

	//If on an invalid platform, collapse and return
	if (!AddingSelectableWidget->IsValidPlatform())
	{
		AddingSelectableWidget->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	AddingToArray.Add(AddingSelectableWidget);
}

EPlatforms UANFunctionLibrary::GetPlatform()
{
#if PLATFORM_PS4
	return EPlatforms::PS4;
#elif PLATFORM_XBOXONE

#endif

	return EPlatforms::Steam;
}

bool UANFunctionLibrary::IsConsole()
{
	EPlatforms CurrentPlatform = GetPlatform();

	switch (CurrentPlatform)
	{
	case(EPlatforms::Steam):
		return false;
	case(EPlatforms::PS4):
		return true;
	default:
		break;
	}

	return false;
}

void UANFunctionLibrary::UnlockAchievement(EANAchievements AchievementNameToUnlock, UObject* WorldRefObject)
{
	if (WorldRefObject == nullptr)
	{
		return;
	}

	UWorld* MyWorld = WorldRefObject->GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	AANAchievementManager* ActiveAchievementManager = nullptr;
	for (TActorIterator<AANAchievementManager> AchievementManagerIterator(MyWorld); AchievementManagerIterator; ++AchievementManagerIterator)
	{
		ActiveAchievementManager = *AchievementManagerIterator;
		break;
	}

	if (ActiveAchievementManager != nullptr)
	{
		ActiveAchievementManager->UnlockAchievement(AchievementNameToUnlock);
	}
}

bool UANFunctionLibrary::IsDevelopmentBuild()
{
#if UE_BUILD_SHIPPING
	return false;
#endif

	return true;
}

//Data Table access reference code
//bool UANFunctionLibrary::FindContextualPingTypesRowByType(const UDataTable* ContextualPingTypesDT, EPingType PingType, FContextualPingTypesRow& ContextualPingTypesRow)
//{
//	if (ContextualPingTypesDT != nullptr)
//	{
//		TArray<FName> RowNames = ContextualPingTypesDT->GetRowNames();
//		TArray<FContextualPingTypesRow*> PingRows;
//
//		ContextualPingTypesDT->GetAllRows("", PingRows);
//
//		for (FContextualPingTypesRow* Ping : PingRows)
//		{
//			if (Ping->PingType == PingType)
//			{
//				ContextualPingTypesRow = *Ping;
//				return true;
//			}
//		}
//	}
//
//	return false;
//}