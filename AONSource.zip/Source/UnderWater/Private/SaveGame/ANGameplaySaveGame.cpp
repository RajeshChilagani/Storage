// �2021 Abyssmal Games and Synodic Arc


#include "SaveGame/ANGameplaySaveGame.h"

#include "ANConsts.h"

UANGameplaySaveGame::UANGameplaySaveGame()
{
	bStarted = false;
	DifficultyLevel = EANDifficultyLevels::Normal;
	GameplayTime = 0.0f;
	SavedAtHealth = 100;
	SavedAtLevel = EANLevels::Tutorial;
	SavedAtTransform = FTransform();
}

FString UANGameplaySaveGame::GenerateCode(int32 CodeLength, int32 MaxIndex /*= 9*/, bool bAllowRepeatNumbers /*= true*/)
{
	FString GeneratedCode = FString("");
	for (int32 i = 0; i < CodeLength; i++)
	{
		int32 RandomNumber = FMath::RandRange(0, MaxIndex);

		//If we don't allow repeated numbers, check to see if we already have that number and continue if so
		if (!bAllowRepeatNumbers)
		{
			if (GeneratedCode.Contains(FString::FromInt(RandomNumber)))
			{
				i--;
				continue;
			}
		}

		GeneratedCode.Append(FString::FromInt(RandomNumber));
	}

	return GeneratedCode;
}

void UANGameplaySaveGame::InitializeDefaultValues(EANDifficultyLevels SelectedDifficultyLevel)
{
	bStarted = false;
	DifficultyLevel = SelectedDifficultyLevel;
	GameplayTime = 0.0f;
	SavedAtHealth = 100;
	SavedAtLevel = EANLevels::Tutorial;
	SavedAtTransform = FTransform();
	SavedAtTransform.SetLocation(DefaultSaveValues::DefaultStartLocation);
	SavedAtTransform.SetRotation(DefaultSaveValues::DefaultStartRotation.Quaternion());

	SetSaveableStringValue(SaveableStringNames::Code1, GenerateCode(4));
	SetSaveableStringValue(SaveableStringNames::Code2, GenerateCode(4));
	SetSaveableStringValue(SaveableStringNames::Code3, GenerateCode(4));
	SetSaveableStringValue(SaveableStringNames::Code4, GenerateCode(4));
	SetSaveableStringValue(SaveableStringNames::Code5, GenerateCode(4));
	SetSaveableStringValue(SaveableStringNames::CrossSwitchesCode, GenerateCode(3, 8, false));
}

void UANGameplaySaveGame::SaveSaveableString(const FGuid& GuidToSave, const FString& SaveString)
{
	//If Guid doesn't exist, add new
	if (!SaveableStrings.Contains(GuidToSave))
	{
		SaveableStrings.Add(GuidToSave, SaveString);
	}
	//if does exist, overwrite
	else
	{
		SaveableStrings[GuidToSave] = SaveString;
	}
}

void UANGameplaySaveGame::SaveWorldSaveable(const FGuid& GuidToSave, const FWorldSaveableData& NewWorldSaveableData)
{
	//If Guid doesn't exist, add new
	if (!WorldSaveableDatas.Contains(GuidToSave))
	{
		WorldSaveableDatas.Add(GuidToSave, NewWorldSaveableData);
	}
	//if does exist, overwrite
	else
	{
		WorldSaveableDatas[GuidToSave] = NewWorldSaveableData;
	}
}

void UANGameplaySaveGame::RemoveWorldSaveable(const FGuid& GuidToRemove)
{
	if (WorldSaveableDatas.Contains(GuidToRemove))
	{
		WorldSaveableDatas.Remove(GuidToRemove);
	}
}

void UANGameplaySaveGame::SetStarted(bool bNewStarted)
{
	bStarted = bNewStarted;
}

void UANGameplaySaveGame::SetGameplayTime(float NewGameplayTime)
{
	GameplayTime = NewGameplayTime;
}

void UANGameplaySaveGame::SetSavedAtHealth(int32 NewSavedAtHealth)
{
	SavedAtHealth = NewSavedAtHealth;
}

void UANGameplaySaveGame::SetSavedAtLevel(EANLevels NewSavedAtLevel)
{
	SavedAtLevel = NewSavedAtLevel;
}

void UANGameplaySaveGame::SetSavedAtTransform(FTransform NewSavedAtTransform)
{
	SavedAtTransform = NewSavedAtTransform;
}

void UANGameplaySaveGame::AddSavedItem(const FString& ItemName, int32 ItemCount)
{
	SavedItems.Add(ItemName, ItemCount);
}

void UANGameplaySaveGame::ClearSavedItems()
{
	SavedItems.Empty();
}

void UANGameplaySaveGame::TryAddVisitedRoom(const FName& NewVisitedRoom)
{
	VisitedRooms.AddUnique(NewVisitedRoom);
}

void UANGameplaySaveGame::SetSaveableBoolValue(FName SaveableName, bool bNewBoolValue)
{
	if (!SaveableBoolValues.Contains(SaveableName))
	{
		SaveableBoolValues.Add(SaveableName);
	}

	SaveableBoolValues[SaveableName] = bNewBoolValue;
}

void UANGameplaySaveGame::SetSaveableIntValue(FName SaveableName, int32 NewIntValue)
{
	if (!SaveableIntValues.Contains(SaveableName))
	{
		SaveableIntValues.Add(SaveableName);
	}

	SaveableIntValues[SaveableName] = NewIntValue;
}

void UANGameplaySaveGame::SetSaveableFloatValue(FName SaveableName, float NewFloatValue)
{
	if (!SaveableFloatValues.Contains(SaveableName))
	{
		SaveableFloatValues.Add(SaveableName);
	}

	SaveableFloatValues[SaveableName] = NewFloatValue;
}

void UANGameplaySaveGame::SetSaveableStringValue(FName SaveableName, FString NewStringValue)
{
	if (!SaveableStringValues.Contains(SaveableName))
	{
		SaveableStringValues.Add(SaveableName);
	}

	SaveableStringValues[SaveableName] = NewStringValue;
}

FString UANGameplaySaveGame::GetSaveableStringForGuid(const FGuid& GuidToCheck)
{
	if (SaveableStrings.Contains(GuidToCheck))
	{
		return SaveableStrings[GuidToCheck];
	}

	return FString();
}

FWorldSaveableData UANGameplaySaveGame::GetWorldSaveableDataForGuid(const FGuid& GuidToCheck)
{
	if (WorldSaveableDatas.Contains(GuidToCheck))
	{
		return WorldSaveableDatas[GuidToCheck];
	}

	return FWorldSaveableData();
}

bool UANGameplaySaveGame::GetSaveableBoolValue(FName SaveableName, bool& bOutBoolValue) const
{
	if (!SaveableBoolValues.Contains(SaveableName))
	{
		return false;
	}

	bOutBoolValue = SaveableBoolValues[SaveableName];
	return true;
}

bool UANGameplaySaveGame::GetSaveableIntValue(FName SaveableName, int32& OutIntValue) const
{
	if (!SaveableIntValues.Contains(SaveableName))
	{
		return false;
	}

	OutIntValue = SaveableIntValues[SaveableName];
	return true;
}

bool UANGameplaySaveGame::GetSaveableFloatValue(FName SaveableName, float& OutFloatValue) const
{
	if (!SaveableFloatValues.Contains(SaveableName))
	{
		return false;
	}

	OutFloatValue = SaveableFloatValues[SaveableName];
	return true;
}

bool UANGameplaySaveGame::GetSaveableStringValue(FName SaveableName, FString& OutStringValue) const
{
	if (!SaveableStringValues.Contains(SaveableName))
	{
		return false;
	}

	OutStringValue = SaveableStringValues[SaveableName];
	return true;
}