// 2021 Abyssmal Games and Synodic Arc


#include "SaveGame/ANGameUserSettings.h"

UANGameUserSettings::UANGameUserSettings(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bInvertYAxis = false;
	bJetBoostToggle = false;
#if PLATFORM_PS4
	IconSet = EIconSets::PS4;
#else
	IconSet = EIconSets::KeyboardMouse;
#endif
	MouseHorizontalSensitivity = 2;
	MouseVerticalSensitivity = 2;
	GamepadHorizontalSensitivity = 2;
	GamepadVerticalSensitivity = 2;

	ColorDeficiencyMode = EColorDeficiencyMode::NormalVision;
#if PLATFORM_PS4
	QualityLevel = 2;
#else
	QualityLevel = 3;
#endif

	SFXVolume = 4;
	DialogueVolume = 4;
	MusicVolume = 4;
}

void UANGameUserSettings::ApplyNonResolutionSettings()
{
	Super::ApplyNonResolutionSettings();
}