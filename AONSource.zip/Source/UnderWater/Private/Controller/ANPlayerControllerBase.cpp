// Fill out your copyright notice in the Description page of Project Settings.


#include "Controller/ANPlayerControllerBase.h"

#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"

#include "ANConsts.h"
#include "ANDefines.h"

#include "Character/ANCharacterBase.h"
#include "Character/ANMainCharacter.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Interface/ANSelectable.h"
#include "UI/Debug/ANDebugMenuWidget.h"
#include "UI/HUD/ANHUDWidget.h"
#include "UI/HUD/ANHUDWidgetBase.h"
#include "Shared/ANFunctionLibrary.h"

AANPlayerControllerBase::AANPlayerControllerBase()
	: Super()
{
	DialogueManager = CreateDefaultSubobject<UANDialogueManagerComponent>(TEXT("DialogueManager"));

	SelectableJustification = EButtonJustifications::Left;
	RowIndex = 0;
	ColumnIndex = 0;

	PlayerNumber = EPlayerNumbers::P1;

	bUpdateInputNextTick = false;
	NextInputType = EGameInputTypes::Transition;

	bPaused = false;
	bInPausableMode = false;
	InputTypeBeforePause = EGameInputTypes::GameOnly;

	bDebugMenuOpen = false;
}

void AANPlayerControllerBase::Tick(float DeltaSeconds)
{
	if (IsInUIInput())
	{
		TraceCursorForSelectable();
	}

	if (bUpdateInputNextTick)
	{
		bUpdateInputNextTick = false;
		SetGameInputAfterDelay(NextInputType);
	}
}

void AANPlayerControllerBase::SetupInputComponent()
{
	// set up gameplay key bindings
	Super::SetupInputComponent();

	//Setup custom inputs
	//Gameplay inputs
	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Fire, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Fire, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Fire, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Fire, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Aim, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Aim, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Aim, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Aim, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Interact, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Interact, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Interact, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Interact, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Flashlight, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Flashlight, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Flashlight, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Flashlight, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Reload, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Reload, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Reload, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Reload, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Jet, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Jet, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Jet, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Jet, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Ascend, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Ascend, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Ascend, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Ascend, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Descend, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Descend, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Descend, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Descend, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameAndUI;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Inventory, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Inventory, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Inventory, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Inventory, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameAndUI;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Map, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Map, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Map, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Map, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	//{
	//	EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
	//	bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);
	//
	//	FInputActionHandlerSignature ActionHandler_Pressed;
	//	ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::AttachmentOne, GameInputType);
	//	AddCustomInput(ActionHandler_Pressed, ActionMappings::AttachmentOne, EInputEvent::IE_Pressed, bExecuteWhenPaused);
	//
	//	FInputActionHandlerSignature ActionHandler_Released;
	//	ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::AttachmentOne, GameInputType);
	//	AddCustomInput(ActionHandler_Released, ActionMappings::AttachmentOne, EInputEvent::IE_Released, bExecuteWhenPaused);
	//}
	//
	//{
	//	EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
	//	bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);
	//
	//	FInputActionHandlerSignature ActionHandler_Pressed;
	//	ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::AttachmentTwo, GameInputType);
	//	AddCustomInput(ActionHandler_Pressed, ActionMappings::AttachmentTwo, EInputEvent::IE_Pressed, bExecuteWhenPaused);
	//
	//	FInputActionHandlerSignature ActionHandler_Released;
	//	ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::AttachmentTwo, GameInputType);
	//	AddCustomInput(ActionHandler_Released, ActionMappings::AttachmentTwo, EInputEvent::IE_Released, bExecuteWhenPaused);
	//}
	//
	//{
	//	EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
	//	bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);
	//
	//	FInputActionHandlerSignature ActionHandler_Pressed;
	//	ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::AttachmentThree, GameInputType);
	//	AddCustomInput(ActionHandler_Pressed, ActionMappings::AttachmentThree, EInputEvent::IE_Pressed, bExecuteWhenPaused);
	//
	//	FInputActionHandlerSignature ActionHandler_Released;
	//	ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::AttachmentThree, GameInputType);
	//	AddCustomInput(ActionHandler_Released, ActionMappings::AttachmentThree, EInputEvent::IE_Released, bExecuteWhenPaused);
	//}
	//
	//{
	//	EGameInputTypes GameInputType = EGameInputTypes::GameOnly;
	//	bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);
	//
	//	FInputActionHandlerSignature ActionHandler_Pressed;
	//	ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::AttachmentFour, GameInputType);
	//	AddCustomInput(ActionHandler_Pressed, ActionMappings::AttachmentFour, EInputEvent::IE_Pressed, bExecuteWhenPaused);
	//
	//	FInputActionHandlerSignature ActionHandler_Released;
	//	ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::AttachmentFour, GameInputType);
	//	AddCustomInput(ActionHandler_Released, ActionMappings::AttachmentFour, EInputEvent::IE_Released, bExecuteWhenPaused);
	//}

	//UI Inputs
	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UIConfirm, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UIConfirm, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UIConfirm, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UIConfirm, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UIBack, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UIBack, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UIBack, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UIBack, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UISpecialOne, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UISpecialOne, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UISpecialOne, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UISpecialOne, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UISpecialTwo, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UISpecialTwo, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UISpecialTwo, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UISpecialTwo, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UITabRightOne, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UITabRightOne, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UITabRightOne, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UITabRightOne, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UITabLeftOne, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UITabLeftOne, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UITabLeftOne, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UITabLeftOne, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UITabRightTwo, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UITabRightTwo, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UITabRightTwo, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UITabRightTwo, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UITabLeftTwo, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UITabLeftTwo, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UITabLeftTwo, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UITabLeftTwo, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UIUp, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UIUp, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UIUp, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UIUp, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UIDown, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UIDown, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UIDown, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UIDown, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UIRight, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UIRight, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UIRight, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UIRight, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UILeft, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UILeft, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UILeft, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UILeft, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::UIOnly;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::UICursorClick, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::UICursorClick, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::UICursorClick, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::UICursorClick, EInputEvent::IE_Released, bExecuteWhenPaused);
	}

	{
		EGameInputTypes GameInputType = EGameInputTypes::GameAndUI;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::Pause, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::Pause, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::Pause, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::Pause, EInputEvent::IE_Released, bExecuteWhenPaused);
	}


	//Setup axis inputs
	InputComponent->BindAxis(AxisMappings::LSVertical, this, &AANPlayerControllerBase::LSVerticalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::LSHorizontal, this, &AANPlayerControllerBase::LSHorizontalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::RSVertical, this, &AANPlayerControllerBase::RSVerticalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::RSHorizontal, this, &AANPlayerControllerBase::RSHorizontalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::MouseVertical, this, &AANPlayerControllerBase::MouseVerticalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::MouseHorizontal, this, &AANPlayerControllerBase::MouseHorizontalInput_Axis).bExecuteWhenPaused = true;
	InputComponent->BindAxis(AxisMappings::MouseWheel, this, &AANPlayerControllerBase::MouseWheelInput_Axis).bExecuteWhenPaused = true;


	//Developer Tools
	if (UANFunctionLibrary::IsDevelopmentBuild())
	{
		EGameInputTypes GameInputType = EGameInputTypes::GameAndUI;
		bool bExecuteWhenPaused = ShouldExecuteWhenPaused(GameInputType);

		FInputActionHandlerSignature ActionHandler_Pressed;
		ActionHandler_Pressed.BindUFunction(this, FunctionNames::SendInput_Pressed, EANInputActions::DebugMenu, GameInputType);
		AddCustomInput(ActionHandler_Pressed, ActionMappings::DebugMenu, EInputEvent::IE_Pressed, bExecuteWhenPaused);

		FInputActionHandlerSignature ActionHandler_Released;
		ActionHandler_Released.BindUFunction(this, FunctionNames::SendInput_Released, EANInputActions::DebugMenu, GameInputType);
		AddCustomInput(ActionHandler_Released, ActionMappings::DebugMenu, EInputEvent::IE_Released, bExecuteWhenPaused);

		InputComponent->BindKey(EKeys::Nine, EInputEvent::IE_Pressed, this, &AANPlayerControllerBase::ToggleDevToolsUI).bExecuteWhenPaused = true;
		InputComponent->BindKey(EKeys::NumPadOne, EInputEvent::IE_Pressed, this, &AANPlayerControllerBase::ToggleAllScreenMessages).bExecuteWhenPaused = true;
		InputComponent->BindKey(EKeys::NumPadTwo, EInputEvent::IE_Pressed, this, &AANPlayerControllerBase::ToggleUI).bExecuteWhenPaused = true;
		InputComponent->BindKey(EKeys::NumPadThree, EInputEvent::IE_Pressed, this, &AANPlayerControllerBase::ToggleControlsUI).bExecuteWhenPaused = true;
		InputComponent->BindKey(EKeys::NumPadFour, EInputEvent::IE_Pressed, this, &AANPlayerControllerBase::TogglePauseGame).bExecuteWhenPaused = true;
	}
}

void AANPlayerControllerBase::Client_CreateHUD_Implementation()
{
	CreateHUD();
}

void AANPlayerControllerBase::TraceCursorForSelectable()
{
	FHitResult Hit;
	GetHitResultUnderCursor(TRACECHANNEL_CURSOR, true, Hit);

	if (Hit.bBlockingHit)
	{
		if (Hit.GetActor() != nullptr)
		{
			if (IANSelectable* SelectableObject = Cast<IANSelectable>(Hit.GetActor()))
			{
				if (SelectableObject->CanSelect())
				{
					if (SelectableObject != CurrentCursorWorldSelectable)
					{
						UnhighlightSelectable();
						UnhighlightGamepadSelectable(); //Also unhighlight the gamepad selectable if it exists

						CurrentCursorWorldSelectable = SelectableObject;
						CurrentCursorWorldSelectable->Highlight(EPlayerNumbers::P1);
					}
				}
				//if can't select this object, still need to unhighlight the previous one
				else
				{
					UnhighlightSelectable();
				}
			}
		}
	}
	else
	{
		UnhighlightSelectable();
	}
}

void AANPlayerControllerBase::TryCursorClick()
{
	if (CurrentCursorWorldSelectable != nullptr)
	{
		CurrentCursorWorldSelectable->Confirm(EPlayerNumbers::P1);
	}
}

void AANPlayerControllerBase::SetGameInput(EGameInputTypes NewGameInputType)
{
	if (UWorld* MyWorld = GetWorld())
	{
		InputType = EGameInputTypes::Transition; //Set to transition because we don't want any additional inputs called in the frame(s) before the new input type
		bUpdateInputNextTick = true;
		NextInputType = NewGameInputType;
		//FTimerHandle DelayTimerHandle;
		//FTimerDelegate DelayTimerDelegate = FTimerDelegate::CreateUObject(this, &AANPlayerControllerBase::SetGameInputAfterDelay, NewGameInputType);
		//MyWorld->GetTimerManager().SetTimer(DelayTimerHandle, DelayTimerDelegate, 0.01f, false);
		//Print("set timer");
	}
}

void AANPlayerControllerBase::SetGameInputAfterDelay(EGameInputTypes NewGameInputType)
{
	//TODO: May be a good idea to find a way to flush all inputs here at some point

	switch (NewGameInputType)
	{
	case(EGameInputTypes::GameOnly):
	{
		FInputModeGameOnly GameOnly;
		SetInputMode(GameOnly);
		bShowMouseCursor = false;
		InputType = EGameInputTypes::GameOnly;
	}
	break;
	case(EGameInputTypes::UIOnly):
	{
		FInputModeGameAndUI GameAndUI; //Need Game and UI here so we can still process controller UI inputs
		SetInputMode(GameAndUI);
		bShowMouseCursor = true;
		InputType = EGameInputTypes::UIOnly;
	}
	break;
	case(EGameInputTypes::GameAndUI):
	{
		FInputModeGameAndUI GameAndUI;
		SetInputMode(GameAndUI);
		bShowMouseCursor = true;
		InputType = EGameInputTypes::GameAndUI;
	}
	break;
	}
}

bool AANPlayerControllerBase::IsInGameInput() const
{
	if (InputType == EGameInputTypes::GameOnly || InputType == EGameInputTypes::GameAndUI)
	{
		return true;
	}

	return false;
}

bool AANPlayerControllerBase::IsInUIInput() const
{
	if (InputType == EGameInputTypes::UIOnly || InputType == EGameInputTypes::GameAndUI)
	{
		return true;
	}

	return false;
}

void AANPlayerControllerBase::UnhighlightSelectable()
{
	if (CurrentCursorWorldSelectable != nullptr)
	{
		CurrentCursorWorldSelectable->Unhighlight(EPlayerNumbers::P1);
		CurrentCursorWorldSelectable = nullptr;
	}
}

void AANPlayerControllerBase::UnhighlightGamepadSelectable()
{
	//Unhighlight the current controller selectable if we have one
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		SelectableRows[RowIndex][ColumnIndex]->Unhighlight(PlayerNumber);
	}
}

void AANPlayerControllerBase::AddCustomInput(FInputActionHandlerSignature& ActionHandler, FName ActionName, EInputEvent InputEvent, bool bExecuteWhenPaused)
{
	FInputActionBinding ActionBinding = FInputActionBinding(ActionName, InputEvent);
	ActionBinding.ActionDelegate = ActionHandler;
	InputComponent->AddActionBinding(ActionBinding).bExecuteWhenPaused = bExecuteWhenPaused;
}

void AANPlayerControllerBase::LSVerticalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::LSVertical, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::LSHorizontalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::LSHorizontal, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::RSVerticalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::RSVertical, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::RSHorizontalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::RSHorizontal, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::MouseVerticalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::MouseVertical, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::MouseHorizontalInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::MouseHorizontal, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::MouseWheelInput_Axis(float AxisValue)
{
	SendAxis(EANInputAxes::MouseWheel, AxisValue, EGameInputTypes::GameOnly);
}

void AANPlayerControllerBase::SendAxis(EANInputAxes InputAxis, float AxisValue, EGameInputTypes CheckGameInputType)
{
	if (IsInputInGameType(CheckGameInputType))
	{
		if (GetPawn())
		{
			if (AANCharacterBase* CharacterBase = Cast<AANCharacterBase>(GetPawn()))
			{
				CharacterBase->ProcessAxis(InputAxis, AxisValue);
			}
		}
	}

	//if (IsInputInUIType(CheckGameInputType))
	//{
	//	//TODO: Process axis?
	//}
}

void AANPlayerControllerBase::SendInput_Pressed(EANInputActions InputAction, EGameInputTypes CheckGameInputType)
{
	if (IsInputInGameType(CheckGameInputType))
	{
		if (GetPawn())
		{
			if (AANCharacterBase* CharacterBase = Cast<AANCharacterBase>(GetPawn()))
			{
				CharacterBase->ProcessInput(InputAction, IE_Pressed);
			}
		}
	}

	if (IsInputInUIType(CheckGameInputType))
	{
		ProcessInput(InputAction, IE_Pressed);
	}
}

void AANPlayerControllerBase::SendInput_Released(EANInputActions InputAction, EGameInputTypes CheckGameInputType)
{
	if (IsInputInGameType(CheckGameInputType))
	{
		if (GetPawn())
		{
			if (AANCharacterBase* CharacterBase = Cast<AANCharacterBase>(GetPawn()))
			{
				CharacterBase->ProcessInput(InputAction, IE_Released);
			}
		}
	}

	if (IsInputInUIType(CheckGameInputType))
	{
		ProcessInput(InputAction, IE_Released);
	}
}

bool AANPlayerControllerBase::IsInputInProperType(EGameInputTypes CheckGameInputType)
{
	switch (CheckGameInputType)
	{
	case (EGameInputTypes::GameOnly):
		return IsInGameInput();
	case (EGameInputTypes::UIOnly):
		return IsInUIInput();
	case (EGameInputTypes::GameAndUI):
		return (IsInGameInput() || IsInUIInput()); //keep like this in case we add transition type where this would be invalid
	}

	return false;
}

bool AANPlayerControllerBase::IsInputInGameType(EGameInputTypes CheckGameInputType)
{
	switch (CheckGameInputType)
	{
	case (EGameInputTypes::GameOnly):
		return IsInGameInput();
	case (EGameInputTypes::GameAndUI):
		return (IsInGameInput() || IsInUIInput()); //keep like this in case we add transition type where this would be invalid
	}

	return false;
}

bool AANPlayerControllerBase::IsInputInUIType(EGameInputTypes CheckGameInputType)
{
	switch (CheckGameInputType)
	{
	case (EGameInputTypes::UIOnly):
		return IsInUIInput();
	case (EGameInputTypes::GameAndUI):
		return (IsInGameInput() || IsInUIInput()); //keep like this in case we add transition type where this would be invalid
	}

	return false;
}

bool AANPlayerControllerBase::ShouldExecuteWhenPaused(EGameInputTypes CheckGameInputType) const
{
	switch (CheckGameInputType)
	{
	case (EGameInputTypes::GameOnly):
		return false;
	case (EGameInputTypes::UIOnly):
		return true;
	case (EGameInputTypes::GameAndUI):
		return true;
	}

	return false;
}

void AANPlayerControllerBase::ProcessInput(EANInputActions ANInputAction, EInputEvent InputEvent)
{
	//Follow the below format when setting up for a base class
	switch (InputEvent)
	{
	case(EInputEvent::IE_Pressed):
		switch (ANInputAction)
		{
		case(EANInputActions::UIConfirm):
			InputAction_UIConfirm_Pressed();
			break;
		case(EANInputActions::UIBack):
			InputAction_UIBack_Pressed();
			break;
		case(EANInputActions::UISpecialOne):
			InputAction_UISpecialOne_Pressed();
			break;
		case(EANInputActions::UISpecialTwo):
			InputAction_UISpecialTwo_Pressed();
			break;
		case(EANInputActions::UITabRightOne):
			InputAction_UITabRightOne_Pressed();
			break;
		case(EANInputActions::UITabLeftOne):
			InputAction_UITabLeftOne_Pressed();
			break;
		case(EANInputActions::UITabRightTwo):
			InputAction_UITabRightTwo_Pressed();
			break;
		case(EANInputActions::UITabLeftTwo):
			InputAction_UITabLeftTwo_Pressed();
			break;
		case(EANInputActions::UIUp):
			InputAction_UIUp_Pressed();
			break;
		case(EANInputActions::UIDown):
			InputAction_UIDown_Pressed();
			break;
		case(EANInputActions::UIRight):
			InputAction_UIRight_Pressed();
			break;
		case(EANInputActions::UILeft):
			InputAction_UILeft_Pressed();
			break;
		case(EANInputActions::UICursorClick):
			InputAction_UICursorClick_Pressed();
			break;

		case(EANInputActions::Pause):
			InputAction_Pause_Pressed();
			break;
		case(EANInputActions::DebugMenu):
			InputAction_DebugMenu_Pressed();
			break;
		default:
			break;
		}
		break;
	case(EInputEvent::IE_Released):
		switch (ANInputAction)
		{
		case(EANInputActions::UIConfirm):
			InputAction_UIConfirm_Released();
			break;
		case(EANInputActions::UIBack):
			InputAction_UIBack_Released();
			break;
		case(EANInputActions::UISpecialOne):
			InputAction_UISpecialOne_Released();
			break;
		case(EANInputActions::UISpecialTwo):
			InputAction_UISpecialTwo_Released();
			break;
		case(EANInputActions::UITabRightOne):
			InputAction_UITabRightOne_Released();
			break;
		case(EANInputActions::UITabLeftOne):
			InputAction_UITabLeftOne_Released();
			break;
		case(EANInputActions::UITabRightTwo):
			InputAction_UITabRightTwo_Released();
			break;
		case(EANInputActions::UITabLeftTwo):
			InputAction_UITabLeftTwo_Released();
			break;
		case(EANInputActions::UIUp):
			InputAction_UIUp_Released();
			break;
		case(EANInputActions::UIDown):
			InputAction_UIDown_Released();
			break;
		case(EANInputActions::UIRight):
			InputAction_UIRight_Released();
			break;
		case(EANInputActions::UILeft):
			InputAction_UILeft_Released();
			break;
		case(EANInputActions::UICursorClick):
			InputAction_UICursorClick_Released();
			break;

		case(EANInputActions::Pause):
			InputAction_Pause_Released();
			break;
		case(EANInputActions::DebugMenu):
			InputAction_DebugMenu_Released();
			break;
		default:
			break;
		}
		break;
	default:
		break;
	}
}

void AANPlayerControllerBase::InputAction_UIConfirm_Pressed()
{
	ConfirmSelectable();
}

void AANPlayerControllerBase::InputAction_UIConfirm_Released()
{
}

void AANPlayerControllerBase::InputAction_UIBack_Pressed()
{
	GoBack();
}

void AANPlayerControllerBase::InputAction_UIBack_Released()
{
}

void AANPlayerControllerBase::InputAction_UISpecialOne_Pressed()
{
}

void AANPlayerControllerBase::InputAction_UISpecialOne_Released()
{
}

void AANPlayerControllerBase::InputAction_UISpecialTwo_Pressed()
{
}

void AANPlayerControllerBase::InputAction_UISpecialTwo_Released()
{
}

void AANPlayerControllerBase::InputAction_UITabRightOne_Pressed()
{

}

void AANPlayerControllerBase::InputAction_UITabRightOne_Released()
{

}

void AANPlayerControllerBase::InputAction_UITabLeftOne_Pressed()
{

}

void AANPlayerControllerBase::InputAction_UITabLeftOne_Released()
{

}

void AANPlayerControllerBase::InputAction_UITabRightTwo_Pressed()
{

}

void AANPlayerControllerBase::InputAction_UITabRightTwo_Released()
{

}

void AANPlayerControllerBase::InputAction_UITabLeftTwo_Pressed()
{

}

void AANPlayerControllerBase::InputAction_UITabLeftTwo_Released()
{

}

void AANPlayerControllerBase::InputAction_UIUp_Pressed()
{
	if (IANSelectable* CurrentSelectable = GetCurrentSelectable())
	{
		if (CurrentSelectable->HasPressUpLogic())
		{
			CurrentSelectable->DoPressUpLogic();
			return;
		}
	}

	IncrementSelectableIndex(0, -1);
}

void AANPlayerControllerBase::InputAction_UIUp_Released()
{
}

void AANPlayerControllerBase::InputAction_UIDown_Pressed()
{
	if (IANSelectable* CurrentSelectable = GetCurrentSelectable())
	{
		if (CurrentSelectable->HasPressDownLogic())
		{
			CurrentSelectable->DoPressDownLogic();
			return;
		}
	}

	IncrementSelectableIndex(0, 1);
}

void AANPlayerControllerBase::InputAction_UIDown_Released()
{
}

void AANPlayerControllerBase::InputAction_UIRight_Pressed()
{
	if (IANSelectable* CurrentSelectable = GetCurrentSelectable())
	{
		if (CurrentSelectable->HasPressRightLogic())
		{
			CurrentSelectable->DoPressRightLogic();
			return;
		}
	}

	IncrementSelectableIndex(1, 0);
}

void AANPlayerControllerBase::InputAction_UIRight_Released()
{
}

void AANPlayerControllerBase::InputAction_UILeft_Pressed()
{
	if (IANSelectable* CurrentSelectable = GetCurrentSelectable())
	{
		if (CurrentSelectable->HasPressLeftLogic())
		{
			CurrentSelectable->DoPressLeftLogic();
			return;
		}
	}

	IncrementSelectableIndex(-1, 0);
}

void AANPlayerControllerBase::InputAction_UILeft_Released()
{
}

void AANPlayerControllerBase::InputAction_UICursorClick_Pressed()
{
	TryCursorClick();
}

void AANPlayerControllerBase::InputAction_UICursorClick_Released()
{
}

void AANPlayerControllerBase::InputAction_Pause_Pressed()
{
	if (bInPausableMode)
	{
		if (AANMainCharacter* ControlledCharacter = Cast<AANMainCharacter>(GetPawn()))
		{
			//If we're interacting with something or have a data log open, use ESC as the go back key
			if (ControlledCharacter->IsInteracting() || ControlledCharacter->bInventoryOpen || ControlledCharacter->bInformationOpen || bDataLogActive)
			{
				GoBack();
				return;
			}

			ControlledCharacter->PreventPauseIssues();
		}
		BP_PressPause();
	}
}

void AANPlayerControllerBase::InputAction_Pause_Released()
{
}

void AANPlayerControllerBase::InputAction_DebugMenu_Pressed()
{
	ToggleDebugMenu();
}

void AANPlayerControllerBase::InputAction_DebugMenu_Released()
{
}

void AANPlayerControllerBase::AssignSelectables(TArray<TArray<IANSelectable*>> NewSelectableRows, int32 NewRowIndex /*= INDEX_NONE*/, int32 NewColumnIndex /*= INDEX_NONE*/)
{
	SelectableRows = NewSelectableRows;

	//If we don't have manually set values, set to first indices
	if (NewRowIndex < 0 && NewColumnIndex < 0)
	{
		NewRowIndex = 0;
		NewColumnIndex = 0;
	}

	RowIndex = NewRowIndex;
	ColumnIndex = NewColumnIndex;

	//Highlight the selectable if we have one
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		SelectableRows[RowIndex][ColumnIndex]->Highlight(PlayerNumber);
	}
}

//void AANPlayerControllerBase::AssignScriptInterfaceSelectables(TArray<TArray<TScriptInterface<IANSelectable>>> NewSelectableRows)
//{
//	TArray<TArray<IANSelectable*>> CustomSelectableRows;
//	
//	for (int32 i = 0; i < NewSelectableRows.Num(); i++)
//	{
//		TArray<IANSelectable*> SelectableRow;
//		for (int32 j = 0; j < NewSelectableRows[i].Num(); j++)
//		{
//			if (IANSelectable* ScriptInterfaceSelectable = Cast<IANSelectable>(NewSelectableRows[i][j].GetObject()))
//			{
//				SelectableRow.Add(ScriptInterfaceSelectable);
//			}
//		}
//
//		if (SelectableRow.Num() > 0)
//		{
//			CustomSelectableRows.Add(SelectableRow);
//		}
//	}
//
//	SelectableRows = CustomSelectableRows;
//
//	//Highlight the first selectable if we have one
//	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
//	{
//		SelectableRows[RowIndex][ColumnIndex]->Highlight(PlayerNumber);
//	}
//}

void AANPlayerControllerBase::ClearSelectables()
{
	//Unhighlight the current selectable if we have one
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		SelectableRows[RowIndex][ColumnIndex]->Unhighlight(PlayerNumber);
	}

	for (int32 i = 0; i < SelectableRows.Num(); i++)
	{
		SelectableRows[i].Empty();
	}

	RowIndex = 0;
	ColumnIndex = 0;

	//Also need to clear the mouse cursor selectable
	CurrentCursorWorldSelectable = nullptr;
}

void AANPlayerControllerBase::IncrementSelectableIndex(int32 ColumnIncrease, int32 RowIncrease)
{
	if (SelectableRows.Num() <= 0)
	{
		Print("No selectable rows.");
		return;
	}

	IANSelectable* PriorSelectable = nullptr;
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		PriorSelectable = SelectableRows[RowIndex][ColumnIndex];
	}

	//Check if we need to increase row
	if (RowIncrease != 0)
	{
		RowIndex += RowIncrease;
		if (!SelectableRows.IsValidIndex(RowIndex))
		{
			if (RowIndex >= SelectableRows.Num())
			{
				RowIndex -= SelectableRows.Num();
			}
			else if (RowIndex < 0)
			{
				RowIndex += SelectableRows.Num();
			}
		}
	}

	if (!SelectableRows.IsValidIndex(RowIndex))
	{
		Print("WARNING: RowIndex is invalid!");
		return;
	}

	//Check if we need to increase column
	if (ColumnIncrease != 0)
	{
		ColumnIndex += ColumnIncrease;
		if (!SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
		{
			if (ColumnIndex >= SelectableRows[RowIndex].Num())
			{
				ColumnIndex -= SelectableRows[RowIndex].Num();
			}
			else if (ColumnIndex < 0)
			{
				ColumnIndex += SelectableRows[RowIndex].Num();
			}
		}
	}

	if (!SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		Print("WARNING: ColumnIndex is invalid!");
		return;
	}

	//We have a valid new selectable, so unhighlight the prior one
	if (PriorSelectable != nullptr)
	{
		//If we hit the same selectable as before, don't unhighlight and rehighlight
		if (PriorSelectable == SelectableRows[RowIndex][ColumnIndex])
		{
			return;
		}

		PriorSelectable->Unhighlight(PlayerNumber);
	}
	
	SelectableRows[RowIndex][ColumnIndex]->Highlight(PlayerNumber);
}

int32 AANPlayerControllerBase::GetNextSelectedColumnIndex(int CurrentColumnIndex, int NumItemsInOriginalRow, int NumItemsInCurrentRow, EButtonJustifications CheckButtonJustification)
{
	//If num items in both current and original rows are the same, then we can assume that our widget index will work
	if (NumItemsInCurrentRow != NumItemsInOriginalRow)
	{
		switch (CheckButtonJustification)
		{
		case(EButtonJustifications::Left):
			if (CurrentColumnIndex > NumItemsInOriginalRow - 1)
			{
				CurrentColumnIndex = NumItemsInOriginalRow - 1;
			}
			break;
		case(EButtonJustifications::Center):
		{
			ESides OriginalSide = ESides::Left;
			int OrigLeftMid = 0;
			int OrigRightMid = 0;
			int OrigDistanceFromMid = 0;

			if (NumItemsInOriginalRow % 2 == 0) //if even
			{
				OrigLeftMid = NumItemsInOriginalRow / 2;
				OrigRightMid = (NumItemsInOriginalRow / 2) + 1;
			}
			else //if odd
			{
				OrigLeftMid = NumItemsInOriginalRow / 2;
				OrigRightMid = NumItemsInOriginalRow / 2;
			}

			if (CurrentColumnIndex == OrigLeftMid && CurrentColumnIndex == OrigRightMid)
			{
				OriginalSide = ESides::Center;
				OrigDistanceFromMid = 0;
			}
			else if (CurrentColumnIndex <= OrigLeftMid)
			{
				OriginalSide = ESides::Left;
				OrigDistanceFromMid = OrigLeftMid - CurrentColumnIndex;
			}
			else if (CurrentColumnIndex >= OrigRightMid)
			{
				OriginalSide = ESides::Right;
				OrigDistanceFromMid = CurrentColumnIndex - OrigRightMid;
			}
			else
			{
				Print("WARNING: selected row index did not match any cases.");
			}

			switch (OriginalSide)
			{
			case(ESides::Left):
				CurrentColumnIndex = (NumItemsInCurrentRow / 2) - OrigDistanceFromMid;
				break;
			case(ESides::Right):
				CurrentColumnIndex = (NumItemsInCurrentRow / 2) + OrigDistanceFromMid;
				break;
			case(ESides::Center):
				CurrentColumnIndex = (NumItemsInCurrentRow / 2);
				break;
			}

			if (CurrentColumnIndex < 0)
			{
				CurrentColumnIndex = 0;
			}
			else if (CurrentColumnIndex >= NumItemsInCurrentRow)
			{
				CurrentColumnIndex = NumItemsInCurrentRow - 1;
			}

			printf("new widget index: %d", CurrentColumnIndex);
		}
		break;
		case(EButtonJustifications::Right):
			Print("WARNING: Right Justification not implemented.");
			if (CurrentColumnIndex > NumItemsInCurrentRow - 1)
			{
				CurrentColumnIndex = NumItemsInCurrentRow - 1;
			}
			break;
		case(EButtonJustifications::Custom):
			Print("WARNING: Custom Justification not implemented.");
			if (CurrentColumnIndex > NumItemsInCurrentRow - 1)
			{
				CurrentColumnIndex = NumItemsInCurrentRow - 1;
			}
			break;
		}
	}

	return CurrentColumnIndex;
}

IANSelectable* AANPlayerControllerBase::GetCurrentSelectable()
{
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		return SelectableRows[RowIndex][ColumnIndex];
	}

	return nullptr;
}

void AANPlayerControllerBase::ConfirmSelectable()
{
	if (SelectableRows.IsValidIndex(RowIndex) && SelectableRows[RowIndex].IsValidIndex(ColumnIndex))
	{
		SelectableRows[RowIndex][ColumnIndex]->Confirm(PlayerNumber);
	}
}

void AANPlayerControllerBase::GoBack()
{
	if (UANHUDWidgetBase* ActiveHUDWidget = GetActiveHUDWidget())
	{
		ActiveHUDWidget->TryGoBack();
	}
}

void AANPlayerControllerBase::AddNewHUD(UANHUDWidgetBase* NewHUD)
{
	if (NewHUD == nullptr)
	{
		return;
	}

	//Cache current HUD information and hide it
	int32 ActiveHUDIndex = ActiveHUDDatas.Num() - 1;
	if (ActiveHUDDatas.IsValidIndex(ActiveHUDIndex))
	{
		FActiveHUDData& ActiveHUDData = ActiveHUDDatas[ActiveHUDIndex];
		UANHUDWidgetBase* ActiveHUD = ActiveHUDData.HUDWidgetBase;
		if (ActiveHUD != nullptr)
		{
			//Update the previous HUD with current selectables
			if (ColumnIndex >= 0 && RowIndex >= 0)
			{
				ActiveHUDData.UpdateSelectables(SelectableRows, RowIndex, ColumnIndex);
			}
			ActiveHUD->HideHUD();
		}
	}

	//Add new HUD and show it
	FActiveHUDData NewHUDData = FActiveHUDData(NewHUD);
	ActiveHUDDatas.Add(NewHUDData);
	NewHUD->ShowHUD();
	if (NewHUD->ShouldAssignSelectablesOnShow())
	{
		NewHUD->AssignDefaultSelectables(this);
	}
}

void AANPlayerControllerBase::RemoveHighestHUD()
{
	if (ActiveHUDDatas.Num() <= 0)
	{
		return;
	}

	//Remove and hide the active HUD
	int32 ActiveHUDIndex = ActiveHUDDatas.Num() - 1;
	if (ActiveHUDDatas.IsValidIndex(ActiveHUDIndex))
	{
		FActiveHUDData& ActiveHUDData = ActiveHUDDatas[ActiveHUDIndex];
		UANHUDWidgetBase* ActiveHUD = ActiveHUDData.HUDWidgetBase;
		if (ActiveHUD != nullptr)
		{
			ActiveHUD->RemoveHUD();
			ActiveHUDDatas.RemoveAt(ActiveHUDIndex);
			ActiveHUDIndex--;
		}
		ClearSelectables(); //Clear any selectables from the previous HUD
	}

	//Show the previous HUD
	if (ActiveHUDDatas.IsValidIndex(ActiveHUDIndex))
	{
		FActiveHUDData& PreviousHUDData = ActiveHUDDatas[ActiveHUDIndex];
		UANHUDWidgetBase* PreviousHUD = PreviousHUDData.HUDWidgetBase;
		if (PreviousHUD != nullptr)
		{
			PreviousHUD->ShowHUD();
			//If the previous HUD had valid selectables when we replaced it, show it
			if (PreviousHUDData.HasValidSelectables())
			{
				AssignSelectables(PreviousHUDData.LastActiveSelectableRows, PreviousHUDData.LastActiveRowIndex, PreviousHUDData.LastActiveColumnIndex);
			}
			//if not, only show default selectables if we should do so on show
			else
			{
				if (PreviousHUD->ShouldAssignSelectablesOnShow())
				{
					PreviousHUD->AssignDefaultSelectables(this);
				}
			}
		}
	}
}

void AANPlayerControllerBase::ShowDataLog_Implementation(const FText& DataLogText)
{
	bDataLogActive = true;
}

void AANPlayerControllerBase::PauseGame()
{
	bPaused = true;
	UGameplayStatics::SetGamePaused(this, true);
}

void AANPlayerControllerBase::UnpauseGame()
{
	bPaused = false;
	UGameplayStatics::SetGamePaused(this, false);
}

void AANPlayerControllerBase::TogglePauseGame()
{
	if (bPaused)
	{
		UGameplayStatics::SetGamePaused(this, false);
	}
	else
	{
		UGameplayStatics::SetGamePaused(this, true);
	}
}

UANHUDWidgetBase* AANPlayerControllerBase::GetActiveHUDWidget() const
{
	int32 ActiveHUDIndex = ActiveHUDDatas.Num() - 1;
	if (ActiveHUDDatas.IsValidIndex(ActiveHUDIndex))
	{
		UANHUDWidgetBase* ActiveHUD = ActiveHUDDatas[ActiveHUDIndex].HUDWidgetBase;
		return ActiveHUD;
	}

	return nullptr;
}

void AANPlayerControllerBase::ToggleDebugMenu()
{
	if (HUDWidget)
	{
		if (bDebugMenuOpen)
		{
			ClearSelectables();
			HUDWidget->BP_CloseDebugMenu();
			SetGameInput(EGameInputTypes::GameOnly);
			bDebugMenuOpen = false;
		}
		else
		{
			if (UANDebugMenuWidget* DebugMenuWidget = HUDWidget->GetDebugMenuWidget())
			{
				AssignSelectables(DebugMenuWidget->GetDebugCommandWidgetsAsSelectables());
			}
			HUDWidget->BP_OpenDebugMenu();
			SetGameInput(EGameInputTypes::UIOnly);
			bDebugMenuOpen = true;
		}
	}
}

void AANPlayerControllerBase::ToggleDevToolsUI()
{
	if (HUDWidget)
	{
		HUDWidget->BP_ToggleDevToolsUI();
	}
}

void AANPlayerControllerBase::ToggleAllScreenMessages()
{
	ConsoleCommand(ConsoleCommands::ToggleAllScreenMessages);
}

void AANPlayerControllerBase::ToggleUI()
{
	if (HUDWidget)
	{
		HUDWidget->BP_ToggleUI();
	}
}

void AANPlayerControllerBase::ToggleControlsUI()
{
	if (HUDWidget)
	{
		HUDWidget->BP_ToggleControlsUI();
	}
}
