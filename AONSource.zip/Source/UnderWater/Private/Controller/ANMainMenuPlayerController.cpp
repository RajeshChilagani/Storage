// Fill out your copyright notice in the Description page of Project Settings.


#include "Controller/ANMainMenuPlayerController.h"

#include "UI/HUD/ANMainMenuHUDWidget.h"

AANMainMenuPlayerController::AANMainMenuPlayerController()
	: Super()
{

}

void AANMainMenuPlayerController::AssignMainScreenSelectables()
{
	if (MainMenuHUDWidget != nullptr)
	{
		AssignSelectables(MainMenuHUDWidget->GetMainMenuButtonWidgetsAsSelectableArray());
		SetGameInput(EGameInputTypes::GameAndUI);
	}
}

void AANMainMenuPlayerController::AssignNewGameScreenSelectables()
{
	if (MainMenuHUDWidget != nullptr)
	{
		AssignSelectables(MainMenuHUDWidget->GetNewGameButtonWidgetsAsSelectableArray());
		SetGameInput(EGameInputTypes::GameAndUI);
	}
}