// Fill out your copyright notice in the Description page of Project Settings.


#include "Controller/ANPersistentAIController.h"
#include "BrainComponent.h"

AANPersistentAIController::AANPersistentAIController()
{
}

void AANPersistentAIController::BeginPlay()
{
	Super::BeginPlay();
	if (PrimaryTree)
	{
		const bool bBehaviorTreeBegan = RunBehaviorTree(PrimaryTree);
		UE_LOG(LogTemp, Warning, TEXT("BehaviourTreeRun status = %d"), bBehaviorTreeBegan);
	}
}

void AANPersistentAIController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}



void AANPersistentAIController::BehaviorSetActive(const bool bEnable)
{
	if (bEnable)
	{
		if (PrimaryTree)
		{
			const bool bBehaviorTreeBegan = RunBehaviorTree(PrimaryTree);
			UE_LOG(LogTemp, Warning, TEXT("BehaviourTreeRun status = %d"), bBehaviorTreeBegan);
		}
	}
	else
	{
		UBrainComponent* brain = GetBrainComponent();
		if (!brain)
		{
			UE_LOG(LogTemp, Warning, TEXT("BrainComponent not found!"));
			return;
		}

		brain->StopLogic(TEXT("Unspawning Persistent AI! Stopping BehaviorTree..."));
	}
}