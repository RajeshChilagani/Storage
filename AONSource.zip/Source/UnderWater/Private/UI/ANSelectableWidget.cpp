// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/ANSelectableWidget.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Kismet/GameplayStatics.h"

#include "Shared/ANFunctionLibrary.h"

UANSelectableWidget::UANSelectableWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bPressUpLogic = false;
	bPressDownLogic = false;
	bPressRightLogic = false;
	bPressLeftLogic = false;

	bHighlighted = false;

	ValidPlatforms.Add(EPlatforms::Steam);
	ValidPlatforms.Add(EPlatforms::PS4);
}

bool UANSelectableWidget::IsValidPlatform() const
{
	EPlatforms CurrentPlatform = UANFunctionLibrary::GetPlatform();

	if (ValidPlatforms.Contains(CurrentPlatform))
	{
		return true;
	}

	return false;
}

void UANSelectableWidget::BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
{
	if (APawn* OwningPawn = GetOwningPlayerPawn())
	{
		UAkGameplayStatics::PostEventAttached(ConfirmSFX, OwningPawn);
	}

	OnSelectableWidgetConfirmed.Broadcast(this);
}

void UANSelectableWidget::BP_Highlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Add(PlayerNumber);
	if (HighlightedPlayers.Num() > 0)
	{
		bHighlighted = true;
		OnSelectableWidgetHighlighted.Broadcast(this);
	}

	if (APawn* OwningPawn = GetOwningPlayerPawn())
	{
		UAkGameplayStatics::PostEventAttached(HighlightSFX, OwningPawn);
	}
}

void UANSelectableWidget::BP_Unhighlight_Implementation(EPlayerNumbers PlayerNumber)
{
	HighlightedPlayers.Remove(PlayerNumber);
	if (HighlightedPlayers.Num() == 0)
	{
		bHighlighted = false;
		OnSelectableWidgetUnhighlighted.Broadcast(this);
	}

	if (APawn* OwningPawn = GetOwningPlayerPawn())
	{
		UAkGameplayStatics::PostEventAttached(UnhighlightSFX, OwningPawn);
	}
}

bool UANSelectableWidget::BP_IsPlayerNumberHighlighting_Implementation(EPlayerNumbers PlayerNumber) const
{
	for (int32 i = 0; i < HighlightedPlayers.Num(); i++)
	{
		if (HighlightedPlayers[i] == PlayerNumber)
		{
			return true;
		}
	}

	return false;
}

bool UANSelectableWidget::BP_CanSelect_Implementation() const
{
	return true;
}

bool UANSelectableWidget::BP_HasPressUpLogic_Implementation() const
{
	return bPressUpLogic;
}

bool UANSelectableWidget::BP_HasPressDownLogic_Implementation() const
{
	return bPressDownLogic;
}

bool UANSelectableWidget::BP_HasPressRightLogic_Implementation() const
{
	return bPressRightLogic;
}

bool UANSelectableWidget::BP_HasPressLeftLogic_Implementation() const
{
	return bPressLeftLogic;
}