// 2021 Abyssmal Games and Synodic Arc


#include "UI/Input/ANInputPromptWidget.h"

UANInputPromptWidget::UANInputPromptWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	InputAction = EANInputActions::UIConfirm;
}

void UANInputPromptWidget::SetNewValues(EANInputActions NewInputAction, FText NewActionDisplayText)
{
	InputAction = NewInputAction;
	ActionDisplayText = NewActionDisplayText;
}

void UANInputPromptWidget::BP_UpdateInputPrompt_Implementation()
{

}