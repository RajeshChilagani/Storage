// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Tutorial/ANTutorialPanelWidget.h"

#include "Engine/World.h"

#include "Tutorial/ANTutorialTask.h"
#include "UI/Tutorial/ANTutorialTaskWidget.h"

UANTutorialPanelWidget::UANTutorialPanelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	TimeToRemoveCompletedTutorialTask = 2.0f;
}

void UANTutorialPanelWidget::NativeConstruct()
{
	Super::NativeConstruct();


}

void UANTutorialPanelWidget::BP_CreateTutorialTask_Implementation(AANTutorialTask* AssociatedTutorialTask)
{
	//call initialization of the widget here in blueprints and add it to our list
}

void UANTutorialPanelWidget::BP_CompleteTutorialTask_Implementation(AANTutorialTask* AssociatedTutorialTask)
{
	if (UWorld* MyWorld = GetWorld())
	{
		FTimerHandle RemoveTutorialTaskTimerHandle;
		FTimerDelegate RemoveTutorialTaskTimerDelegate = FTimerDelegate::CreateUObject(this, &UANTutorialPanelWidget::BP_RemoveTutorialTask, AssociatedTutorialTask);
		MyWorld->GetTimerManager().SetTimer(RemoveTutorialTaskTimerHandle, RemoveTutorialTaskTimerDelegate, TimeToRemoveCompletedTutorialTask, false);
	}
}

void UANTutorialPanelWidget::BP_RemoveTutorialTask_Implementation(AANTutorialTask* AssociatedTutorialTask)
{
	for (int32 i = 0; i < ActiveTutorialTaskWidgets.Num(); i++)
	{
		if (ActiveTutorialTaskWidgets[i] != nullptr && ActiveTutorialTaskWidgets[i]->GetAssociatedTutorialTask() != nullptr)
		{
			if (ActiveTutorialTaskWidgets[i]->GetAssociatedTutorialTask() == AssociatedTutorialTask)
			{
				ActiveTutorialTaskWidgets.RemoveAt(i);
				break;
			}
		}
	}
}

UANTutorialTaskWidget* UANTutorialPanelWidget::GetTutorialTaskWidgetForTutorialTask(AANTutorialTask* AssociatedTutorialTask)
{
	for (int32 i = 0; i < ActiveTutorialTaskWidgets.Num(); i++)
	{
		if (ActiveTutorialTaskWidgets[i] != nullptr && ActiveTutorialTaskWidgets[i]->GetAssociatedTutorialTask() != nullptr)
		{
			if (ActiveTutorialTaskWidgets[i]->GetAssociatedTutorialTask() == AssociatedTutorialTask)
			{
				return ActiveTutorialTaskWidgets[i];
			}
		}
	}

	return nullptr;
}