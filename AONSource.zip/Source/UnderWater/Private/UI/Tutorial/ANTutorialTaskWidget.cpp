// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Tutorial/ANTutorialTaskWidget.h"

UANTutorialTaskWidget::UANTutorialTaskWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANTutorialTaskWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UANTutorialTaskWidget::AssignTutorialTask(AANTutorialTask* NewTutorialTask)
{
	AssociatedTutorialTask = NewTutorialTask;
}