// 2021 Abyssmal Games and Synodic Arc


#include "UI/ANCarouselWidget.h"

#include "AkGameplayStatics.h"

UANCarouselWidget::UANCarouselWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bPressRightLogic = true;
	bPressLeftLogic = true;

	CurrentCarouselIndex = 0;
}

void UANCarouselWidget::CycleRight()
{
	CycleIndex(1);
}

void UANCarouselWidget::CycleLeft()
{
	CycleIndex(-1);
}

void UANCarouselWidget::SetIndexDirectly(int32 NewIndex)
{
	int32 PreviousIndex = CurrentCarouselIndex;
	CurrentCarouselIndex = NewIndex;

	if (CurrentCarouselIndex < 0)
	{
		CurrentCarouselIndex = CarouselItems.Num() - 1;
	}
	else if (CurrentCarouselIndex >= CarouselItems.Num())
	{
		CurrentCarouselIndex = 0;
	}

	BP_CycleToNewIndex(PreviousIndex, CurrentCarouselIndex);
}

void UANCarouselWidget::CycleIndex(int32 IndexChange)
{
	int32 PreviousIndex = CurrentCarouselIndex;
	CurrentCarouselIndex += IndexChange;

	if (CurrentCarouselIndex < 0)
	{
		CurrentCarouselIndex = CarouselItems.Num() - 1;
	}
	else if (CurrentCarouselIndex >= CarouselItems.Num())
	{
		CurrentCarouselIndex = 0;
	}

	OnCarouselIndexChanged.Broadcast(this, PreviousIndex, CurrentCarouselIndex);

	//Only play SFX for normal cycling, not in direct index setting
	if (ConfirmSFX != nullptr)
	{
		UAkGameplayStatics::PostEventAttached(ConfirmSFX, GetOwningPlayerPawn());
	}

	BP_CycleToNewIndex(PreviousIndex, CurrentCarouselIndex);
}

void UANCarouselWidget::BP_DoPressRightLogic_Implementation()
{
	CycleRight();
}

void UANCarouselWidget::BP_DoPressLeftLogic_Implementation()
{
	CycleLeft();
}
