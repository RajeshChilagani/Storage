// 2021 Abyssmal Games and Synodic Arc


#include "UI/Puzzle/ANVoltageSystemPanelWidget.h"

#include "UI/Puzzle/ANVoltageSystemItemWidget.h"

UANVoltageSystemPanelWidget::UANVoltageSystemPanelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANVoltageSystemPanelWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UANVoltageSystemPanelWidget::UpdatePoweredStatus(int32 NewVoltage)
{
	for (UANVoltageSystemItemWidget* VoltageSystemItemWidget : VoltageSystemItemWidgets)
	{
		VoltageSystemItemWidget->UpdatePoweredStatus(NewVoltage);
	}
}