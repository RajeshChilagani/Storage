// 2021 Abyssmal Games and Synodic Arc


#include "UI/Puzzle/ANVoltageSystemItemWidget.h"

UANVoltageSystemItemWidget::UANVoltageSystemItemWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANVoltageSystemItemWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UANVoltageSystemItemWidget::SetDefaultValues(AActor* NewAssociatedActor, int32 NewTargetVoltage)
{
	AssociatedActor = NewAssociatedActor;
	TargetVoltage = NewTargetVoltage;

	BP_SetupDefaultAppearance();
}

void UANVoltageSystemItemWidget::UpdatePoweredStatus(int32 NewVoltage)
{
	if (NewVoltage == TargetVoltage)
	{
		bPoweredOn = true;
	}
	else
	{
		bPoweredOn = false;
	}

	BP_ShowPoweredStatus(bPoweredOn);
}