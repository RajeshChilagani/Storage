// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Player/ANMessageWidget.h"

UANMessageWidget::UANMessageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	DisplayTime = 2.5f;
	DisplayColor = FLinearColor::White;
}