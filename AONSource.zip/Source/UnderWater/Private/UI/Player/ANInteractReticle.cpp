// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Player/ANInteractReticle.h"

#include "ANDefines.h"

#include "Character/ANMainCharacter.h"

UANInteractReticle::UANInteractReticle(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANInteractReticle::NativeConstruct()
{
	Super::NativeConstruct();

	Print("native con");
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		Print("assign dyn");
		MainCharacter->OnShowInteractTargeting.AddDynamic(this, &UANInteractReticle::BP_ShowInteractTargeting);
		MainCharacter->OnHideInteractTargeting.AddDynamic(this, &UANInteractReticle::BP_HideInteractTargeting);
		MainCharacter->OnCinematicStarted.AddDynamic(this, &UANInteractReticle::BP_HideReticle);
		MainCharacter->OnCinematicEnded.AddDynamic(this, &UANInteractReticle::BP_ShowReticle);
	}
}

void UANInteractReticle::NativeTick(const FGeometry& MyGeometry, float DeltaTime)
{
	Super::NativeTick(MyGeometry, DeltaTime);
}