// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Player/ANMessageBoxWidget.h"

#include "ANDefines.h"

#include "Character/ANMainCharacter.h"

UANMessageBoxWidget::UANMessageBoxWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANMessageBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		//MainCharacter->OnDisplayMediumO2WarningUI.AddDynamic(this, &UANMessageBoxWidget::BP_AddMessage);
		//MainCharacter->OnDisplayLowO2WarningUI.AddDynamic(this, &UANMessageBoxWidget::BP_AddMessage);
		//MainCharacter->bDisplayedSuffocationWarning.AddDynamic(this, &UANMessageBoxWidget::BP_AddMessage);
	}
}