// 2021 Abyssmal Games and Synodic Arc


#include "UI/Player/ANPlayerHealthWidget.h"

UANPlayerHealthWidget::UANPlayerHealthWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	
}

