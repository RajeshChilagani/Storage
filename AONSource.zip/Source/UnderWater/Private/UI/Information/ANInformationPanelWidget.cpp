// 2021 Abyssmal Games and Synodic Arc


#include "UI/Information/ANInformationPanelWidget.h"

UANInformationPanelWidget::UANInformationPanelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}