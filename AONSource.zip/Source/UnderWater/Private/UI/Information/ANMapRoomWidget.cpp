// 2021 Abyssmal Games and Synodic Arc


#include "UI/Information/ANMapRoomWidget.h"

UANMapRoomWidget::UANMapRoomWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	MapRoomName = NAME_None;
	MapRoomState = EMapRoomStates::NeverVisited;
}

void UANMapRoomWidget::SetMapRoomDefaults_Implementation(const FMapRoomInfo& NewMapRoomInfo)
{
	MapRoomName = NewMapRoomInfo.RoomName;
	MapRoomDisplayName = NewMapRoomInfo.RoomDisplayName;
}

void UANMapRoomWidget::UpdateMapRoomState_Implementation(EMapRoomStates NewMapRoomState)
{
	MapRoomState = NewMapRoomState;
}