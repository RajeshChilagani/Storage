// 2021 Abyssmal Games and Synodic Arc


#include "UI/Information/ANSignalInfoWidget.h"

#include "Character/ANMainCharacter.h"

UANSignalInfoWidget::UANSignalInfoWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANSignalInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		MainCharacter->OnSignalDistanceUpdated.AddDynamic(this, &UANSignalInfoWidget::BP_UpdateSignalDistance);
	}
}