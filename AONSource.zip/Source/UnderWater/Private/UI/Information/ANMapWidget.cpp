// 2021 Abyssmal Games and Synodic Arc


#include "UI/Information/ANMapWidget.h"

#include "Shared/ANFunctionLibrary.h"
#include "UI/Information/ANMapLevelData.h"
#include "UI/Information/ANMapRoomWidget.h"

UANMapWidget::UANMapWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	CurrentLevel = EANLevels::Tutorial;
	CurrentRoomName = NAME_None;
}

void UANMapWidget::MoveToRoom(EANLevels NewLevel, int32 NewFloor, const FName& NewRoomName)
{
	//If moving to a new level or floor, we have to set the map for that one
	if (NewLevel != CurrentLevel || NewFloor != CurrentFloor)
	{
		BP_ClearMap();
		if (UANMapLevelData* RetrievedMapLevelData = BP_RetrieveMapLevelData(NewLevel, NewFloor))
		{
			//if (UANFunctionLibrary::LoadSoftObject(SoftRetrievedMapLevelData))
			//{
				//CurrentMapLevelData = SoftRetrievedMapLevelData.Get();
				CurrentMapLevelData = RetrievedMapLevelData;
				BP_CreateMapRoomWidgets(CurrentMapLevelData);
			//}
		}

		//Update current level
		CurrentLevel = NewLevel;
		CurrentFloor = NewFloor;
	}

	//Get the previous room and set it to previously visited
	if (UANMapRoomWidget* LastRoom = GetLoadedMapRoomWidgetWithName(CurrentRoomName))
	{
		LastRoom->UpdateMapRoomState(EMapRoomStates::PreviouslyVisited);
	}

	//Get the next room and set it to currently visited
	if (UANMapRoomWidget* NextRoom = GetLoadedMapRoomWidgetWithName(NewRoomName))
	{
		NextRoom->UpdateMapRoomState(EMapRoomStates::CurrentlyVisited);
	}

	//Update current room name
	CurrentRoomName = NewRoomName;
}

UANMapRoomWidget* UANMapWidget::GetLoadedMapRoomWidgetWithName(const FName& CheckRoomName) const
{
	for (UANMapRoomWidget* MapRoomWidget : MapRoomWidgets)
	{
		if (MapRoomWidget->GetMapRoomName() == CheckRoomName)
		{
			return MapRoomWidget;
		}
	}

	return nullptr;
}

UANMapRoomWidget* UANMapWidget::GetCurrentMapRoomWidget() const
{
	return GetLoadedMapRoomWidgetWithName(CurrentRoomName);
}
