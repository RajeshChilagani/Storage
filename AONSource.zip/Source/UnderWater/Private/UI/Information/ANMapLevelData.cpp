// 2021 Abyssmal Games and Synodic Arc


#include "UI/Information/ANMapLevelData.h"

UANMapLevelData::UANMapLevelData()
	: Super()
{

}