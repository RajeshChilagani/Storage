// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Inventory/ANInventoryItemSlotWidget.h"

#include "Character/ANMainCharacter.h"
#include "UI/Inventory/ANInventoryItemWidget.h"
#include "UI/Inventory/ANInventoryPanelWidget.h"

UANInventoryItemSlotWidget::UANInventoryItemSlotWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ItemCount = 0;
}

void UANInventoryItemSlotWidget::AssignItemWidget(UANInventoryItemWidget* NewItemWidget, int32 DefaultItemCount)
{
	if (NewItemWidget == nullptr)
	{
		return;
	}

	//If something is already filled, we need to remove it
	if (IsFilled())
	{
		ClearItemSlot();
	}

	ItemCount = DefaultItemCount;

	AssociatedItemWidget = NewItemWidget;
	AssociatedItemWidget->UpdateInventoryItemCount(DefaultItemCount);
	BP_AssignItemWidget(NewItemWidget);
}

void UANInventoryItemSlotWidget::SelectItemSlot()
{
	AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn());
	if (MainCharacter == nullptr)
	{
		return;
	}

	if (AssociatedItemWidget != nullptr && AssociatedInventoryPanelWidget != nullptr)
	{
		//Try to use/insert the item--may need special logic here later if we can select items to do things other than insert
		if (MainCharacter->SelectItem(AssociatedItemWidget->GetInventoryItemName(), AssociatedInventoryPanelWidget->GetInventoryMode()))
		{
			MainCharacter->PostAkAudioEventOnCharacter(ConfirmSFX);
			return;
		}
	}

	//Play the invalid SFX
	MainCharacter->PostAkAudioEventOnCharacter(ConfirmFailedSFX);
}

void UANInventoryItemSlotWidget::ClearItemSlot()
{
	BP_ClearItemWidget();
	AssociatedItemWidget = nullptr;
}

void UANInventoryItemSlotWidget::SetInventoryPanelWidget(UANInventoryPanelWidget* NewInventoryPanelWidget)
{
	AssociatedInventoryPanelWidget = NewInventoryPanelWidget;
}

void UANInventoryItemSlotWidget::AddItemCount(int32 Count)
{
	if (AssociatedItemWidget != nullptr)
	{
		ItemCount += Count;
		AssociatedItemWidget->UpdateInventoryItemCount(ItemCount);
	}
}

void UANInventoryItemSlotWidget::RemoveItemCount(int32 Count)
{
	if (AssociatedItemWidget != nullptr)
	{
		ItemCount -= Count;
		AssociatedItemWidget->UpdateInventoryItemCount(ItemCount);

		if (ItemCount <= 0)
		{
			ClearItemSlot();
		}
	}
}

void UANInventoryItemSlotWidget::BP_Confirm_Implementation(EPlayerNumbers PlayerNumber)
{
	//Override here so we can support the invalid SFX too
	OnSelectableWidgetConfirmed.Broadcast(this);
}

bool UANInventoryItemSlotWidget::IsFilled() const
{
	if (AssociatedItemWidget != nullptr)
	{
		return true;
	}

	return false;
}
