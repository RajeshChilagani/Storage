// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Inventory/ANInventoryItemWidget.h"

#include "Shared/ANFunctionLibrary.h"
#include "Systems/ANInventorySystem.h"

UANInventoryItemWidget::UANInventoryItemWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

FANItem UANInventoryItemWidget::GetItemData() const
{
	FANItem ItemData = FANItem();

	if (UANInventorySystem* InventorySystem = UANFunctionLibrary::GetInventorySystem(this))
	{
		FANItem* ItemDataPtr = InventorySystem->GetItemDataFromTable(InventoryItemName);
		if (ItemDataPtr != nullptr)
		{
			ItemData = *ItemDataPtr;
		}
	}

	return ItemData;
}

FANItem* UANInventoryItemWidget::GetItemDataPointer() const
{
	if (UANInventorySystem* InventorySystem = UANFunctionLibrary::GetInventorySystem(this))
	{
		return InventorySystem->GetItemDataFromTable(InventoryItemName);
	}

	return nullptr;
}

void UANInventoryItemWidget::AssignInventoryItem(const FString& NewInventoryItemName)
{
	InventoryItemName = NewInventoryItemName;
	
	BP_AssignInventoryItemUI();
}

void UANInventoryItemWidget::UpdateInventoryItemCount(int32 NewCount)
{
	BP_UpdateInventoryItemCountUI(NewCount);
}