// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/Inventory/ANSelectItemNotifierPanelWidget.h"

#include "Character/ANMainCharacter.h"
#include "Interface/ANInteractable.h"

UANSelectItemNotifierPanelWidget::UANSelectItemNotifierPanelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANSelectItemNotifierPanelWidget::TryClose()
{
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		MainCharacter->TryGoBack();
		//if (IANInteractable* CurrentInteractingInteractable = MainCharacter->GetCurrentInteractingInteractable())
		//{
		//	CurrentInteractingInteractable->EndInteract(MainCharacter);
		//}
	}
}