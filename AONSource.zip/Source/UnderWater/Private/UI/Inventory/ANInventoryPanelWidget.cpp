// 2021 Abyssmal Games and Synodic Arc


#include "UI/Inventory/ANInventoryPanelWidget.h"

#include "Interface/ANItemable.h"
#include "Systems/ANInventorySystem.h"
#include "UI/Inventory/ANInventoryItemSlotWidget.h"
#include "UI/Inventory/ANInventoryItemWidget.h"

UANInventoryPanelWidget::UANInventoryPanelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	InventoryMode = EANInventoryModes::None;
}

void UANInventoryPanelWidget::UpdateIconOpacityForItemable(IANItemable* Itemable)
{
	if (Itemable == nullptr)
	{
		return;
	}

	for (UANInventoryItemSlotWidget* InventoryItemSlot : GetAllInventoryItemSlotWidgets())
	{
		if (InventoryItemSlot->IsFilled())
		{
			if (UANInventoryItemWidget* InventoryItemWidget = InventoryItemSlot->GetAssociatedItemWidget())
			{
				//If we can insert/use the item on the itemable, show at full opacity
				if (Itemable->CanInsertItem(InventoryItemWidget->GetInventoryItemName()))
				{
					InventoryItemWidget->BP_SetPartialOpacity(false);
				}
				else
				{
					InventoryItemWidget->BP_SetPartialOpacity(true);
				}
			}
		}
	}
}

void UANInventoryPanelWidget::UpdateIconOpacityForInventoryUseTypes()
{
	for (UANInventoryItemSlotWidget* InventoryItemSlot : GetAllInventoryItemSlotWidgets())
	{
		if (InventoryItemSlot->IsFilled())
		{
			if (UANInventoryItemWidget* InventoryItemWidget = InventoryItemSlot->GetAssociatedItemWidget())
			{
				if (FANItem* ItemData = InventoryItemWidget->GetItemDataPointer())
				{
					//If the inventory use type is valid, show it
					if (ItemData->InventoryUseType != EANItemInventoryUseTypes::None)
					{
						InventoryItemWidget->BP_SetPartialOpacity(false);
					}
					else
					{
						InventoryItemWidget->BP_SetPartialOpacity(true);
					}
				}
			}
		}
	}
}

void UANInventoryPanelWidget::SetInventoryMode(EANInventoryModes NewInventoryMode)
{
	InventoryMode = NewInventoryMode;
}

TArray<UANInventoryItemSlotWidget*> UANInventoryPanelWidget::GetAllInventoryItemSlotWidgets() const
{
	TArray<UANInventoryItemSlotWidget*> AllInventoryItemSlotWidgets;

	for (int32 i = 0; i < InventoryItemSlotWidgetsRow1.Num(); i++)
	{
		AllInventoryItemSlotWidgets.Add(InventoryItemSlotWidgetsRow1[i]);
	}

	for (int32 i = 0; i < InventoryItemSlotWidgetsRow2.Num(); i++)
	{
		AllInventoryItemSlotWidgets.Add(InventoryItemSlotWidgetsRow2[i]);
	}

	return AllInventoryItemSlotWidgets;
}

TArray<TArray<IANSelectable*>> UANInventoryPanelWidget::GetAllInventoryItemSlotWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;
	TArray<IANSelectable*> RowSelectables;

	for (int32 i = 0; i < InventoryItemSlotWidgetsRow1.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(InventoryItemSlotWidgetsRow1[i]))
		{
			RowSelectables.Add(InventoryItemSlotWidgetsRow1[i]);
		}
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	for (int32 i = 0; i < InventoryItemSlotWidgetsRow2.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(InventoryItemSlotWidgetsRow2[i]))
		{
			RowSelectables.Add(InventoryItemSlotWidgetsRow2[i]);
		}
	}
	AllSelectables.Add(RowSelectables);
	RowSelectables.Empty();

	return AllSelectables;
}

bool UANInventoryPanelWidget::GetFirstUnfilledInventoryItemSlot(UANInventoryItemSlotWidget*& FirstUnfilledInventoryItemSlot) const
{
	TArray<UANInventoryItemSlotWidget*> InventoryItemSlotWidgets = GetAllInventoryItemSlotWidgets();
	for (int32 i = 0; i < InventoryItemSlotWidgets.Num(); i++)
	{
		if (!InventoryItemSlotWidgets[i]->IsFilled())
		{
			FirstUnfilledInventoryItemSlot = InventoryItemSlotWidgets[i];
			return true;
		}
	}

	return false;
}

bool UANInventoryPanelWidget::GetInventoryItemSlotForInventoryItem(const FString& SearchingInventoryItemName, UANInventoryItemSlotWidget*& CorrespondingInventoryItemSlot) const
{
	TArray<UANInventoryItemSlotWidget*> InventoryItemSlotWidgets = GetAllInventoryItemSlotWidgets();
	for (int32 i = 0; i < InventoryItemSlotWidgets.Num(); i++)
	{
		if (InventoryItemSlotWidgets[i]->IsFilled())
		{
			if (UANInventoryItemWidget* InventoryItemWidget = InventoryItemSlotWidgets[i]->GetAssociatedItemWidget())
			{
				if (InventoryItemWidget->GetInventoryItemName().Equals(SearchingInventoryItemName))
				{
					CorrespondingInventoryItemSlot = InventoryItemSlotWidgets[i];
					return true;
				}
			}
		}
	}

	return false;
}