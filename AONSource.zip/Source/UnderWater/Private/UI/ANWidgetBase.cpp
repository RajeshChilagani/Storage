// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/ANWidgetBase.h"

UANWidgetBase::UANWidgetBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANWidgetBase::NativeConstruct()
{
	Super::NativeConstruct();
}

void UANWidgetBase::NativeTick(const FGeometry& MyGeometry, float DeltaTime)
{
	Super::NativeTick(MyGeometry, DeltaTime);
}