// 2021 Abyssmal Games and Synodic Arc


#include "UI/HUD/ANLogHUDWidget.h"

UANLogHUDWidget::UANLogHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANLogHUDWidget::SetLogText_Implementation(const FText& NewLogText)
{
	CurrentLogText = NewLogText;
}

void UANLogHUDWidget::FadeOutAndDestroy_Implementation()
{

}

void UANLogHUDWidget::AssignDefaultSelectables(AANPlayerControllerBase* AssigningController)
{

}

bool UANLogHUDWidget::ShouldAssignSelectablesOnShow_Implementation() const
{
	return false;
}