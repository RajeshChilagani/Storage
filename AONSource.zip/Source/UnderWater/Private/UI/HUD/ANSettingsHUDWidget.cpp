// 2021 Abyssmal Games and Synodic Arc


#include "UI/HUD/ANSettingsHUDWidget.h"

#include "Controller/ANPlayerControllerBase.h"
#include "Interface/ANSelectable.h"
#include "UI/ANGenericTextButtonWidget.h"

UANSettingsHUDWidget::UANSettingsHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANSettingsHUDWidget::AssignDefaultSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetSettingsListButtonWidgetsAsSelectableArray());
	}
}

void UANSettingsHUDWidget::AssignSettingsListButtonSelectables(AANPlayerControllerBase* AssigningPlayerController)
{
	if (AssigningPlayerController != nullptr)
	{
		AssigningPlayerController->AssignSelectables(GetSettingsListButtonWidgetsAsSelectableArray());
	}
}

void UANSettingsHUDWidget::AssignControlsButtonSelectables(AANPlayerControllerBase* AssigningPlayerController)
{
	if (AssigningPlayerController != nullptr)
	{
		AssigningPlayerController->AssignSelectables(GetControlsButtonWidgetsAsSelectableArray());
	}
}

void UANSettingsHUDWidget::AssignDisplayButtonSelectables(AANPlayerControllerBase* AssigningPlayerController)
{
	if (AssigningPlayerController != nullptr)
	{
		AssigningPlayerController->AssignSelectables(GetDisplayButtonWidgetsAsSelectableArray());
	}
}

void UANSettingsHUDWidget::AssignAudioButtonSelectables(AANPlayerControllerBase* AssigningPlayerController)
{
	if (AssigningPlayerController != nullptr)
	{
		AssigningPlayerController->AssignSelectables(GetAudioButtonWidgetsAsSelectableArray());
	}
}

TArray<TArray<IANSelectable*>> UANSettingsHUDWidget::GetSettingsListButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < SettingsListButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(SettingsListButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(SettingsListButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}

TArray<TArray<IANSelectable*>> UANSettingsHUDWidget::GetControlsButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < ControlsButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(ControlsButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(ControlsButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}

TArray<TArray<IANSelectable*>> UANSettingsHUDWidget::GetDisplayButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < DisplayButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(DisplayButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(DisplayButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}

TArray<TArray<IANSelectable*>> UANSettingsHUDWidget::GetAudioButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < AudioButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(AudioButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(AudioButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}