// 2021 Abyssmal Games and Synodic Arc


#include "UI/HUD/ANPauseMenuHUDWidget.h"

#include "Controller/ANPlayerControllerBase.h"
#include "Interface/ANSelectable.h"
#include "UI/ANGenericTextButtonWidget.h"

UANPauseMenuHUDWidget::UANPauseMenuHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UANPauseMenuHUDWidget::AssignDefaultSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetPauseMenuButtonWidgetsAsSelectableArray());
	}
}

void UANPauseMenuHUDWidget::AssignPauseMenuButtonSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetPauseMenuButtonWidgetsAsSelectableArray());
	}
}

void UANPauseMenuHUDWidget::AssignReloadCheckpointButtonSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetReloadCheckpointButtonWidgetsAsSelectableArray());
	}
}

void UANPauseMenuHUDWidget::AssignMainMenuButtonSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetMainMenuButtonWidgetsAsSelectableArray());
	}
}

void UANPauseMenuHUDWidget::AssignExitGameButtonSelectables(AANPlayerControllerBase* AssigningController)
{
	Super::AssignDefaultSelectables(AssigningController);
	if (AssigningController != nullptr)
	{
		AssigningController->AssignSelectables(GetExitGameButtonWidgetsAsSelectableArray());
	}
}

TArray<TArray<IANSelectable*>> UANPauseMenuHUDWidget::GetPauseMenuButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < PauseMenuButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(PauseMenuButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(PauseMenuButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}

TArray<TArray<IANSelectable*>> UANPauseMenuHUDWidget::GetReloadCheckpointButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < ReloadCheckpointButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(ReloadCheckpointButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(ReloadCheckpointButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}


TArray<TArray<IANSelectable*>> UANPauseMenuHUDWidget::GetMainMenuButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < MainMenuButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(MainMenuButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(MainMenuButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}


TArray<TArray<IANSelectable*>> UANPauseMenuHUDWidget::GetExitGameButtonWidgetsAsSelectableArray() const
{
	TArray<TArray<IANSelectable*>> AllSelectables;

	for (int32 i = 0; i < ExitGameButtonWidgets.Num(); i++)
	{
		if (IANSelectable* Selectable = Cast<IANSelectable>(ExitGameButtonWidgets[i]))
		{
			TArray<IANSelectable*> RowSelectables;
			RowSelectables.Add(ExitGameButtonWidgets[i]);
			AllSelectables.Add(RowSelectables);
		}
	}

	return AllSelectables;
}
