// 2021 Abyssmal Games and Synodic Arc


#include "UI/HUD/ANMessagesHUDWidget.h"

#include "Kismet/GameplayStatics.h"

#include "ANDefines.h"

#include "Game/ANGameInstance.h"
#include "Systems/ANInventorySystem.h"

UANMessagesHUDWidget::UANMessagesHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(UGameplayStatics::GetGameInstance(this)))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			InventorySystem->OnItemAdded.AddDynamic(this, &UANMessagesHUDWidget::BP_AddItemToInventoryUI);
		}
	}
}