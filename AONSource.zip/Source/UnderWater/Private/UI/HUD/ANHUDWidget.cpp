// Fill out your copyright notice in the Description page of Project Settings.


#include "UI/HUD/ANHUDWidget.h"

#include "Kismet/GameplayStatics.h"

#include "ANDefines.h"

#include "Character/ANMainCharacter.h"
#include "Game/ANGameInstance.h"
#include "Systems/ANInventorySystem.h"

UANHUDWidget::UANHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bInventoryTransitioning = false;
	bInformationTransitioning = false;
}

void UANHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (UANGameInstance* GameInstance = Cast<UANGameInstance>(UGameplayStatics::GetGameInstance(this)))
	{
		if (UANInventorySystem* InventorySystem = GameInstance->GetInventorySystem())
		{
			Print("Got inventory system!");
			InventorySystem->OnItemAdded.AddDynamic(this, &UANHUDWidget::BP_AddItemToInventoryUI);
			InventorySystem->OnItemRemoved.AddDynamic(this, &UANHUDWidget::BP_RemoveItemFromInventoryUI);
		}
	}

	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		MainCharacter->OnPlayerBeginLongInteract.AddDynamic(this, &UANHUDWidget::BP_HideReticleUI);
		MainCharacter->OnPlayerEndLongInteract.AddDynamic(this, &UANHUDWidget::BP_ShowReticleUI);
	}
}

void UANHUDWidget::AssignDefaultSelectables(AANPlayerControllerBase* AssigningController)
{

}

bool UANHUDWidget::ShouldAssignSelectablesOnShow_Implementation() const
{
	return false;
}

void UANHUDWidget::TryGoBack_Implementation()
{
	//If we are using the standard game HUD, try to go back on the main character
	if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(GetOwningPlayerPawn()))
	{
		MainCharacter->TryGoBack();
	}
}
