// 2021 Abyssmal Games and Synodic Arc


#include "UI/HUD/ANHUDWidgetBase.h"

#include "Controller/ANPlayerControllerBase.h"

UANHUDWidgetBase::UANHUDWidgetBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bAssignSelectablesOnShow = true;
}

void UANHUDWidgetBase::ShowHUD_Implementation()
{
	SetVisibility(ESlateVisibility::Visible);
}

void UANHUDWidgetBase::HideHUD_Implementation()
{
	SetVisibility(ESlateVisibility::Collapsed);
}

void UANHUDWidgetBase::RemoveHUD_Implementation()
{
	RemoveFromParent();
}

void UANHUDWidgetBase::AssignDefaultSelectables(AANPlayerControllerBase* AssigningController)
{
	if (AssigningController != nullptr)
	{
		AssigningController->ClearSelectables();
	}
}

bool UANHUDWidgetBase::ShouldAssignSelectablesOnShow_Implementation() const
{
	return bAssignSelectablesOnShow;
}

void UANHUDWidgetBase::TryGoBack_Implementation()
{

}