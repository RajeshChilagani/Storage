// Fill out your copyright notice in the Description page of Project Settings.


#include "Audio/ANDialogueConversationTrigger.h"

#include "ANConsts.h"

#include "Audio/ANDialogueConversation.h"
#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "Component/ANDialogueManagerComponent.h"
#include "Shared/ANFunctionLibrary.h"

// Sets default values
AANDialogueConversationTrigger::AANDialogueConversationTrigger()
	: Super()
{

}

void AANDialogueConversationTrigger::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	Super::PlayTriggerEvent_Implementation(OverlappedActor);
}