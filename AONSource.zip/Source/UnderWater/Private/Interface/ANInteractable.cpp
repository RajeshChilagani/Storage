// �2021 Abyssmal Games and Synodic Arc
#include "Interface/ANInteractable.h"

#include "EngineUtils.h"
#include "Character/ANCharacterBase.h"
#include "Utils/ANPostprocessingManager.h"



void IANInteractable::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	UWorld* World = InteractingCharacter->GetWorld();
	if (World)
	{
		for (TActorIterator<AANPostProcessingManager>It(World); It; ++It)
		{
			AANPostProcessingManager* Manager = *It;
			if (Manager)
			{
				Manager->DisableFocus();
			}
		}
	}
}

void IANInteractable::EndInteract(AANCharacterBase* InteractingCharacter)
{
	UWorld* World = InteractingCharacter->GetWorld();
	if (World)
	{
		for (TActorIterator<AANPostProcessingManager>It(World); It; ++It)
		{
			AANPostProcessingManager* Manager = *It;
			if (Manager)
			{
				Manager->EnableFocus();
			}
		}
	}
}
