
#include "Interface/ANPowerable.h"

void IANPowerable::BP_PowerOn_Implementation()
{

}

void IANPowerable::BP_PowerOff_Implementation()
{

}

bool IANPowerable::BP_IsPoweredOn_Implementation()
{
	return false;
}

FText IANPowerable::BP_GetPowerableName_Implementation()
{
	return FText();
}