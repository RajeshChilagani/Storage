// 2021 Abyssmal Games and Synodic Arc

#include "ScriptedEvents/ANScriptEventActor.h"
#include "ScriptedEvents/ANScriptedEvent.h"
// Sets default values
AANScriptEventActor::AANScriptEventActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

void AANScriptEventActor::MarkCompleted()
{
	hasCompletedRole = true;
	if (parentEvent)
	{
		parentEvent->CheckCanCleanup();
	}
}

// Called when the game starts or when spawned
void AANScriptEventActor::BeginPlay()
{
	Super::BeginPlay();
	if (!toDestroyActorWhenCompleted)
	{
		hasCompletedRole = true;
	}
}

// Called every frame
void AANScriptEventActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

