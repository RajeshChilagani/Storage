// 2021 Abyssmal Games and Synodic Arc


#include "ScriptedEvents/ANScriptedEvent.h"

#include "Components/BoxComponent.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"

#include "Character/ANMainCharacter.h"
#include "ScriptedEvents/ANScriptEventActor.h"

// Sets default values
AANScriptedEvent::AANScriptedEvent()
	: Super()
{
}


// Called when the game starts or when spawned
void AANScriptedEvent::BeginPlay()
{
	//Setup parent scripted event references for each
	for (AANScriptEventActor* eventActor : eventActors)
	{
		if (eventActor)
		{
			eventActor->SetScriptedEvent(this);
		}
	}

	Super::BeginPlay();

	//If this object has already been played and is not repeatable, destroy all scripted event actors
	if (bPlayed && !bRepeatable)
	{
		for (int32 i = 0; i < eventActors.Num(); i++)
		{
			eventActors[i]->Destroy();
		}
		eventActors.Empty();
	}
}

void AANScriptedEvent::CheckCanCleanup()
{
	bool result = true;
	for (AANScriptEventActor* eventActor : eventActors)
	{
		if (eventActor)
		{
			//Make sure all actors have completed their roles before cleaning up
			result = (result && eventActor->IsCompleted());
		}
	}
	if (result)
	{
		Cleanup();
	}
}

void AANScriptedEvent::Cleanup()
{
	for (AANScriptEventActor* eventActor : eventActors)
	{
		if (eventActor)
		{
			if (eventActor->toDestroyActorWhenCompleted)
			{
				//Remove parent reference
				eventActor->SetScriptedEvent(nullptr);
				//Call induvidual actor cleanup routines
				eventActor->Cleanup();
			}
		}
	}
	//Make sure all actors are removed
	eventActors.Empty();
	//Destroy Self
	Destroy();
}

void AANScriptedEvent::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	//Notify all actors to play their roles
	for (AANScriptEventActor* eventActor : eventActors)
	{
		if (eventActor)
		{
			eventActor->Play();
		}
	}
}

void AANScriptedEvent::DestroyUnplayableTriggerOnLoad()
{
	//Cleanup and destroy all event actors if this trigger can't be played
	for (int32 i = 0; i < eventActors.Num(); i++)
	{
		eventActors[i]->Cleanup();
		eventActors[i]->Destroy();
		i--;
	}

	Destroy();
}