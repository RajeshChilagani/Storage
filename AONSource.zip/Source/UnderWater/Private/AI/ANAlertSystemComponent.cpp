// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANAlertSystemComponent.h"

// Sets default values for this component's properties
UANAlertSystemComponent::UANAlertSystemComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UANAlertSystemComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}


// Called every frame
void UANAlertSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UANAlertSystemComponent::SetMaxAlertPoints(int NewMaxAlert) {
	MaxAlertPoints = NewMaxAlert;
}
int UANAlertSystemComponent::GetMaxAlertPoints() {
	return MaxAlertPoints;
}

void UANAlertSystemComponent::SetCurrentAlertPoints(int NewAlert) {
	if (NewAlert > MaxAlertPoints) {
		CurrentAlertPoints = MaxAlertPoints;
	}
	else {
		CurrentAlertPoints = NewAlert;
	}
}

int UANAlertSystemComponent::GetCurrentAlertPoints() {
	return CurrentAlertPoints;
}

void UANAlertSystemComponent::AddAlertPoints(int Points) {
	if (CurrentAlertPoints + Points > MaxAlertPoints) {
		CurrentAlertPoints = MaxAlertPoints;
	}
	else {
		CurrentAlertPoints = CurrentAlertPoints + Points;
	}
}

void UANAlertSystemComponent::MinusAlertPoints(int Points) {
	if (CurrentAlertPoints - Points < 0) {
		CurrentAlertPoints = 0;
	}
	else {
		CurrentAlertPoints = CurrentAlertPoints - Points;
	}
}

