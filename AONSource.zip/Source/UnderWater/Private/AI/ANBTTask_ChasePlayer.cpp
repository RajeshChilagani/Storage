// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_ChasePlayer.h"
#include "AI/ANEnemyAIController.h"
#include "NavigationSystem.h"
#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"


EBTNodeResult::Type UANBTTask_ChasePlayer::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	UAIBlueprintHelperLibrary::SimpleMoveToLocation(EnemyController, EnemyController->BlackBoardComp->GetValueAsVector(EnemyController->TargetLocationKeyName));
	return EBTNodeResult::Succeeded;
}


