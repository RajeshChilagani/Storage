// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_AttackPlayer.h"
#include "AI/ANEnemyAIController.h"
#include "AI/ANEnemyCharacterBase.h"
#include "Character/ANMainCharacter.h"

#include "Kismet/GameplayStatics.h"

EBTNodeResult::Type UANBTTask_AttackPlayer::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	AANEnemyCharacterBase* EnemyCharacter = Cast<AANEnemyCharacterBase>(EnemyController->GetPawn());

	AANMainCharacter* player = Cast<AANMainCharacter>( UGameplayStatics::GetPlayerCharacter(GetWorld(), 0));

	if (EnemyController->BlackBoardComp)
	{
		float dist = EnemyCharacter->GetDistanceTo(player);
		UE_LOG(LogTemp, Warning, TEXT("Distance: %d"), dist);
		if (EnemyCharacter->GetDistanceTo(player) < 125) {
			player->ReceiveDamage(1);
			UE_LOG(LogTemp, Warning, TEXT("NPC: %s"), "is Attacking");
			
			return EBTNodeResult::Succeeded;
		}
	}

	return EBTNodeResult::Failed;
}