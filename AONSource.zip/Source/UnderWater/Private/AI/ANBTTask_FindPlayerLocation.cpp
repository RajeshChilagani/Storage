// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_FindPlayerLocation.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"
#include "NavigationSystem.h"
#include "AI/ANEnemyAIController.h"
#include "BehaviorTree/BlackboardComponent.h"


EBTNodeResult::Type UANBTTask_FindPlayerLocation::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{

	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	ACharacter* playercharacter = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);

	const FVector origin = playercharacter->GetActorLocation();
	FVector TargetLocation;
	bool success = UNavigationSystemV1::K2_GetRandomLocationInNavigableRadius(GetWorld(),origin, TargetLocation, 100.0f);

	if(EnemyController->BlackBoardComp)
	{
		EnemyController->BlackBoardComp->SetValueAsVector(EnemyController->TargetLocationKeyName, TargetLocation);
		return  EBTNodeResult::Succeeded;
	}

	
	return EBTNodeResult::Failed;
}


