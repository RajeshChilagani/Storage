// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANEnemyCharacterBase.h"

#include "Blueprint/AIBlueprintHelperLibrary.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "Projectiles/ANBaseProjectile.h"
#include "AI/ANAlertSystemComponent.h"
#include "AI/ANEnemyAIController.h"

// Sets default values
AANEnemyCharacterBase::AANEnemyCharacterBase()
{
 	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	AlertSystemComponent = CreateDefaultSubobject<UANAlertSystemComponent>(TEXT("AlertSystemComponent"));
	AlertSystemComponent->SetMaxAlertPoints(100);
	AlertSystemComponent->SetCurrentAlertPoints(0);
}

// Called when the game starts or when spawned
void AANEnemyCharacterBase::BeginPlay()
{
	Super::BeginPlay();
	//AAIController* AIC = UAIBlueprintHelperLibrary::GetAIController(this);

	//AIC->RunBehaviorTree(BehaviorTree);
}

// Called every frame
void AANEnemyCharacterBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

// Called to bind functionality to input
void AANEnemyCharacterBase::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}

void AANEnemyCharacterBase::NotifyActorBeginOverlap(AActor* i_OtherActor)
{
	AANBaseProjectile* harpoonShot = Cast<AANBaseProjectile>(i_OtherActor);
	if(harpoonShot != nullptr)
	{
		TakeEnemyDamage(1, harpoonShot);
	}
}


void AANEnemyCharacterBase::TakeEnemyDamage(int i_DamageValue, AActor* i_Instigator)
{
	health = health - i_DamageValue;
}


void AANEnemyCharacterBase::SetBotType(EAIMode NewType) {
	
	BotType = NewType;

	AANEnemyAIController* AIController = Cast<AANEnemyAIController>( GetController());

	if (AIController) {
		AIController->SetBlackBoardBotMode(NewType);
	}
}

