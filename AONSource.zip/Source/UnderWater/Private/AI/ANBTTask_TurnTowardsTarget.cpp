// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_TurnTowardsTarget.h"

EBTNodeResult::Type UANBTTask_TurnTowardsTarget::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{

	return EBTNodeResult::Failed;
}


