// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_FindRandomLocation.h"

#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "NavigationSystem.h"
#include "BehaviorTree/BlackboardComponent.h"

#include "AI/ANEnemyAIController.h"
#include "AI/ANEnemyCharacterBase.h"


EBTNodeResult::Type UANBTTask_FindRandomLocation::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	//GEngine->AddOnScreenDebugMessage(-1, 2, FColor::Red, "has Root!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	
	AANEnemyCharacterBase* playercharacter = Cast<AANEnemyCharacterBase>(EnemyController->GetPawn());

	const FVector origin = playercharacter->GetActorLocation();
	FVector TargetLocation;
	bool success = UNavigationSystemV1::K2_GetRandomLocationInNavigableRadius(GetWorld(), origin, TargetLocation, 100.0f);

	if (EnemyController->BlackBoardComp)
	{
		EnemyController->BlackBoardComp->SetValueAsVector(EnemyController->TargetLocationKeyName, TargetLocation);
		return  EBTNodeResult::Succeeded;
	}
	return EBTNodeResult::Failed;
}


