// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANLocker.h"

#include "AkAudioEvent.h"
#include "AkGameplayStatics.h"
#include "Camera/CameraComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

#include "Character/ANMainCharacter.h"
#include "Character/ANPersistentCharacter.h"

// Sets default values
AANLocker::AANLocker()
{
	PrimaryActorTick.bCanEverTick = true;

	//RootSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootSceneComponent"));

	//LockerSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("LockerSceneComponent"));
	//LockerSceneComponent->SetupAttachment(MainMeshComponent);
	
	LockerBack = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LockerBack"));
	LockerBack->SetupAttachment(MainMeshComponent);
	
	LockerFront_Right = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LockerFront_Right"));
	LockerFront_Right->SetupAttachment(MainMeshComponent);

	LockerPivotPoint_Right = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("LockerPivotPoint_Right"));
	LockerPivotPoint_Right->SetupAttachment(MainMeshComponent);

	//LockerCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("LockerCamera"));
	//LockerCamera->AttachToComponent(LockerBack, FAttachmentTransformRules::KeepRelativeTransform);

	Box = CreateDefaultSubobject<UBoxComponent>(TEXT("Box"));
	Box->SetupAttachment(LockerBack);
	Box->OnComponentBeginOverlap.AddDynamic(this, &AANLocker::OnOverlapBegin);

	Open = false;
	ReadyState = true;
	HasPlayer = false;
}

// Called when the game starts or when spawned
void AANLocker::BeginPlay()
{
	Super::BeginPlay();
	RotateValue = 1.0f;

	if(LockerCurve){
		FOnTimelineFloat TimelineCallback;
		FOnTimelineEventStatic TimelineFinishedCallback;

		TimelineCallback.BindUFunction(this, FName("ControlDoor"));
		TimelineFinishedCallback.BindUFunction(this, FName{ TEXT("SetState") });
		MyTimeline.AddInterpFloat(LockerCurve, TimelineCallback);
		MyTimeline.SetTimelineFinishedFunc(TimelineFinishedCallback);
	}
}

// Called every frame
void AANLocker::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	MyTimeline.TickTimeline(DeltaTime);
}

void AANLocker::ControlDoor() 
{
	TimelineValue = MyTimeline.GetPlaybackPosition();
	CurveFloatValue = RotateValue * LockerCurve->GetFloatValue(TimelineValue);

	FQuat NewRotation = FQuat(FRotator(0.f, -CurveFloatValue, 0.f));

	LockerPivotPoint_Right->SetRelativeRotation(NewRotation);
	LockerFront_Right->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
}

void AANLocker::SetState() 
{
	ReadyState = true;
}
bool AANLocker::IsInteracting() const
{
	return bInteracting;
}
void AANLocker::ToggleLockerFront() 
{
	if (ReadyState) {
		Open = !Open;
		LockerDoorRotation = LockerFront_Right->GetRelativeRotation();

		APawn* OurPawn = UGameplayStatics::GetPlayerPawn(this, 0);
		FVector PawnLocation = OurPawn->GetActorLocation();
		FVector Direction = GetActorLocation() - PawnLocation;
		Direction = UKismetMathLibrary::LessLess_VectorRotator(Direction, GetActorRotation());
		
		if (Open) {
			if (Direction.X > 0.0f) {
				RotateValue = -1.0f;
			}
			else {
				RotateValue = 1.0f;
			}

			ReadyState = false;
			LockerFront_Right->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			MyTimeline.PlayFromStart();
		}
		else {
			ReadyState = false;
			LockerFront_Right->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			MyTimeline.Reverse();
		}
	}
}

void AANLocker::OnOverlapBegin(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweel, const FHitResult& SweepResult) 
{
	UE_LOG(LogTemp, Warning, TEXT("%s"),*(OtherActor->GetFName().ToString()));
	AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(OtherActor);
	if (PlayerCharacter != nullptr) {
		
		APlayerController* PlayerControl = UGameplayStatics::GetPlayerController(GetWorld(),0);

		PlayerCharacter->PutInLocker(PuzzleCameraComponent);
		PlayerCharacter->SetActorHiddenInGame(true);
		ToggleLockerFront();
		HasPlayer = true;
	}

}



void AANLocker::PossessPlayer() 
{
	APlayerController* PlayerControl = UGameplayStatics::GetPlayerController(GetWorld(), 0);
	if (PlayerControl != nullptr) {
		AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(), AANMainCharacter::StaticClass()));
		if (PlayerCharacter != nullptr) {
			PlayerControl->Possess(PlayerCharacter);
			HasPlayer = false;
		}
	}
}


bool AANLocker::CanInteract() const 
{
	return !HasPlayer;
}

void AANLocker::BeginInteract(AANCharacterBase* InteractingCharacter) 
{
	if (bInteracting) {
		return;
	}
	GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Has Player True please"));
	if (AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(InteractingCharacter)) {
		
		if (AANPersistentCharacter* Baddy = Cast<AANPersistentCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(),AANPersistentCharacter::StaticClass()))) {

			if (Baddy->bCanSeePlayer == false) {
				Super::BeginInteract(InteractingCharacter);
				GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Has Player True"));

				PlayerCharacter->PutInLocker(PuzzleCameraComponent);
				DisablePlayer(InteractingCharacter);
				if (EnterLockerSFX != nullptr)
				{
					PlayerCharacter->PostAkAudioEventOnCharacter(EnterLockerSFX);
				}
				HasPlayer = true;
			}
			else {
				FailEnterLocker();
			}
		}
	}

}

bool AANLocker::CanEnter() {
	return false;
}
void AANLocker::EndInteract(AANCharacterBase* InteractingCharacter) 
{

	if (!bInteracting)
	{
		return;
	}
	if (AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(InteractingCharacter))
	{
		Super::EndInteract(InteractingCharacter);
		PlayerCharacter->RemoveFromLocker(PuzzleCameraComponent);
		EnablePlayer(InteractingCharacter);
		bInteracting = false;
		HasPlayer = false;
	}

	GEngine->AddOnScreenDebugMessage(-1, 3, FColor::White, TEXT("Has Player True"));
}

bool AANLocker::IsLongInteract() const 
{
	AANPersistentCharacter* Baddy = Cast<AANPersistentCharacter>(UGameplayStatics::GetActorOfClass(GetWorld(), AANPersistentCharacter::StaticClass()));

		
	return  !(Baddy->bCanSeePlayer);
}


void AANLocker::DisablePlayer(AANCharacterBase* InteractingCharacter) 
{
	AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(InteractingCharacter);
	PlayerCharacter->SetActorHiddenInGame(true);
	PlayerCharacter->SetActorEnableCollision(false);
}

void AANLocker::EnablePlayer(AANCharacterBase* InteractingCharacter) 
{
	AANMainCharacter* PlayerCharacter = Cast<AANMainCharacter>(InteractingCharacter);
	PlayerCharacter->SetActorHiddenInGame(false);
	PlayerCharacter->SetActorEnableCollision(true);
}

void AANLocker::FailEnterLocker_Implementation() {

}
