// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANAISpawner.h"


#include "ANDefines.h"
#include "AI/ANAISpawnPoints.h"
#include "AI/ANAISpawnTriggerBox.h"
#include "Character/ANSecondaryEnemy.h"
#include "Environment/ANWorldNavRoom.h"

// Sets default values
AANAISpawner::AANAISpawner()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AANAISpawner::BeginPlay()
{
	Super::BeginPlay();
	// I can send in the trigger id here? on begin play and when the trigger enters it can call spawn enemies?
	for (int i =0; i <SpawnGroupSettings.Num();i++)
	{
		//if (SpawnGroupSettings[i].bNeedsTriggerBox)
		//{
		//	if (SpawnGroupSettings[i].TriggerBox)
		//	{
		//	/*	SpawnGroupSettings[i].TriggerBox->SetGroupID(i);
		//		SpawnGroupSettings[i].TriggerBox->OnTriggerEnter.AddDynamic(this, &AANAISpawner::SpawnGroup);*/
		//	}
		//}
	}
}

// Called every frame
void AANAISpawner::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AANAISpawner::SpawnANewSpawnPoint()
{
	if (GetWorld() && SpawnPointBP)
	{
		FVector Loc = this->GetActorLocation();
		FRotator Rot = this->GetActorRotation();
		auto temp = Cast<AANAISpawnPoints>(GetWorld()->SpawnActor(SpawnPointBP, &Loc, &Rot));
		temp->AttachToActor(this, FAttachmentTransformRules::KeepWorldTransform);
	}
}

void AANAISpawner::SpawnTriggerBox()
{
	if (GetWorld() && TriggerBoxBP)
	{
		FVector Loc = this->GetActorLocation();
		FRotator Rot = this->GetActorRotation();
		auto temp = Cast<AANAISpawnTriggerBox>(GetWorld()->SpawnActor(TriggerBoxBP, &Loc, &Rot));
		temp->AttachToActor(this, FAttachmentTransformRules::KeepWorldTransform);
		
		
	}
}

void AANAISpawner::SpawnEnemiesInEditor()
{
	if (GroupIDToSpawnInEditor > -1 && GroupIDToSpawnInEditor < SpawnGroupSettings.Num())
	{
		FAISpawnSettings& SpawnSettings = SpawnGroupSettings[GroupIDToSpawnInEditor];

		for (int i = 0; i < SpawnSettings.EnemyCount; i++)
		{
			if (SpawnSettings.SpawnLocation)
			{
				FVector Location = SpawnSettings.SpawnLocation->GetActorLocation();
				FRotator Rot(0.0f, 0.0f, 0.0f);
				if (SpawnSettings.EnemyTypeToSpawn != nullptr)
				{
					FActorSpawnParameters SpawnParameters;
					SpawnParameters.SpawnCollisionHandlingOverride =
						ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
					auto TempEnemy = GetWorld()->SpawnActor(SpawnSettings.EnemyTypeToSpawn.Get(), &Location, &Rot,
						SpawnParameters);
					TempEnemy->AttachToActor(SpawnSettings.SpawnLocation, FAttachmentTransformRules::KeepWorldTransform);
				}
			}
		}
		/*SpawnEnemiesDelegate.BindUFunction(this, FName("SpawnEnemy"), SpawnSettings);
		GetWorld()->GetTimerManager().SetTimer(SpawnEnemiesTimerHandler, SpawnEnemiesDelegate, SpawnSettings.IntervalBetweenEnemies, true, 0.0f);*/
	}
	else
	{
		Print_Color("Check the Group ID!", FColor::Red);
	}

}

//void AANAISpawner::SpawnEnemies(const FAISpawnSettings& SpawnSettings, FVector SpawnLocation)
//{
//	if(SpawnEnemyCount < SpawnSettings.EnemyCount)
//	{
//		FVector Location = GetRandomLocationWithInTheRadius(SpawnSettings.SpawnRadius,SpawnLocation);
//		
//		FRotator Rot(0.0f,0.0f,0.0f);
//		if(SpawnSettings.EnemyTypeToSpawn!=nullptr)
//		{
//			FActorSpawnParameters SpawnParameters;
//			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
//			auto TempEnemy = GetWorld()->SpawnActor(SpawnSettings.EnemyTypeToSpawn.Get(), &Location, &Rot, SpawnParameters);
//		
//		}
//		else
//		{
//			
//		}
//		SpawnEnemyCount++;
//		
//	}
//}

void AANAISpawner::SpawnGroup(int GroupID)
{

	
	if (GroupID > -1 && GroupID < SpawnGroupSettings.Num())
	{
		FAISpawnSettings& SpawnSettings = SpawnGroupSettings[GroupID];
		
		SpawnEnemiesDelegate.BindUFunction(this, FName("SpawnEnemy"), SpawnSettings);
		if(SpawnSettings.IntervalBetweenEnemies==0.0)
		{
			SpawnSettings.IntervalBetweenEnemies = 0.1f;
		}
		GetWorld()->GetTimerManager().SetTimer(SpawnEnemiesTimerHandler, SpawnEnemiesDelegate, SpawnSettings.IntervalBetweenEnemies, true,0.0f);
	}
	else
	{
		Print_Color("Check the Group ID!", FColor::Red);
	}
	
}

void AANAISpawner::SpawnGroupWithSettings(FAISpawnSettings SpawnSettings)
{
	if (SpawnSettings.IntervalBetweenEnemies == 0.0)
	{
		SpawnSettings.IntervalBetweenEnemies = 0.1f;
	}
	
	
	SpawnEnemiesDelegate.BindUFunction(this, FName("SpawnEnemy"), SpawnSettings);
	GetWorld()->GetTimerManager().SetTimer(SpawnEnemiesTimerHandler, SpawnEnemiesDelegate, SpawnSettings.IntervalBetweenEnemies, true, 0.0f);
}

void AANAISpawner::SpawnEnemy(const FAISpawnSettings& SpawnSettings)
{
	if (SpawnEnemyCount < SpawnSettings.EnemyCount)
	{
		
		if (SpawnSettings.SpawnLocation)
		{
		FVector Location = SpawnSettings.SpawnLocation->GetActorLocation();
		FRotator Rot(0.0f, 0.0f, 0.0f);
		if (SpawnSettings.EnemyTypeToSpawn != nullptr)
		{
			FActorSpawnParameters SpawnParameters;
			SpawnParameters.SpawnCollisionHandlingOverride =
				ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
			auto TempEnemy = GetWorld()->SpawnActor(SpawnSettings.EnemyTypeToSpawn.Get(), &Location, &Rot,
				SpawnParameters);
			auto SecondaryAI = Cast<AANSecondaryEnemy>(TempEnemy);
			if (SecondaryAI)
			{
				SecondaryAI->CustomPoints = SpawnSettings.CustomPoints;
				SecondaryAI->RoomDataNav = SpawnSettings.ANNavRoom;
				SecondaryAI->MinDistanceToActivate = SpawnSettings.MinDistanceToActivate;
				
			}

		}
		else
		{
		}
		SpawnEnemyCount++;
		}
	}
	else
	{
		SpawnEnemyCount = 0;
		GetWorld()->GetTimerManager().ClearTimer(SpawnEnemiesTimerHandler);
	}
}


