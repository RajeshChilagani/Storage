// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/Services/BTS_PlayerReader.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Character/ANMainCharacter.h"
#include "Character/ANPersistentCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "AI/Helpers/NavController.h"
#include "AI/Helpers/NavUnit.h"


void UBTS_PlayerReader::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	if (!Blackboard) Blackboard = OwnerComp.GetBlackboardComponent();
	UObject* playerObject = Blackboard->GetValueAsObject(Key_PlayerActor.SelectedKeyName);
	AActor* playerActor = Cast<AActor>(playerObject);

	if (!playerActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("PlayerRef not found, refreshing!"));
		
		TArray<AActor*> actors;
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), AANMainCharacter::StaticClass(), actors);
		
		// PlayerActor
		if (actors.Num() > 0) {
			Blackboard->SetValueAsObject(Key_PlayerActor.SelectedKeyName, actors[0]);
		}

		return;
	}

	// Alertness
	UObject* selfObject = Blackboard->GetValueAsObject(FName("SelfActor"));
	AANPersistentCharacter* myCharacter = Cast<AANPersistentCharacter>(selfObject);


		Blackboard->SetValueAsFloat(Key_Alertness.SelectedKeyName, myCharacter->Alertness);


	// Persistence
	Blackboard->SetValueAsBool(Key_IsPersistent.SelectedKeyName, myCharacter->GetIsPersistent());


	Blackboard->SetValueAsFloat(Key_MaxChaseSpeed.SelectedKeyName, myCharacter->TargetChaseSpeed);
	Blackboard->SetValueAsFloat(Key_MaxTurnSpeed.SelectedKeyName, myCharacter->TargetTurnSpeed);
	Blackboard->SetValueAsBool(Key_PlayerHidingInLocker.SelectedKeyName, Cast<AANMainCharacter>(playerActor)->bHidesInLocker);

	// Current Enemy State
	Blackboard->SetValueAsEnum(Key_CurrentState.SelectedKeyName, static_cast<uint8>(myCharacter->EnemyState));

	// Current IsEngaginga
	Blackboard->SetValueAsBool(Key_IsEngaging.SelectedKeyName, myCharacter->bIsEngaging);



	////////// Player Room (Needs delayed update)
	// Refresh NavController
	if (!NavController)
	{
		AActor* controllerActor = UGameplayStatics::GetActorOfClass(GetWorld(), ANavController::StaticClass());
		if (controllerActor) NavController = Cast<ANavController>(controllerActor);
	}

	// Compare both rooms
	ARoom* playerRoom = NavController->GetContainingRoom(playerActor->GetActorLocation());
	ARoom* baddyRoom = NavController->GetContainingRoom(myCharacter->GetActorLocation());

	if (playerRoom && baddyRoom && playerRoom == baddyRoom)
	{
		Blackboard->SetValueAsFloat(Key_CurrentPlayerRoomTime.SelectedKeyName, 0);
	}
	else
	{
		const float roomTime = Blackboard->GetValueAsFloat(Key_CurrentPlayerRoomTime.SelectedKeyName);
		Blackboard->SetValueAsFloat(Key_CurrentPlayerRoomTime.SelectedKeyName, roomTime + DeltaSeconds);
	}


	// Get LastSeenLocation & bCanSeePlayer
	const bool bBBCanSeePlayer = Blackboard->GetValueAsBool(Key_CanSeePlayer.SelectedKeyName);
	const bool bCanSeePlayer = myCharacter->bCanSeePlayer;

	Blackboard->SetValueAsVector(Key_LastSeenLocation.SelectedKeyName, myCharacter->PlayerLastSeenLocation);

	
	// Vision Time
	if (bBBCanSeePlayer == bCanSeePlayer)
	{
			const float visionTime = Blackboard->GetValueAsFloat(Key_VisionTime.SelectedKeyName);
			Blackboard->SetValueAsFloat(Key_VisionTime.SelectedKeyName, visionTime + DeltaSeconds);
	}
	else
	{
		Blackboard->SetValueAsBool(Key_CanSeePlayer.SelectedKeyName, bCanSeePlayer);
		Blackboard->SetValueAsFloat(Key_VisionTime.SelectedKeyName, 0.f);
	}
		
}