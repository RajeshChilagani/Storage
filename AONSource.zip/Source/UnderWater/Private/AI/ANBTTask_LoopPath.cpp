// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_LoopPath.h"

EBTNodeResult::Type UANBTTask_LoopPath::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{

	UE_LOG(LogTemp, Warning, TEXT("doing something"));
	 return EBTNodeResult::Failed;
}


