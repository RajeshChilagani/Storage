// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTService_IsPlayerInRange.h"
#include "Character/ANMainCharacter.h"
#include "AI/ANEnemyAIController.h"
#include "AI/ANEnemyCharacterBase.h"
#include "Kismet/GameplayStatics.h"
#include "BehaviorTree/BlackboardComponent.h"

UANBTService_IsPlayerInRange::UANBTService_IsPlayerInRange()
{
	bNotifyBecomeRelevant = true;
}

void UANBTService_IsPlayerInRange::OnBecomeRelevant(UBehaviorTreeComponent& owner_comp, uint8* node_memory)
{
	Super::OnBecomeRelevant(owner_comp, node_memory);

	// get NPC
	AANEnemyAIController* const cont = Cast<AANEnemyAIController>(owner_comp.GetAIOwner());
	AANEnemyCharacterBase* const npc = Cast<AANEnemyCharacterBase>(cont->GetPawn());
	// get player character
	AANMainCharacter* player = Cast<AANMainCharacter>( UGameplayStatics::GetPlayerCharacter(GetWorld(), 0));

	if (player != NULL) {
		float const distance = FVector::Dist(npc->GetActorLocation(), player->GetActorLocation());
		//float const distance = FVector::Dist(FVector::ZeroVector, FVector(50,50,50));

		UE_LOG(LogTemp, Warning, TEXT("Distance: %d"), distance);
		UE_LOG(LogTemp, Warning, TEXT("NPC: %s"), *npc->GetActorLocation().ToString());
		UE_LOG(LogTemp, Warning, TEXT("Player: %s"), *player->GetActorLocation().ToString());


		if (distance <= melee_range) {
			cont->BlackBoardComp->SetValueAsBool(cont->PlayerInMeleeRangeKeyName, true);
		}
		else {
			cont->BlackBoardComp->SetValueAsBool(cont->PlayerInMeleeRangeKeyName, false);
		}
	}
	else {
		GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, "player Null");
	}
	
	
}

