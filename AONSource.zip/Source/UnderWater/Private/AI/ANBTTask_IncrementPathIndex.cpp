// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_IncrementPathIndex.h"

#include "Kismet/KismetMathLibrary.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BlackboardData.h"
#include "BehaviorTree/BTFunctionLibrary.h"

#include "AI/ANEnemyAIController.h"
#include "AI/ANEnemyCharacterBase.h"
#include "AI/ANPatrolPath.h"

EBTNodeResult::Type UANBTTask_IncrementPathIndex::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	AANEnemyCharacterBase* EnemyCharacter = Cast<AANEnemyCharacterBase>(EnemyController->GetCharacter());

	int CurrentIndex = OwnerComp.GetBlackboardComponent()->GetValueAsInt(BB_PathIndex.SelectedKeyName);

	if(EnemyCharacter->PatrolPath->PathPoints.Max() > CurrentIndex + 1)
	{
		EnemyController->BlackBoardComp->SetValueAsInt(BB_PathIndex.SelectedKeyName, CurrentIndex + 1);
	}else
	{
		EnemyController->BlackBoardComp->SetValueAsInt(BB_PathIndex.SelectedKeyName, 0);
	}
	
	return EBTNodeResult::Succeeded;
}


