// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANEnemyAIController.h"

#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeTypes.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Hearing.h"
#include "Perception/AISense_Damage.h"

#include "AI/EnumAIMode.h"
#include "AI/ANEnemyCharacterBase.h"


AANEnemyAIController::AANEnemyAIController()
{
	
	BehaviorTreeComp = CreateDefaultSubobject<UBehaviorTreeComponent>(TEXT("BehaviorTreeComp"));
	BlackBoardComp = CreateDefaultSubobject<UBlackboardComponent>(TEXT("BlackBoardComp"));
	
	AIPerception = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("AIPerception"));
	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));
	HearingConfig = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("HearingConfig"));

	SightConfig->SightRadius = AISightRadius;
	SightConfig->LoseSightRadius = AILooseSightRadius;
	SightConfig->PeripheralVisionAngleDegrees = AIFieldOfView;
	SightConfig->SetMaxAge(AISightAge);

	SightConfig->DetectionByAffiliation.bDetectEnemies = true;
	SightConfig->DetectionByAffiliation.bDetectFriendlies = true;
	SightConfig->DetectionByAffiliation.bDetectNeutrals = true;
	
	HearingConfig->HearingRange = AIHearingRange;
	HearingConfig->DetectionByAffiliation.bDetectEnemies = true;
	HearingConfig->DetectionByAffiliation.bDetectFriendlies = true;
	HearingConfig->DetectionByAffiliation.bDetectNeutrals = true;

	AIPerception->SetDominantSense(*SightConfig->GetSenseImplementation());
	AIPerception->OnPerceptionUpdated.AddDynamic(this, &AANEnemyAIController::OnPawnDetected);
	
	AIPerception->ConfigureSense(*SightConfig);
	AIPerception->ConfigureSense(*HearingConfig);

	CanSeePlayerKeyName = "CanSeePlayer";
	TargetLocationKeyName = "TargetLocation";
	IsInvestigatingKeyName = "IsInvestigating";
	PatrolPathIndexKeyName = "PatrolPathIndex";
	PatrolPathVectorKeyName = "PatrolPathVector";
	BotModeKeyName = "BotType";
	PlayerInMeleeRangeKeyName = "PlayerInMeleeRange";
}

void AANEnemyAIController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);
	AANEnemyCharacterBase* Enemy = Cast<AANEnemyCharacterBase>(InPawn);

	if(Enemy)
	{
		
		if(ensure(Enemy->BehaviorTree->BlackboardAsset))
		{
			//BehaviorTreeComp->
			BlackBoardComp->InitializeBlackboard(*Enemy->BehaviorTree->BlackboardAsset);
			//BlackBoardComp->SetValueAsBool(CanSeePlayerKeyName, false);
			//BlackBoardComp->SetValueAsBool(IsInvestigatingKeyName, false);
			//BlackBoardComp->SetValueAsVector(TargetLocationKeyName, FVector::ZeroVector);
			//BlackBoardComp->SetValueAsVector(PatrolPathVectorKeyName, FVector::ZeroVector);
			//BlackBoardComp->SetValueAsInt(PatrolPathIndexKeyName, 0);
		}
		
		BehaviorTreeComp->StartTree(*Enemy->BehaviorTree);
	}
}

void AANEnemyAIController::OnUnPossess()
{
	Super::OnUnPossess();

	/* Stop any behavior running as we no longer have a pawn to control */
	BehaviorTreeComp->StopTree();
}

void AANEnemyAIController::OnPawnDetected(const TArray<AActor*>& DetectedActors)
{
	GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, "I see you!");

	for (AActor* Actor : DetectedActors)
	{
		FActorPerceptionBlueprintInfo Info;
		AIPerception->GetActorsPerception(Actor, Info);
		for (FAIStimulus Stimuli : Info.LastSensedStimuli)
		{
			if(Stimuli.Type == UAISense::GetSenseID<UAISense_Sight>())
			{
				if(Stimuli.WasSuccessfullySensed())
				{
					BlackBoardComp->SetValueAsBool(CanSeePlayerKeyName, true);
					BlackBoardComp->SetValueAsEnum(BotModeKeyName,(uint8)EAIMode::Chasing);
					BlackBoardComp->SetValueAsVector(TargetLocationKeyName, Stimuli.StimulusLocation);
				}else
				{
					BlackBoardComp->SetValueAsEnum(BotModeKeyName, (uint8)EAIMode::Patrol);
					BlackBoardComp->SetValueAsBool(CanSeePlayerKeyName, false);
				}
			}else if(Stimuli.WasSuccessfullySensed() && Stimuli.Type == UAISense::GetSenseID<UAISense_Hearing>())
			{
				AANEnemyCharacterBase* Enemy = Cast<AANEnemyCharacterBase>(GetPawn());

				if (Enemy) {
						if (Stimuli.WasSuccessfullySensed())
						{
							Enemy->AlertSystemComponent->AddAlertPoints(100);
							//if (Enemy->AlertSystemComponent->GetMaxAlertPoints() == Enemy->AlertSystemComponent->GetCurrentAlertPoints()) {
								BlackBoardComp->SetValueAsBool(IsInvestigatingKeyName, true);
								BlackBoardComp->SetValueAsEnum(BotModeKeyName, (uint8)EAIMode::Searching);
								BlackBoardComp->SetValueAsVector(TargetLocationKeyName, Stimuli.StimulusLocation);
							//}
						}
						else
						{
							//Enemy->AlertSystemComponent->MinusAlertPoints(100);
							//if (Enemy->AlertSystemComponent->GetCurrentAlertPoints() == 0) {
								BlackBoardComp->SetValueAsEnum(BotModeKeyName, (uint8)EAIMode::Patrol);
								BlackBoardComp->SetValueAsBool(IsInvestigatingKeyName, false);
						//	}
						}
					
				}
			}
		}
	}
	return;
}

void AANEnemyAIController::SetBlackBoardBotMode(EAIMode NewMode) {

	if (BlackBoardComp) {
		BlackBoardComp->SetValueAsEnum(BotModeKeyName, (uint8)NewMode);
	}
}

