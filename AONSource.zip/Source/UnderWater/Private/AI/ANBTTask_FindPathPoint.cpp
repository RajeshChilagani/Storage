// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANBTTask_FindPathPoint.h"

#include "Kismet/KismetMathLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BlackboardData.h"
#include "BehaviorTree/BTFunctionLibrary.h"
#include "BehaviorTree/Blackboard/BlackboardKeyAllTypes.h"
#include "AI/ANEnemyAIController.h"
#include "AI/ANEnemyCharacterBase.h"
#include "AI/ANPatrolPath.h"

EBTNodeResult::Type UANBTTask_FindPathPoint::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AANEnemyAIController* EnemyController = Cast<AANEnemyAIController>(OwnerComp.GetOwner());
	AANEnemyCharacterBase* EnemyCharacter = Cast<AANEnemyCharacterBase>(EnemyController->GetPawn());

	

	if(EnemyController->BlackBoardComp)
	{
		int index = OwnerComp.GetBlackboardComponent()->GetValueAsInt(BB_PathIndex.SelectedKeyName);//UBTFunctionLibrary::GetBlackboardValueAsInt(this, BB_PathIndex);
		FVector NewPoint = UKismetMathLibrary::TransformLocation(EnemyCharacter->PatrolPath->GetActorTransform(), EnemyCharacter->PatrolPath->PathPoints[index]);
		UE_LOG(LogTemp, Warning, TEXT("%s"), *EnemyCharacter->PatrolPath->PathPoints[index].ToString());
		EnemyController->BlackBoardComp->SetValueAsVector(BB_PathVector.SelectedKeyName, NewPoint);
		UE_LOG(LogTemp, Warning, TEXT("%s"), *NewPoint.ToString()); //*OwnerComp.GetBlackboardComponent()->GetValueAsVector(BB_PathVector.SelectedKeyName).ToString());
		return EBTNodeResult::Succeeded;
	}
	
	return EBTNodeResult::Failed;
}
