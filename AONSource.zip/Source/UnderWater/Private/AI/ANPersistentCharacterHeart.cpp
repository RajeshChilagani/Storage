// 2021 Abyssmal Games and Synodic Arc


#include "AI/ANPersistentCharacterHeart.h"
#include "Character/ANPersistentCharacter.h"

void AANPersistentCharacterHeart::OnStunned()
{
	SetDepthStencilState(true);
	bCanInteract = true;
	BP_OnStunned();
}

void AANPersistentCharacterHeart::OnUnStunned()
{
	SetDepthStencilState(false);
	bCanInteract = false;
	BP_OnUnStunned();
}

void AANPersistentCharacterHeart::ApplyDamage(AController* IController, AActor* DamageCauser)
{
	if (OwningActor)
	{
		OwningActor->TakeDamage(DamageToApply,FDamageEvent(), IController,DamageCauser);
	}
}

bool AANPersistentCharacterHeart::CanInteract() const
{
	return bCanInteract;
}
