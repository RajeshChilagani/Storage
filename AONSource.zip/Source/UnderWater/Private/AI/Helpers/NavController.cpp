// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1


#include "AI/Helpers/NavController.h"
#include "AI/Helpers/Room.h"
#include "AI/Helpers/NavUnit.h"
#include "AI/Helpers/NavUserCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"

ANavController::ANavController()
{
	PrimaryActorTick.bCanEverTick = true;

}

void ANavController::BeginPlay()
{
	Super::BeginPlay();
	GetAllRoomReferences();
	RefreshNavRooms();
}

void ANavController::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}









////////////////////////////////////////////////////////////////////// CORE
// Stateless
ANavUnit* ANavController::GetClosestNavUnit(FVector Location)
{
	const TArray<AActor*> actorsToIgnore;
	TArray<FHitResult> outHits;
	UKismetSystemLibrary::SphereTraceMulti(GetWorld(), Location, Location, 1, TraceTypeQuery5, false, actorsToIgnore, EDrawDebugTrace::None, outHits, true);
	ANavUnit* closestNavUnit = nullptr;

	// Old => Assuming the order of TArray population is based on hit distance, but I was wrong
	/*if (outHits.Num() > 0)
	{
		ARoom* room = Cast<ARoom>(outHits[outHits.Num() - 1].GetActor());
		closestNavUnit = GetClosestNavUnitInRoom(Location, room);
	}*/

	
	// New => Force find the closest one before returning
	AActor* closestRoomActor = nullptr;
	float minDistance = FLT_MAX;
	for (const auto & hit : outHits)
	{
		const auto roomActor = hit.GetActor();
		const FVector& roomLocation = roomActor->GetActorLocation();
		const float distance = (Location - roomLocation).Size();

		if (distance < minDistance)
		{
			closestRoomActor = roomActor;
			minDistance = distance;
		}
	}

	if (!closestRoomActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("ERROR: Closest Room Actor is NULL"));
		return nullptr;
	}

	ARoom* room = Cast<ARoom>(closestRoomActor);
	closestNavUnit = GetClosestNavUnitInRoom(Location, room);
	return closestNavUnit;
}

ARoom* ANavController::GetContainingRoom(FVector Location)
{
	const TArray<AActor*> actorsToIgnore;
	TArray<FHitResult> outHits;
	UKismetSystemLibrary::SphereTraceMulti(GetWorld(), Location, Location, 1, TraceTypeQuery5, false, actorsToIgnore, EDrawDebugTrace::None, outHits, true);

	if (outHits.Num() > 0)
	{
		ARoom* room = Cast<ARoom>(outHits[outHits.Num() - 1].GetActor());
		return room;
	}

	return nullptr;
}

ANavUnit* ANavController::GetBlindClosestNavUnit(FVector Location)
{
	float minDist = FLT_MAX;
	ANavUnit* closestNavUnit = nullptr;
	for (ARoom* room : AllRooms)
	{
		for (ANavUnit* navUnit : room->ConnectingNavUnits)
		{
			const float dist = (Location - navUnit->Location).Size();
			if (dist < minDist)
			{
				closestNavUnit = navUnit;
				minDist = dist;
			}
		}
	}
	return closestNavUnit;
}
ANavUnit* ANavController::GetClosestNavUnitInRoom(FVector Location, ARoom* Room)
{
	float minDist = FLT_MAX;
	ANavUnit* closestNavUnit = nullptr;
	for (ANavUnit* navUnit : Room->ConnectingNavUnits)
	{
		const float dist = (Location - navUnit->Location).Size();
		if (dist < minDist)
		{
			closestNavUnit = navUnit;
			minDist = dist;
		}
	}
	return closestNavUnit;
}

// Path-finding
bool ANavController::FindPathToTarget(TArray<ANavUnit*>& OutNavTrace, FVector OriginLocation, FVector TargetLocation)
{
	ANavUnit* OriginNavUnit = GetClosestNavUnit(OriginLocation);
	ANavUnit* TargetNavUnit = GetClosestNavUnit(TargetLocation);
	if (!OriginNavUnit || !TargetNavUnit)
	{
		UE_LOG(LogTemp, Warning, TEXT("Room/NavTagging failed!"));
		return false;
	}

	OutNavTrace.Empty();
	OutNavTrace.Add(OriginNavUnit);

	if (!OriginNavUnit)
	{
		UE_LOG(LogTemp, Warning, TEXT("OriginNavUnit null!"));
		return false;
	}

	if (!TargetNavUnit)
	{
		UE_LOG(LogTemp, Warning, TEXT("TargetNavUnit null!"));
		return false;
	}
		
	
	ARoom* currentRoom = OriginNavUnit->Room;
	ARoom* targetRoom = TargetNavUnit->Room;
	TArray<FRoomConnection> roomsToCover;
	FindRoomTraceToTarget(roomsToCover, currentRoom, targetRoom);

	int i = 0;
	FVector localTargetLocation = OutNavTrace.Last()->Location;
	ARoom* localTargetRoom = nullptr;
	FRoomConnection nextConnection = FRoomConnection();
	FSubPath current;
	current.CurrentNavUnit = OriginNavUnit;

	while (true)
	{
		if (++i >= MaxPointDepth)
		{
			UE_LOG(LogTemp, Warning, TEXT("Max Point Depth reached!"));
			return false;
		}
		if (!current.CurrentNavUnit)
		{
			UE_LOG(LogTemp, Warning, TEXT("Broken link in the nav system!"));
			return false;
		}

		ANavUnit* peekUnit = OutNavTrace.Last();
		if (peekUnit->Location.Equals(localTargetLocation, 1))
		{
			if (nextConnection)
			{
				OutNavTrace.Push(nextConnection.ToNavUnit);
				current.LastNavUnit = nextConnection.FromNavUnit;
				current.CurrentNavUnit = nextConnection.ToNavUnit;
				current.DistanceFromLast = FLT_MAX;
				current.DistanceFromTarget = FLT_MAX;
			}
			
			if (roomsToCover.Num() == 0)
			{
				localTargetLocation = TargetLocation;
				localTargetRoom = targetRoom;
				nextConnection = FRoomConnection();
			}
			else
			{
				nextConnection = roomsToCover.Pop();
				localTargetLocation = nextConnection.FromNavUnit->Location;
				localTargetRoom = nextConnection.FromNavUnit->Room;
			}
		}

		

		bool bTracedNext = false;
		for (ANavUnit* nextUnit : current.CurrentNavUnit->ConnectingNavUnits)
		{
			if (nextUnit == current.LastNavUnit) continue;

			const float dCurrentToNext = (current.CurrentNavUnit->Location - nextUnit->Location).Size();
			const float dNextToTarget = (nextUnit->Location - localTargetLocation).Size();
			const float dCurrentToTarget = (localTargetLocation - current.CurrentNavUnit->Location).Size();

			if (nextUnit->Room == localTargetRoom && current.CurrentNavUnit->Room == localTargetRoom)
			{
				if (dCurrentToTarget < dNextToTarget) continue;

				if (dCurrentToNext + dNextToTarget < current.DistanceFromLast + current.DistanceFromTarget)
				{
					current.LastNavUnit = current.CurrentNavUnit;
					current.CurrentNavUnit = nextUnit;
					current.DistanceFromLast = dCurrentToNext;
					current.DistanceFromTarget = dNextToTarget;
					bTracedNext = true;
				}
			}
		}

		if (!bTracedNext)
		{
			if (nextConnection)
			{
				OutNavTrace.Push(nextConnection.FromNavUnit);
				continue;
			}
				
			if (current.CurrentNavUnit->Room == targetRoom)
				return true;
		}
		
		OutNavTrace.Push(current.CurrentNavUnit);
	}
}

bool ANavController::FindRoomTraceToTarget(TArray<FRoomConnection>& OutRoomTrace, ARoom* OriginRoom, ARoom* TargetRoom)
{
	if (OriginRoom == TargetRoom)
		return true;
	
	bool bTargetRoomFound = false;
	OutRoomTrace.Empty();
	
	TArray<FRoomTrace*> roomTraces;
	TQueue<FRoomTrace*> roomQ;
	ARoom* currentRoom = OriginRoom;

	// Init
	for (FRoomConnection roomConnection : currentRoom->ConnectingRooms)
	{
		FRoomTrace* newTrace = new FRoomTrace();
		newTrace->Parent = nullptr;
		newTrace->RoomConnection = roomConnection;
		
		roomTraces.Push(newTrace);
		roomQ.Enqueue(newTrace);

		currentRoom = roomConnection.OtherRoom;
		if (currentRoom == TargetRoom)
		{
			bTargetRoomFound = true;
			roomQ.Empty();
			break;
		}
	}

	// Search Loop
	int currentPointDepth = 0;
	while (!roomQ.IsEmpty() && currentPointDepth < MaxPointDepth)
	{
		FRoomTrace* nextTrace;
		roomQ.Dequeue(nextTrace);

		for (FRoomConnection connection : nextTrace->RoomConnection.OtherRoom->ConnectingRooms)
		{
			if (connection == nextTrace->RoomConnection.Inverse())
				continue;
			

			++currentPointDepth;
			FRoomTrace* newTrace = new FRoomTrace();
			newTrace->Parent = nextTrace;
			newTrace->RoomConnection = connection;

			roomTraces.Push(newTrace);
			roomQ.Enqueue(newTrace);

			currentRoom = connection.OtherRoom;
			if (currentRoom == TargetRoom)
			{
				bTargetRoomFound = true;
				roomQ.Empty();
				break;
			}
		}
	}

	// Build Trace
	if (bTargetRoomFound)
	{
		FRoomTrace* currentTrace = roomTraces.Last();
		while (currentTrace)
		{
			OutRoomTrace.Push(currentTrace->RoomConnection);
			currentTrace = currentTrace->Parent;
		}

		for (FRoomTrace* trace : roomTraces)
			delete trace;
		
		return true;
	}
	
	return false;
}
////////////////////////////////////////////////////////////////////// CORE














////////////////////////////////////////////////////////////////////// UTILITY
void ANavController::GetAllRoomReferences()
{
	TArray<AActor*> roomActors;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ARoom::StaticClass(), roomActors);

	for (AActor* roomActor : roomActors)
	{
		ARoom* room = Cast<ARoom>(roomActor);
		if (room) AllRooms.AddUnique(room);
	}
}

void ANavController::RefreshNavRooms()
{
	/*for (ARoom* room : AllRooms)
		room->RefreshConnectingNavUnits();*/

	TArray<AActor*> navUnits;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ANavUnit::StaticClass(), navUnits);
	for (AActor* actor : navUnits)
	{
		ANavUnit* unit = Cast<ANavUnit>(actor);

		TArray<AActor*> actorsToIgnore;
		TArray<FHitResult> outHits;
		const FVector unitLocation = unit->GetActorLocation();
		UKismetSystemLibrary::SphereTraceMulti(GetWorld(), unitLocation, unitLocation, 1, TraceTypeQuery5, false, actorsToIgnore, EDrawDebugTrace::None, outHits, true);

		float minDist = FLT_MAX;
		AActor* roomActor = nullptr;
		for (FHitResult hit : outHits)
		{
			AActor* hitActor = hit.GetActor();
			const float dist = (unitLocation - hitActor->GetActorLocation()).Size();		// MIGHT BE INEFFICIENT: Get containing room by distance from unit
			if (dist < minDist)
			{
				minDist = dist;
				roomActor = hit.GetActor();
			}
		}

		if (roomActor)
		{
			ARoom* room = Cast<ARoom>(roomActor);
			unit->Room = room;
			room->ConnectingNavUnits.Add(unit);
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("No NavRoom found for %s"), *unit->GetName());
		}
	}

	for (ARoom* room : AllRooms)
		room->RefreshConnectingRooms();

	

	
}
////////////////////////////////////////////////////////////////////// UTILITY