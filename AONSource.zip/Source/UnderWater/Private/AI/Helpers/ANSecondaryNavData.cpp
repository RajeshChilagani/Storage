// 2021 Abyssmal Games and Synodic Arc


#include "AI/Helpers/ANSecondaryNavData.h"

// Sets default values
AANSecondaryNavData::AANSecondaryNavData()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;
	BoxCollisionComponent = CreateDefaultSubobject<UBoxComponent>("Mesh Boundary");
	SetRootComponent(BoxCollisionComponent);

}