// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1


#include "AI/Helpers/NavUserCharacter.h"
#include "AI/Helpers/NavController.h"
#include "AI/Helpers/NavUnit.h"
#include "AI/Helpers/Room.h"
#include "Kismet/GameplayStatics.h"


ANavUserCharacter::ANavUserCharacter()
{
	PrimaryActorTick.bCanEverTick = true;
}

void ANavUserCharacter::BeginPlay()
{
	Super::BeginPlay();
}

void ANavUserCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	Tick_Debug();

	Tick_AI(DeltaTime);
}

void ANavUserCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

}











////////////////////////////////////////////////////////////////////// CORE
bool ANavUserCharacter::FindNavController()
{
	TArray<AActor*> actors;
	UGameplayStatics::GetAllActorsOfClass(GetWorld(), ANavController::StaticClass(), actors);

	if (actors.Num() > 0)
	{
		ANavController* navController = Cast<ANavController>(actors[0]);
		if (navController)
		{
			NavController = navController;
			return true;
		}
	}

	return false;
}

ANavController* ANavUserCharacter::GetNavController()
{
	if (!NavController)
	{
		UE_LOG(LogTemp, Warning, TEXT("No NavController Reference, Refreshing!"))
		const bool bSuccess = FindNavController();
		if (!bSuccess)
		{
			UE_LOG(LogTemp, Warning, TEXT("NO NavController FOUND!"));
			return nullptr;
		}
	}
	return NavController;
}
////////////////////////////////////////////////////////////////////// CORE
















////////////////////////////////////////////////////////////////////// PAWN NAV CONTROL
void ANavUserCharacter::Tick_AI(const float DeltaSeconds)
{
	if (!bIsMoving) return;
	const FVector myLocation = GetActorLocation();
	
	if (bIsTargetActor)
	{
		if (!TargetActor) return;
		
		const FVector targetActorLocation = TargetActor->GetActorLocation();
		FHitResult hit;
		GetWorld()->LineTraceSingleByChannel(hit, myLocation, targetActorLocation, ECollisionChannel::ECC_Visibility);

		if (!hit.bBlockingHit && (hit.TraceStart - hit.TraceEnd).Size() < ForceChaseRadius)
		{
			const FVector distance = targetActorLocation - myLocation;
			const FVector direction = distance.GetSafeNormal();
			CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);

			if (distance.Size() < AcceptanceRadius)
			{
				UE_LOG(LogTemp, Warning, TEXT("AI reached destination!"));
				bIsMoving = false;
				OnMoveToCompleted.Broadcast(ENavTaskStatus::Reached);
			}
		}
		else
		{
			NavController->FindPathToTarget(NavUnitsToCover, myLocation, TargetActor->GetActorLocation());
			NavTraceCleanup();

			if (NavUnitsToCover.Num() > 0)
			{
				ANavUnit* nextUnit = NavUnitsToCover[0];
				if (nextUnit == LastUnitCovered)
					NavUnitsToCover.RemoveAt(0);
				else
				{
					const FVector nextLocation = nextUnit->Location;
					const FVector distance = nextLocation - myLocation;
					const FVector direction = distance.GetSafeNormal();

					if (distance.Size() < SkipRadius)
					{
						LastUnitCovered = nextUnit;
						NavUnitsToCover.RemoveAt(0);
					}
					else
						CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);
				}
			}

			if (NavUnitsToCover.Num() == 0)
			{
				if (!TargetActor)
				{
					UE_LOG(LogTemp, Warning, TEXT("TargetActor reference null!"));
					return;
				}
				const FVector targetLocation = TargetActor->GetActorLocation();
				const FVector distance = targetLocation - myLocation;
				const FVector direction = distance.GetSafeNormal();

				CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);
				if (distance.Size() < AcceptanceRadius)
				{
					bIsMoving = false;
					OnMoveToCompleted.Broadcast(ENavTaskStatus::Reached);
				}
			}
		}
	}
	else
	{
		FHitResult hit;
		GetWorld()->LineTraceSingleByChannel(hit, myLocation, TargetLocation, ECollisionChannel::ECC_Visibility);

		if (!hit.bBlockingHit && (hit.TraceStart - hit.TraceEnd).Size() < ForceChaseRadius)
		{
			const FVector distance = TargetLocation - myLocation;
			const FVector direction = distance.GetSafeNormal();
			CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);

			if (distance.Size() < AcceptanceRadius)
			{
				UE_LOG(LogTemp, Warning, TEXT("AI reached destination!"));
				bIsMoving = false;
				OnMoveToCompleted.Broadcast(ENavTaskStatus::Reached);
			}
		}
		else
		{
			const int nNavUnitsLeft = NavUnitsToCover.Num();
			if (nNavUnitsLeft > 0)
			{
				ANavUnit* first = NavUnitsToCover[0];
				const FVector distance = first->Location - myLocation;
				const FVector direction = distance.GetSafeNormal();
				CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);

				if (distance.Size() < SkipRadius)
					NavUnitsToCover.RemoveAt(0);
			}

			if (!bIsTargetActor && nNavUnitsLeft == 0)
			{
				const FVector distance = TargetLocation - myLocation;
				const FVector direction = distance.GetSafeNormal();
				CurrentHeading = FMath::VInterpTo(CurrentHeading, direction, DeltaSeconds, TurningRate);

				if (distance.Size() < AcceptanceRadius)
				{
					UE_LOG(LogTemp, Warning, TEXT("AI reached destination!"));
					bIsMoving = false;
					OnMoveToCompleted.Broadcast(ENavTaskStatus::Reached);
				}
			}
		}
	}
	

	
	if (bCustomMovementOverride)
	{
		OnTick_AI();
	}
	else
	{
		AddMovementInput(CurrentHeading, 1);
	}
}

bool ANavUserCharacter::RefreshNavigation()
{
	if (!GetNavController()) return false;

	NavUnitsToCover.Empty();

	ANavUnit* closestNavUnit = NavController->GetClosestNavUnit(GetActorLocation());
	if (closestNavUnit)
	{
		CurrentNavUnit = closestNavUnit;
		return true;
	}

	return false;
}

bool ANavUserCharacter::MoveToLocation(FVector Location)
{
	if (!RefreshNavigation()) return false;

	const bool bSuccess = NavController->FindPathToTarget(NavUnitsToCover, GetActorLocation(), Location);
	if (!bSuccess) return false;
	
	TargetLocation = Location;
	NavTraceCleanup();
	bIsMoving = true;
	bIsTargetActor = false;
	return true;
}

bool ANavUserCharacter::MoveToActor(AActor* Actor)
{
	if (!RefreshNavigation()) return false;

	TargetActor = Actor;
	bIsMoving = true;
	bIsTargetActor = true;
	LastUnitCovered = nullptr;

	return true;
}

bool ANavUserCharacter::StopAllMovement()
{
	bIsMoving = false;
	NavUnitsToCover.Empty();
	LastUnitCovered = nullptr;
	OnMoveToCompleted.Broadcast(ENavTaskStatus::Cancelled);
	return true;
}
////////////////////////////////////////////////////////////////////// PAWN NAV CONTROL










////////////////////////////////////////////////////////////////////// UTILITY
void ANavUserCharacter::Tick_Debug()
{
	const FVector location = GetActorLocation();

	// Room & Closest Unit Tagging
	if (bShowDebugTag)
	{
		ANavController* navController = GetNavController();
		if (navController)
		{
			ANavUnit* closestNavUnit = navController->GetClosestNavUnit(location);
			if (closestNavUnit)
			{
				ARoom* room = closestNavUnit->Room;
				if (room)
				{
					UKismetSystemLibrary::DrawDebugLine(GetWorld(), location, room->Location, FColor::Turquoise, 0, DebugNavTraceThickness);
					UKismetSystemLibrary::DrawDebugLine(GetWorld(), location, closestNavUnit->Location, FColor::Orange, 0, DebugNavTraceThickness);
				}
			}
		}
	}

	// Full Navigation Trace
	if (bShowDebugNavTrace)
	{
		for (int i = 0; i < NavUnitsToCover.Num(); i++)
		{
			if (i == 0)
				UKismetSystemLibrary::DrawDebugLine(GetWorld(), NavUnitsToCover[i]->Location, location, DebugNavTraceColor, 0, DebugNavTraceThickness);
			else
				UKismetSystemLibrary::DrawDebugLine(GetWorld(), NavUnitsToCover[i]->Location, NavUnitsToCover[i - 1]->Location, DebugNavTraceColor, 0, DebugNavTraceThickness);
		}
		if (NavUnitsToCover.Num() > 0)
		{
			if (bIsTargetActor && !TargetActor)
			{
				UE_LOG(LogTemp, Warning, TEXT("TargetActor reference null!"));
				return;
			}
			const FVector targetLocation = bIsTargetActor ? TargetActor->GetActorLocation() : TargetLocation;
			UKismetSystemLibrary::DrawDebugLine(GetWorld(), NavUnitsToCover.Last()->Location, targetLocation, DebugNavTraceColor, 0, DebugNavTraceThickness);
		}
	}
}

void ANavUserCharacter::NavTraceCleanup()
{
	if (NavUnitsToCover.Num() > 1 && NavUnitsToCover[0] == NavUnitsToCover[1]) NavUnitsToCover.RemoveAt(0);

	// End Cleanup
	if (NavUnitsToCover.Num() > 1)
	{
		const FVector unitL1Location = NavUnitsToCover.Last()->Location;
		const FVector unitL2Location = NavUnitsToCover.Last(1)->Location;

		const AActor* targetActor = TargetActor;
		if (bIsTargetActor && !targetActor)
		{
			UE_LOG(LogTemp, Warning, TEXT("TargetActor reference null!"));
			return;
		}
		const FVector targetLocation = bIsTargetActor ? targetActor->GetActorLocation() : TargetLocation;
		
		const FVector vL1 = (targetLocation - unitL1Location).GetSafeNormal();
		const FVector vL12 = (unitL2Location - unitL1Location).GetSafeNormal();

		const float angle = FMath::Acos(FVector::DotProduct(vL1, vL12)) * 180 / 3.14f;

		if (angle < 90)
			NavUnitsToCover.Pop();
	}

	// Start Cleanup
	if (NavUnitsToCover.Num() > 1)
	{
		const FVector l1 = NavUnitsToCover[0]->Location;
		const FVector l2 = NavUnitsToCover[1]->Location;
		const FVector l = GetActorLocation();

		const FVector dm1 = (l1 - l).GetSafeNormal();
		const FVector d12 = (l1 - l2).GetSafeNormal();

		const float angle = FMath::Acos(FVector::DotProduct(dm1, d12)) * 180 / 3.14f;

		if (angle < 75 || (l1 - l).Size() < SkipRadius)
			NavUnitsToCover.RemoveAt(0);
	}
}

ARoom* ANavUserCharacter::GetCurrentRoom()
{
	// Check Ref
	if (!RefreshNavigation()) return nullptr;

	const FVector location = GetActorLocation();
	return NavController->GetContainingRoom(location);
}
////////////////////////////////////////////////////////////////////// UTILITY