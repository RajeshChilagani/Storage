// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1


#include "AI/Helpers/Room.h"

#include "DrawDebugHelpers.h"
#include "AI/Helpers/NavUnit.h"
#include "Components/BillboardComponent.h"
#include "Components/BoxComponent.h"


ARoom::ARoom()
{
	PrimaryActorTick.bCanEverTick = true;

	SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
	RootComponent = SceneRoot;

	RoomBox = CreateDefaultSubobject<UBoxComponent>(TEXT("RoomBox"));
	RoomBox->SetupAttachment(RootComponent);

	Billboard = CreateDefaultSubobject<UBillboardComponent>(TEXT("BillboardRoot"));
	Billboard->SetupAttachment(RootComponent);

	//RefreshConnectingRooms();
}

////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK
void ARoom::BeginPlay()
{
	Super::BeginPlay();
	Location = GetActorLocation();
}

void ARoom::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (bEnableDebug)
		ShowContainingNavUnits();
}
////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK









////////////////////////////////////////////////////////////////////// UTILITY
// Refresh
void ARoom::RefreshConnectingNavUnits()
{
	for (ANavUnit* navUnit : ConnectingNavUnits)
		navUnit->Room = this;
}

void ARoom::RefreshConnectingRooms()
{
	for (ANavUnit* unit : ConnectingNavUnits)
	{
		for (ANavUnit* outUnit : unit->ConnectingNavUnits)
		{
			ARoom* outRoom = outUnit->Room;
			if (outRoom && outRoom != this)
			{
				FRoomConnection newConnection;
				newConnection.OtherRoom = outRoom;
				newConnection.FromNavUnit = unit;
				newConnection.ToNavUnit = outUnit;
				newConnection.CurrentRoom = this;
				ConnectingRooms.Add(newConnection);
			}
		}
	}
}


// Show
void ARoom::ShowContainingNavUnits()
{
	for (ANavUnit* navUnit : ConnectingNavUnits)
	{
		const FVector otherLocation = navUnit->GetActorLocation();
		const FVector stopLocation = Location + (otherLocation - Location);
		DrawDebugLine(GetWorld(), Location, stopLocation, DebugLineColor, false, -1, 0, 2);
	}
}

bool ARoom::CheckRoomConnection(ARoom* OtherRoom) const
{
	for (const FRoomConnection & roomConnection : ConnectingRooms)
	{
		if (roomConnection.OtherRoom == OtherRoom)
			return true;
	}

	return false;
}

ANavUnit* ARoom::GetRandomNavUnit()
{
	const int len = ConnectingNavUnits.Num();
	if (len == 0)
		return nullptr;

	const int randIndex = FMath::RandRange(0, len - 1);
	return ConnectingNavUnits[randIndex];
}

ARoom* ARoom::GetRandomConnectedRoom()
{
	const int len = ConnectingRooms.Num();
	if (len == 0)
		return nullptr;

	const int randIndex = FMath::RandRange(0, len - 1);
	return ConnectingRooms[randIndex].OtherRoom;
}

TArray<ARoom*> ARoom::GetConnectingRooms(ARoom* RoomToIgnore)
{
	TArray<ARoom*> toReturn;
	for (FRoomConnection connection : ConnectingRooms)
	{
		if (connection.OtherRoom == RoomToIgnore)
			continue;

		toReturn.Add(connection.OtherRoom);
	}

	return toReturn;
}
////////////////////////////////////////////////////////////////////// UTILITY