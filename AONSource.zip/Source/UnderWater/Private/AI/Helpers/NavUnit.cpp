// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1


#include "AI/Helpers/NavUnit.h"

#include "DrawDebugHelpers.h"


////////////////////////////////////////////////////////////////////// INIT
ANavUnit::ANavUnit()
{
	PrimaryActorTick.bCanEverTick = true;
}
////////////////////////////////////////////////////////////////////// INIT









////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK
void ANavUnit::BeginPlay()
{
	Super::BeginPlay();
	Location = GetActorLocation();
	
	if (bEnableDebug)
		DebugLineColor = FColor::MakeRandomColor();
}

void ANavUnit::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bEnableDebug)
		ShowConnectedNavUnits();
}
////////////////////////////////////////////////////////////////////// BEGINPLAY & TICK













////////////////////////////////////////////////////////////////////// UTILITY
// Show
void ANavUnit::ShowConnectedNavUnits()
{
	for (ANavUnit* otherUnit : ConnectingNavUnits)
	{
		const FVector otherLocation = otherUnit->GetActorLocation();
		const FVector stopLocation = Location + (otherLocation - Location) * 0.5f;
		DrawDebugLine(GetWorld(), Location, stopLocation, DebugLineColor, false, -1, 0, DebugLineThickness);
	}
}
////////////////////////////////////////////////////////////////////// UTILITY