// 2021 Abyssmal Games and Synodic Arc

#include "AI/Helpers/ANSecondaryAINavRoom.h"
#include "Kismet/KismetMathLibrary.h"
#include "Character/ANCustomNavPathFinder.h"
#include "Components/BoxComponent.h"

#include "Environment/ANWorldNavRoom.h"
#include "Kismet/KismetSystemLibrary.h"
#include "ANDefines.h"
#include "Algo/Reverse.h"

// Sets default values
AANSecondaryAINavRoom::AANSecondaryAINavRoom()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;


	ANNavRoomBounds = CreateDefaultSubobject<UBoxComponent>("An room bounds");
	RootComponent = ANNavRoomBounds;
	ANNavRoomBounds->SetCollisionProfileName("NoCollision");
	
}



// Called when the game starts or when spawned
void AANSecondaryAINavRoom::BeginPlay()
{
	Super::BeginPlay();
	FTimerHandle TimerHandle;
	GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &AANSecondaryAINavRoom::CalculateFreePath, 0.5f);
	//CalculateFreePath();
	NavPoints.GenerateValueArray(TempArray);
}

// Called every frame
void AANSecondaryAINavRoom::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);


}

void AANSecondaryAINavRoom::ToggleGridVisibility()
{
	if (NavPoints.Num() > 0)
	{
		for (auto Element : NavPoints)
		{
			Element.Value.BoxComponent->SetVisibility(!Element.Value.BoxComponent->GetVisibleFlag());
		}
	}
}

void AANSecondaryAINavRoom::CreateGrid()
{
	if (ANNavRoomBounds)
	{
		int counter = 0;
		auto BoxExtent = ANNavRoomBounds->GetScaledBoxExtent();
		auto Origin = ANNavRoomBounds->GetComponentToWorld().GetLocation() - BoxExtent;
		NavRegionBeginLocation = Origin;
		float MaxX = floor(BoxExtent.X / GridSize.X);
		float MaxY = floor(BoxExtent.Y / GridSize.Y);
		float MaxZ = floor(BoxExtent.Z / GridSize.Z);
		for (int z = 0; z < MaxZ; z++)
		{
			for (int y = 0; y < MaxY; y++)
			{
				for (int x = 0; x < MaxX; x++)
				{
					{

						FVector Location;
						Location.X = Origin.X + (2 * (GridSize.X * x));
						Location.Y = Origin.Y + (2 * (GridSize.Y * y));
						Location.Z = Origin.Z + (2 * (GridSize.Z * z));
						CreateBoxCollision(Location, FVector(x, y, z));
						counter++;
					}
				}
			}
		}
	}
	else
	{
	}
}

void AANSecondaryAINavRoom::DeleteGrid()
{
	if (NavPoints.Num() > 0)
	{

		for (auto Element : NavPoints)
		{
			Element.Value.BoxComponent->DestroyComponent();
		}

	}
	NavPoints.Empty();
}

float AANSecondaryAINavRoom::GetArea(float x, float y, float z)
{
	return  ((2 * x * y) + (2 * x * z) + (2 * z * y));
}

bool AANSecondaryAINavRoom::IsBoxFree(UBoxComponent* box)
{
	auto index = GetNavPointIndexFromLocation(box->GetComponentLocation());
	return  NavPoints[index].bIsFree;
}

TArray<FVector> AANSecondaryAINavRoom::GenerateBFSPath(FVector StartPoint, FVector EndPoint, bool UseThread)
{
	/*if (UseThread)
	{
		Print("Using Threads");
		if (!CurrentRunningThread)
		{
			ThreadPathFinder = new AANCustomNavPathFinder(StartPoint, EndPoint, NavPoints,GridSize, NavRegionBeginLocation);
			CurrentRunningThread = FRunnableThread::Create(ThreadPathFinder, TEXT("Path finding thread"));
			return TArray<FVector>();
		}
		else
		{

			if (CurrentRunningThread && ThreadPathFinder && ThreadPathFinder->IsPathFindingComplete())
			{
				TArray<FVector> Path = ThreadPathFinder->GetPath();
				CurrentRunningThread->Suspend(true);
				ThreadPathFinder->Stop();
				CurrentRunningThread->Suspend(false);
				CurrentRunningThread->Kill(false);
				CurrentRunningThread->WaitForCompletion();
				delete ThreadPathFinder;
				CurrentRunningThread = nullptr;
				return Path;
			}

			return TArray<FVector>();

		}
	}*/
	
	{
		//Print("Not Using Threads");
		if (NavPoints.Num() > 0)
		{

			StartPoint = GetNavPointIndexFromLocation(StartPoint);
			EndPoint = GetNavPointIndexFromLocation(EndPoint);
			/*if (IsPointValid(StartPoint))
			{
				Print_1("StartPoint, %s", *StartPoint.ToString());
			}
			if (!IsPointValid(EndPoint))
			{
				Print("EndPoint is Invalid");
			}*/
			if (IsPointValid(StartPoint) && IsPointValid(EndPoint))
			{
				NavPoints[StartPoint].bIsFree = true;
			}
			else
			{
				TArray<FVector> EmptyPath;
				//Print("failed here check starting point!!! or ending point");
				return EmptyPath;
			}
			TSet<FVector> ExploredPoint;
			TArray<FVector> Path = { StartPoint };
			TArray<TArray<FVector>> Queue = { Path };

			while (Queue.Num() > 0)
			{

				Path = Queue[0];
				Queue.RemoveAt(0);
				FVector LastPoint = Path.Last(0);
				if (LastPoint == EndPoint)
				{
					//Print_1("Print Failing 4 %d", Path.Num());
					return Path;
				}
				//Get all faces
				else if (!ExploredPoint.Contains(LastPoint) && IsPointValid(LastPoint) && NavPoints[LastPoint].bIsFree)
				{

					//TODO Compute diagonals
					FVector Diagonal_one = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z);
					FVector Diagonal_two = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z);
					FVector Diagonal_three = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z);
					FVector Diagonal_four = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z);

					FVector Diagonal_five = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z + 1);
					FVector Diagonal_six = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z - 1);
					FVector Diagonal_seven = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z - 1);
					FVector Diagonal_eight = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z + 1);

					FVector Diagonal_nine = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z + 1);
					FVector Diagonal_one_one = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z - 1);
					FVector Diagonal_one_two = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z - 1);
					FVector Diagonal_one_three = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z + 1);

					FVector Diagonal_one_four = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z + 1);
					FVector Diagonal_one_seven = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z - 1);
					FVector Diagonal_one_five = FVector(LastPoint.X + 1, LastPoint.Y + 1, LastPoint.Z - 1);
					FVector Diagonal_one_one_one = FVector(LastPoint.X - 1, LastPoint.Y - 1, LastPoint.Z + 1);
					FVector Diagonal_one_six = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z - 1);
					FVector Diagonal_one_one_two = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z + 1);
					FVector Diagonal_one_nine = FVector(LastPoint.X - 1, LastPoint.Y + 1, LastPoint.Z - 1);
					FVector Diagonal_one_eight = FVector(LastPoint.X + 1, LastPoint.Y - 1, LastPoint.Z + 1);



					FVector Left = FVector(LastPoint.X - 1, LastPoint.Y, LastPoint.Z);
					FVector Right = FVector(LastPoint.X + 1, LastPoint.Y, LastPoint.Z);
					FVector Top = FVector(LastPoint.X, LastPoint.Y, LastPoint.Z + 1);
					FVector Bottom = FVector(LastPoint.X, LastPoint.Y, LastPoint.Z - 1);
					FVector Forward = FVector(LastPoint.X, LastPoint.Y + 1, LastPoint.Z);
					FVector Backward = FVector(LastPoint.X, LastPoint.Y - 1, LastPoint.Z);


					TArray<FVector> AdjList = { Left, Right, Top,Bottom, Forward,Backward };

					AdjList.Add(Diagonal_one);
					AdjList.Add(Diagonal_two);
					AdjList.Add(Diagonal_three);
					AdjList.Add(Diagonal_four);
					AdjList.Add(Diagonal_five);
					AdjList.Add(Diagonal_six);
					AdjList.Add(Diagonal_seven);
					AdjList.Add(Diagonal_eight);
					AdjList.Add(Diagonal_nine);
					AdjList.Add(Diagonal_one_one);
					AdjList.Add(Diagonal_one_two);
					AdjList.Add(Diagonal_one_three);
					AdjList.Add(Diagonal_one_four);
					AdjList.Add(Diagonal_one_five);
					AdjList.Add(Diagonal_one_six);
					AdjList.Add(Diagonal_one_seven);
					AdjList.Add(Diagonal_one_one_two);
					AdjList.Add(Diagonal_one_eight);
					AdjList.Add(Diagonal_one_nine);
					AdjList.Add(Diagonal_one_one_one);






					for (int i = 0; i < AdjList.Num(); i++)
					{
						if (!ExploredPoint.Contains(AdjList[i]))
						{
							TArray<FVector> NewPath = { Path };
							NewPath.Add(AdjList[i]);
							Queue.Add(NewPath);

						}
					}
					ExploredPoint.Add(LastPoint);
				}

			}
			//Failed
			Path.Empty();
			//Print("Failing 1");
			return Path;
		}
		//Print("Failing 2");
		TArray<FVector> EmptyPath;
		return EmptyPath;
	}

}


TArray<FVector> AANSecondaryAINavRoom::GenerateAStarPath(FVector StartPoint, FVector Endpoint)
{
	//first check if the navpoint has some points in them


	if (!CurrentRunningThread)
	{
		ThreadPathFinder = new AANCustomNavPathFinder(StartPoint, Endpoint, NavPoints, GridSize, NavRegionBeginLocation);
		CurrentRunningThread = FRunnableThread::Create(ThreadPathFinder, TEXT("Path finding thread"));
		return TArray<FVector>();
	}
	else
	{

		if (CurrentRunningThread && ThreadPathFinder && ThreadPathFinder->IsPathFindingComplete())
		{
			TArray<FVector> Path = ThreadPathFinder->GetPath();
			CurrentRunningThread->Suspend(true);
			ThreadPathFinder->StopThread();
			CurrentRunningThread->Suspend(false);
			CurrentRunningThread->Kill(false);
			CurrentRunningThread->WaitForCompletion();
			delete ThreadPathFinder;
			CurrentRunningThread = nullptr;
			return Path;
		}

		///Failed to find a path here.
		return TArray<FVector>();
	}

}
FVector AANSecondaryAINavRoom::GetNavPointIndexFromLocation(FVector Location)
{
	
		if (NavPoints.Num() > 0)
		{
			const FVector NavPointExtents = FVector(GridSize);
			const FVector Distance = Location - (NavRegionBeginLocation);

			FVector comLoc = NavPoints[FVector(0, 0, 0)].BoxComponent->GetComponentToWorld().GetLocation();

			const int IndexX = Distance.X / (NavPointExtents.X * 2);
			const int IndexY = Distance.Y / (NavPointExtents.Y * 2);
			const int IndexZ = Distance.Z / (NavPointExtents.Z * 2);

			return FVector(IndexX, IndexY, IndexZ);
		}
	return FVector(-1, -1, -1);

}

FVector AANSecondaryAINavRoom::FindRandomPoint()
{
	if (TempArray.Num() > 0)
	{
		const FNavMeshData& RandomNavMeshData = TempArray[FMath::RandRange(0, TempArray.Num() - 1)];
		if (RandomNavMeshData.BoxComponent != nullptr)
		{
			return RandomNavMeshData.BoxComponent->GetComponentLocation();
		}
	}

	Print("missing nav points in the room or Temp Array had an issue");
	return FVector(-1, -1, -1);
}

bool AANSecondaryAINavRoom::IsPointValid(FVector Point)
{
	return NavPoints.Contains(Point);
}

bool AANSecondaryAINavRoom::IsLocationValid(FVector Location)
{
	auto index = GetNavPointIndexFromLocation(Location);
	return IsPointValid(index);
}

bool AANSecondaryAINavRoom::IsLocationFree(FVector Location)
{
	auto Valid = GetNavPointIndexFromLocation(Location);
	if (IsPointValid(Valid))
	{

		return NavPoints[Valid].bIsFree;
	}
	return false;
}

void AANSecondaryAINavRoom::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (CurrentRunningThread && ThreadPathFinder)
	{

		CurrentRunningThread->Suspend(true);
		ThreadPathFinder->Stop();
		CurrentRunningThread->Suspend(false);
		CurrentRunningThread->Kill(false);
		CurrentRunningThread->WaitForCompletion();
		delete ThreadPathFinder;
	}
}

void AANSecondaryAINavRoom::OnBoxOverlapBegin(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	const auto Index = GetNavPointIndexFromLocation(OverlappedComp->GetComponentLocation());
	TArray<AActor*> Actors;
	NavPoints[Index].BoxComponent->GetOverlappingActors(Actors);
	if (Actors.Num() > 0)
	{
		NavPoints[Index].bIsFree = false;
	}
	else
		NavPoints[Index].bIsFree = true;
}

void AANSecondaryAINavRoom::OnBoxOverlapEnd(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	auto Index = GetNavPointIndexFromLocation(OverlappedComp->GetComponentLocation());

}

void AANSecondaryAINavRoom::CreateBoxCollision(FVector Location, FVector ID)
{
	UBoxComponent* temp = NewObject<UBoxComponent>(this, UBoxComponent::StaticClass());
	temp->SetWorldLocation(Location);
	temp->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
	temp->RegisterComponentWithWorld(GetWorld());
	temp->SetVisibility(false);
	temp->SetBoxExtent(FVector(GridSize));
	temp->SetGenerateOverlapEvents(true);
	/*temp->OnComponentBeginOverlap.AddDynamic(this, &AANSecondaryAINavRoom::OnBoxOverlapBegin);
	temp->OnComponentEndOverlap.AddDynamic(this, &AANSecondaryAINavRoom::OnBoxOverlapEnd);*/
	temp->SetCollisionProfileName("3DNavPoint");
	FNavMeshData data(temp, false);

	NavPoints.Add(ID, data);
}
void AANSecondaryAINavRoom::CalculateFreePath()
{
	if (NavPoints.Num() > 0)
	{
		for (auto& It : NavPoints)
		{
			bool isFree;
			TArray<AActor*> Actors;
			It.Value.BoxComponent->GetOverlappingActors(Actors);
			if (Actors.Num() > 0)
			{
				/*for (auto actor : Actors)
				{
					Print_1("Actor? %s", *actor->GetName());
				}*/
				It.Value.bIsFree = false;
				
			}
			else
			{
				It.Value.bIsFree = true;
				isFree = true;

			}

			TArray<FVector> PossibleNeighborlist;
			PossibleNeighborlist.Reserve(26);



			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y + 1, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y - 1, It.Key.Z));
			
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y + 1, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y + 1, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y - 1, It.Key.Z));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y - 1, It.Key.Z));
																					  
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y + 1, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y + 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y - 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X, It.Key.Y - 1, It.Key.Z + 1));
																					  
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y, It.Key.Z + 1));

			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y + 1, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y - 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y + 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y - 1, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y - 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y + 1, It.Key.Z + 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X - 1, It.Key.Y + 1, It.Key.Z - 1));
			PossibleNeighborlist.Emplace(FVector(It.Key.X + 1, It.Key.Y - 1, It.Key.Z + 1));


			

			for (auto Element : PossibleNeighborlist)
			{
				if(IsPointValid(Element))
				{
					
					It.Value.NeighborsList.Emplace(Element);

					if(!isFree)
					{
						NavPoints[Element].cost = 5;
					}
					else
					{
						NavPoints[Element].cost = 2;
					}
				}
			}


			
			


			
		}
	}

	
}

