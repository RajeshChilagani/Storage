// Fill out your copyright notice in the Description page of Project Settings.


#include "AI/ANAISpawnTriggerBox.h"

#include "AI/ANAISpawner.h"
#include "Character/ANSecondaryEnemy.h"

AANAISpawnTriggerBox::AANAISpawnTriggerBox()
{
	//GetCollisionComponent()->OnComponentBeginOverlap.AddDynamic(this,&AANAISpawnTriggerBox::OnOverlapBegin);
}

void AANAISpawnTriggerBox::BeginPlay()
{
	Super::BeginPlay();
}

void AANAISpawnTriggerBox::PlayTriggerEvent_Implementation(AActor* OverlappedActor)
{
	SpawnEnemies();
}

void AANAISpawnTriggerBox::SpawnEnemies()
{
	UWorld* MyWorld = GetWorld();
	if (MyWorld == nullptr)
	{
		return;
	}

	while (SpawnEnemyCount < SpawnSettings.EnemyCount)
	{
		if (SpawnSettings.SpawnLocation)
		{
			FVector Location = SpawnSettings.SpawnLocation->GetActorLocation();
			FRotator Rot(0.0f, 0.0f, 0.0f);
			if (SpawnSettings.EnemyTypeToSpawn != nullptr)
			{
				FActorSpawnParameters SpawnParameters;
				SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;
				FTransform SpawnTransform;
				SpawnTransform.SetLocation(Location);
				SpawnTransform.SetRotation(Rot.Quaternion());
				AANSecondaryEnemy* SecondaryAI = MyWorld->SpawnActorDeferred<AANSecondaryEnemy>(SpawnSettings.EnemyTypeToSpawn.Get(), SpawnTransform, nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn);
				if (SecondaryAI != nullptr)
				{
					SecondaryAI->AssignSpawnData(SpawnSettings);
					SecondaryAI->SetSpawnSourceGuid(GetSaveableGuid());
				}
				SecondaryAI->FinishSpawning(SpawnTransform);

			}
			SpawnEnemyCount++;
		}
	}
	
	SpawnEnemyCount = 0;
}


