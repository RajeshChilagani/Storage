// 2021 Abyssmal Games and Synodic Arc


#include "AI/Tasks/BTT_TeleportEnemy.h"
#include "AIController.h"
#include "AI/Helpers/NavController.h"
#include "AI/Helpers/NavUnit.h"
#include "AI/Helpers/Room.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Character/ANMainCharacter.h"
#include "Character/ANPersistentCharacter.h"
#include "Kismet/GameplayStatics.h"


EBTNodeResult::Type UBTT_TeleportEnemy::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* blackboard = OwnerComp.GetBlackboardComponent();
	
	// Controller Reference Check
	AAIController* controller = OwnerComp.GetAIOwner();
	if (!controller)
	{
		UE_LOG(LogTemp, Warning, TEXT("Couldn't find AIController!"));
		return EBTNodeResult::Failed;
	}

	AANPersistentCharacter* enemy = Cast<AANPersistentCharacter>(controller->GetCharacter());
	if (!enemy)
	{
		UE_LOG(LogTemp, Warning, TEXT("Couldn't find PersistentCharacter!"));
		return EBTNodeResult::Failed;
	}


	// Get Enemy's Current Room
	ARoom* enemyRoom = enemy->GetCurrentRoom();


	// Get Player's Current Room
	UObject* playerObject = blackboard->GetValueAsObject(Key_PlayerActor.SelectedKeyName);
	AActor* playerActor = Cast<AActor>(playerObject);

	if (!playerActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("PlayerRef not found, refreshing!"));

		TArray<AActor*> actors;
		UGameplayStatics::GetAllActorsOfClass(GetWorld(), AANMainCharacter::StaticClass(), actors);

		if (actors.Num() > 0)
			blackboard->SetValueAsObject(Key_PlayerActor.SelectedKeyName, actors[0]);

		return EBTNodeResult::Failed;
	}



	AActor* controllerActor = UGameplayStatics::GetActorOfClass(GetWorld(), ANavController::StaticClass());
	if (!controllerActor)
	{
		UE_LOG(LogTemp, Warning, TEXT("NavController not found! BTT_TeleportEnemy"));
		return EBTNodeResult::Failed;
	}

	ANavController* navController = Cast<ANavController>(controllerActor);
	ARoom* playerRoom = navController->GetContainingRoom(playerActor->GetActorLocation());



	// Failed if both are untagged in Navigation
	if (!playerRoom && !enemyRoom)
		return EBTNodeResult::Failed;

	if (playerRoom)
	{
		const bool isPlayerInAdjacentRoom = playerRoom->CheckRoomConnection(enemyRoom);
		if (playerRoom != enemyRoom && !isPlayerInAdjacentRoom)
		{
			ARoom* adjacentRoom = playerRoom->GetRandomConnectedRoom();
			TArray<ARoom*> nonAdjacentRooms = adjacentRoom->GetConnectingRooms(playerRoom);

			const int len = nonAdjacentRooms.Num();
			if (len == 0)
				return EBTNodeResult::Failed;

			const int randIndex = FMath::RandRange(0, len - 1);
			ARoom* nonAdjacentRoom = nonAdjacentRooms[randIndex];

			// Teleport
			ANavUnit* spawnNavUnit = nonAdjacentRoom->GetRandomNavUnit();
			const bool bSuccess = enemy->TeleportTo(spawnNavUnit->GetActorLocation(), FRotator());

			if (bSuccess)
			{
				blackboard->SetValueAsFloat(Key_CurrentPlayerRoomTime.SelectedKeyName, PostTeleportResetTime);
				return EBTNodeResult::Succeeded;
			}

			return EBTNodeResult::Failed;
		}
		else
		{
			UE_LOG(LogTemp, Warning, TEXT("Already in a close-by room!"));
			blackboard->SetValueAsFloat(Key_CurrentPlayerRoomTime.SelectedKeyName, 0.f);
			return EBTNodeResult::Failed;
		}
	}
	

	UE_LOG(LogTemp, Warning, TEXT("Couldn't NavTag player"));
	return EBTNodeResult::Succeeded;
}
