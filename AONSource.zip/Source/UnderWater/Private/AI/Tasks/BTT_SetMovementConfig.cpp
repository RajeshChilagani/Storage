// Created by Vishal Naidu (Davian One): GitHub => http://github.com/Vieper1

#include "AI/Tasks/BTT_SetMovementConfig.h"

#include "AIController.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Character/ANPersistentCharacter.h"

EBTNodeResult::Type UBTT_SetMovementConfig::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* controller = OwnerComp.GetAIOwner();
	if (!controller)
	{
		UE_LOG(LogTemp, Warning, TEXT("Couldn't find AIController!"));
		return EBTNodeResult::Failed;
	}

	AANPersistentCharacter* character = Cast<AANPersistentCharacter>(controller->GetCharacter());
	if (!character)
	{
		UE_LOG(LogTemp, Warning, TEXT("Couldn't find PersistentCharacter!"));
		return EBTNodeResult::Failed;
	}


	
	// Movement Speed & Turning Rate
	UCharacterMovementComponent* movementComp = character->GetCharacterMovement();
	movementComp->MaxSwimSpeed = MaxSpeed;
	character->TurningRate = TurningRate;

	if (character->GetIsPersistent())
	{
		if (UBlackboardComponent* Blackboard = OwnerComp.GetBlackboardComponent())
		{
			movementComp->MaxSwimSpeed = Blackboard->GetValueAsFloat(Key_MaxChaseSpeed.SelectedKeyName);
			character->TurningRate = Blackboard->GetValueAsFloat(Key_MaxTurnSpeed.SelectedKeyName);
		}
	}

	
	// Anim Head LookAt
	character->bShouldLookAtPlayer = bShouldLookAtPlayer;

	
	// Face Player
	character->bShouldFacePlayer = bShouldFacePlayer;
	movementComp->bOrientRotationToMovement = !bShouldFacePlayer;



	
	return EBTNodeResult::Succeeded;
}
