// 2021 Abyssmal Games and Synodic Arc


#include "Inventory/ANKeyCardItem.h"
#include "Systems/ANInventorySystem.h"
#include "POD/ANKeycardAccessData.h"

void AANKeyCardItem::AddItemToInventory(UANInventorySystem* IS)
{
	if (!IS)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to add item to inventory. Inventory not found"));
		return;
	}

	FANItem* ItemData = IS->GetItemDataFromTable(ItemName);
	if (!ItemData)
	{
		UE_LOG(LogTemp, Error, TEXT("Failed to add item to inventory. Invalid ItemName"));
		return;
	}

	KeyType ItemKeyCardValue = static_cast<KeyType>(ItemData->IntegerValue);
	TArray<FString> KeyCards;
	FString SearchString = "KeyCardLevel";
	IS->SearchInventory(SearchString, KeyCards);
	if (KeyCards.Num() == 0)
	{
		IS->AddItem(ItemName, 1, EAddItemMethods::PickUp);
		OnItemPickedUp.Broadcast(this);
		return;
	}

	for (auto& KeyCard : KeyCards)
	{
		if (FANItem* Item = IS->GetItemDataFromTable(KeyCard))
		{
			KeyType KeyCardValue = static_cast<KeyType>(Item->IntegerValue);
			if (ItemKeyCardValue > KeyCardValue)
			{
				IS->RemoveItem(KeyCard,1);
				IS->AddItem(ItemName, 1, EAddItemMethods::PickUp);
				OnItemPickedUp.Broadcast(this);
				return;
			}
			
		}
		else
		{
			UE_LOG(LogTemp, Error, TEXT("Failed to add item to inventory. Invalid ItemName"));
			return;
		}
	}

}