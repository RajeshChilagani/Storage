// Fill out your copyright notice in the Description page of Project Settings.


#include "Interact/ANInspectable.h"
#include "Camera/CameraComponent.h"
#include "Components/SceneComponent.h"
#include "Components/SpotLightComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/WidgetComponent.h"
#include "Components/WidgetComponent.h"
#include "UObject/ConstructorHelpers.h"

#include "Character/ANMainCharacter.h"
#include "Controller/ANPlayerControllerBase.h"
#include "UI/HUD/ANHUDWidgetBase.h"

static float DefaultFOV = 90.f;
AANInspectable::AANInspectable()
	:Super()
	,MeshRotationSpeed(10.f)
	,ZoomSpeed(5.f)
	,MinFOVClamp(15.f)
	,MaxFOVClamp(90.f)
	,bInteracting(false)
	,LongInteractingCharacter(nullptr)
{
	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = SceneComponent;

	CameraComponent = CreateDefaultSubobject<UCameraComponent>(TEXT("PuzzleCameraCom"));
	CameraComponent->SetupAttachment(RootComponent);

	SpotLightComponent = CreateDefaultSubobject<USpotLightComponent>(TEXT("SpotLightComponent"));
	SpotLightComponent->SetRelativeLocation(FVector(-200.0f, 0.0f, 0.0f));
	SpotLightComponent->SetRelativeRotation(FRotator(-30.0f, 0.0f, 0.0f));
	SpotLightComponent->SetVisibility(false);
	SpotLightComponent->SetIntensity(10.0f);
	SpotLightComponent->SetLightColor(FLinearColor(1.0f, 0.79f, 0.52f, 1.0f)); //Tan-yellow
	SpotLightComponent->SetAttenuationRadius(1500.0f);
	SpotLightComponent->SetInnerConeAngle(20.0f);
	SpotLightComponent->SetOuterConeAngle(47.0f);
	SpotLightComponent->SetVolumetricScatteringIntensity(1.0f);
	SpotLightComponent->bUseInverseSquaredFalloff = false;
	SpotLightComponent->SetAffectTranslucentLighting(false);
	SpotLightComponent->SetCastRaytracedShadow(false);
	SpotLightComponent->SetAffectReflection(false);
	SpotLightComponent->SetAffectGlobalIllumination(false);
	SpotLightComponent->SetupAttachment(RootComponent);

	MainMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
	MainMeshComponent->SetupAttachment(RootComponent);
	// Custom depth pass for focus ability
	MainMeshComponent->bRenderCustomDepth = true;
	MainMeshComponent->CustomDepthStencilWriteMask = ERendererStencilMask::ERSM_Default;
	MainMeshComponent->CustomDepthStencilValue = static_cast<int32>(EFocusOutlineColor::AquaBlue);

	bWasInventoryOpen = false;
}

void AANInspectable::Inspect(float AxisValue, EInspectAction InspectAction)
{
	if (bInteracting)
	{
		if (InspectAction == EInspectAction::Zoom)
		{
			float FOV = -AxisValue * ZoomSpeed;
			const float& CurrentFOV = CameraComponent->FieldOfView;
			float NewFOV = FMath::Clamp<float>(CurrentFOV + FOV,MinFOVClamp,MaxFOVClamp);
			CameraComponent->SetFieldOfView(NewFOV);			
		}
		else
		{
			float NewRoationValue = AxisValue * MeshRotationSpeed;
			FRotator Rotation;
			switch (InspectAction)
			{
			case EInspectAction::Horizontal:
				Rotation.Yaw = -NewRoationValue;
				break;
			case EInspectAction::Vertical:
				Rotation.Pitch = NewRoationValue;
				break;
			}
			MainMeshComponent->AddRelativeRotation(Rotation.Quaternion());
#if WITH_EDITOR
			const auto& CR = MainMeshComponent->GetRelativeRotation();
			UE_LOG(LogTemp, Log, TEXT("(%f,%f,%f)"), CR.Yaw, CR.Pitch, CR.Roll);
#endif
		}
	}
}

bool AANInspectable::CanInteract() const
{
	return !bInteracting;
}

void AANInspectable::BeginInteract(AANCharacterBase* InteractingCharacter)
{
	if (!bInteracting)
	{
		IANInteractable::BeginInteract(InteractingCharacter);
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
		{
			MainCharacter->SetViewTargetWithBlend(this);
			MainCharacter->SetGameInput(EGameInputTypes::GameAndUI);
			MainCharacter->SetActorHiddenInGame(true);
			bInteracting = true;
			LongInteractingCharacter = MainCharacter;
			SpotLightComponent->SetVisibility(true);
			if (bInventoryItem)
			{
				//If we had the inventory open, keep this in mind for when we exit this
				if (MainCharacter->bInventoryOpen)
				{
					bWasInventoryOpen = true;
				}

				if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
				{
					BP_AddInspectableHUD(PlayerControllerBase);
				}
			}
		}
	}
}

void AANInspectable::EndInteract(AANCharacterBase* InteractingCharacter)
{
	if (bInteracting)
	{
		IANInteractable::EndInteract(InteractingCharacter);
		if (AANMainCharacter* MainCharacter = Cast<AANMainCharacter>(InteractingCharacter))
		{
			CameraComponent->SetFieldOfView(DefaultFOV);
			MainCharacter->SetViewTargetWithBlend(MainCharacter);
			MainCharacter->SetActorHiddenInGame(false); //Unhide the character

			LongInteractingCharacter = nullptr;
			SpotLightComponent->SetVisibility(false);
			bInteracting = false;
			MainCharacter->TryEndInteract();

			//Need input after try end interact since that will automatically go back to game only input
			if (bWasInventoryOpen)
			{
				MainCharacter->SetGameInput(EGameInputTypes::UIOnly); //Assume UI only since we are going back to the inventory
			}
			else
			{
				MainCharacter->SetGameInput(EGameInputTypes::GameOnly); //Assume game only since we didn't have the inventory open
			}

			if (bInventoryItem)
			{
				if (AANPlayerControllerBase* PlayerControllerBase = Cast<AANPlayerControllerBase>(InteractingCharacter->GetController()))
				{
					BP_RemoveInspectableHUD(PlayerControllerBase);
				}
			}
			Destroy();
		}
	}
}

bool AANInspectable::IsLongInteract() const
{
	return true;
}

bool AANInspectable::IsInteracting() const
{
	return bInteracting;
}

